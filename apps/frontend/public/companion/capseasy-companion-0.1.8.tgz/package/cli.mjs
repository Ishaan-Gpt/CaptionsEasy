#!/usr/bin/env node
import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/error.js
var require_error = __commonJS({
  "../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/error.js"(exports) {
    var CommanderError2 = class extends Error {
      /**
       * Constructs the CommanderError class
       * @param {number} exitCode suggested exit code which could be used with process.exit
       * @param {string} code an id string representing the error
       * @param {string} message human-readable description of the error
       */
      constructor(exitCode, code, message) {
        super(message);
        Error.captureStackTrace(this, this.constructor);
        this.name = this.constructor.name;
        this.code = code;
        this.exitCode = exitCode;
        this.nestedError = void 0;
      }
    };
    var InvalidArgumentError2 = class extends CommanderError2 {
      /**
       * Constructs the InvalidArgumentError class
       * @param {string} [message] explanation of why argument is invalid
       */
      constructor(message) {
        super(1, "commander.invalidArgument", message);
        Error.captureStackTrace(this, this.constructor);
        this.name = this.constructor.name;
      }
    };
    exports.CommanderError = CommanderError2;
    exports.InvalidArgumentError = InvalidArgumentError2;
  }
});

// ../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/argument.js
var require_argument = __commonJS({
  "../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/argument.js"(exports) {
    var { InvalidArgumentError: InvalidArgumentError2 } = require_error();
    var Argument2 = class {
      /**
       * Initialize a new command argument with the given name and description.
       * The default is that the argument is required, and you can explicitly
       * indicate this with <> around the name. Put [] around the name for an optional argument.
       *
       * @param {string} name
       * @param {string} [description]
       */
      constructor(name, description) {
        this.description = description || "";
        this.variadic = false;
        this.parseArg = void 0;
        this.defaultValue = void 0;
        this.defaultValueDescription = void 0;
        this.argChoices = void 0;
        switch (name[0]) {
          case "<":
            this.required = true;
            this._name = name.slice(1, -1);
            break;
          case "[":
            this.required = false;
            this._name = name.slice(1, -1);
            break;
          default:
            this.required = true;
            this._name = name;
            break;
        }
        if (this._name.length > 3 && this._name.slice(-3) === "...") {
          this.variadic = true;
          this._name = this._name.slice(0, -3);
        }
      }
      /**
       * Return argument name.
       *
       * @return {string}
       */
      name() {
        return this._name;
      }
      /**
       * @package
       */
      _concatValue(value, previous) {
        if (previous === this.defaultValue || !Array.isArray(previous)) {
          return [value];
        }
        return previous.concat(value);
      }
      /**
       * Set the default value, and optionally supply the description to be displayed in the help.
       *
       * @param {*} value
       * @param {string} [description]
       * @return {Argument}
       */
      default(value, description) {
        this.defaultValue = value;
        this.defaultValueDescription = description;
        return this;
      }
      /**
       * Set the custom handler for processing CLI command arguments into argument values.
       *
       * @param {Function} [fn]
       * @return {Argument}
       */
      argParser(fn) {
        this.parseArg = fn;
        return this;
      }
      /**
       * Only allow argument value to be one of choices.
       *
       * @param {string[]} values
       * @return {Argument}
       */
      choices(values) {
        this.argChoices = values.slice();
        this.parseArg = (arg, previous) => {
          if (!this.argChoices.includes(arg)) {
            throw new InvalidArgumentError2(
              `Allowed choices are ${this.argChoices.join(", ")}.`
            );
          }
          if (this.variadic) {
            return this._concatValue(arg, previous);
          }
          return arg;
        };
        return this;
      }
      /**
       * Make argument required.
       *
       * @returns {Argument}
       */
      argRequired() {
        this.required = true;
        return this;
      }
      /**
       * Make argument optional.
       *
       * @returns {Argument}
       */
      argOptional() {
        this.required = false;
        return this;
      }
    };
    function humanReadableArgName(arg) {
      const nameOutput = arg.name() + (arg.variadic === true ? "..." : "");
      return arg.required ? "<" + nameOutput + ">" : "[" + nameOutput + "]";
    }
    exports.Argument = Argument2;
    exports.humanReadableArgName = humanReadableArgName;
  }
});

// ../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/help.js
var require_help = __commonJS({
  "../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/help.js"(exports) {
    var { humanReadableArgName } = require_argument();
    var Help2 = class {
      constructor() {
        this.helpWidth = void 0;
        this.sortSubcommands = false;
        this.sortOptions = false;
        this.showGlobalOptions = false;
      }
      /**
       * Get an array of the visible subcommands. Includes a placeholder for the implicit help command, if there is one.
       *
       * @param {Command} cmd
       * @returns {Command[]}
       */
      visibleCommands(cmd) {
        const visibleCommands = cmd.commands.filter((cmd2) => !cmd2._hidden);
        const helpCommand = cmd._getHelpCommand();
        if (helpCommand && !helpCommand._hidden) {
          visibleCommands.push(helpCommand);
        }
        if (this.sortSubcommands) {
          visibleCommands.sort((a, b) => {
            return a.name().localeCompare(b.name());
          });
        }
        return visibleCommands;
      }
      /**
       * Compare options for sort.
       *
       * @param {Option} a
       * @param {Option} b
       * @returns {number}
       */
      compareOptions(a, b) {
        const getSortKey = (option) => {
          return option.short ? option.short.replace(/^-/, "") : option.long.replace(/^--/, "");
        };
        return getSortKey(a).localeCompare(getSortKey(b));
      }
      /**
       * Get an array of the visible options. Includes a placeholder for the implicit help option, if there is one.
       *
       * @param {Command} cmd
       * @returns {Option[]}
       */
      visibleOptions(cmd) {
        const visibleOptions = cmd.options.filter((option) => !option.hidden);
        const helpOption = cmd._getHelpOption();
        if (helpOption && !helpOption.hidden) {
          const removeShort = helpOption.short && cmd._findOption(helpOption.short);
          const removeLong = helpOption.long && cmd._findOption(helpOption.long);
          if (!removeShort && !removeLong) {
            visibleOptions.push(helpOption);
          } else if (helpOption.long && !removeLong) {
            visibleOptions.push(
              cmd.createOption(helpOption.long, helpOption.description)
            );
          } else if (helpOption.short && !removeShort) {
            visibleOptions.push(
              cmd.createOption(helpOption.short, helpOption.description)
            );
          }
        }
        if (this.sortOptions) {
          visibleOptions.sort(this.compareOptions);
        }
        return visibleOptions;
      }
      /**
       * Get an array of the visible global options. (Not including help.)
       *
       * @param {Command} cmd
       * @returns {Option[]}
       */
      visibleGlobalOptions(cmd) {
        if (!this.showGlobalOptions) return [];
        const globalOptions = [];
        for (let ancestorCmd = cmd.parent; ancestorCmd; ancestorCmd = ancestorCmd.parent) {
          const visibleOptions = ancestorCmd.options.filter(
            (option) => !option.hidden
          );
          globalOptions.push(...visibleOptions);
        }
        if (this.sortOptions) {
          globalOptions.sort(this.compareOptions);
        }
        return globalOptions;
      }
      /**
       * Get an array of the arguments if any have a description.
       *
       * @param {Command} cmd
       * @returns {Argument[]}
       */
      visibleArguments(cmd) {
        if (cmd._argsDescription) {
          cmd.registeredArguments.forEach((argument) => {
            argument.description = argument.description || cmd._argsDescription[argument.name()] || "";
          });
        }
        if (cmd.registeredArguments.find((argument) => argument.description)) {
          return cmd.registeredArguments;
        }
        return [];
      }
      /**
       * Get the command term to show in the list of subcommands.
       *
       * @param {Command} cmd
       * @returns {string}
       */
      subcommandTerm(cmd) {
        const args = cmd.registeredArguments.map((arg) => humanReadableArgName(arg)).join(" ");
        return cmd._name + (cmd._aliases[0] ? "|" + cmd._aliases[0] : "") + (cmd.options.length ? " [options]" : "") + // simplistic check for non-help option
        (args ? " " + args : "");
      }
      /**
       * Get the option term to show in the list of options.
       *
       * @param {Option} option
       * @returns {string}
       */
      optionTerm(option) {
        return option.flags;
      }
      /**
       * Get the argument term to show in the list of arguments.
       *
       * @param {Argument} argument
       * @returns {string}
       */
      argumentTerm(argument) {
        return argument.name();
      }
      /**
       * Get the longest command term length.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {number}
       */
      longestSubcommandTermLength(cmd, helper) {
        return helper.visibleCommands(cmd).reduce((max, command) => {
          return Math.max(max, helper.subcommandTerm(command).length);
        }, 0);
      }
      /**
       * Get the longest option term length.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {number}
       */
      longestOptionTermLength(cmd, helper) {
        return helper.visibleOptions(cmd).reduce((max, option) => {
          return Math.max(max, helper.optionTerm(option).length);
        }, 0);
      }
      /**
       * Get the longest global option term length.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {number}
       */
      longestGlobalOptionTermLength(cmd, helper) {
        return helper.visibleGlobalOptions(cmd).reduce((max, option) => {
          return Math.max(max, helper.optionTerm(option).length);
        }, 0);
      }
      /**
       * Get the longest argument term length.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {number}
       */
      longestArgumentTermLength(cmd, helper) {
        return helper.visibleArguments(cmd).reduce((max, argument) => {
          return Math.max(max, helper.argumentTerm(argument).length);
        }, 0);
      }
      /**
       * Get the command usage to be displayed at the top of the built-in help.
       *
       * @param {Command} cmd
       * @returns {string}
       */
      commandUsage(cmd) {
        let cmdName = cmd._name;
        if (cmd._aliases[0]) {
          cmdName = cmdName + "|" + cmd._aliases[0];
        }
        let ancestorCmdNames = "";
        for (let ancestorCmd = cmd.parent; ancestorCmd; ancestorCmd = ancestorCmd.parent) {
          ancestorCmdNames = ancestorCmd.name() + " " + ancestorCmdNames;
        }
        return ancestorCmdNames + cmdName + " " + cmd.usage();
      }
      /**
       * Get the description for the command.
       *
       * @param {Command} cmd
       * @returns {string}
       */
      commandDescription(cmd) {
        return cmd.description();
      }
      /**
       * Get the subcommand summary to show in the list of subcommands.
       * (Fallback to description for backwards compatibility.)
       *
       * @param {Command} cmd
       * @returns {string}
       */
      subcommandDescription(cmd) {
        return cmd.summary() || cmd.description();
      }
      /**
       * Get the option description to show in the list of options.
       *
       * @param {Option} option
       * @return {string}
       */
      optionDescription(option) {
        const extraInfo = [];
        if (option.argChoices) {
          extraInfo.push(
            // use stringify to match the display of the default value
            `choices: ${option.argChoices.map((choice) => JSON.stringify(choice)).join(", ")}`
          );
        }
        if (option.defaultValue !== void 0) {
          const showDefault = option.required || option.optional || option.isBoolean() && typeof option.defaultValue === "boolean";
          if (showDefault) {
            extraInfo.push(
              `default: ${option.defaultValueDescription || JSON.stringify(option.defaultValue)}`
            );
          }
        }
        if (option.presetArg !== void 0 && option.optional) {
          extraInfo.push(`preset: ${JSON.stringify(option.presetArg)}`);
        }
        if (option.envVar !== void 0) {
          extraInfo.push(`env: ${option.envVar}`);
        }
        if (extraInfo.length > 0) {
          return `${option.description} (${extraInfo.join(", ")})`;
        }
        return option.description;
      }
      /**
       * Get the argument description to show in the list of arguments.
       *
       * @param {Argument} argument
       * @return {string}
       */
      argumentDescription(argument) {
        const extraInfo = [];
        if (argument.argChoices) {
          extraInfo.push(
            // use stringify to match the display of the default value
            `choices: ${argument.argChoices.map((choice) => JSON.stringify(choice)).join(", ")}`
          );
        }
        if (argument.defaultValue !== void 0) {
          extraInfo.push(
            `default: ${argument.defaultValueDescription || JSON.stringify(argument.defaultValue)}`
          );
        }
        if (extraInfo.length > 0) {
          const extraDescripton = `(${extraInfo.join(", ")})`;
          if (argument.description) {
            return `${argument.description} ${extraDescripton}`;
          }
          return extraDescripton;
        }
        return argument.description;
      }
      /**
       * Generate the built-in help text.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {string}
       */
      formatHelp(cmd, helper) {
        const termWidth = helper.padWidth(cmd, helper);
        const helpWidth = helper.helpWidth || 80;
        const itemIndentWidth = 2;
        const itemSeparatorWidth = 2;
        function formatItem(term, description) {
          if (description) {
            const fullText = `${term.padEnd(termWidth + itemSeparatorWidth)}${description}`;
            return helper.wrap(
              fullText,
              helpWidth - itemIndentWidth,
              termWidth + itemSeparatorWidth
            );
          }
          return term;
        }
        function formatList(textArray) {
          return textArray.join("\n").replace(/^/gm, " ".repeat(itemIndentWidth));
        }
        let output = [`Usage: ${helper.commandUsage(cmd)}`, ""];
        const commandDescription = helper.commandDescription(cmd);
        if (commandDescription.length > 0) {
          output = output.concat([
            helper.wrap(commandDescription, helpWidth, 0),
            ""
          ]);
        }
        const argumentList = helper.visibleArguments(cmd).map((argument) => {
          return formatItem(
            helper.argumentTerm(argument),
            helper.argumentDescription(argument)
          );
        });
        if (argumentList.length > 0) {
          output = output.concat(["Arguments:", formatList(argumentList), ""]);
        }
        const optionList = helper.visibleOptions(cmd).map((option) => {
          return formatItem(
            helper.optionTerm(option),
            helper.optionDescription(option)
          );
        });
        if (optionList.length > 0) {
          output = output.concat(["Options:", formatList(optionList), ""]);
        }
        if (this.showGlobalOptions) {
          const globalOptionList = helper.visibleGlobalOptions(cmd).map((option) => {
            return formatItem(
              helper.optionTerm(option),
              helper.optionDescription(option)
            );
          });
          if (globalOptionList.length > 0) {
            output = output.concat([
              "Global Options:",
              formatList(globalOptionList),
              ""
            ]);
          }
        }
        const commandList = helper.visibleCommands(cmd).map((cmd2) => {
          return formatItem(
            helper.subcommandTerm(cmd2),
            helper.subcommandDescription(cmd2)
          );
        });
        if (commandList.length > 0) {
          output = output.concat(["Commands:", formatList(commandList), ""]);
        }
        return output.join("\n");
      }
      /**
       * Calculate the pad width from the maximum term length.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {number}
       */
      padWidth(cmd, helper) {
        return Math.max(
          helper.longestOptionTermLength(cmd, helper),
          helper.longestGlobalOptionTermLength(cmd, helper),
          helper.longestSubcommandTermLength(cmd, helper),
          helper.longestArgumentTermLength(cmd, helper)
        );
      }
      /**
       * Wrap the given string to width characters per line, with lines after the first indented.
       * Do not wrap if insufficient room for wrapping (minColumnWidth), or string is manually formatted.
       *
       * @param {string} str
       * @param {number} width
       * @param {number} indent
       * @param {number} [minColumnWidth=40]
       * @return {string}
       *
       */
      wrap(str, width, indent, minColumnWidth = 40) {
        const indents = " \\f\\t\\v\xA0\u1680\u2000-\u200A\u202F\u205F\u3000\uFEFF";
        const manualIndent = new RegExp(`[\\n][${indents}]+`);
        if (str.match(manualIndent)) return str;
        const columnWidth = width - indent;
        if (columnWidth < minColumnWidth) return str;
        const leadingStr = str.slice(0, indent);
        const columnText = str.slice(indent).replace("\r\n", "\n");
        const indentString = " ".repeat(indent);
        const zeroWidthSpace = "\u200B";
        const breaks = `\\s${zeroWidthSpace}`;
        const regex = new RegExp(
          `
|.{1,${columnWidth - 1}}([${breaks}]|$)|[^${breaks}]+?([${breaks}]|$)`,
          "g"
        );
        const lines = columnText.match(regex) || [];
        return leadingStr + lines.map((line2, i) => {
          if (line2 === "\n") return "";
          return (i > 0 ? indentString : "") + line2.trimEnd();
        }).join("\n");
      }
    };
    exports.Help = Help2;
  }
});

// ../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/option.js
var require_option = __commonJS({
  "../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/option.js"(exports) {
    var { InvalidArgumentError: InvalidArgumentError2 } = require_error();
    var Option2 = class {
      /**
       * Initialize a new `Option` with the given `flags` and `description`.
       *
       * @param {string} flags
       * @param {string} [description]
       */
      constructor(flags, description) {
        this.flags = flags;
        this.description = description || "";
        this.required = flags.includes("<");
        this.optional = flags.includes("[");
        this.variadic = /\w\.\.\.[>\]]$/.test(flags);
        this.mandatory = false;
        const optionFlags = splitOptionFlags(flags);
        this.short = optionFlags.shortFlag;
        this.long = optionFlags.longFlag;
        this.negate = false;
        if (this.long) {
          this.negate = this.long.startsWith("--no-");
        }
        this.defaultValue = void 0;
        this.defaultValueDescription = void 0;
        this.presetArg = void 0;
        this.envVar = void 0;
        this.parseArg = void 0;
        this.hidden = false;
        this.argChoices = void 0;
        this.conflictsWith = [];
        this.implied = void 0;
      }
      /**
       * Set the default value, and optionally supply the description to be displayed in the help.
       *
       * @param {*} value
       * @param {string} [description]
       * @return {Option}
       */
      default(value, description) {
        this.defaultValue = value;
        this.defaultValueDescription = description;
        return this;
      }
      /**
       * Preset to use when option used without option-argument, especially optional but also boolean and negated.
       * The custom processing (parseArg) is called.
       *
       * @example
       * new Option('--color').default('GREYSCALE').preset('RGB');
       * new Option('--donate [amount]').preset('20').argParser(parseFloat);
       *
       * @param {*} arg
       * @return {Option}
       */
      preset(arg) {
        this.presetArg = arg;
        return this;
      }
      /**
       * Add option name(s) that conflict with this option.
       * An error will be displayed if conflicting options are found during parsing.
       *
       * @example
       * new Option('--rgb').conflicts('cmyk');
       * new Option('--js').conflicts(['ts', 'jsx']);
       *
       * @param {(string | string[])} names
       * @return {Option}
       */
      conflicts(names) {
        this.conflictsWith = this.conflictsWith.concat(names);
        return this;
      }
      /**
       * Specify implied option values for when this option is set and the implied options are not.
       *
       * The custom processing (parseArg) is not called on the implied values.
       *
       * @example
       * program
       *   .addOption(new Option('--log', 'write logging information to file'))
       *   .addOption(new Option('--trace', 'log extra details').implies({ log: 'trace.txt' }));
       *
       * @param {object} impliedOptionValues
       * @return {Option}
       */
      implies(impliedOptionValues) {
        let newImplied = impliedOptionValues;
        if (typeof impliedOptionValues === "string") {
          newImplied = { [impliedOptionValues]: true };
        }
        this.implied = Object.assign(this.implied || {}, newImplied);
        return this;
      }
      /**
       * Set environment variable to check for option value.
       *
       * An environment variable is only used if when processed the current option value is
       * undefined, or the source of the current value is 'default' or 'config' or 'env'.
       *
       * @param {string} name
       * @return {Option}
       */
      env(name) {
        this.envVar = name;
        return this;
      }
      /**
       * Set the custom handler for processing CLI option arguments into option values.
       *
       * @param {Function} [fn]
       * @return {Option}
       */
      argParser(fn) {
        this.parseArg = fn;
        return this;
      }
      /**
       * Whether the option is mandatory and must have a value after parsing.
       *
       * @param {boolean} [mandatory=true]
       * @return {Option}
       */
      makeOptionMandatory(mandatory = true) {
        this.mandatory = !!mandatory;
        return this;
      }
      /**
       * Hide option in help.
       *
       * @param {boolean} [hide=true]
       * @return {Option}
       */
      hideHelp(hide = true) {
        this.hidden = !!hide;
        return this;
      }
      /**
       * @package
       */
      _concatValue(value, previous) {
        if (previous === this.defaultValue || !Array.isArray(previous)) {
          return [value];
        }
        return previous.concat(value);
      }
      /**
       * Only allow option value to be one of choices.
       *
       * @param {string[]} values
       * @return {Option}
       */
      choices(values) {
        this.argChoices = values.slice();
        this.parseArg = (arg, previous) => {
          if (!this.argChoices.includes(arg)) {
            throw new InvalidArgumentError2(
              `Allowed choices are ${this.argChoices.join(", ")}.`
            );
          }
          if (this.variadic) {
            return this._concatValue(arg, previous);
          }
          return arg;
        };
        return this;
      }
      /**
       * Return option name.
       *
       * @return {string}
       */
      name() {
        if (this.long) {
          return this.long.replace(/^--/, "");
        }
        return this.short.replace(/^-/, "");
      }
      /**
       * Return option name, in a camelcase format that can be used
       * as a object attribute key.
       *
       * @return {string}
       */
      attributeName() {
        return camelcase(this.name().replace(/^no-/, ""));
      }
      /**
       * Check if `arg` matches the short or long flag.
       *
       * @param {string} arg
       * @return {boolean}
       * @package
       */
      is(arg) {
        return this.short === arg || this.long === arg;
      }
      /**
       * Return whether a boolean option.
       *
       * Options are one of boolean, negated, required argument, or optional argument.
       *
       * @return {boolean}
       * @package
       */
      isBoolean() {
        return !this.required && !this.optional && !this.negate;
      }
    };
    var DualOptions = class {
      /**
       * @param {Option[]} options
       */
      constructor(options) {
        this.positiveOptions = /* @__PURE__ */ new Map();
        this.negativeOptions = /* @__PURE__ */ new Map();
        this.dualOptions = /* @__PURE__ */ new Set();
        options.forEach((option) => {
          if (option.negate) {
            this.negativeOptions.set(option.attributeName(), option);
          } else {
            this.positiveOptions.set(option.attributeName(), option);
          }
        });
        this.negativeOptions.forEach((value, key) => {
          if (this.positiveOptions.has(key)) {
            this.dualOptions.add(key);
          }
        });
      }
      /**
       * Did the value come from the option, and not from possible matching dual option?
       *
       * @param {*} value
       * @param {Option} option
       * @returns {boolean}
       */
      valueFromOption(value, option) {
        const optionKey = option.attributeName();
        if (!this.dualOptions.has(optionKey)) return true;
        const preset = this.negativeOptions.get(optionKey).presetArg;
        const negativeValue = preset !== void 0 ? preset : false;
        return option.negate === (negativeValue === value);
      }
    };
    function camelcase(str) {
      return str.split("-").reduce((str2, word) => {
        return str2 + word[0].toUpperCase() + word.slice(1);
      });
    }
    function splitOptionFlags(flags) {
      let shortFlag;
      let longFlag;
      const flagParts = flags.split(/[ |,]+/);
      if (flagParts.length > 1 && !/^[[<]/.test(flagParts[1]))
        shortFlag = flagParts.shift();
      longFlag = flagParts.shift();
      if (!shortFlag && /^-[^-]$/.test(longFlag)) {
        shortFlag = longFlag;
        longFlag = void 0;
      }
      return { shortFlag, longFlag };
    }
    exports.Option = Option2;
    exports.DualOptions = DualOptions;
  }
});

// ../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/suggestSimilar.js
var require_suggestSimilar = __commonJS({
  "../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/suggestSimilar.js"(exports) {
    var maxDistance = 3;
    function editDistance(a, b) {
      if (Math.abs(a.length - b.length) > maxDistance)
        return Math.max(a.length, b.length);
      const d = [];
      for (let i = 0; i <= a.length; i++) {
        d[i] = [i];
      }
      for (let j = 0; j <= b.length; j++) {
        d[0][j] = j;
      }
      for (let j = 1; j <= b.length; j++) {
        for (let i = 1; i <= a.length; i++) {
          let cost = 1;
          if (a[i - 1] === b[j - 1]) {
            cost = 0;
          } else {
            cost = 1;
          }
          d[i][j] = Math.min(
            d[i - 1][j] + 1,
            // deletion
            d[i][j - 1] + 1,
            // insertion
            d[i - 1][j - 1] + cost
            // substitution
          );
          if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
            d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
          }
        }
      }
      return d[a.length][b.length];
    }
    function suggestSimilar(word, candidates) {
      if (!candidates || candidates.length === 0) return "";
      candidates = Array.from(new Set(candidates));
      const searchingOptions = word.startsWith("--");
      if (searchingOptions) {
        word = word.slice(2);
        candidates = candidates.map((candidate) => candidate.slice(2));
      }
      let similar = [];
      let bestDistance = maxDistance;
      const minSimilarity = 0.4;
      candidates.forEach((candidate) => {
        if (candidate.length <= 1) return;
        const distance = editDistance(word, candidate);
        const length = Math.max(word.length, candidate.length);
        const similarity = (length - distance) / length;
        if (similarity > minSimilarity) {
          if (distance < bestDistance) {
            bestDistance = distance;
            similar = [candidate];
          } else if (distance === bestDistance) {
            similar.push(candidate);
          }
        }
      });
      similar.sort((a, b) => a.localeCompare(b));
      if (searchingOptions) {
        similar = similar.map((candidate) => `--${candidate}`);
      }
      if (similar.length > 1) {
        return `
(Did you mean one of ${similar.join(", ")}?)`;
      }
      if (similar.length === 1) {
        return `
(Did you mean ${similar[0]}?)`;
      }
      return "";
    }
    exports.suggestSimilar = suggestSimilar;
  }
});

// ../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/command.js
var require_command = __commonJS({
  "../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/lib/command.js"(exports) {
    var EventEmitter = __require("node:events").EventEmitter;
    var childProcess = __require("node:child_process");
    var path2 = __require("node:path");
    var fs = __require("node:fs");
    var process3 = __require("node:process");
    var { Argument: Argument2, humanReadableArgName } = require_argument();
    var { CommanderError: CommanderError2 } = require_error();
    var { Help: Help2 } = require_help();
    var { Option: Option2, DualOptions } = require_option();
    var { suggestSimilar } = require_suggestSimilar();
    var Command2 = class _Command extends EventEmitter {
      /**
       * Initialize a new `Command`.
       *
       * @param {string} [name]
       */
      constructor(name) {
        super();
        this.commands = [];
        this.options = [];
        this.parent = null;
        this._allowUnknownOption = false;
        this._allowExcessArguments = true;
        this.registeredArguments = [];
        this._args = this.registeredArguments;
        this.args = [];
        this.rawArgs = [];
        this.processedArgs = [];
        this._scriptPath = null;
        this._name = name || "";
        this._optionValues = {};
        this._optionValueSources = {};
        this._storeOptionsAsProperties = false;
        this._actionHandler = null;
        this._executableHandler = false;
        this._executableFile = null;
        this._executableDir = null;
        this._defaultCommandName = null;
        this._exitCallback = null;
        this._aliases = [];
        this._combineFlagAndOptionalValue = true;
        this._description = "";
        this._summary = "";
        this._argsDescription = void 0;
        this._enablePositionalOptions = false;
        this._passThroughOptions = false;
        this._lifeCycleHooks = {};
        this._showHelpAfterError = false;
        this._showSuggestionAfterError = true;
        this._outputConfiguration = {
          writeOut: (str) => process3.stdout.write(str),
          writeErr: (str) => process3.stderr.write(str),
          getOutHelpWidth: () => process3.stdout.isTTY ? process3.stdout.columns : void 0,
          getErrHelpWidth: () => process3.stderr.isTTY ? process3.stderr.columns : void 0,
          outputError: (str, write2) => write2(str)
        };
        this._hidden = false;
        this._helpOption = void 0;
        this._addImplicitHelpCommand = void 0;
        this._helpCommand = void 0;
        this._helpConfiguration = {};
      }
      /**
       * Copy settings that are useful to have in common across root command and subcommands.
       *
       * (Used internally when adding a command using `.command()` so subcommands inherit parent settings.)
       *
       * @param {Command} sourceCommand
       * @return {Command} `this` command for chaining
       */
      copyInheritedSettings(sourceCommand) {
        this._outputConfiguration = sourceCommand._outputConfiguration;
        this._helpOption = sourceCommand._helpOption;
        this._helpCommand = sourceCommand._helpCommand;
        this._helpConfiguration = sourceCommand._helpConfiguration;
        this._exitCallback = sourceCommand._exitCallback;
        this._storeOptionsAsProperties = sourceCommand._storeOptionsAsProperties;
        this._combineFlagAndOptionalValue = sourceCommand._combineFlagAndOptionalValue;
        this._allowExcessArguments = sourceCommand._allowExcessArguments;
        this._enablePositionalOptions = sourceCommand._enablePositionalOptions;
        this._showHelpAfterError = sourceCommand._showHelpAfterError;
        this._showSuggestionAfterError = sourceCommand._showSuggestionAfterError;
        return this;
      }
      /**
       * @returns {Command[]}
       * @private
       */
      _getCommandAndAncestors() {
        const result = [];
        for (let command = this; command; command = command.parent) {
          result.push(command);
        }
        return result;
      }
      /**
       * Define a command.
       *
       * There are two styles of command: pay attention to where to put the description.
       *
       * @example
       * // Command implemented using action handler (description is supplied separately to `.command`)
       * program
       *   .command('clone <source> [destination]')
       *   .description('clone a repository into a newly created directory')
       *   .action((source, destination) => {
       *     console.log('clone command called');
       *   });
       *
       * // Command implemented using separate executable file (description is second parameter to `.command`)
       * program
       *   .command('start <service>', 'start named service')
       *   .command('stop [service]', 'stop named service, or all if no name supplied');
       *
       * @param {string} nameAndArgs - command name and arguments, args are `<required>` or `[optional]` and last may also be `variadic...`
       * @param {(object | string)} [actionOptsOrExecDesc] - configuration options (for action), or description (for executable)
       * @param {object} [execOpts] - configuration options (for executable)
       * @return {Command} returns new command for action handler, or `this` for executable command
       */
      command(nameAndArgs, actionOptsOrExecDesc, execOpts) {
        let desc = actionOptsOrExecDesc;
        let opts = execOpts;
        if (typeof desc === "object" && desc !== null) {
          opts = desc;
          desc = null;
        }
        opts = opts || {};
        const [, name, args] = nameAndArgs.match(/([^ ]+) *(.*)/);
        const cmd = this.createCommand(name);
        if (desc) {
          cmd.description(desc);
          cmd._executableHandler = true;
        }
        if (opts.isDefault) this._defaultCommandName = cmd._name;
        cmd._hidden = !!(opts.noHelp || opts.hidden);
        cmd._executableFile = opts.executableFile || null;
        if (args) cmd.arguments(args);
        this._registerCommand(cmd);
        cmd.parent = this;
        cmd.copyInheritedSettings(this);
        if (desc) return this;
        return cmd;
      }
      /**
       * Factory routine to create a new unattached command.
       *
       * See .command() for creating an attached subcommand, which uses this routine to
       * create the command. You can override createCommand to customise subcommands.
       *
       * @param {string} [name]
       * @return {Command} new command
       */
      createCommand(name) {
        return new _Command(name);
      }
      /**
       * You can customise the help with a subclass of Help by overriding createHelp,
       * or by overriding Help properties using configureHelp().
       *
       * @return {Help}
       */
      createHelp() {
        return Object.assign(new Help2(), this.configureHelp());
      }
      /**
       * You can customise the help by overriding Help properties using configureHelp(),
       * or with a subclass of Help by overriding createHelp().
       *
       * @param {object} [configuration] - configuration options
       * @return {(Command | object)} `this` command for chaining, or stored configuration
       */
      configureHelp(configuration) {
        if (configuration === void 0) return this._helpConfiguration;
        this._helpConfiguration = configuration;
        return this;
      }
      /**
       * The default output goes to stdout and stderr. You can customise this for special
       * applications. You can also customise the display of errors by overriding outputError.
       *
       * The configuration properties are all functions:
       *
       *     // functions to change where being written, stdout and stderr
       *     writeOut(str)
       *     writeErr(str)
       *     // matching functions to specify width for wrapping help
       *     getOutHelpWidth()
       *     getErrHelpWidth()
       *     // functions based on what is being written out
       *     outputError(str, write) // used for displaying errors, and not used for displaying help
       *
       * @param {object} [configuration] - configuration options
       * @return {(Command | object)} `this` command for chaining, or stored configuration
       */
      configureOutput(configuration) {
        if (configuration === void 0) return this._outputConfiguration;
        Object.assign(this._outputConfiguration, configuration);
        return this;
      }
      /**
       * Display the help or a custom message after an error occurs.
       *
       * @param {(boolean|string)} [displayHelp]
       * @return {Command} `this` command for chaining
       */
      showHelpAfterError(displayHelp = true) {
        if (typeof displayHelp !== "string") displayHelp = !!displayHelp;
        this._showHelpAfterError = displayHelp;
        return this;
      }
      /**
       * Display suggestion of similar commands for unknown commands, or options for unknown options.
       *
       * @param {boolean} [displaySuggestion]
       * @return {Command} `this` command for chaining
       */
      showSuggestionAfterError(displaySuggestion = true) {
        this._showSuggestionAfterError = !!displaySuggestion;
        return this;
      }
      /**
       * Add a prepared subcommand.
       *
       * See .command() for creating an attached subcommand which inherits settings from its parent.
       *
       * @param {Command} cmd - new subcommand
       * @param {object} [opts] - configuration options
       * @return {Command} `this` command for chaining
       */
      addCommand(cmd, opts) {
        if (!cmd._name) {
          throw new Error(`Command passed to .addCommand() must have a name
- specify the name in Command constructor or using .name()`);
        }
        opts = opts || {};
        if (opts.isDefault) this._defaultCommandName = cmd._name;
        if (opts.noHelp || opts.hidden) cmd._hidden = true;
        this._registerCommand(cmd);
        cmd.parent = this;
        cmd._checkForBrokenPassThrough();
        return this;
      }
      /**
       * Factory routine to create a new unattached argument.
       *
       * See .argument() for creating an attached argument, which uses this routine to
       * create the argument. You can override createArgument to return a custom argument.
       *
       * @param {string} name
       * @param {string} [description]
       * @return {Argument} new argument
       */
      createArgument(name, description) {
        return new Argument2(name, description);
      }
      /**
       * Define argument syntax for command.
       *
       * The default is that the argument is required, and you can explicitly
       * indicate this with <> around the name. Put [] around the name for an optional argument.
       *
       * @example
       * program.argument('<input-file>');
       * program.argument('[output-file]');
       *
       * @param {string} name
       * @param {string} [description]
       * @param {(Function|*)} [fn] - custom argument processing function
       * @param {*} [defaultValue]
       * @return {Command} `this` command for chaining
       */
      argument(name, description, fn, defaultValue) {
        const argument = this.createArgument(name, description);
        if (typeof fn === "function") {
          argument.default(defaultValue).argParser(fn);
        } else {
          argument.default(fn);
        }
        this.addArgument(argument);
        return this;
      }
      /**
       * Define argument syntax for command, adding multiple at once (without descriptions).
       *
       * See also .argument().
       *
       * @example
       * program.arguments('<cmd> [env]');
       *
       * @param {string} names
       * @return {Command} `this` command for chaining
       */
      arguments(names) {
        names.trim().split(/ +/).forEach((detail) => {
          this.argument(detail);
        });
        return this;
      }
      /**
       * Define argument syntax for command, adding a prepared argument.
       *
       * @param {Argument} argument
       * @return {Command} `this` command for chaining
       */
      addArgument(argument) {
        const previousArgument = this.registeredArguments.slice(-1)[0];
        if (previousArgument && previousArgument.variadic) {
          throw new Error(
            `only the last argument can be variadic '${previousArgument.name()}'`
          );
        }
        if (argument.required && argument.defaultValue !== void 0 && argument.parseArg === void 0) {
          throw new Error(
            `a default value for a required argument is never used: '${argument.name()}'`
          );
        }
        this.registeredArguments.push(argument);
        return this;
      }
      /**
       * Customise or override default help command. By default a help command is automatically added if your command has subcommands.
       *
       * @example
       *    program.helpCommand('help [cmd]');
       *    program.helpCommand('help [cmd]', 'show help');
       *    program.helpCommand(false); // suppress default help command
       *    program.helpCommand(true); // add help command even if no subcommands
       *
       * @param {string|boolean} enableOrNameAndArgs - enable with custom name and/or arguments, or boolean to override whether added
       * @param {string} [description] - custom description
       * @return {Command} `this` command for chaining
       */
      helpCommand(enableOrNameAndArgs, description) {
        if (typeof enableOrNameAndArgs === "boolean") {
          this._addImplicitHelpCommand = enableOrNameAndArgs;
          return this;
        }
        enableOrNameAndArgs = enableOrNameAndArgs ?? "help [command]";
        const [, helpName, helpArgs] = enableOrNameAndArgs.match(/([^ ]+) *(.*)/);
        const helpDescription = description ?? "display help for command";
        const helpCommand = this.createCommand(helpName);
        helpCommand.helpOption(false);
        if (helpArgs) helpCommand.arguments(helpArgs);
        if (helpDescription) helpCommand.description(helpDescription);
        this._addImplicitHelpCommand = true;
        this._helpCommand = helpCommand;
        return this;
      }
      /**
       * Add prepared custom help command.
       *
       * @param {(Command|string|boolean)} helpCommand - custom help command, or deprecated enableOrNameAndArgs as for `.helpCommand()`
       * @param {string} [deprecatedDescription] - deprecated custom description used with custom name only
       * @return {Command} `this` command for chaining
       */
      addHelpCommand(helpCommand, deprecatedDescription) {
        if (typeof helpCommand !== "object") {
          this.helpCommand(helpCommand, deprecatedDescription);
          return this;
        }
        this._addImplicitHelpCommand = true;
        this._helpCommand = helpCommand;
        return this;
      }
      /**
       * Lazy create help command.
       *
       * @return {(Command|null)}
       * @package
       */
      _getHelpCommand() {
        const hasImplicitHelpCommand = this._addImplicitHelpCommand ?? (this.commands.length && !this._actionHandler && !this._findCommand("help"));
        if (hasImplicitHelpCommand) {
          if (this._helpCommand === void 0) {
            this.helpCommand(void 0, void 0);
          }
          return this._helpCommand;
        }
        return null;
      }
      /**
       * Add hook for life cycle event.
       *
       * @param {string} event
       * @param {Function} listener
       * @return {Command} `this` command for chaining
       */
      hook(event, listener) {
        const allowedValues = ["preSubcommand", "preAction", "postAction"];
        if (!allowedValues.includes(event)) {
          throw new Error(`Unexpected value for event passed to hook : '${event}'.
Expecting one of '${allowedValues.join("', '")}'`);
        }
        if (this._lifeCycleHooks[event]) {
          this._lifeCycleHooks[event].push(listener);
        } else {
          this._lifeCycleHooks[event] = [listener];
        }
        return this;
      }
      /**
       * Register callback to use as replacement for calling process.exit.
       *
       * @param {Function} [fn] optional callback which will be passed a CommanderError, defaults to throwing
       * @return {Command} `this` command for chaining
       */
      exitOverride(fn) {
        if (fn) {
          this._exitCallback = fn;
        } else {
          this._exitCallback = (err) => {
            if (err.code !== "commander.executeSubCommandAsync") {
              throw err;
            } else {
            }
          };
        }
        return this;
      }
      /**
       * Call process.exit, and _exitCallback if defined.
       *
       * @param {number} exitCode exit code for using with process.exit
       * @param {string} code an id string representing the error
       * @param {string} message human-readable description of the error
       * @return never
       * @private
       */
      _exit(exitCode, code, message) {
        if (this._exitCallback) {
          this._exitCallback(new CommanderError2(exitCode, code, message));
        }
        process3.exit(exitCode);
      }
      /**
       * Register callback `fn` for the command.
       *
       * @example
       * program
       *   .command('serve')
       *   .description('start service')
       *   .action(function() {
       *      // do work here
       *   });
       *
       * @param {Function} fn
       * @return {Command} `this` command for chaining
       */
      action(fn) {
        const listener = (args) => {
          const expectedArgsCount = this.registeredArguments.length;
          const actionArgs = args.slice(0, expectedArgsCount);
          if (this._storeOptionsAsProperties) {
            actionArgs[expectedArgsCount] = this;
          } else {
            actionArgs[expectedArgsCount] = this.opts();
          }
          actionArgs.push(this);
          return fn.apply(this, actionArgs);
        };
        this._actionHandler = listener;
        return this;
      }
      /**
       * Factory routine to create a new unattached option.
       *
       * See .option() for creating an attached option, which uses this routine to
       * create the option. You can override createOption to return a custom option.
       *
       * @param {string} flags
       * @param {string} [description]
       * @return {Option} new option
       */
      createOption(flags, description) {
        return new Option2(flags, description);
      }
      /**
       * Wrap parseArgs to catch 'commander.invalidArgument'.
       *
       * @param {(Option | Argument)} target
       * @param {string} value
       * @param {*} previous
       * @param {string} invalidArgumentMessage
       * @private
       */
      _callParseArg(target, value, previous, invalidArgumentMessage) {
        try {
          return target.parseArg(value, previous);
        } catch (err) {
          if (err.code === "commander.invalidArgument") {
            const message = `${invalidArgumentMessage} ${err.message}`;
            this.error(message, { exitCode: err.exitCode, code: err.code });
          }
          throw err;
        }
      }
      /**
       * Check for option flag conflicts.
       * Register option if no conflicts found, or throw on conflict.
       *
       * @param {Option} option
       * @private
       */
      _registerOption(option) {
        const matchingOption = option.short && this._findOption(option.short) || option.long && this._findOption(option.long);
        if (matchingOption) {
          const matchingFlag = option.long && this._findOption(option.long) ? option.long : option.short;
          throw new Error(`Cannot add option '${option.flags}'${this._name && ` to command '${this._name}'`} due to conflicting flag '${matchingFlag}'
-  already used by option '${matchingOption.flags}'`);
        }
        this.options.push(option);
      }
      /**
       * Check for command name and alias conflicts with existing commands.
       * Register command if no conflicts found, or throw on conflict.
       *
       * @param {Command} command
       * @private
       */
      _registerCommand(command) {
        const knownBy = (cmd) => {
          return [cmd.name()].concat(cmd.aliases());
        };
        const alreadyUsed = knownBy(command).find(
          (name) => this._findCommand(name)
        );
        if (alreadyUsed) {
          const existingCmd = knownBy(this._findCommand(alreadyUsed)).join("|");
          const newCmd = knownBy(command).join("|");
          throw new Error(
            `cannot add command '${newCmd}' as already have command '${existingCmd}'`
          );
        }
        this.commands.push(command);
      }
      /**
       * Add an option.
       *
       * @param {Option} option
       * @return {Command} `this` command for chaining
       */
      addOption(option) {
        this._registerOption(option);
        const oname = option.name();
        const name = option.attributeName();
        if (option.negate) {
          const positiveLongFlag = option.long.replace(/^--no-/, "--");
          if (!this._findOption(positiveLongFlag)) {
            this.setOptionValueWithSource(
              name,
              option.defaultValue === void 0 ? true : option.defaultValue,
              "default"
            );
          }
        } else if (option.defaultValue !== void 0) {
          this.setOptionValueWithSource(name, option.defaultValue, "default");
        }
        const handleOptionValue = (val, invalidValueMessage, valueSource) => {
          if (val == null && option.presetArg !== void 0) {
            val = option.presetArg;
          }
          const oldValue = this.getOptionValue(name);
          if (val !== null && option.parseArg) {
            val = this._callParseArg(option, val, oldValue, invalidValueMessage);
          } else if (val !== null && option.variadic) {
            val = option._concatValue(val, oldValue);
          }
          if (val == null) {
            if (option.negate) {
              val = false;
            } else if (option.isBoolean() || option.optional) {
              val = true;
            } else {
              val = "";
            }
          }
          this.setOptionValueWithSource(name, val, valueSource);
        };
        this.on("option:" + oname, (val) => {
          const invalidValueMessage = `error: option '${option.flags}' argument '${val}' is invalid.`;
          handleOptionValue(val, invalidValueMessage, "cli");
        });
        if (option.envVar) {
          this.on("optionEnv:" + oname, (val) => {
            const invalidValueMessage = `error: option '${option.flags}' value '${val}' from env '${option.envVar}' is invalid.`;
            handleOptionValue(val, invalidValueMessage, "env");
          });
        }
        return this;
      }
      /**
       * Internal implementation shared by .option() and .requiredOption()
       *
       * @return {Command} `this` command for chaining
       * @private
       */
      _optionEx(config, flags, description, fn, defaultValue) {
        if (typeof flags === "object" && flags instanceof Option2) {
          throw new Error(
            "To add an Option object use addOption() instead of option() or requiredOption()"
          );
        }
        const option = this.createOption(flags, description);
        option.makeOptionMandatory(!!config.mandatory);
        if (typeof fn === "function") {
          option.default(defaultValue).argParser(fn);
        } else if (fn instanceof RegExp) {
          const regex = fn;
          fn = (val, def) => {
            const m = regex.exec(val);
            return m ? m[0] : def;
          };
          option.default(defaultValue).argParser(fn);
        } else {
          option.default(fn);
        }
        return this.addOption(option);
      }
      /**
       * Define option with `flags`, `description`, and optional argument parsing function or `defaultValue` or both.
       *
       * The `flags` string contains the short and/or long flags, separated by comma, a pipe or space. A required
       * option-argument is indicated by `<>` and an optional option-argument by `[]`.
       *
       * See the README for more details, and see also addOption() and requiredOption().
       *
       * @example
       * program
       *     .option('-p, --pepper', 'add pepper')
       *     .option('-p, --pizza-type <TYPE>', 'type of pizza') // required option-argument
       *     .option('-c, --cheese [CHEESE]', 'add extra cheese', 'mozzarella') // optional option-argument with default
       *     .option('-t, --tip <VALUE>', 'add tip to purchase cost', parseFloat) // custom parse function
       *
       * @param {string} flags
       * @param {string} [description]
       * @param {(Function|*)} [parseArg] - custom option processing function or default value
       * @param {*} [defaultValue]
       * @return {Command} `this` command for chaining
       */
      option(flags, description, parseArg, defaultValue) {
        return this._optionEx({}, flags, description, parseArg, defaultValue);
      }
      /**
       * Add a required option which must have a value after parsing. This usually means
       * the option must be specified on the command line. (Otherwise the same as .option().)
       *
       * The `flags` string contains the short and/or long flags, separated by comma, a pipe or space.
       *
       * @param {string} flags
       * @param {string} [description]
       * @param {(Function|*)} [parseArg] - custom option processing function or default value
       * @param {*} [defaultValue]
       * @return {Command} `this` command for chaining
       */
      requiredOption(flags, description, parseArg, defaultValue) {
        return this._optionEx(
          { mandatory: true },
          flags,
          description,
          parseArg,
          defaultValue
        );
      }
      /**
       * Alter parsing of short flags with optional values.
       *
       * @example
       * // for `.option('-f,--flag [value]'):
       * program.combineFlagAndOptionalValue(true);  // `-f80` is treated like `--flag=80`, this is the default behaviour
       * program.combineFlagAndOptionalValue(false) // `-fb` is treated like `-f -b`
       *
       * @param {boolean} [combine] - if `true` or omitted, an optional value can be specified directly after the flag.
       * @return {Command} `this` command for chaining
       */
      combineFlagAndOptionalValue(combine = true) {
        this._combineFlagAndOptionalValue = !!combine;
        return this;
      }
      /**
       * Allow unknown options on the command line.
       *
       * @param {boolean} [allowUnknown] - if `true` or omitted, no error will be thrown for unknown options.
       * @return {Command} `this` command for chaining
       */
      allowUnknownOption(allowUnknown = true) {
        this._allowUnknownOption = !!allowUnknown;
        return this;
      }
      /**
       * Allow excess command-arguments on the command line. Pass false to make excess arguments an error.
       *
       * @param {boolean} [allowExcess] - if `true` or omitted, no error will be thrown for excess arguments.
       * @return {Command} `this` command for chaining
       */
      allowExcessArguments(allowExcess = true) {
        this._allowExcessArguments = !!allowExcess;
        return this;
      }
      /**
       * Enable positional options. Positional means global options are specified before subcommands which lets
       * subcommands reuse the same option names, and also enables subcommands to turn on passThroughOptions.
       * The default behaviour is non-positional and global options may appear anywhere on the command line.
       *
       * @param {boolean} [positional]
       * @return {Command} `this` command for chaining
       */
      enablePositionalOptions(positional = true) {
        this._enablePositionalOptions = !!positional;
        return this;
      }
      /**
       * Pass through options that come after command-arguments rather than treat them as command-options,
       * so actual command-options come before command-arguments. Turning this on for a subcommand requires
       * positional options to have been enabled on the program (parent commands).
       * The default behaviour is non-positional and options may appear before or after command-arguments.
       *
       * @param {boolean} [passThrough] for unknown options.
       * @return {Command} `this` command for chaining
       */
      passThroughOptions(passThrough = true) {
        this._passThroughOptions = !!passThrough;
        this._checkForBrokenPassThrough();
        return this;
      }
      /**
       * @private
       */
      _checkForBrokenPassThrough() {
        if (this.parent && this._passThroughOptions && !this.parent._enablePositionalOptions) {
          throw new Error(
            `passThroughOptions cannot be used for '${this._name}' without turning on enablePositionalOptions for parent command(s)`
          );
        }
      }
      /**
       * Whether to store option values as properties on command object,
       * or store separately (specify false). In both cases the option values can be accessed using .opts().
       *
       * @param {boolean} [storeAsProperties=true]
       * @return {Command} `this` command for chaining
       */
      storeOptionsAsProperties(storeAsProperties = true) {
        if (this.options.length) {
          throw new Error("call .storeOptionsAsProperties() before adding options");
        }
        if (Object.keys(this._optionValues).length) {
          throw new Error(
            "call .storeOptionsAsProperties() before setting option values"
          );
        }
        this._storeOptionsAsProperties = !!storeAsProperties;
        return this;
      }
      /**
       * Retrieve option value.
       *
       * @param {string} key
       * @return {object} value
       */
      getOptionValue(key) {
        if (this._storeOptionsAsProperties) {
          return this[key];
        }
        return this._optionValues[key];
      }
      /**
       * Store option value.
       *
       * @param {string} key
       * @param {object} value
       * @return {Command} `this` command for chaining
       */
      setOptionValue(key, value) {
        return this.setOptionValueWithSource(key, value, void 0);
      }
      /**
       * Store option value and where the value came from.
       *
       * @param {string} key
       * @param {object} value
       * @param {string} source - expected values are default/config/env/cli/implied
       * @return {Command} `this` command for chaining
       */
      setOptionValueWithSource(key, value, source) {
        if (this._storeOptionsAsProperties) {
          this[key] = value;
        } else {
          this._optionValues[key] = value;
        }
        this._optionValueSources[key] = source;
        return this;
      }
      /**
       * Get source of option value.
       * Expected values are default | config | env | cli | implied
       *
       * @param {string} key
       * @return {string}
       */
      getOptionValueSource(key) {
        return this._optionValueSources[key];
      }
      /**
       * Get source of option value. See also .optsWithGlobals().
       * Expected values are default | config | env | cli | implied
       *
       * @param {string} key
       * @return {string}
       */
      getOptionValueSourceWithGlobals(key) {
        let source;
        this._getCommandAndAncestors().forEach((cmd) => {
          if (cmd.getOptionValueSource(key) !== void 0) {
            source = cmd.getOptionValueSource(key);
          }
        });
        return source;
      }
      /**
       * Get user arguments from implied or explicit arguments.
       * Side-effects: set _scriptPath if args included script. Used for default program name, and subcommand searches.
       *
       * @private
       */
      _prepareUserArgs(argv, parseOptions) {
        if (argv !== void 0 && !Array.isArray(argv)) {
          throw new Error("first parameter to parse must be array or undefined");
        }
        parseOptions = parseOptions || {};
        if (argv === void 0 && parseOptions.from === void 0) {
          if (process3.versions?.electron) {
            parseOptions.from = "electron";
          }
          const execArgv = process3.execArgv ?? [];
          if (execArgv.includes("-e") || execArgv.includes("--eval") || execArgv.includes("-p") || execArgv.includes("--print")) {
            parseOptions.from = "eval";
          }
        }
        if (argv === void 0) {
          argv = process3.argv;
        }
        this.rawArgs = argv.slice();
        let userArgs;
        switch (parseOptions.from) {
          case void 0:
          case "node":
            this._scriptPath = argv[1];
            userArgs = argv.slice(2);
            break;
          case "electron":
            if (process3.defaultApp) {
              this._scriptPath = argv[1];
              userArgs = argv.slice(2);
            } else {
              userArgs = argv.slice(1);
            }
            break;
          case "user":
            userArgs = argv.slice(0);
            break;
          case "eval":
            userArgs = argv.slice(1);
            break;
          default:
            throw new Error(
              `unexpected parse option { from: '${parseOptions.from}' }`
            );
        }
        if (!this._name && this._scriptPath)
          this.nameFromFilename(this._scriptPath);
        this._name = this._name || "program";
        return userArgs;
      }
      /**
       * Parse `argv`, setting options and invoking commands when defined.
       *
       * Use parseAsync instead of parse if any of your action handlers are async.
       *
       * Call with no parameters to parse `process.argv`. Detects Electron and special node options like `node --eval`. Easy mode!
       *
       * Or call with an array of strings to parse, and optionally where the user arguments start by specifying where the arguments are `from`:
       * - `'node'`: default, `argv[0]` is the application and `argv[1]` is the script being run, with user arguments after that
       * - `'electron'`: `argv[0]` is the application and `argv[1]` varies depending on whether the electron application is packaged
       * - `'user'`: just user arguments
       *
       * @example
       * program.parse(); // parse process.argv and auto-detect electron and special node flags
       * program.parse(process.argv); // assume argv[0] is app and argv[1] is script
       * program.parse(my-args, { from: 'user' }); // just user supplied arguments, nothing special about argv[0]
       *
       * @param {string[]} [argv] - optional, defaults to process.argv
       * @param {object} [parseOptions] - optionally specify style of options with from: node/user/electron
       * @param {string} [parseOptions.from] - where the args are from: 'node', 'user', 'electron'
       * @return {Command} `this` command for chaining
       */
      parse(argv, parseOptions) {
        const userArgs = this._prepareUserArgs(argv, parseOptions);
        this._parseCommand([], userArgs);
        return this;
      }
      /**
       * Parse `argv`, setting options and invoking commands when defined.
       *
       * Call with no parameters to parse `process.argv`. Detects Electron and special node options like `node --eval`. Easy mode!
       *
       * Or call with an array of strings to parse, and optionally where the user arguments start by specifying where the arguments are `from`:
       * - `'node'`: default, `argv[0]` is the application and `argv[1]` is the script being run, with user arguments after that
       * - `'electron'`: `argv[0]` is the application and `argv[1]` varies depending on whether the electron application is packaged
       * - `'user'`: just user arguments
       *
       * @example
       * await program.parseAsync(); // parse process.argv and auto-detect electron and special node flags
       * await program.parseAsync(process.argv); // assume argv[0] is app and argv[1] is script
       * await program.parseAsync(my-args, { from: 'user' }); // just user supplied arguments, nothing special about argv[0]
       *
       * @param {string[]} [argv]
       * @param {object} [parseOptions]
       * @param {string} parseOptions.from - where the args are from: 'node', 'user', 'electron'
       * @return {Promise}
       */
      async parseAsync(argv, parseOptions) {
        const userArgs = this._prepareUserArgs(argv, parseOptions);
        await this._parseCommand([], userArgs);
        return this;
      }
      /**
       * Execute a sub-command executable.
       *
       * @private
       */
      _executeSubCommand(subcommand, args) {
        args = args.slice();
        let launchWithNode = false;
        const sourceExt = [".js", ".ts", ".tsx", ".mjs", ".cjs"];
        function findFile(baseDir, baseName) {
          const localBin = path2.resolve(baseDir, baseName);
          if (fs.existsSync(localBin)) return localBin;
          if (sourceExt.includes(path2.extname(baseName))) return void 0;
          const foundExt = sourceExt.find(
            (ext) => fs.existsSync(`${localBin}${ext}`)
          );
          if (foundExt) return `${localBin}${foundExt}`;
          return void 0;
        }
        this._checkForMissingMandatoryOptions();
        this._checkForConflictingOptions();
        let executableFile = subcommand._executableFile || `${this._name}-${subcommand._name}`;
        let executableDir = this._executableDir || "";
        if (this._scriptPath) {
          let resolvedScriptPath;
          try {
            resolvedScriptPath = fs.realpathSync(this._scriptPath);
          } catch (err) {
            resolvedScriptPath = this._scriptPath;
          }
          executableDir = path2.resolve(
            path2.dirname(resolvedScriptPath),
            executableDir
          );
        }
        if (executableDir) {
          let localFile = findFile(executableDir, executableFile);
          if (!localFile && !subcommand._executableFile && this._scriptPath) {
            const legacyName = path2.basename(
              this._scriptPath,
              path2.extname(this._scriptPath)
            );
            if (legacyName !== this._name) {
              localFile = findFile(
                executableDir,
                `${legacyName}-${subcommand._name}`
              );
            }
          }
          executableFile = localFile || executableFile;
        }
        launchWithNode = sourceExt.includes(path2.extname(executableFile));
        let proc;
        if (process3.platform !== "win32") {
          if (launchWithNode) {
            args.unshift(executableFile);
            args = incrementNodeInspectorPort(process3.execArgv).concat(args);
            proc = childProcess.spawn(process3.argv[0], args, { stdio: "inherit" });
          } else {
            proc = childProcess.spawn(executableFile, args, { stdio: "inherit" });
          }
        } else {
          args.unshift(executableFile);
          args = incrementNodeInspectorPort(process3.execArgv).concat(args);
          proc = childProcess.spawn(process3.execPath, args, { stdio: "inherit" });
        }
        if (!proc.killed) {
          const signals = ["SIGUSR1", "SIGUSR2", "SIGTERM", "SIGINT", "SIGHUP"];
          signals.forEach((signal) => {
            process3.on(signal, () => {
              if (proc.killed === false && proc.exitCode === null) {
                proc.kill(signal);
              }
            });
          });
        }
        const exitCallback = this._exitCallback;
        proc.on("close", (code) => {
          code = code ?? 1;
          if (!exitCallback) {
            process3.exit(code);
          } else {
            exitCallback(
              new CommanderError2(
                code,
                "commander.executeSubCommandAsync",
                "(close)"
              )
            );
          }
        });
        proc.on("error", (err) => {
          if (err.code === "ENOENT") {
            const executableDirMessage = executableDir ? `searched for local subcommand relative to directory '${executableDir}'` : "no directory for search for local subcommand, use .executableDir() to supply a custom directory";
            const executableMissing = `'${executableFile}' does not exist
 - if '${subcommand._name}' is not meant to be an executable command, remove description parameter from '.command()' and use '.description()' instead
 - if the default executable name is not suitable, use the executableFile option to supply a custom name or path
 - ${executableDirMessage}`;
            throw new Error(executableMissing);
          } else if (err.code === "EACCES") {
            throw new Error(`'${executableFile}' not executable`);
          }
          if (!exitCallback) {
            process3.exit(1);
          } else {
            const wrappedError = new CommanderError2(
              1,
              "commander.executeSubCommandAsync",
              "(error)"
            );
            wrappedError.nestedError = err;
            exitCallback(wrappedError);
          }
        });
        this.runningCommand = proc;
      }
      /**
       * @private
       */
      _dispatchSubcommand(commandName, operands, unknown) {
        const subCommand = this._findCommand(commandName);
        if (!subCommand) this.help({ error: true });
        let promiseChain;
        promiseChain = this._chainOrCallSubCommandHook(
          promiseChain,
          subCommand,
          "preSubcommand"
        );
        promiseChain = this._chainOrCall(promiseChain, () => {
          if (subCommand._executableHandler) {
            this._executeSubCommand(subCommand, operands.concat(unknown));
          } else {
            return subCommand._parseCommand(operands, unknown);
          }
        });
        return promiseChain;
      }
      /**
       * Invoke help directly if possible, or dispatch if necessary.
       * e.g. help foo
       *
       * @private
       */
      _dispatchHelpCommand(subcommandName) {
        if (!subcommandName) {
          this.help();
        }
        const subCommand = this._findCommand(subcommandName);
        if (subCommand && !subCommand._executableHandler) {
          subCommand.help();
        }
        return this._dispatchSubcommand(
          subcommandName,
          [],
          [this._getHelpOption()?.long ?? this._getHelpOption()?.short ?? "--help"]
        );
      }
      /**
       * Check this.args against expected this.registeredArguments.
       *
       * @private
       */
      _checkNumberOfArguments() {
        this.registeredArguments.forEach((arg, i) => {
          if (arg.required && this.args[i] == null) {
            this.missingArgument(arg.name());
          }
        });
        if (this.registeredArguments.length > 0 && this.registeredArguments[this.registeredArguments.length - 1].variadic) {
          return;
        }
        if (this.args.length > this.registeredArguments.length) {
          this._excessArguments(this.args);
        }
      }
      /**
       * Process this.args using this.registeredArguments and save as this.processedArgs!
       *
       * @private
       */
      _processArguments() {
        const myParseArg = (argument, value, previous) => {
          let parsedValue = value;
          if (value !== null && argument.parseArg) {
            const invalidValueMessage = `error: command-argument value '${value}' is invalid for argument '${argument.name()}'.`;
            parsedValue = this._callParseArg(
              argument,
              value,
              previous,
              invalidValueMessage
            );
          }
          return parsedValue;
        };
        this._checkNumberOfArguments();
        const processedArgs = [];
        this.registeredArguments.forEach((declaredArg, index) => {
          let value = declaredArg.defaultValue;
          if (declaredArg.variadic) {
            if (index < this.args.length) {
              value = this.args.slice(index);
              if (declaredArg.parseArg) {
                value = value.reduce((processed, v) => {
                  return myParseArg(declaredArg, v, processed);
                }, declaredArg.defaultValue);
              }
            } else if (value === void 0) {
              value = [];
            }
          } else if (index < this.args.length) {
            value = this.args[index];
            if (declaredArg.parseArg) {
              value = myParseArg(declaredArg, value, declaredArg.defaultValue);
            }
          }
          processedArgs[index] = value;
        });
        this.processedArgs = processedArgs;
      }
      /**
       * Once we have a promise we chain, but call synchronously until then.
       *
       * @param {(Promise|undefined)} promise
       * @param {Function} fn
       * @return {(Promise|undefined)}
       * @private
       */
      _chainOrCall(promise, fn) {
        if (promise && promise.then && typeof promise.then === "function") {
          return promise.then(() => fn());
        }
        return fn();
      }
      /**
       *
       * @param {(Promise|undefined)} promise
       * @param {string} event
       * @return {(Promise|undefined)}
       * @private
       */
      _chainOrCallHooks(promise, event) {
        let result = promise;
        const hooks = [];
        this._getCommandAndAncestors().reverse().filter((cmd) => cmd._lifeCycleHooks[event] !== void 0).forEach((hookedCommand) => {
          hookedCommand._lifeCycleHooks[event].forEach((callback) => {
            hooks.push({ hookedCommand, callback });
          });
        });
        if (event === "postAction") {
          hooks.reverse();
        }
        hooks.forEach((hookDetail) => {
          result = this._chainOrCall(result, () => {
            return hookDetail.callback(hookDetail.hookedCommand, this);
          });
        });
        return result;
      }
      /**
       *
       * @param {(Promise|undefined)} promise
       * @param {Command} subCommand
       * @param {string} event
       * @return {(Promise|undefined)}
       * @private
       */
      _chainOrCallSubCommandHook(promise, subCommand, event) {
        let result = promise;
        if (this._lifeCycleHooks[event] !== void 0) {
          this._lifeCycleHooks[event].forEach((hook) => {
            result = this._chainOrCall(result, () => {
              return hook(this, subCommand);
            });
          });
        }
        return result;
      }
      /**
       * Process arguments in context of this command.
       * Returns action result, in case it is a promise.
       *
       * @private
       */
      _parseCommand(operands, unknown) {
        const parsed = this.parseOptions(unknown);
        this._parseOptionsEnv();
        this._parseOptionsImplied();
        operands = operands.concat(parsed.operands);
        unknown = parsed.unknown;
        this.args = operands.concat(unknown);
        if (operands && this._findCommand(operands[0])) {
          return this._dispatchSubcommand(operands[0], operands.slice(1), unknown);
        }
        if (this._getHelpCommand() && operands[0] === this._getHelpCommand().name()) {
          return this._dispatchHelpCommand(operands[1]);
        }
        if (this._defaultCommandName) {
          this._outputHelpIfRequested(unknown);
          return this._dispatchSubcommand(
            this._defaultCommandName,
            operands,
            unknown
          );
        }
        if (this.commands.length && this.args.length === 0 && !this._actionHandler && !this._defaultCommandName) {
          this.help({ error: true });
        }
        this._outputHelpIfRequested(parsed.unknown);
        this._checkForMissingMandatoryOptions();
        this._checkForConflictingOptions();
        const checkForUnknownOptions = () => {
          if (parsed.unknown.length > 0) {
            this.unknownOption(parsed.unknown[0]);
          }
        };
        const commandEvent = `command:${this.name()}`;
        if (this._actionHandler) {
          checkForUnknownOptions();
          this._processArguments();
          let promiseChain;
          promiseChain = this._chainOrCallHooks(promiseChain, "preAction");
          promiseChain = this._chainOrCall(
            promiseChain,
            () => this._actionHandler(this.processedArgs)
          );
          if (this.parent) {
            promiseChain = this._chainOrCall(promiseChain, () => {
              this.parent.emit(commandEvent, operands, unknown);
            });
          }
          promiseChain = this._chainOrCallHooks(promiseChain, "postAction");
          return promiseChain;
        }
        if (this.parent && this.parent.listenerCount(commandEvent)) {
          checkForUnknownOptions();
          this._processArguments();
          this.parent.emit(commandEvent, operands, unknown);
        } else if (operands.length) {
          if (this._findCommand("*")) {
            return this._dispatchSubcommand("*", operands, unknown);
          }
          if (this.listenerCount("command:*")) {
            this.emit("command:*", operands, unknown);
          } else if (this.commands.length) {
            this.unknownCommand();
          } else {
            checkForUnknownOptions();
            this._processArguments();
          }
        } else if (this.commands.length) {
          checkForUnknownOptions();
          this.help({ error: true });
        } else {
          checkForUnknownOptions();
          this._processArguments();
        }
      }
      /**
       * Find matching command.
       *
       * @private
       * @return {Command | undefined}
       */
      _findCommand(name) {
        if (!name) return void 0;
        return this.commands.find(
          (cmd) => cmd._name === name || cmd._aliases.includes(name)
        );
      }
      /**
       * Return an option matching `arg` if any.
       *
       * @param {string} arg
       * @return {Option}
       * @package
       */
      _findOption(arg) {
        return this.options.find((option) => option.is(arg));
      }
      /**
       * Display an error message if a mandatory option does not have a value.
       * Called after checking for help flags in leaf subcommand.
       *
       * @private
       */
      _checkForMissingMandatoryOptions() {
        this._getCommandAndAncestors().forEach((cmd) => {
          cmd.options.forEach((anOption) => {
            if (anOption.mandatory && cmd.getOptionValue(anOption.attributeName()) === void 0) {
              cmd.missingMandatoryOptionValue(anOption);
            }
          });
        });
      }
      /**
       * Display an error message if conflicting options are used together in this.
       *
       * @private
       */
      _checkForConflictingLocalOptions() {
        const definedNonDefaultOptions = this.options.filter((option) => {
          const optionKey = option.attributeName();
          if (this.getOptionValue(optionKey) === void 0) {
            return false;
          }
          return this.getOptionValueSource(optionKey) !== "default";
        });
        const optionsWithConflicting = definedNonDefaultOptions.filter(
          (option) => option.conflictsWith.length > 0
        );
        optionsWithConflicting.forEach((option) => {
          const conflictingAndDefined = definedNonDefaultOptions.find(
            (defined) => option.conflictsWith.includes(defined.attributeName())
          );
          if (conflictingAndDefined) {
            this._conflictingOption(option, conflictingAndDefined);
          }
        });
      }
      /**
       * Display an error message if conflicting options are used together.
       * Called after checking for help flags in leaf subcommand.
       *
       * @private
       */
      _checkForConflictingOptions() {
        this._getCommandAndAncestors().forEach((cmd) => {
          cmd._checkForConflictingLocalOptions();
        });
      }
      /**
       * Parse options from `argv` removing known options,
       * and return argv split into operands and unknown arguments.
       *
       * Examples:
       *
       *     argv => operands, unknown
       *     --known kkk op => [op], []
       *     op --known kkk => [op], []
       *     sub --unknown uuu op => [sub], [--unknown uuu op]
       *     sub -- --unknown uuu op => [sub --unknown uuu op], []
       *
       * @param {string[]} argv
       * @return {{operands: string[], unknown: string[]}}
       */
      parseOptions(argv) {
        const operands = [];
        const unknown = [];
        let dest = operands;
        const args = argv.slice();
        function maybeOption(arg) {
          return arg.length > 1 && arg[0] === "-";
        }
        let activeVariadicOption = null;
        while (args.length) {
          const arg = args.shift();
          if (arg === "--") {
            if (dest === unknown) dest.push(arg);
            dest.push(...args);
            break;
          }
          if (activeVariadicOption && !maybeOption(arg)) {
            this.emit(`option:${activeVariadicOption.name()}`, arg);
            continue;
          }
          activeVariadicOption = null;
          if (maybeOption(arg)) {
            const option = this._findOption(arg);
            if (option) {
              if (option.required) {
                const value = args.shift();
                if (value === void 0) this.optionMissingArgument(option);
                this.emit(`option:${option.name()}`, value);
              } else if (option.optional) {
                let value = null;
                if (args.length > 0 && !maybeOption(args[0])) {
                  value = args.shift();
                }
                this.emit(`option:${option.name()}`, value);
              } else {
                this.emit(`option:${option.name()}`);
              }
              activeVariadicOption = option.variadic ? option : null;
              continue;
            }
          }
          if (arg.length > 2 && arg[0] === "-" && arg[1] !== "-") {
            const option = this._findOption(`-${arg[1]}`);
            if (option) {
              if (option.required || option.optional && this._combineFlagAndOptionalValue) {
                this.emit(`option:${option.name()}`, arg.slice(2));
              } else {
                this.emit(`option:${option.name()}`);
                args.unshift(`-${arg.slice(2)}`);
              }
              continue;
            }
          }
          if (/^--[^=]+=/.test(arg)) {
            const index = arg.indexOf("=");
            const option = this._findOption(arg.slice(0, index));
            if (option && (option.required || option.optional)) {
              this.emit(`option:${option.name()}`, arg.slice(index + 1));
              continue;
            }
          }
          if (maybeOption(arg)) {
            dest = unknown;
          }
          if ((this._enablePositionalOptions || this._passThroughOptions) && operands.length === 0 && unknown.length === 0) {
            if (this._findCommand(arg)) {
              operands.push(arg);
              if (args.length > 0) unknown.push(...args);
              break;
            } else if (this._getHelpCommand() && arg === this._getHelpCommand().name()) {
              operands.push(arg);
              if (args.length > 0) operands.push(...args);
              break;
            } else if (this._defaultCommandName) {
              unknown.push(arg);
              if (args.length > 0) unknown.push(...args);
              break;
            }
          }
          if (this._passThroughOptions) {
            dest.push(arg);
            if (args.length > 0) dest.push(...args);
            break;
          }
          dest.push(arg);
        }
        return { operands, unknown };
      }
      /**
       * Return an object containing local option values as key-value pairs.
       *
       * @return {object}
       */
      opts() {
        if (this._storeOptionsAsProperties) {
          const result = {};
          const len = this.options.length;
          for (let i = 0; i < len; i++) {
            const key = this.options[i].attributeName();
            result[key] = key === this._versionOptionName ? this._version : this[key];
          }
          return result;
        }
        return this._optionValues;
      }
      /**
       * Return an object containing merged local and global option values as key-value pairs.
       *
       * @return {object}
       */
      optsWithGlobals() {
        return this._getCommandAndAncestors().reduce(
          (combinedOptions, cmd) => Object.assign(combinedOptions, cmd.opts()),
          {}
        );
      }
      /**
       * Display error message and exit (or call exitOverride).
       *
       * @param {string} message
       * @param {object} [errorOptions]
       * @param {string} [errorOptions.code] - an id string representing the error
       * @param {number} [errorOptions.exitCode] - used with process.exit
       */
      error(message, errorOptions) {
        this._outputConfiguration.outputError(
          `${message}
`,
          this._outputConfiguration.writeErr
        );
        if (typeof this._showHelpAfterError === "string") {
          this._outputConfiguration.writeErr(`${this._showHelpAfterError}
`);
        } else if (this._showHelpAfterError) {
          this._outputConfiguration.writeErr("\n");
          this.outputHelp({ error: true });
        }
        const config = errorOptions || {};
        const exitCode = config.exitCode || 1;
        const code = config.code || "commander.error";
        this._exit(exitCode, code, message);
      }
      /**
       * Apply any option related environment variables, if option does
       * not have a value from cli or client code.
       *
       * @private
       */
      _parseOptionsEnv() {
        this.options.forEach((option) => {
          if (option.envVar && option.envVar in process3.env) {
            const optionKey = option.attributeName();
            if (this.getOptionValue(optionKey) === void 0 || ["default", "config", "env"].includes(
              this.getOptionValueSource(optionKey)
            )) {
              if (option.required || option.optional) {
                this.emit(`optionEnv:${option.name()}`, process3.env[option.envVar]);
              } else {
                this.emit(`optionEnv:${option.name()}`);
              }
            }
          }
        });
      }
      /**
       * Apply any implied option values, if option is undefined or default value.
       *
       * @private
       */
      _parseOptionsImplied() {
        const dualHelper = new DualOptions(this.options);
        const hasCustomOptionValue = (optionKey) => {
          return this.getOptionValue(optionKey) !== void 0 && !["default", "implied"].includes(this.getOptionValueSource(optionKey));
        };
        this.options.filter(
          (option) => option.implied !== void 0 && hasCustomOptionValue(option.attributeName()) && dualHelper.valueFromOption(
            this.getOptionValue(option.attributeName()),
            option
          )
        ).forEach((option) => {
          Object.keys(option.implied).filter((impliedKey) => !hasCustomOptionValue(impliedKey)).forEach((impliedKey) => {
            this.setOptionValueWithSource(
              impliedKey,
              option.implied[impliedKey],
              "implied"
            );
          });
        });
      }
      /**
       * Argument `name` is missing.
       *
       * @param {string} name
       * @private
       */
      missingArgument(name) {
        const message = `error: missing required argument '${name}'`;
        this.error(message, { code: "commander.missingArgument" });
      }
      /**
       * `Option` is missing an argument.
       *
       * @param {Option} option
       * @private
       */
      optionMissingArgument(option) {
        const message = `error: option '${option.flags}' argument missing`;
        this.error(message, { code: "commander.optionMissingArgument" });
      }
      /**
       * `Option` does not have a value, and is a mandatory option.
       *
       * @param {Option} option
       * @private
       */
      missingMandatoryOptionValue(option) {
        const message = `error: required option '${option.flags}' not specified`;
        this.error(message, { code: "commander.missingMandatoryOptionValue" });
      }
      /**
       * `Option` conflicts with another option.
       *
       * @param {Option} option
       * @param {Option} conflictingOption
       * @private
       */
      _conflictingOption(option, conflictingOption) {
        const findBestOptionFromValue = (option2) => {
          const optionKey = option2.attributeName();
          const optionValue = this.getOptionValue(optionKey);
          const negativeOption = this.options.find(
            (target) => target.negate && optionKey === target.attributeName()
          );
          const positiveOption = this.options.find(
            (target) => !target.negate && optionKey === target.attributeName()
          );
          if (negativeOption && (negativeOption.presetArg === void 0 && optionValue === false || negativeOption.presetArg !== void 0 && optionValue === negativeOption.presetArg)) {
            return negativeOption;
          }
          return positiveOption || option2;
        };
        const getErrorMessage = (option2) => {
          const bestOption = findBestOptionFromValue(option2);
          const optionKey = bestOption.attributeName();
          const source = this.getOptionValueSource(optionKey);
          if (source === "env") {
            return `environment variable '${bestOption.envVar}'`;
          }
          return `option '${bestOption.flags}'`;
        };
        const message = `error: ${getErrorMessage(option)} cannot be used with ${getErrorMessage(conflictingOption)}`;
        this.error(message, { code: "commander.conflictingOption" });
      }
      /**
       * Unknown option `flag`.
       *
       * @param {string} flag
       * @private
       */
      unknownOption(flag) {
        if (this._allowUnknownOption) return;
        let suggestion = "";
        if (flag.startsWith("--") && this._showSuggestionAfterError) {
          let candidateFlags = [];
          let command = this;
          do {
            const moreFlags = command.createHelp().visibleOptions(command).filter((option) => option.long).map((option) => option.long);
            candidateFlags = candidateFlags.concat(moreFlags);
            command = command.parent;
          } while (command && !command._enablePositionalOptions);
          suggestion = suggestSimilar(flag, candidateFlags);
        }
        const message = `error: unknown option '${flag}'${suggestion}`;
        this.error(message, { code: "commander.unknownOption" });
      }
      /**
       * Excess arguments, more than expected.
       *
       * @param {string[]} receivedArgs
       * @private
       */
      _excessArguments(receivedArgs) {
        if (this._allowExcessArguments) return;
        const expected = this.registeredArguments.length;
        const s = expected === 1 ? "" : "s";
        const forSubcommand = this.parent ? ` for '${this.name()}'` : "";
        const message = `error: too many arguments${forSubcommand}. Expected ${expected} argument${s} but got ${receivedArgs.length}.`;
        this.error(message, { code: "commander.excessArguments" });
      }
      /**
       * Unknown command.
       *
       * @private
       */
      unknownCommand() {
        const unknownName = this.args[0];
        let suggestion = "";
        if (this._showSuggestionAfterError) {
          const candidateNames = [];
          this.createHelp().visibleCommands(this).forEach((command) => {
            candidateNames.push(command.name());
            if (command.alias()) candidateNames.push(command.alias());
          });
          suggestion = suggestSimilar(unknownName, candidateNames);
        }
        const message = `error: unknown command '${unknownName}'${suggestion}`;
        this.error(message, { code: "commander.unknownCommand" });
      }
      /**
       * Get or set the program version.
       *
       * This method auto-registers the "-V, --version" option which will print the version number.
       *
       * You can optionally supply the flags and description to override the defaults.
       *
       * @param {string} [str]
       * @param {string} [flags]
       * @param {string} [description]
       * @return {(this | string | undefined)} `this` command for chaining, or version string if no arguments
       */
      version(str, flags, description) {
        if (str === void 0) return this._version;
        this._version = str;
        flags = flags || "-V, --version";
        description = description || "output the version number";
        const versionOption = this.createOption(flags, description);
        this._versionOptionName = versionOption.attributeName();
        this._registerOption(versionOption);
        this.on("option:" + versionOption.name(), () => {
          this._outputConfiguration.writeOut(`${str}
`);
          this._exit(0, "commander.version", str);
        });
        return this;
      }
      /**
       * Set the description.
       *
       * @param {string} [str]
       * @param {object} [argsDescription]
       * @return {(string|Command)}
       */
      description(str, argsDescription) {
        if (str === void 0 && argsDescription === void 0)
          return this._description;
        this._description = str;
        if (argsDescription) {
          this._argsDescription = argsDescription;
        }
        return this;
      }
      /**
       * Set the summary. Used when listed as subcommand of parent.
       *
       * @param {string} [str]
       * @return {(string|Command)}
       */
      summary(str) {
        if (str === void 0) return this._summary;
        this._summary = str;
        return this;
      }
      /**
       * Set an alias for the command.
       *
       * You may call more than once to add multiple aliases. Only the first alias is shown in the auto-generated help.
       *
       * @param {string} [alias]
       * @return {(string|Command)}
       */
      alias(alias) {
        if (alias === void 0) return this._aliases[0];
        let command = this;
        if (this.commands.length !== 0 && this.commands[this.commands.length - 1]._executableHandler) {
          command = this.commands[this.commands.length - 1];
        }
        if (alias === command._name)
          throw new Error("Command alias can't be the same as its name");
        const matchingCommand = this.parent?._findCommand(alias);
        if (matchingCommand) {
          const existingCmd = [matchingCommand.name()].concat(matchingCommand.aliases()).join("|");
          throw new Error(
            `cannot add alias '${alias}' to command '${this.name()}' as already have command '${existingCmd}'`
          );
        }
        command._aliases.push(alias);
        return this;
      }
      /**
       * Set aliases for the command.
       *
       * Only the first alias is shown in the auto-generated help.
       *
       * @param {string[]} [aliases]
       * @return {(string[]|Command)}
       */
      aliases(aliases) {
        if (aliases === void 0) return this._aliases;
        aliases.forEach((alias) => this.alias(alias));
        return this;
      }
      /**
       * Set / get the command usage `str`.
       *
       * @param {string} [str]
       * @return {(string|Command)}
       */
      usage(str) {
        if (str === void 0) {
          if (this._usage) return this._usage;
          const args = this.registeredArguments.map((arg) => {
            return humanReadableArgName(arg);
          });
          return [].concat(
            this.options.length || this._helpOption !== null ? "[options]" : [],
            this.commands.length ? "[command]" : [],
            this.registeredArguments.length ? args : []
          ).join(" ");
        }
        this._usage = str;
        return this;
      }
      /**
       * Get or set the name of the command.
       *
       * @param {string} [str]
       * @return {(string|Command)}
       */
      name(str) {
        if (str === void 0) return this._name;
        this._name = str;
        return this;
      }
      /**
       * Set the name of the command from script filename, such as process.argv[1],
       * or require.main.filename, or __filename.
       *
       * (Used internally and public although not documented in README.)
       *
       * @example
       * program.nameFromFilename(require.main.filename);
       *
       * @param {string} filename
       * @return {Command}
       */
      nameFromFilename(filename) {
        this._name = path2.basename(filename, path2.extname(filename));
        return this;
      }
      /**
       * Get or set the directory for searching for executable subcommands of this command.
       *
       * @example
       * program.executableDir(__dirname);
       * // or
       * program.executableDir('subcommands');
       *
       * @param {string} [path]
       * @return {(string|null|Command)}
       */
      executableDir(path3) {
        if (path3 === void 0) return this._executableDir;
        this._executableDir = path3;
        return this;
      }
      /**
       * Return program help documentation.
       *
       * @param {{ error: boolean }} [contextOptions] - pass {error:true} to wrap for stderr instead of stdout
       * @return {string}
       */
      helpInformation(contextOptions) {
        const helper = this.createHelp();
        if (helper.helpWidth === void 0) {
          helper.helpWidth = contextOptions && contextOptions.error ? this._outputConfiguration.getErrHelpWidth() : this._outputConfiguration.getOutHelpWidth();
        }
        return helper.formatHelp(this, helper);
      }
      /**
       * @private
       */
      _getHelpContext(contextOptions) {
        contextOptions = contextOptions || {};
        const context = { error: !!contextOptions.error };
        let write2;
        if (context.error) {
          write2 = (arg) => this._outputConfiguration.writeErr(arg);
        } else {
          write2 = (arg) => this._outputConfiguration.writeOut(arg);
        }
        context.write = contextOptions.write || write2;
        context.command = this;
        return context;
      }
      /**
       * Output help information for this command.
       *
       * Outputs built-in help, and custom text added using `.addHelpText()`.
       *
       * @param {{ error: boolean } | Function} [contextOptions] - pass {error:true} to write to stderr instead of stdout
       */
      outputHelp(contextOptions) {
        let deprecatedCallback;
        if (typeof contextOptions === "function") {
          deprecatedCallback = contextOptions;
          contextOptions = void 0;
        }
        const context = this._getHelpContext(contextOptions);
        this._getCommandAndAncestors().reverse().forEach((command) => command.emit("beforeAllHelp", context));
        this.emit("beforeHelp", context);
        let helpInformation = this.helpInformation(context);
        if (deprecatedCallback) {
          helpInformation = deprecatedCallback(helpInformation);
          if (typeof helpInformation !== "string" && !Buffer.isBuffer(helpInformation)) {
            throw new Error("outputHelp callback must return a string or a Buffer");
          }
        }
        context.write(helpInformation);
        if (this._getHelpOption()?.long) {
          this.emit(this._getHelpOption().long);
        }
        this.emit("afterHelp", context);
        this._getCommandAndAncestors().forEach(
          (command) => command.emit("afterAllHelp", context)
        );
      }
      /**
       * You can pass in flags and a description to customise the built-in help option.
       * Pass in false to disable the built-in help option.
       *
       * @example
       * program.helpOption('-?, --help' 'show help'); // customise
       * program.helpOption(false); // disable
       *
       * @param {(string | boolean)} flags
       * @param {string} [description]
       * @return {Command} `this` command for chaining
       */
      helpOption(flags, description) {
        if (typeof flags === "boolean") {
          if (flags) {
            this._helpOption = this._helpOption ?? void 0;
          } else {
            this._helpOption = null;
          }
          return this;
        }
        flags = flags ?? "-h, --help";
        description = description ?? "display help for command";
        this._helpOption = this.createOption(flags, description);
        return this;
      }
      /**
       * Lazy create help option.
       * Returns null if has been disabled with .helpOption(false).
       *
       * @returns {(Option | null)} the help option
       * @package
       */
      _getHelpOption() {
        if (this._helpOption === void 0) {
          this.helpOption(void 0, void 0);
        }
        return this._helpOption;
      }
      /**
       * Supply your own option to use for the built-in help option.
       * This is an alternative to using helpOption() to customise the flags and description etc.
       *
       * @param {Option} option
       * @return {Command} `this` command for chaining
       */
      addHelpOption(option) {
        this._helpOption = option;
        return this;
      }
      /**
       * Output help information and exit.
       *
       * Outputs built-in help, and custom text added using `.addHelpText()`.
       *
       * @param {{ error: boolean }} [contextOptions] - pass {error:true} to write to stderr instead of stdout
       */
      help(contextOptions) {
        this.outputHelp(contextOptions);
        let exitCode = process3.exitCode || 0;
        if (exitCode === 0 && contextOptions && typeof contextOptions !== "function" && contextOptions.error) {
          exitCode = 1;
        }
        this._exit(exitCode, "commander.help", "(outputHelp)");
      }
      /**
       * Add additional text to be displayed with the built-in help.
       *
       * Position is 'before' or 'after' to affect just this command,
       * and 'beforeAll' or 'afterAll' to affect this command and all its subcommands.
       *
       * @param {string} position - before or after built-in help
       * @param {(string | Function)} text - string to add, or a function returning a string
       * @return {Command} `this` command for chaining
       */
      addHelpText(position, text) {
        const allowedValues = ["beforeAll", "before", "after", "afterAll"];
        if (!allowedValues.includes(position)) {
          throw new Error(`Unexpected value for position to addHelpText.
Expecting one of '${allowedValues.join("', '")}'`);
        }
        const helpEvent = `${position}Help`;
        this.on(helpEvent, (context) => {
          let helpStr;
          if (typeof text === "function") {
            helpStr = text({ error: context.error, command: context.command });
          } else {
            helpStr = text;
          }
          if (helpStr) {
            context.write(`${helpStr}
`);
          }
        });
        return this;
      }
      /**
       * Output help information if help flags specified
       *
       * @param {Array} args - array of options to search for help flags
       * @private
       */
      _outputHelpIfRequested(args) {
        const helpOption = this._getHelpOption();
        const helpRequested = helpOption && args.find((arg) => helpOption.is(arg));
        if (helpRequested) {
          this.outputHelp();
          this._exit(0, "commander.helpDisplayed", "(outputHelp)");
        }
      }
    };
    function incrementNodeInspectorPort(args) {
      return args.map((arg) => {
        if (!arg.startsWith("--inspect")) {
          return arg;
        }
        let debugOption;
        let debugHost = "127.0.0.1";
        let debugPort = "9229";
        let match;
        if ((match = arg.match(/^(--inspect(-brk)?)$/)) !== null) {
          debugOption = match[1];
        } else if ((match = arg.match(/^(--inspect(-brk|-port)?)=([^:]+)$/)) !== null) {
          debugOption = match[1];
          if (/^\d+$/.test(match[3])) {
            debugPort = match[3];
          } else {
            debugHost = match[3];
          }
        } else if ((match = arg.match(/^(--inspect(-brk|-port)?)=([^:]+):(\d+)$/)) !== null) {
          debugOption = match[1];
          debugHost = match[3];
          debugPort = match[4];
        }
        if (debugOption && debugPort !== "0") {
          return `${debugOption}=${debugHost}:${parseInt(debugPort) + 1}`;
        }
        return arg;
      });
    }
    exports.Command = Command2;
  }
});

// ../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/index.js
var require_commander = __commonJS({
  "../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/index.js"(exports) {
    var { Argument: Argument2 } = require_argument();
    var { Command: Command2 } = require_command();
    var { CommanderError: CommanderError2, InvalidArgumentError: InvalidArgumentError2 } = require_error();
    var { Help: Help2 } = require_help();
    var { Option: Option2 } = require_option();
    exports.program = new Command2();
    exports.createCommand = (name) => new Command2(name);
    exports.createOption = (flags, description) => new Option2(flags, description);
    exports.createArgument = (name, description) => new Argument2(name, description);
    exports.Command = Command2;
    exports.Option = Option2;
    exports.Argument = Argument2;
    exports.Help = Help2;
    exports.CommanderError = CommanderError2;
    exports.InvalidArgumentError = InvalidArgumentError2;
    exports.InvalidOptionArgumentError = InvalidArgumentError2;
  }
});

// src/cli.ts
import { rmSync as rmSync6 } from "node:fs";
import { join as join9 } from "node:path";

// ../../node_modules/.pnpm/commander@12.1.0/node_modules/commander/esm.mjs
var import_index = __toESM(require_commander(), 1);
var {
  program,
  createCommand,
  createArgument,
  createOption,
  CommanderError,
  InvalidArgumentError,
  InvalidOptionArgumentError,
  // deprecated old name
  Command,
  Argument,
  Option,
  Help
} = import_index.default;

// src/cli.ts
import { ensureBrowser as ensureBrowser2 } from "@remotion/renderer";

// ../shared/src/ids.ts
var newId = () => globalThis.crypto.randomUUID().replace(/-/g, "").slice(0, 12);

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/external.js
var external_exports = {};
__export(external_exports, {
  BRAND: () => BRAND,
  DIRTY: () => DIRTY,
  EMPTY_PATH: () => EMPTY_PATH,
  INVALID: () => INVALID,
  NEVER: () => NEVER,
  OK: () => OK,
  ParseStatus: () => ParseStatus,
  Schema: () => ZodType,
  ZodAny: () => ZodAny,
  ZodArray: () => ZodArray,
  ZodBigInt: () => ZodBigInt,
  ZodBoolean: () => ZodBoolean,
  ZodBranded: () => ZodBranded,
  ZodCatch: () => ZodCatch,
  ZodDate: () => ZodDate,
  ZodDefault: () => ZodDefault,
  ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
  ZodEffects: () => ZodEffects,
  ZodEnum: () => ZodEnum,
  ZodError: () => ZodError,
  ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
  ZodFunction: () => ZodFunction,
  ZodIntersection: () => ZodIntersection,
  ZodIssueCode: () => ZodIssueCode,
  ZodLazy: () => ZodLazy,
  ZodLiteral: () => ZodLiteral,
  ZodMap: () => ZodMap,
  ZodNaN: () => ZodNaN,
  ZodNativeEnum: () => ZodNativeEnum,
  ZodNever: () => ZodNever,
  ZodNull: () => ZodNull,
  ZodNullable: () => ZodNullable,
  ZodNumber: () => ZodNumber,
  ZodObject: () => ZodObject,
  ZodOptional: () => ZodOptional,
  ZodParsedType: () => ZodParsedType,
  ZodPipeline: () => ZodPipeline,
  ZodPromise: () => ZodPromise,
  ZodReadonly: () => ZodReadonly,
  ZodRecord: () => ZodRecord,
  ZodSchema: () => ZodType,
  ZodSet: () => ZodSet,
  ZodString: () => ZodString,
  ZodSymbol: () => ZodSymbol,
  ZodTransformer: () => ZodEffects,
  ZodTuple: () => ZodTuple,
  ZodType: () => ZodType,
  ZodUndefined: () => ZodUndefined,
  ZodUnion: () => ZodUnion,
  ZodUnknown: () => ZodUnknown,
  ZodVoid: () => ZodVoid,
  addIssueToContext: () => addIssueToContext,
  any: () => anyType,
  array: () => arrayType,
  bigint: () => bigIntType,
  boolean: () => booleanType,
  coerce: () => coerce,
  custom: () => custom,
  date: () => dateType,
  datetimeRegex: () => datetimeRegex,
  defaultErrorMap: () => en_default,
  discriminatedUnion: () => discriminatedUnionType,
  effect: () => effectsType,
  enum: () => enumType,
  function: () => functionType,
  getErrorMap: () => getErrorMap,
  getParsedType: () => getParsedType,
  instanceof: () => instanceOfType,
  intersection: () => intersectionType,
  isAborted: () => isAborted,
  isAsync: () => isAsync,
  isDirty: () => isDirty,
  isValid: () => isValid,
  late: () => late,
  lazy: () => lazyType,
  literal: () => literalType,
  makeIssue: () => makeIssue,
  map: () => mapType,
  nan: () => nanType,
  nativeEnum: () => nativeEnumType,
  never: () => neverType,
  null: () => nullType,
  nullable: () => nullableType,
  number: () => numberType,
  object: () => objectType,
  objectUtil: () => objectUtil,
  oboolean: () => oboolean,
  onumber: () => onumber,
  optional: () => optionalType,
  ostring: () => ostring,
  pipeline: () => pipelineType,
  preprocess: () => preprocessType,
  promise: () => promiseType,
  quotelessJson: () => quotelessJson,
  record: () => recordType,
  set: () => setType,
  setErrorMap: () => setErrorMap,
  strictObject: () => strictObjectType,
  string: () => stringType,
  symbol: () => symbolType,
  transformer: () => effectsType,
  tuple: () => tupleType,
  undefined: () => undefinedType,
  union: () => unionType,
  unknown: () => unknownType,
  util: () => util,
  void: () => voidType
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/util.js
var util;
(function(util2) {
  util2.assertEqual = (_) => {
  };
  function assertIs(_arg) {
  }
  util2.assertIs = assertIs;
  function assertNever(_x) {
    throw new Error();
  }
  util2.assertNever = assertNever;
  util2.arrayToEnum = (items) => {
    const obj = {};
    for (const item of items) {
      obj[item] = item;
    }
    return obj;
  };
  util2.getValidEnumValues = (obj) => {
    const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
    const filtered = {};
    for (const k of validKeys) {
      filtered[k] = obj[k];
    }
    return util2.objectValues(filtered);
  };
  util2.objectValues = (obj) => {
    return util2.objectKeys(obj).map(function(e) {
      return obj[e];
    });
  };
  util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
    const keys = [];
    for (const key in object) {
      if (Object.prototype.hasOwnProperty.call(object, key)) {
        keys.push(key);
      }
    }
    return keys;
  };
  util2.find = (arr, checker) => {
    for (const item of arr) {
      if (checker(item))
        return item;
    }
    return void 0;
  };
  util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
  function joinValues(array, separator = " | ") {
    return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
  }
  util2.joinValues = joinValues;
  util2.jsonStringifyReplacer = (_, value) => {
    if (typeof value === "bigint") {
      return value.toString();
    }
    return value;
  };
})(util || (util = {}));
var objectUtil;
(function(objectUtil2) {
  objectUtil2.mergeShapes = (first, second) => {
    return {
      ...first,
      ...second
      // second overwrites first
    };
  };
})(objectUtil || (objectUtil = {}));
var ZodParsedType = util.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]);
var getParsedType = (data) => {
  const t = typeof data;
  switch (t) {
    case "undefined":
      return ZodParsedType.undefined;
    case "string":
      return ZodParsedType.string;
    case "number":
      return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
    case "boolean":
      return ZodParsedType.boolean;
    case "function":
      return ZodParsedType.function;
    case "bigint":
      return ZodParsedType.bigint;
    case "symbol":
      return ZodParsedType.symbol;
    case "object":
      if (Array.isArray(data)) {
        return ZodParsedType.array;
      }
      if (data === null) {
        return ZodParsedType.null;
      }
      if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
        return ZodParsedType.promise;
      }
      if (typeof Map !== "undefined" && data instanceof Map) {
        return ZodParsedType.map;
      }
      if (typeof Set !== "undefined" && data instanceof Set) {
        return ZodParsedType.set;
      }
      if (typeof Date !== "undefined" && data instanceof Date) {
        return ZodParsedType.date;
      }
      return ZodParsedType.object;
    default:
      return ZodParsedType.unknown;
  }
};

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/ZodError.js
var ZodIssueCode = util.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
var quotelessJson = (obj) => {
  const json = JSON.stringify(obj, null, 2);
  return json.replace(/"([^"]+)":/g, "$1:");
};
var ZodError = class _ZodError extends Error {
  get errors() {
    return this.issues;
  }
  constructor(issues) {
    super();
    this.issues = [];
    this.addIssue = (sub) => {
      this.issues = [...this.issues, sub];
    };
    this.addIssues = (subs = []) => {
      this.issues = [...this.issues, ...subs];
    };
    const actualProto = new.target.prototype;
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(this, actualProto);
    } else {
      this.__proto__ = actualProto;
    }
    this.name = "ZodError";
    this.issues = issues;
  }
  format(_mapper) {
    const mapper = _mapper || function(issue) {
      return issue.message;
    };
    const fieldErrors = { _errors: [] };
    const processError = (error) => {
      for (const issue of error.issues) {
        if (issue.code === "invalid_union") {
          issue.unionErrors.map(processError);
        } else if (issue.code === "invalid_return_type") {
          processError(issue.returnTypeError);
        } else if (issue.code === "invalid_arguments") {
          processError(issue.argumentsError);
        } else if (issue.path.length === 0) {
          fieldErrors._errors.push(mapper(issue));
        } else {
          let curr = fieldErrors;
          let i = 0;
          while (i < issue.path.length) {
            const el = issue.path[i];
            const terminal = i === issue.path.length - 1;
            if (!terminal) {
              curr[el] = curr[el] || { _errors: [] };
            } else {
              curr[el] = curr[el] || { _errors: [] };
              curr[el]._errors.push(mapper(issue));
            }
            curr = curr[el];
            i++;
          }
        }
      }
    };
    processError(this);
    return fieldErrors;
  }
  static assert(value) {
    if (!(value instanceof _ZodError)) {
      throw new Error(`Not a ZodError: ${value}`);
    }
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(mapper = (issue) => issue.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of this.issues) {
      if (sub.path.length > 0) {
        const firstEl = sub.path[0];
        fieldErrors[firstEl] = fieldErrors[firstEl] || [];
        fieldErrors[firstEl].push(mapper(sub));
      } else {
        formErrors.push(mapper(sub));
      }
    }
    return { formErrors, fieldErrors };
  }
  get formErrors() {
    return this.flatten();
  }
};
ZodError.create = (issues) => {
  const error = new ZodError(issues);
  return error;
};

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/locales/en.js
var errorMap = (issue, _ctx) => {
  let message;
  switch (issue.code) {
    case ZodIssueCode.invalid_type:
      if (issue.received === ZodParsedType.undefined) {
        message = "Required";
      } else {
        message = `Expected ${issue.expected}, received ${issue.received}`;
      }
      break;
    case ZodIssueCode.invalid_literal:
      message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
      break;
    case ZodIssueCode.unrecognized_keys:
      message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
      break;
    case ZodIssueCode.invalid_union:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_union_discriminator:
      message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
      break;
    case ZodIssueCode.invalid_enum_value:
      message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
      break;
    case ZodIssueCode.invalid_arguments:
      message = `Invalid function arguments`;
      break;
    case ZodIssueCode.invalid_return_type:
      message = `Invalid function return type`;
      break;
    case ZodIssueCode.invalid_date:
      message = `Invalid date`;
      break;
    case ZodIssueCode.invalid_string:
      if (typeof issue.validation === "object") {
        if ("includes" in issue.validation) {
          message = `Invalid input: must include "${issue.validation.includes}"`;
          if (typeof issue.validation.position === "number") {
            message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
          }
        } else if ("startsWith" in issue.validation) {
          message = `Invalid input: must start with "${issue.validation.startsWith}"`;
        } else if ("endsWith" in issue.validation) {
          message = `Invalid input: must end with "${issue.validation.endsWith}"`;
        } else {
          util.assertNever(issue.validation);
        }
      } else if (issue.validation !== "regex") {
        message = `Invalid ${issue.validation}`;
      } else {
        message = "Invalid";
      }
      break;
    case ZodIssueCode.too_small:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "bigint")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.too_big:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "bigint")
        message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.custom:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_intersection_types:
      message = `Intersection results could not be merged`;
      break;
    case ZodIssueCode.not_multiple_of:
      message = `Number must be a multiple of ${issue.multipleOf}`;
      break;
    case ZodIssueCode.not_finite:
      message = "Number must be finite";
      break;
    default:
      message = _ctx.defaultError;
      util.assertNever(issue);
  }
  return { message };
};
var en_default = errorMap;

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/errors.js
var overrideErrorMap = en_default;
function setErrorMap(map) {
  overrideErrorMap = map;
}
function getErrorMap() {
  return overrideErrorMap;
}

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/parseUtil.js
var makeIssue = (params) => {
  const { data, path: path2, errorMaps, issueData } = params;
  const fullPath = [...path2, ...issueData.path || []];
  const fullIssue = {
    ...issueData,
    path: fullPath
  };
  if (issueData.message !== void 0) {
    return {
      ...issueData,
      path: fullPath,
      message: issueData.message
    };
  }
  let errorMessage = "";
  const maps = errorMaps.filter((m) => !!m).slice().reverse();
  for (const map of maps) {
    errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
  }
  return {
    ...issueData,
    path: fullPath,
    message: errorMessage
  };
};
var EMPTY_PATH = [];
function addIssueToContext(ctx, issueData) {
  const overrideMap = getErrorMap();
  const issue = makeIssue({
    issueData,
    data: ctx.data,
    path: ctx.path,
    errorMaps: [
      ctx.common.contextualErrorMap,
      // contextual error map is first priority
      ctx.schemaErrorMap,
      // then schema-bound map if available
      overrideMap,
      // then global override map
      overrideMap === en_default ? void 0 : en_default
      // then global default map
    ].filter((x) => !!x)
  });
  ctx.common.issues.push(issue);
}
var ParseStatus = class _ParseStatus {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    if (this.value === "valid")
      this.value = "dirty";
  }
  abort() {
    if (this.value !== "aborted")
      this.value = "aborted";
  }
  static mergeArray(status, results) {
    const arrayValue = [];
    for (const s of results) {
      if (s.status === "aborted")
        return INVALID;
      if (s.status === "dirty")
        status.dirty();
      arrayValue.push(s.value);
    }
    return { status: status.value, value: arrayValue };
  }
  static async mergeObjectAsync(status, pairs) {
    const syncPairs = [];
    for (const pair of pairs) {
      const key = await pair.key;
      const value = await pair.value;
      syncPairs.push({
        key,
        value
      });
    }
    return _ParseStatus.mergeObjectSync(status, syncPairs);
  }
  static mergeObjectSync(status, pairs) {
    const finalObject = {};
    for (const pair of pairs) {
      const { key, value } = pair;
      if (key.status === "aborted")
        return INVALID;
      if (value.status === "aborted")
        return INVALID;
      if (key.status === "dirty")
        status.dirty();
      if (value.status === "dirty")
        status.dirty();
      if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
        finalObject[key.value] = value.value;
      }
    }
    return { status: status.value, value: finalObject };
  }
};
var INVALID = Object.freeze({
  status: "aborted"
});
var DIRTY = (value) => ({ status: "dirty", value });
var OK = (value) => ({ status: "valid", value });
var isAborted = (x) => x.status === "aborted";
var isDirty = (x) => x.status === "dirty";
var isValid = (x) => x.status === "valid";
var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil2) {
  errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
  errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
  constructor(parent, value, path2, key) {
    this._cachedPath = [];
    this.parent = parent;
    this.data = value;
    this._path = path2;
    this._key = key;
  }
  get path() {
    if (!this._cachedPath.length) {
      if (Array.isArray(this._key)) {
        this._cachedPath.push(...this._path, ...this._key);
      } else {
        this._cachedPath.push(...this._path, this._key);
      }
    }
    return this._cachedPath;
  }
};
var handleResult = (ctx, result) => {
  if (isValid(result)) {
    return { success: true, data: result.value };
  } else {
    if (!ctx.common.issues.length) {
      throw new Error("Validation failed but no issues detected.");
    }
    return {
      success: false,
      get error() {
        if (this._error)
          return this._error;
        const error = new ZodError(ctx.common.issues);
        this._error = error;
        return this._error;
      }
    };
  }
};
function processCreateParams(params) {
  if (!params)
    return {};
  const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
  if (errorMap2 && (invalid_type_error || required_error)) {
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  }
  if (errorMap2)
    return { errorMap: errorMap2, description };
  const customMap = (iss, ctx) => {
    const { message } = params;
    if (iss.code === "invalid_enum_value") {
      return { message: message ?? ctx.defaultError };
    }
    if (typeof ctx.data === "undefined") {
      return { message: message ?? required_error ?? ctx.defaultError };
    }
    if (iss.code !== "invalid_type")
      return { message: ctx.defaultError };
    return { message: message ?? invalid_type_error ?? ctx.defaultError };
  };
  return { errorMap: customMap, description };
}
var ZodType = class {
  get description() {
    return this._def.description;
  }
  _getType(input) {
    return getParsedType(input.data);
  }
  _getOrReturnCtx(input, ctx) {
    return ctx || {
      common: input.parent.common,
      data: input.data,
      parsedType: getParsedType(input.data),
      schemaErrorMap: this._def.errorMap,
      path: input.path,
      parent: input.parent
    };
  }
  _processInputParams(input) {
    return {
      status: new ParseStatus(),
      ctx: {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      }
    };
  }
  _parseSync(input) {
    const result = this._parse(input);
    if (isAsync(result)) {
      throw new Error("Synchronous parse encountered promise.");
    }
    return result;
  }
  _parseAsync(input) {
    const result = this._parse(input);
    return Promise.resolve(result);
  }
  parse(data, params) {
    const result = this.safeParse(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  safeParse(data, params) {
    const ctx = {
      common: {
        issues: [],
        async: params?.async ?? false,
        contextualErrorMap: params?.errorMap
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const result = this._parseSync({ data, path: ctx.path, parent: ctx });
    return handleResult(ctx, result);
  }
  "~validate"(data) {
    const ctx = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    if (!this["~standard"].async) {
      try {
        const result = this._parseSync({ data, path: [], parent: ctx });
        return isValid(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        };
      } catch (err) {
        if (err?.message?.toLowerCase()?.includes("encountered")) {
          this["~standard"].async = true;
        }
        ctx.common = {
          issues: [],
          async: true
        };
      }
    }
    return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
      value: result.value
    } : {
      issues: ctx.common.issues
    });
  }
  async parseAsync(data, params) {
    const result = await this.safeParseAsync(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  async safeParseAsync(data, params) {
    const ctx = {
      common: {
        issues: [],
        contextualErrorMap: params?.errorMap,
        async: true
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
    const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
    return handleResult(ctx, result);
  }
  refine(check, message) {
    const getIssueProperties = (val) => {
      if (typeof message === "string" || typeof message === "undefined") {
        return { message };
      } else if (typeof message === "function") {
        return message(val);
      } else {
        return message;
      }
    };
    return this._refinement((val, ctx) => {
      const result = check(val);
      const setError = () => ctx.addIssue({
        code: ZodIssueCode.custom,
        ...getIssueProperties(val)
      });
      if (typeof Promise !== "undefined" && result instanceof Promise) {
        return result.then((data) => {
          if (!data) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      if (!result) {
        setError();
        return false;
      } else {
        return true;
      }
    });
  }
  refinement(check, refinementData) {
    return this._refinement((val, ctx) => {
      if (!check(val)) {
        ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
        return false;
      } else {
        return true;
      }
    });
  }
  _refinement(refinement) {
    return new ZodEffects({
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "refinement", refinement }
    });
  }
  superRefine(refinement) {
    return this._refinement(refinement);
  }
  constructor(def) {
    this.spa = this.safeParseAsync;
    this._def = def;
    this.parse = this.parse.bind(this);
    this.safeParse = this.safeParse.bind(this);
    this.parseAsync = this.parseAsync.bind(this);
    this.safeParseAsync = this.safeParseAsync.bind(this);
    this.spa = this.spa.bind(this);
    this.refine = this.refine.bind(this);
    this.refinement = this.refinement.bind(this);
    this.superRefine = this.superRefine.bind(this);
    this.optional = this.optional.bind(this);
    this.nullable = this.nullable.bind(this);
    this.nullish = this.nullish.bind(this);
    this.array = this.array.bind(this);
    this.promise = this.promise.bind(this);
    this.or = this.or.bind(this);
    this.and = this.and.bind(this);
    this.transform = this.transform.bind(this);
    this.brand = this.brand.bind(this);
    this.default = this.default.bind(this);
    this.catch = this.catch.bind(this);
    this.describe = this.describe.bind(this);
    this.pipe = this.pipe.bind(this);
    this.readonly = this.readonly.bind(this);
    this.isNullable = this.isNullable.bind(this);
    this.isOptional = this.isOptional.bind(this);
    this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: (data) => this["~validate"](data)
    };
  }
  optional() {
    return ZodOptional.create(this, this._def);
  }
  nullable() {
    return ZodNullable.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return ZodArray.create(this);
  }
  promise() {
    return ZodPromise.create(this, this._def);
  }
  or(option) {
    return ZodUnion.create([this, option], this._def);
  }
  and(incoming) {
    return ZodIntersection.create(this, incoming, this._def);
  }
  transform(transform) {
    return new ZodEffects({
      ...processCreateParams(this._def),
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "transform", transform }
    });
  }
  default(def) {
    const defaultValueFunc = typeof def === "function" ? def : () => def;
    return new ZodDefault({
      ...processCreateParams(this._def),
      innerType: this,
      defaultValue: defaultValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodDefault
    });
  }
  brand() {
    return new ZodBranded({
      typeName: ZodFirstPartyTypeKind.ZodBranded,
      type: this,
      ...processCreateParams(this._def)
    });
  }
  catch(def) {
    const catchValueFunc = typeof def === "function" ? def : () => def;
    return new ZodCatch({
      ...processCreateParams(this._def),
      innerType: this,
      catchValue: catchValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodCatch
    });
  }
  describe(description) {
    const This = this.constructor;
    return new This({
      ...this._def,
      description
    });
  }
  pipe(target) {
    return ZodPipeline.create(this, target);
  }
  readonly() {
    return ZodReadonly.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
};
var cuidRegex = /^c[^\s-]{8,}$/i;
var cuid2Regex = /^[0-9a-z]+$/;
var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
var nanoidRegex = /^[a-z0-9_-]{21}$/i;
var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
var emojiRegex;
var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
var dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
  let secondsRegexSource = `[0-5]\\d`;
  if (args.precision) {
    secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
  } else if (args.precision == null) {
    secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
  }
  const secondsQuantifier = args.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
  return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
  let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
  const opts = [];
  opts.push(args.local ? `Z?` : `Z`);
  if (args.offset)
    opts.push(`([+-]\\d{2}:?\\d{2})`);
  regex = `${regex}(${opts.join("|")})`;
  return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
  if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
    return true;
  }
  return false;
}
function isValidJWT(jwt, alg) {
  if (!jwtRegex.test(jwt))
    return false;
  try {
    const [header] = jwt.split(".");
    if (!header)
      return false;
    const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
    const decoded = JSON.parse(atob(base64));
    if (typeof decoded !== "object" || decoded === null)
      return false;
    if ("typ" in decoded && decoded?.typ !== "JWT")
      return false;
    if (!decoded.alg)
      return false;
    if (alg && decoded.alg !== alg)
      return false;
    return true;
  } catch {
    return false;
  }
}
function isValidCidr(ip, version) {
  if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
    return true;
  }
  return false;
}
var ZodString = class _ZodString extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = String(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.string) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.string,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.length < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.length > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "length") {
        const tooBig = input.data.length > check.value;
        const tooSmall = input.data.length < check.value;
        if (tooBig || tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          if (tooBig) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          } else if (tooSmall) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          }
          status.dirty();
        }
      } else if (check.kind === "email") {
        if (!emailRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "email",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "emoji") {
        if (!emojiRegex) {
          emojiRegex = new RegExp(_emojiRegex, "u");
        }
        if (!emojiRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "emoji",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "uuid") {
        if (!uuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "uuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "nanoid") {
        if (!nanoidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "nanoid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid") {
        if (!cuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid2") {
        if (!cuid2Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid2",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ulid") {
        if (!ulidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ulid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "url") {
        try {
          new URL(input.data);
        } catch {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "regex") {
        check.regex.lastIndex = 0;
        const testResult = check.regex.test(input.data);
        if (!testResult) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "regex",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "trim") {
        input.data = input.data.trim();
      } else if (check.kind === "includes") {
        if (!input.data.includes(check.value, check.position)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { includes: check.value, position: check.position },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "toLowerCase") {
        input.data = input.data.toLowerCase();
      } else if (check.kind === "toUpperCase") {
        input.data = input.data.toUpperCase();
      } else if (check.kind === "startsWith") {
        if (!input.data.startsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { startsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "endsWith") {
        if (!input.data.endsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { endsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "datetime") {
        const regex = datetimeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "datetime",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "date") {
        const regex = dateRegex;
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "date",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "time") {
        const regex = timeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "time",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "duration") {
        if (!durationRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "duration",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ip") {
        if (!isValidIP(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ip",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "jwt") {
        if (!isValidJWT(input.data, check.alg)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "jwt",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cidr") {
        if (!isValidCidr(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cidr",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64") {
        if (!base64Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64url") {
        if (!base64urlRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _regex(regex, validation, message) {
    return this.refinement((data) => regex.test(data), {
      validation,
      code: ZodIssueCode.invalid_string,
      ...errorUtil.errToObj(message)
    });
  }
  _addCheck(check) {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  email(message) {
    return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
  }
  url(message) {
    return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
  }
  emoji(message) {
    return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
  }
  uuid(message) {
    return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
  }
  nanoid(message) {
    return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
  }
  cuid(message) {
    return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
  }
  cuid2(message) {
    return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
  }
  ulid(message) {
    return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
  }
  base64(message) {
    return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
  }
  base64url(message) {
    return this._addCheck({
      kind: "base64url",
      ...errorUtil.errToObj(message)
    });
  }
  jwt(options) {
    return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
  }
  ip(options) {
    return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
  }
  cidr(options) {
    return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
  }
  datetime(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "datetime",
        precision: null,
        offset: false,
        local: false,
        message: options
      });
    }
    return this._addCheck({
      kind: "datetime",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      offset: options?.offset ?? false,
      local: options?.local ?? false,
      ...errorUtil.errToObj(options?.message)
    });
  }
  date(message) {
    return this._addCheck({ kind: "date", message });
  }
  time(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "time",
        precision: null,
        message: options
      });
    }
    return this._addCheck({
      kind: "time",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      ...errorUtil.errToObj(options?.message)
    });
  }
  duration(message) {
    return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
  }
  regex(regex, message) {
    return this._addCheck({
      kind: "regex",
      regex,
      ...errorUtil.errToObj(message)
    });
  }
  includes(value, options) {
    return this._addCheck({
      kind: "includes",
      value,
      position: options?.position,
      ...errorUtil.errToObj(options?.message)
    });
  }
  startsWith(value, message) {
    return this._addCheck({
      kind: "startsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  endsWith(value, message) {
    return this._addCheck({
      kind: "endsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  min(minLength, message) {
    return this._addCheck({
      kind: "min",
      value: minLength,
      ...errorUtil.errToObj(message)
    });
  }
  max(maxLength, message) {
    return this._addCheck({
      kind: "max",
      value: maxLength,
      ...errorUtil.errToObj(message)
    });
  }
  length(len, message) {
    return this._addCheck({
      kind: "length",
      value: len,
      ...errorUtil.errToObj(message)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(message) {
    return this.min(1, errorUtil.errToObj(message));
  }
  trim() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((ch) => ch.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((ch) => ch.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((ch) => ch.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((ch) => ch.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((ch) => ch.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((ch) => ch.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((ch) => ch.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((ch) => ch.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((ch) => ch.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((ch) => ch.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((ch) => ch.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((ch) => ch.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((ch) => ch.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((ch) => ch.kind === "base64url");
  }
  get minLength() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxLength() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodString.create = (params) => {
  return new ZodString({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodString,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepDecCount = (step.toString().split(".")[1] || "").length;
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
var ZodNumber = class _ZodNumber extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
    this.step = this.multipleOf;
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = Number(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.number) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.number,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "int") {
        if (!util.isInteger(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: "integer",
            received: "float",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (floatSafeRemainder(input.data, check.value) !== 0) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "finite") {
        if (!Number.isFinite(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_finite,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodNumber({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodNumber({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  int(message) {
    return this._addCheck({
      kind: "int",
      message: errorUtil.toString(message)
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  finite(message) {
    return this._addCheck({
      kind: "finite",
      message: errorUtil.toString(message)
    });
  }
  safe(message) {
    return this._addCheck({
      kind: "min",
      inclusive: true,
      value: Number.MIN_SAFE_INTEGER,
      message: errorUtil.toString(message)
    })._addCheck({
      kind: "max",
      inclusive: true,
      value: Number.MAX_SAFE_INTEGER,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
  get isInt() {
    return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
  }
  get isFinite() {
    let max = null;
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
        return true;
      } else if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      } else if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return Number.isFinite(min) && Number.isFinite(max);
  }
};
ZodNumber.create = (params) => {
  return new ZodNumber({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodNumber,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodBigInt = class _ZodBigInt extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
  }
  _parse(input) {
    if (this._def.coerce) {
      try {
        input.data = BigInt(input.data);
      } catch {
        return this._getInvalidInput(input);
      }
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.bigint) {
      return this._getInvalidInput(input);
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            type: "bigint",
            minimum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            type: "bigint",
            maximum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (input.data % check.value !== BigInt(0)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _getInvalidInput(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.bigint,
      received: ctx.parsedType
    });
    return INVALID;
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodBigInt({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodBigInt({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodBigInt.create = (params) => {
  return new ZodBigInt({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodBigInt,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
var ZodBoolean = class extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = Boolean(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.boolean) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.boolean,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodBoolean.create = (params) => {
  return new ZodBoolean({
    typeName: ZodFirstPartyTypeKind.ZodBoolean,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodDate = class _ZodDate extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = new Date(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.date) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.date,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    if (Number.isNaN(input.data.getTime())) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_date
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.getTime() < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            message: check.message,
            inclusive: true,
            exact: false,
            minimum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.getTime() > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            message: check.message,
            inclusive: true,
            exact: false,
            maximum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return {
      status: status.value,
      value: new Date(input.data.getTime())
    };
  }
  _addCheck(check) {
    return new _ZodDate({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  min(minDate, message) {
    return this._addCheck({
      kind: "min",
      value: minDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  max(maxDate, message) {
    return this._addCheck({
      kind: "max",
      value: maxDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  get minDate() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min != null ? new Date(min) : null;
  }
  get maxDate() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max != null ? new Date(max) : null;
  }
};
ZodDate.create = (params) => {
  return new ZodDate({
    checks: [],
    coerce: params?.coerce || false,
    typeName: ZodFirstPartyTypeKind.ZodDate,
    ...processCreateParams(params)
  });
};
var ZodSymbol = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.symbol) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.symbol,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodSymbol.create = (params) => {
  return new ZodSymbol({
    typeName: ZodFirstPartyTypeKind.ZodSymbol,
    ...processCreateParams(params)
  });
};
var ZodUndefined = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.undefined,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodUndefined.create = (params) => {
  return new ZodUndefined({
    typeName: ZodFirstPartyTypeKind.ZodUndefined,
    ...processCreateParams(params)
  });
};
var ZodNull = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.null) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.null,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodNull.create = (params) => {
  return new ZodNull({
    typeName: ZodFirstPartyTypeKind.ZodNull,
    ...processCreateParams(params)
  });
};
var ZodAny = class extends ZodType {
  constructor() {
    super(...arguments);
    this._any = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodAny.create = (params) => {
  return new ZodAny({
    typeName: ZodFirstPartyTypeKind.ZodAny,
    ...processCreateParams(params)
  });
};
var ZodUnknown = class extends ZodType {
  constructor() {
    super(...arguments);
    this._unknown = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodUnknown.create = (params) => {
  return new ZodUnknown({
    typeName: ZodFirstPartyTypeKind.ZodUnknown,
    ...processCreateParams(params)
  });
};
var ZodNever = class extends ZodType {
  _parse(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.never,
      received: ctx.parsedType
    });
    return INVALID;
  }
};
ZodNever.create = (params) => {
  return new ZodNever({
    typeName: ZodFirstPartyTypeKind.ZodNever,
    ...processCreateParams(params)
  });
};
var ZodVoid = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.void,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodVoid.create = (params) => {
  return new ZodVoid({
    typeName: ZodFirstPartyTypeKind.ZodVoid,
    ...processCreateParams(params)
  });
};
var ZodArray = class _ZodArray extends ZodType {
  _parse(input) {
    const { ctx, status } = this._processInputParams(input);
    const def = this._def;
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (def.exactLength !== null) {
      const tooBig = ctx.data.length > def.exactLength.value;
      const tooSmall = ctx.data.length < def.exactLength.value;
      if (tooBig || tooSmall) {
        addIssueToContext(ctx, {
          code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
          minimum: tooSmall ? def.exactLength.value : void 0,
          maximum: tooBig ? def.exactLength.value : void 0,
          type: "array",
          inclusive: true,
          exact: true,
          message: def.exactLength.message
        });
        status.dirty();
      }
    }
    if (def.minLength !== null) {
      if (ctx.data.length < def.minLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.minLength.message
        });
        status.dirty();
      }
    }
    if (def.maxLength !== null) {
      if (ctx.data.length > def.maxLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.maxLength.message
        });
        status.dirty();
      }
    }
    if (ctx.common.async) {
      return Promise.all([...ctx.data].map((item, i) => {
        return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      })).then((result2) => {
        return ParseStatus.mergeArray(status, result2);
      });
    }
    const result = [...ctx.data].map((item, i) => {
      return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
    });
    return ParseStatus.mergeArray(status, result);
  }
  get element() {
    return this._def.type;
  }
  min(minLength, message) {
    return new _ZodArray({
      ...this._def,
      minLength: { value: minLength, message: errorUtil.toString(message) }
    });
  }
  max(maxLength, message) {
    return new _ZodArray({
      ...this._def,
      maxLength: { value: maxLength, message: errorUtil.toString(message) }
    });
  }
  length(len, message) {
    return new _ZodArray({
      ...this._def,
      exactLength: { value: len, message: errorUtil.toString(message) }
    });
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodArray.create = (schema, params) => {
  return new ZodArray({
    type: schema,
    minLength: null,
    maxLength: null,
    exactLength: null,
    typeName: ZodFirstPartyTypeKind.ZodArray,
    ...processCreateParams(params)
  });
};
function deepPartialify(schema) {
  if (schema instanceof ZodObject) {
    const newShape = {};
    for (const key in schema.shape) {
      const fieldSchema = schema.shape[key];
      newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
    }
    return new ZodObject({
      ...schema._def,
      shape: () => newShape
    });
  } else if (schema instanceof ZodArray) {
    return new ZodArray({
      ...schema._def,
      type: deepPartialify(schema.element)
    });
  } else if (schema instanceof ZodOptional) {
    return ZodOptional.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodNullable) {
    return ZodNullable.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodTuple) {
    return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
  } else {
    return schema;
  }
}
var ZodObject = class _ZodObject extends ZodType {
  constructor() {
    super(...arguments);
    this._cached = null;
    this.nonstrict = this.passthrough;
    this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const shape = this._def.shape();
    const keys = util.objectKeys(shape);
    this._cached = { shape, keys };
    return this._cached;
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.object) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const { status, ctx } = this._processInputParams(input);
    const { shape, keys: shapeKeys } = this._getCached();
    const extraKeys = [];
    if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
      for (const key in ctx.data) {
        if (!shapeKeys.includes(key)) {
          extraKeys.push(key);
        }
      }
    }
    const pairs = [];
    for (const key of shapeKeys) {
      const keyValidator = shape[key];
      const value = ctx.data[key];
      pairs.push({
        key: { status: "valid", value: key },
        value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (this._def.catchall instanceof ZodNever) {
      const unknownKeys = this._def.unknownKeys;
      if (unknownKeys === "passthrough") {
        for (const key of extraKeys) {
          pairs.push({
            key: { status: "valid", value: key },
            value: { status: "valid", value: ctx.data[key] }
          });
        }
      } else if (unknownKeys === "strict") {
        if (extraKeys.length > 0) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.unrecognized_keys,
            keys: extraKeys
          });
          status.dirty();
        }
      } else if (unknownKeys === "strip") {
      } else {
        throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
      }
    } else {
      const catchall = this._def.catchall;
      for (const key of extraKeys) {
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: catchall._parse(
            new ParseInputLazyPath(ctx, value, ctx.path, key)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: key in ctx.data
        });
      }
    }
    if (ctx.common.async) {
      return Promise.resolve().then(async () => {
        const syncPairs = [];
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          syncPairs.push({
            key,
            value,
            alwaysSet: pair.alwaysSet
          });
        }
        return syncPairs;
      }).then((syncPairs) => {
        return ParseStatus.mergeObjectSync(status, syncPairs);
      });
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get shape() {
    return this._def.shape();
  }
  strict(message) {
    errorUtil.errToObj;
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strict",
      ...message !== void 0 ? {
        errorMap: (issue, ctx) => {
          const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
          if (issue.code === "unrecognized_keys")
            return {
              message: errorUtil.errToObj(message).message ?? defaultError
            };
          return {
            message: defaultError
          };
        }
      } : {}
    });
  }
  strip() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(augmentation) {
    return new _ZodObject({
      ...this._def,
      shape: () => ({
        ...this._def.shape(),
        ...augmentation
      })
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(merging) {
    const merged = new _ZodObject({
      unknownKeys: merging._def.unknownKeys,
      catchall: merging._def.catchall,
      shape: () => ({
        ...this._def.shape(),
        ...merging._def.shape()
      }),
      typeName: ZodFirstPartyTypeKind.ZodObject
    });
    return merged;
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(key, schema) {
    return this.augment({ [key]: schema });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(index) {
    return new _ZodObject({
      ...this._def,
      catchall: index
    });
  }
  pick(mask) {
    const shape = {};
    for (const key of util.objectKeys(mask)) {
      if (mask[key] && this.shape[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  omit(mask) {
    const shape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (!mask[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return deepPartialify(this);
  }
  partial(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      const fieldSchema = this.shape[key];
      if (mask && !mask[key]) {
        newShape[key] = fieldSchema;
      } else {
        newShape[key] = fieldSchema.optional();
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  required(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (mask && !mask[key]) {
        newShape[key] = this.shape[key];
      } else {
        const fieldSchema = this.shape[key];
        let newField = fieldSchema;
        while (newField instanceof ZodOptional) {
          newField = newField._def.innerType;
        }
        newShape[key] = newField;
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  keyof() {
    return createZodEnum(util.objectKeys(this.shape));
  }
};
ZodObject.create = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.strictCreate = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strict",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.lazycreate = (shape, params) => {
  return new ZodObject({
    shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
var ZodUnion = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const options = this._def.options;
    function handleResults(results) {
      for (const result of results) {
        if (result.result.status === "valid") {
          return result.result;
        }
      }
      for (const result of results) {
        if (result.result.status === "dirty") {
          ctx.common.issues.push(...result.ctx.common.issues);
          return result.result;
        }
      }
      const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return Promise.all(options.map(async (option) => {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          }),
          ctx: childCtx
        };
      })).then(handleResults);
    } else {
      let dirty = void 0;
      const issues = [];
      for (const option of options) {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        const result = option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: childCtx
        });
        if (result.status === "valid") {
          return result;
        } else if (result.status === "dirty" && !dirty) {
          dirty = { result, ctx: childCtx };
        }
        if (childCtx.common.issues.length) {
          issues.push(childCtx.common.issues);
        }
      }
      if (dirty) {
        ctx.common.issues.push(...dirty.ctx.common.issues);
        return dirty.result;
      }
      const unionErrors = issues.map((issues2) => new ZodError(issues2));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
  }
  get options() {
    return this._def.options;
  }
};
ZodUnion.create = (types, params) => {
  return new ZodUnion({
    options: types,
    typeName: ZodFirstPartyTypeKind.ZodUnion,
    ...processCreateParams(params)
  });
};
var getDiscriminator = (type) => {
  if (type instanceof ZodLazy) {
    return getDiscriminator(type.schema);
  } else if (type instanceof ZodEffects) {
    return getDiscriminator(type.innerType());
  } else if (type instanceof ZodLiteral) {
    return [type.value];
  } else if (type instanceof ZodEnum) {
    return type.options;
  } else if (type instanceof ZodNativeEnum) {
    return util.objectValues(type.enum);
  } else if (type instanceof ZodDefault) {
    return getDiscriminator(type._def.innerType);
  } else if (type instanceof ZodUndefined) {
    return [void 0];
  } else if (type instanceof ZodNull) {
    return [null];
  } else if (type instanceof ZodOptional) {
    return [void 0, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodNullable) {
    return [null, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodBranded) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodReadonly) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodCatch) {
    return getDiscriminator(type._def.innerType);
  } else {
    return [];
  }
};
var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const discriminator = this.discriminator;
    const discriminatorValue = ctx.data[discriminator];
    const option = this.optionsMap.get(discriminatorValue);
    if (!option) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union_discriminator,
        options: Array.from(this.optionsMap.keys()),
        path: [discriminator]
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return option._parseAsync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    } else {
      return option._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    }
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(discriminator, options, params) {
    const optionsMap = /* @__PURE__ */ new Map();
    for (const type of options) {
      const discriminatorValues = getDiscriminator(type.shape[discriminator]);
      if (!discriminatorValues.length) {
        throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
      }
      for (const value of discriminatorValues) {
        if (optionsMap.has(value)) {
          throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
        }
        optionsMap.set(value, type);
      }
    }
    return new _ZodDiscriminatedUnion({
      typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
      discriminator,
      options,
      optionsMap,
      ...processCreateParams(params)
    });
  }
};
function mergeValues(a, b) {
  const aType = getParsedType(a);
  const bType = getParsedType(b);
  if (a === b) {
    return { valid: true, data: a };
  } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
    const bKeys = util.objectKeys(b);
    const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a, ...b };
    for (const key of sharedKeys) {
      const sharedValue = mergeValues(a[key], b[key]);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
    if (a.length !== b.length) {
      return { valid: false };
    }
    const newArray = [];
    for (let index = 0; index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
    return { valid: true, data: a };
  } else {
    return { valid: false };
  }
}
var ZodIntersection = class extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const handleParsed = (parsedLeft, parsedRight) => {
      if (isAborted(parsedLeft) || isAborted(parsedRight)) {
        return INVALID;
      }
      const merged = mergeValues(parsedLeft.value, parsedRight.value);
      if (!merged.valid) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_intersection_types
        });
        return INVALID;
      }
      if (isDirty(parsedLeft) || isDirty(parsedRight)) {
        status.dirty();
      }
      return { status: status.value, value: merged.data };
    };
    if (ctx.common.async) {
      return Promise.all([
        this._def.left._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }),
        this._def.right._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        })
      ]).then(([left, right]) => handleParsed(left, right));
    } else {
      return handleParsed(this._def.left._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }), this._def.right._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }));
    }
  }
};
ZodIntersection.create = (left, right, params) => {
  return new ZodIntersection({
    left,
    right,
    typeName: ZodFirstPartyTypeKind.ZodIntersection,
    ...processCreateParams(params)
  });
};
var ZodTuple = class _ZodTuple extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (ctx.data.length < this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_small,
        minimum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      return INVALID;
    }
    const rest = this._def.rest;
    if (!rest && ctx.data.length > this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_big,
        maximum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      status.dirty();
    }
    const items = [...ctx.data].map((item, itemIndex) => {
      const schema = this._def.items[itemIndex] || this._def.rest;
      if (!schema)
        return null;
      return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
    }).filter((x) => !!x);
    if (ctx.common.async) {
      return Promise.all(items).then((results) => {
        return ParseStatus.mergeArray(status, results);
      });
    } else {
      return ParseStatus.mergeArray(status, items);
    }
  }
  get items() {
    return this._def.items;
  }
  rest(rest) {
    return new _ZodTuple({
      ...this._def,
      rest
    });
  }
};
ZodTuple.create = (schemas, params) => {
  if (!Array.isArray(schemas)) {
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  }
  return new ZodTuple({
    items: schemas,
    typeName: ZodFirstPartyTypeKind.ZodTuple,
    rest: null,
    ...processCreateParams(params)
  });
};
var ZodRecord = class _ZodRecord extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const pairs = [];
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    for (const key in ctx.data) {
      pairs.push({
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
        value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (ctx.common.async) {
      return ParseStatus.mergeObjectAsync(status, pairs);
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get element() {
    return this._def.valueType;
  }
  static create(first, second, third) {
    if (second instanceof ZodType) {
      return new _ZodRecord({
        keyType: first,
        valueType: second,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(third)
      });
    }
    return new _ZodRecord({
      keyType: ZodString.create(),
      valueType: first,
      typeName: ZodFirstPartyTypeKind.ZodRecord,
      ...processCreateParams(second)
    });
  }
};
var ZodMap = class extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.map) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.map,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    const pairs = [...ctx.data.entries()].map(([key, value], index) => {
      return {
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
        value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
      };
    });
    if (ctx.common.async) {
      const finalMap = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      });
    } else {
      const finalMap = /* @__PURE__ */ new Map();
      for (const pair of pairs) {
        const key = pair.key;
        const value = pair.value;
        if (key.status === "aborted" || value.status === "aborted") {
          return INVALID;
        }
        if (key.status === "dirty" || value.status === "dirty") {
          status.dirty();
        }
        finalMap.set(key.value, value.value);
      }
      return { status: status.value, value: finalMap };
    }
  }
};
ZodMap.create = (keyType, valueType, params) => {
  return new ZodMap({
    valueType,
    keyType,
    typeName: ZodFirstPartyTypeKind.ZodMap,
    ...processCreateParams(params)
  });
};
var ZodSet = class _ZodSet extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.set) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.set,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const def = this._def;
    if (def.minSize !== null) {
      if (ctx.data.size < def.minSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.minSize.message
        });
        status.dirty();
      }
    }
    if (def.maxSize !== null) {
      if (ctx.data.size > def.maxSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.maxSize.message
        });
        status.dirty();
      }
    }
    const valueType = this._def.valueType;
    function finalizeSet(elements2) {
      const parsedSet = /* @__PURE__ */ new Set();
      for (const element of elements2) {
        if (element.status === "aborted")
          return INVALID;
        if (element.status === "dirty")
          status.dirty();
        parsedSet.add(element.value);
      }
      return { status: status.value, value: parsedSet };
    }
    const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
    if (ctx.common.async) {
      return Promise.all(elements).then((elements2) => finalizeSet(elements2));
    } else {
      return finalizeSet(elements);
    }
  }
  min(minSize, message) {
    return new _ZodSet({
      ...this._def,
      minSize: { value: minSize, message: errorUtil.toString(message) }
    });
  }
  max(maxSize, message) {
    return new _ZodSet({
      ...this._def,
      maxSize: { value: maxSize, message: errorUtil.toString(message) }
    });
  }
  size(size, message) {
    return this.min(size, message).max(size, message);
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodSet.create = (valueType, params) => {
  return new ZodSet({
    valueType,
    minSize: null,
    maxSize: null,
    typeName: ZodFirstPartyTypeKind.ZodSet,
    ...processCreateParams(params)
  });
};
var ZodFunction = class _ZodFunction extends ZodType {
  constructor() {
    super(...arguments);
    this.validate = this.implement;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.function) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.function,
        received: ctx.parsedType
      });
      return INVALID;
    }
    function makeArgsIssue(args, error) {
      return makeIssue({
        data: args,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_arguments,
          argumentsError: error
        }
      });
    }
    function makeReturnsIssue(returns, error) {
      return makeIssue({
        data: returns,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_return_type,
          returnTypeError: error
        }
      });
    }
    const params = { errorMap: ctx.common.contextualErrorMap };
    const fn = ctx.data;
    if (this._def.returns instanceof ZodPromise) {
      const me = this;
      return OK(async function(...args) {
        const error = new ZodError([]);
        const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
          error.addIssue(makeArgsIssue(args, e));
          throw error;
        });
        const result = await Reflect.apply(fn, this, parsedArgs);
        const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
          error.addIssue(makeReturnsIssue(result, e));
          throw error;
        });
        return parsedReturns;
      });
    } else {
      const me = this;
      return OK(function(...args) {
        const parsedArgs = me._def.args.safeParse(args, params);
        if (!parsedArgs.success) {
          throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
        }
        const result = Reflect.apply(fn, this, parsedArgs.data);
        const parsedReturns = me._def.returns.safeParse(result, params);
        if (!parsedReturns.success) {
          throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
        }
        return parsedReturns.data;
      });
    }
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...items) {
    return new _ZodFunction({
      ...this._def,
      args: ZodTuple.create(items).rest(ZodUnknown.create())
    });
  }
  returns(returnType) {
    return new _ZodFunction({
      ...this._def,
      returns: returnType
    });
  }
  implement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  strictImplement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  static create(args, returns, params) {
    return new _ZodFunction({
      args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
      returns: returns || ZodUnknown.create(),
      typeName: ZodFirstPartyTypeKind.ZodFunction,
      ...processCreateParams(params)
    });
  }
};
var ZodLazy = class extends ZodType {
  get schema() {
    return this._def.getter();
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const lazySchema = this._def.getter();
    return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
  }
};
ZodLazy.create = (getter, params) => {
  return new ZodLazy({
    getter,
    typeName: ZodFirstPartyTypeKind.ZodLazy,
    ...processCreateParams(params)
  });
};
var ZodLiteral = class extends ZodType {
  _parse(input) {
    if (input.data !== this._def.value) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_literal,
        expected: this._def.value
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
  get value() {
    return this._def.value;
  }
};
ZodLiteral.create = (value, params) => {
  return new ZodLiteral({
    value,
    typeName: ZodFirstPartyTypeKind.ZodLiteral,
    ...processCreateParams(params)
  });
};
function createZodEnum(values, params) {
  return new ZodEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodEnum,
    ...processCreateParams(params)
  });
}
var ZodEnum = class _ZodEnum extends ZodType {
  _parse(input) {
    if (typeof input.data !== "string") {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(this._def.values);
    }
    if (!this._cache.has(input.data)) {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Values() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  extract(values, newDef = this._def) {
    return _ZodEnum.create(values, {
      ...this._def,
      ...newDef
    });
  }
  exclude(values, newDef = this._def) {
    return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
      ...this._def,
      ...newDef
    });
  }
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
  _parse(input) {
    const nativeEnumValues = util.getValidEnumValues(this._def.values);
    const ctx = this._getOrReturnCtx(input);
    if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(util.getValidEnumValues(this._def.values));
    }
    if (!this._cache.has(input.data)) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get enum() {
    return this._def.values;
  }
};
ZodNativeEnum.create = (values, params) => {
  return new ZodNativeEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
    ...processCreateParams(params)
  });
};
var ZodPromise = class extends ZodType {
  unwrap() {
    return this._def.type;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.promise,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
    return OK(promisified.then((data) => {
      return this._def.type.parseAsync(data, {
        path: ctx.path,
        errorMap: ctx.common.contextualErrorMap
      });
    }));
  }
};
ZodPromise.create = (schema, params) => {
  return new ZodPromise({
    type: schema,
    typeName: ZodFirstPartyTypeKind.ZodPromise,
    ...processCreateParams(params)
  });
};
var ZodEffects = class extends ZodType {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const effect = this._def.effect || null;
    const checkCtx = {
      addIssue: (arg) => {
        addIssueToContext(ctx, arg);
        if (arg.fatal) {
          status.abort();
        } else {
          status.dirty();
        }
      },
      get path() {
        return ctx.path;
      }
    };
    checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
    if (effect.type === "preprocess") {
      const processed = effect.transform(ctx.data, checkCtx);
      if (ctx.common.async) {
        return Promise.resolve(processed).then(async (processed2) => {
          if (status.value === "aborted")
            return INVALID;
          const result = await this._def.schema._parseAsync({
            data: processed2,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        });
      } else {
        if (status.value === "aborted")
          return INVALID;
        const result = this._def.schema._parseSync({
          data: processed,
          path: ctx.path,
          parent: ctx
        });
        if (result.status === "aborted")
          return INVALID;
        if (result.status === "dirty")
          return DIRTY(result.value);
        if (status.value === "dirty")
          return DIRTY(result.value);
        return result;
      }
    }
    if (effect.type === "refinement") {
      const executeRefinement = (acc) => {
        const result = effect.refinement(acc, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(result);
        }
        if (result instanceof Promise) {
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        }
        return acc;
      };
      if (ctx.common.async === false) {
        const inner = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inner.status === "aborted")
          return INVALID;
        if (inner.status === "dirty")
          status.dirty();
        executeRefinement(inner.value);
        return { status: status.value, value: inner.value };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          return executeRefinement(inner.value).then(() => {
            return { status: status.value, value: inner.value };
          });
        });
      }
    }
    if (effect.type === "transform") {
      if (ctx.common.async === false) {
        const base = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (!isValid(base))
          return INVALID;
        const result = effect.transform(base.value, checkCtx);
        if (result instanceof Promise) {
          throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
        }
        return { status: status.value, value: result };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
          if (!isValid(base))
            return INVALID;
          return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
            status: status.value,
            value: result
          }));
        });
      }
    }
    util.assertNever(effect);
  }
};
ZodEffects.create = (schema, effect, params) => {
  return new ZodEffects({
    schema,
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    effect,
    ...processCreateParams(params)
  });
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
  return new ZodEffects({
    schema,
    effect: { type: "preprocess", transform: preprocess },
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    ...processCreateParams(params)
  });
};
var ZodOptional = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.undefined) {
      return OK(void 0);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodOptional.create = (type, params) => {
  return new ZodOptional({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodOptional,
    ...processCreateParams(params)
  });
};
var ZodNullable = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.null) {
      return OK(null);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodNullable.create = (type, params) => {
  return new ZodNullable({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodNullable,
    ...processCreateParams(params)
  });
};
var ZodDefault = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    let data = ctx.data;
    if (ctx.parsedType === ZodParsedType.undefined) {
      data = this._def.defaultValue();
    }
    return this._def.innerType._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
};
ZodDefault.create = (type, params) => {
  return new ZodDefault({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodDefault,
    defaultValue: typeof params.default === "function" ? params.default : () => params.default,
    ...processCreateParams(params)
  });
};
var ZodCatch = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const newCtx = {
      ...ctx,
      common: {
        ...ctx.common,
        issues: []
      }
    };
    const result = this._def.innerType._parse({
      data: newCtx.data,
      path: newCtx.path,
      parent: {
        ...newCtx
      }
    });
    if (isAsync(result)) {
      return result.then((result2) => {
        return {
          status: "valid",
          value: result2.status === "valid" ? result2.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      });
    } else {
      return {
        status: "valid",
        value: result.status === "valid" ? result.value : this._def.catchValue({
          get error() {
            return new ZodError(newCtx.common.issues);
          },
          input: newCtx.data
        })
      };
    }
  }
  removeCatch() {
    return this._def.innerType;
  }
};
ZodCatch.create = (type, params) => {
  return new ZodCatch({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodCatch,
    catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
    ...processCreateParams(params)
  });
};
var ZodNaN = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.nan) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.nan,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
};
ZodNaN.create = (params) => {
  return new ZodNaN({
    typeName: ZodFirstPartyTypeKind.ZodNaN,
    ...processCreateParams(params)
  });
};
var BRAND = /* @__PURE__ */ Symbol("zod_brand");
var ZodBranded = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const data = ctx.data;
    return this._def.type._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  unwrap() {
    return this._def.type;
  }
};
var ZodPipeline = class _ZodPipeline extends ZodType {
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.common.async) {
      const handleAsync = async () => {
        const inResult = await this._def.in._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return DIRTY(inResult.value);
        } else {
          return this._def.out._parseAsync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      };
      return handleAsync();
    } else {
      const inResult = this._def.in._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
      if (inResult.status === "aborted")
        return INVALID;
      if (inResult.status === "dirty") {
        status.dirty();
        return {
          status: "dirty",
          value: inResult.value
        };
      } else {
        return this._def.out._parseSync({
          data: inResult.value,
          path: ctx.path,
          parent: ctx
        });
      }
    }
  }
  static create(a, b) {
    return new _ZodPipeline({
      in: a,
      out: b,
      typeName: ZodFirstPartyTypeKind.ZodPipeline
    });
  }
};
var ZodReadonly = class extends ZodType {
  _parse(input) {
    const result = this._def.innerType._parse(input);
    const freeze = (data) => {
      if (isValid(data)) {
        data.value = Object.freeze(data.value);
      }
      return data;
    };
    return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodReadonly.create = (type, params) => {
  return new ZodReadonly({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodReadonly,
    ...processCreateParams(params)
  });
};
function cleanParams(params, data) {
  const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
  const p2 = typeof p === "string" ? { message: p } : p;
  return p2;
}
function custom(check, _params = {}, fatal) {
  if (check)
    return ZodAny.create().superRefine((data, ctx) => {
      const r = check(data);
      if (r instanceof Promise) {
        return r.then((r2) => {
          if (!r2) {
            const params = cleanParams(_params, data);
            const _fatal = params.fatal ?? fatal ?? true;
            ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
          }
        });
      }
      if (!r) {
        const params = cleanParams(_params, data);
        const _fatal = params.fatal ?? fatal ?? true;
        ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
      }
      return;
    });
  return ZodAny.create();
}
var late = {
  object: ZodObject.lazycreate
};
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind2) {
  ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
  ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
  ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
  ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
  ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
  ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
  ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
  ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
  ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
  ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
  ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
  ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
  ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
  ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
  ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
  ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
  ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
  ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
  ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
  ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
  ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
  ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
  ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
  ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
  ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
  ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
  ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
  ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
  ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
  ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
  ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
  ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
  ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
  ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
  ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
  ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
var instanceOfType = (cls, params = {
  message: `Input not instance of ${cls.name}`
}) => custom((data) => data instanceof cls, params);
var stringType = ZodString.create;
var numberType = ZodNumber.create;
var nanType = ZodNaN.create;
var bigIntType = ZodBigInt.create;
var booleanType = ZodBoolean.create;
var dateType = ZodDate.create;
var symbolType = ZodSymbol.create;
var undefinedType = ZodUndefined.create;
var nullType = ZodNull.create;
var anyType = ZodAny.create;
var unknownType = ZodUnknown.create;
var neverType = ZodNever.create;
var voidType = ZodVoid.create;
var arrayType = ZodArray.create;
var objectType = ZodObject.create;
var strictObjectType = ZodObject.strictCreate;
var unionType = ZodUnion.create;
var discriminatedUnionType = ZodDiscriminatedUnion.create;
var intersectionType = ZodIntersection.create;
var tupleType = ZodTuple.create;
var recordType = ZodRecord.create;
var mapType = ZodMap.create;
var setType = ZodSet.create;
var functionType = ZodFunction.create;
var lazyType = ZodLazy.create;
var literalType = ZodLiteral.create;
var enumType = ZodEnum.create;
var nativeEnumType = ZodNativeEnum.create;
var promiseType = ZodPromise.create;
var effectsType = ZodEffects.create;
var optionalType = ZodOptional.create;
var nullableType = ZodNullable.create;
var preprocessType = ZodEffects.createWithPreprocess;
var pipelineType = ZodPipeline.create;
var ostring = () => stringType().optional();
var onumber = () => numberType().optional();
var oboolean = () => booleanType().optional();
var coerce = {
  string: ((arg) => ZodString.create({ ...arg, coerce: true })),
  number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
  boolean: ((arg) => ZodBoolean.create({
    ...arg,
    coerce: true
  })),
  bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
  date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
};
var NEVER = INVALID;

// ../shared/src/doc.ts
var EmotionSchema = external_exports.enum([
  "neutral",
  "excited",
  "funny",
  "serious",
  "sad",
  "angry",
  "surprised",
  "question",
  "hype",
  "calm"
]);
var WordSchema = external_exports.object({
  id: external_exports.string().min(1),
  text: external_exports.string(),
  startMs: external_exports.number().nonnegative(),
  endMs: external_exports.number().nonnegative(),
  confidence: external_exports.number().min(0).max(1).optional(),
  hidden: external_exports.boolean().optional(),
  emphasis: external_exports.enum(["none", "strong", "hero"]).optional(),
  color: external_exports.string().optional(),
  emoji: external_exports.object({ char: external_exports.string(), position: external_exports.enum(["before", "after", "above"]) }).nullable().optional(),
  source: external_exports.object({
    text: external_exports.enum(["asr", "user"]).optional(),
    emphasis: external_exports.enum(["ai", "heuristic", "user"]).optional(),
    emoji: external_exports.enum(["ai", "user"]).optional(),
    /** hidden automatically by the filler filter (reversible) */
    filler: external_exports.boolean().optional()
  }).optional()
});
var CardMetaSchema = external_exports.object({
  emotion: EmotionSchema.optional(),
  emotionSource: external_exports.enum(["ai", "heuristic", "user"]).optional(),
  position: external_exports.object({ x: external_exports.number(), y: external_exports.number() }).nullable().optional(),
  styleOverride: external_exports.record(external_exports.unknown()).nullable().optional()
});
var CaptionDocSchema = external_exports.object({
  version: external_exports.literal(2),
  language: external_exports.string().default("en"),
  direction: external_exports.enum(["ltr", "rtl"]).default("ltr"),
  words: external_exports.array(WordSchema),
  /** ids of words that START a new card (user "split here") */
  manualBreaks: external_exports.array(external_exports.string()).default([]),
  /** ids of words after which an automatic break is forbidden (user "merge") */
  noBreakAfter: external_exports.array(external_exports.string()).default([]),
  /** per-card metadata keyed by the card's FIRST word id */
  cards: external_exports.record(CardMetaSchema).default({}),
  meta: external_exports.object({
    userEdited: external_exports.boolean().default(false),
    createdFromTranscriptId: external_exports.string().optional(),
    enrichedAt: external_exports.string().optional()
  }).default({})
});

// ../shared/src/settings.ts
var PlatformSchema = external_exports.enum(["tiktok", "reels", "shorts", "youtube", "linkedin", "podcast", "custom"]);
var DEFAULT_WORDS_PER_CARD = 3;
var ProjectSettingsSchema = external_exports.object({
  platform: PlatformSchema.default("custom"),
  maxWordsPerCard: external_exports.number().int().min(1).max(12).default(DEFAULT_WORDS_PER_CARD),
  maxLines: external_exports.number().int().min(1).max(3).default(2),
  maxCharsPerLine: external_exports.number().int().min(8).max(60).default(24),
  pauseMs: external_exports.number().min(150).max(1500).default(400),
  holdMs: external_exports.number().min(0).max(1500).default(250),
  minCardMs: external_exports.number().min(200).max(2e3).default(450),
  gapBehavior: external_exports.enum(["hold", "clear"]).default("hold"),
  syncOffsetMs: external_exports.number().min(-1e3).max(1e3).default(0),
  removeFillers: external_exports.boolean().default(false),
  fillerList: external_exports.array(external_exports.string()).default([]),
  profanity: external_exports.enum(["off", "mask", "emoji", "hide"]).default("off"),
  customVocabulary: external_exports.array(external_exports.string()).default([]),
  romanize: external_exports.boolean().default(false),
  language: external_exports.string().default("auto"),
  translateTo: external_exports.string().nullable().default(null),
  bilingual: external_exports.boolean().default(false)
});

// ../shared/src/style.ts
var ACTIVE_EFFECTS = [
  "none",
  "color",
  "pop",
  "box",
  "underline",
  "marker",
  "glow",
  "bounce",
  "shake",
  "fill-sweep",
  "scale-up",
  "outline-fill"
];
var ENTRANCES = [
  "none",
  "fade",
  "rise",
  "drop",
  "pop",
  "zoom",
  "slide-left",
  "slide-right",
  "blur-in",
  "typewriter",
  "wave",
  "flip",
  "elastic",
  "glitch",
  "mask-reveal"
];
var EXITS = ["none", "fade", "fall", "zoom-out", "blur-out", "slide-up"];
var EASINGS = ["linear", "outQuad", "outCubic", "outExpo", "inOutCubic", "spring"];
var Color = external_exports.string();
var Casing = external_exports.enum(["none", "upper", "lower", "title", "sentence"]);
var Stroke = external_exports.object({
  enabled: external_exports.boolean().default(false),
  width: external_exports.number().min(0).max(40).default(4),
  color: Color.default("#000000")
});
var FillSchema = external_exports.discriminatedUnion("type", [
  external_exports.object({ type: external_exports.literal("solid"), color: Color }),
  external_exports.object({
    type: external_exports.literal("gradient"),
    stops: external_exports.array(external_exports.object({ color: Color, at: external_exports.number().min(0).max(1) })).min(2),
    angle: external_exports.number().default(135)
  })
]);
var CaptionStyleSchema = external_exports.object({
  templateId: external_exports.string().default("sentence_highlight"),
  fontId: external_exports.string().default("Montserrat"),
  fontWeight: external_exports.number().int().min(100).max(900).default(800),
  fontStyle: external_exports.enum(["normal", "italic"]).default("normal"),
  /** reference px at 1080 short edge */
  fontSize: external_exports.number().min(12).max(300).default(64),
  casing: Casing.default("none"),
  letterSpacing: external_exports.number().default(0),
  wordSpacing: external_exports.number().default(0),
  lineHeight: external_exports.number().min(0.7).max(2.5).default(1.15),
  align: external_exports.enum(["left", "center", "right"]).default("center"),
  maxWidth: external_exports.number().min(0.3).max(1).default(0.86),
  fill: FillSchema.default({ type: "solid", color: "#FFFFFF" }),
  inactiveOpacity: external_exports.number().min(0).max(1).default(1),
  hero: external_exports.object({
    fontId: external_exports.string().optional(),
    fontWeight: external_exports.number().int().optional(),
    scale: external_exports.number().min(0.5).max(4).default(1.4),
    fill: FillSchema.optional(),
    stroke: Stroke.optional(),
    casing: Casing.optional(),
    rotate: external_exports.number().default(0)
  }).default({}),
  active: external_exports.object({
    effect: external_exports.enum(ACTIVE_EFFECTS).default("color"),
    color: Color.default("#FFE600"),
    scale: external_exports.number().min(0.8).max(2).default(1.08),
    boxColor: Color.optional(),
    boxRadius: external_exports.number().min(0).max(100).default(12)
  }).default({}),
  stroke: Stroke.default({}),
  shadows: external_exports.array(external_exports.object({ x: external_exports.number(), y: external_exports.number(), blur: external_exports.number().min(0), color: Color })).max(12).default([]),
  glow: external_exports.object({
    enabled: external_exports.boolean().default(false),
    color: Color.default("#FFFFFF"),
    radius: external_exports.number().min(0).max(80).default(12),
    intensity: external_exports.number().min(0).max(2).default(0.8)
  }).default({}),
  background: external_exports.object({
    type: external_exports.enum(["none", "pill", "box", "bar", "word-box", "bubble"]).default("none"),
    color: Color.default("#000000"),
    opacity: external_exports.number().min(0).max(1).default(0.7),
    padding: external_exports.number().min(0).max(120).default(16),
    radius: external_exports.number().min(0).max(120).default(16),
    blur: external_exports.number().min(0).max(60).default(0)
  }).default({}),
  /** normalized 0..1 (center of the caption block) */
  position: external_exports.object({ x: external_exports.number().min(0).max(1), y: external_exports.number().min(0).max(1) }).default({ x: 0.5, y: 0.72 }),
  safeBox: external_exports.object({
    top: external_exports.number().min(0).max(0.5),
    bottom: external_exports.number().min(0).max(0.5),
    left: external_exports.number().min(0).max(0.5),
    right: external_exports.number().min(0).max(0.5)
  }).default({ top: 0.06, bottom: 0.1, left: 0.06, right: 0.06 }),
  rotation: external_exports.number().min(-45).max(45).default(0),
  entrance: external_exports.object({
    type: external_exports.enum(ENTRANCES).default("rise"),
    durationMs: external_exports.number().min(0).max(1500).default(220),
    stagger: external_exports.enum(["none", "word", "char"]).default("none"),
    easing: external_exports.enum(EASINGS).default("outExpo")
  }).default({}),
  exit: external_exports.object({ type: external_exports.enum(EXITS).default("none"), durationMs: external_exports.number().min(0).max(1e3).default(120) }).default({}),
  motionIntensity: external_exports.number().min(0).max(2).default(1),
  emotionReactivity: external_exports.number().min(0).max(1).default(0.6),
  emoji: external_exports.object({
    enabled: external_exports.boolean().default(false),
    size: external_exports.number().min(0.5).max(3).default(1),
    animation: external_exports.enum(["pop", "float", "spin", "none"]).default("pop")
  }).default({}),
  templateOptions: external_exports.record(external_exports.unknown()).default({})
});

// ../shared/src/jobs.ts
var JOB_KINDS = ["transcribe", "enrich", "render", "proxy", "thumbnail"];
var WHISPER_MODELS = [
  "tiny",
  "tiny.en",
  "base",
  "base.en",
  "small",
  "small.en",
  "medium",
  "medium.en",
  "large-v1",
  "large-v2",
  "large-v3",
  "large-v3-turbo"
];
var FontRefSchema = external_exports.object({
  family: external_exports.string(),
  weight: external_exports.number().default(400),
  style: external_exports.string().default("normal"),
  url: external_exports.string().url().optional()
});
var TranscribeJobSchema = external_exports.object({
  kind: external_exports.literal("transcribe"),
  videoId: external_exports.string(),
  engine: external_exports.enum(["local", "cloud"]),
  model: external_exports.string().default("small"),
  language: external_exports.string().default("auto"),
  prompt: external_exports.string().optional(),
  romanize: external_exports.boolean().default(false)
});
var EnrichJobSchema = external_exports.object({
  kind: external_exports.literal("enrich"),
  documentRevision: external_exports.number().int(),
  features: external_exports.array(external_exports.enum(["hero", "emoji", "emotion", "fillers"]))
});
var ProxyJobSchema = external_exports.object({ kind: external_exports.literal("proxy"), videoId: external_exports.string(), targetHeight: external_exports.number().default(720) });
var ThumbnailJobSchema = external_exports.object({ kind: external_exports.literal("thumbnail"), videoId: external_exports.string(), atMs: external_exports.number().optional() });
var RENDER_FORMATS = ["mp4", "mov_alpha", "webm_alpha", "png"];
var RenderJobSchema = external_exports.object({
  kind: external_exports.literal("render"),
  exportId: external_exports.string(),
  format: external_exports.enum(RENDER_FORMATS),
  width: external_exports.number().int().positive(),
  height: external_exports.number().int().positive(),
  fps: external_exports.number().positive(),
  crf: external_exports.number().int().min(0).max(51).default(21),
  range: external_exports.object({ startMs: external_exports.number().nonnegative(), endMs: external_exports.number().positive() }).optional(),
  docSnapshot: CaptionDocSchema,
  style: CaptionStyleSchema,
  settings: ProjectSettingsSchema,
  fonts: external_exports.array(FontRefSchema).default([]),
  sourceVideoId: external_exports.string()
});
var JobPayloadSchema = external_exports.discriminatedUnion("kind", [
  TranscribeJobSchema,
  EnrichJobSchema,
  ProxyJobSchema,
  ThumbnailJobSchema,
  RenderJobSchema
]);
var WorkerCapabilitiesSchema = external_exports.object({
  kinds: external_exports.array(external_exports.enum(JOB_KINDS)).default([]),
  whisper: external_exports.object({ installed: external_exports.boolean(), models: external_exports.array(external_exports.string()) }).optional(),
  gpu: external_exports.enum(["nvidia", "apple", "amd"]).nullable().optional(),
  cpuCores: external_exports.number().optional(),
  ramGb: external_exports.number().optional(),
  diskFreeGb: external_exports.number().optional(),
  chromeReady: external_exports.boolean().optional(),
  ffmpeg: external_exports.boolean().optional()
});

// ../shared/src/plans.ts
var PLANS = {
  free: { maxUploadBytes: 50 * 1024 * 1024, maxDurationSec: 5 * 60, cloudAsrMinutesPerMonth: 30, exportRetentionDays: 7, maxProjects: 10 },
  pro: { maxUploadBytes: 2 * 1024 * 1024 * 1024, maxDurationSec: 3 * 3600, cloudAsrMinutesPerMonth: 600, exportRetentionDays: 60, maxProjects: 1e3 }
};

// ../shared/src/api-schemas.ts
var ProbeSchema = external_exports.object({
  durationMs: external_exports.number().nonnegative(),
  width: external_exports.number().int().positive(),
  height: external_exports.number().int().positive(),
  fps: external_exports.number().positive().optional(),
  rotation: external_exports.number().optional(),
  videoCodec: external_exports.string().optional(),
  audioCodec: external_exports.string().optional(),
  hasAudio: external_exports.boolean().optional()
});
var CreateVideoBody = external_exports.object({
  filename: external_exports.string().min(1).max(300),
  size: external_exports.number().int().positive(),
  mime: external_exports.string(),
  probe: ProbeSchema.optional()
});
var CompleteVideoBody = external_exports.object({ needsProxy: external_exports.boolean().optional() }).default({});
var SaveDocumentBody = external_exports.object({
  expectedRevision: external_exports.number().int().nonnegative(),
  doc: CaptionDocSchema
});
var EXPORT_KINDS = ["mp4", "mov_alpha", "webm_alpha", "srt", "vtt", "ass", "txt", "json", "png"];
var CreateExportBody = external_exports.object({
  kind: external_exports.enum(EXPORT_KINDS),
  width: external_exports.number().int().min(64).max(7680).optional(),
  height: external_exports.number().int().min(64).max(7680).optional(),
  fps: external_exports.number().min(1).max(120).optional(),
  crf: external_exports.number().int().min(0).max(51).optional(),
  range: external_exports.object({ startMs: external_exports.number().nonnegative(), endMs: external_exports.number().positive() }).optional()
});
var DeviceStartBody = external_exports.object({
  workerName: external_exports.string().min(1).max(80).default("My Computer"),
  platform: external_exports.string().max(40).optional(),
  version: external_exports.string().max(40).optional()
});
var DeviceTokenBody = external_exports.object({
  deviceCode: external_exports.string().min(16).max(200),
  /** one-click setup codes are created before the computer is known: it names itself when it claims the code */
  workerName: external_exports.string().trim().min(1).max(80).optional(),
  platform: external_exports.string().max(40).optional()
});
var DeviceApproveBody = external_exports.object({ userCode: external_exports.string().min(4).max(20), approve: external_exports.boolean().default(true) });
var HeartbeatBody = external_exports.object({
  version: external_exports.string().max(40).optional(),
  platform: external_exports.string().max(40).optional(),
  capabilities: WorkerCapabilitiesSchema.optional(),
  currentJobId: external_exports.string().uuid().nullable().optional()
});
var ClaimBody = external_exports.object({
  kinds: external_exports.array(external_exports.enum(JOB_KINDS)).min(1),
  /** long-poll: hold the request up to this long waiting for a job (instant pickup without a socket) */
  waitMs: external_exports.number().int().min(0).max(25e3).default(0)
});
var ProgressBody = external_exports.object({
  stage: external_exports.string().max(60),
  progress: external_exports.number().min(0).max(100),
  message: external_exports.string().max(500).optional()
});
var FailBody = external_exports.object({
  errorCode: external_exports.string().max(60).default("WORKER_ERROR"),
  message: external_exports.string().max(2e3),
  retryable: external_exports.boolean().default(false)
});
var TranscribeResult = external_exports.object({
  kind: external_exports.literal("transcribe"),
  engine: external_exports.enum(["whisper_cpp", "groq"]),
  model: external_exports.string(),
  language: external_exports.string().default("en"),
  durationMs: external_exports.number().nonnegative().optional(),
  width: external_exports.number().int().positive().optional(),
  height: external_exports.number().int().positive().optional(),
  words: external_exports.array(WordSchema).max(2e5)
});
var ProxyResult = external_exports.object({ kind: external_exports.literal("proxy"), previewPath: external_exports.string() });
var ThumbnailResult = external_exports.object({ kind: external_exports.literal("thumbnail"), thumbnailPath: external_exports.string() });
var RenderResult = external_exports.object({
  kind: external_exports.literal("render"),
  path: external_exports.string(),
  size: external_exports.number().int().nonnegative(),
  durationMs: external_exports.number().nonnegative().optional(),
  renderMs: external_exports.number().nonnegative().optional()
});
var CompleteBody = external_exports.discriminatedUnion("kind", [TranscribeResult, ProxyResult, ThumbnailResult, RenderResult]);

// src/api.ts
var ApiError = class extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
  status;
  code;
  details;
};
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
var CompanionApi = class {
  constructor(base, token) {
    this.base = base;
    this.token = token;
  }
  base;
  token;
  async req(method, path2, body, opts = {}) {
    const retries = opts.retries ?? 3;
    for (let attempt = 0; ; attempt++) {
      try {
        const res = await fetch(`${this.base.replace(/\/$/, "")}/api/v1${path2}`, {
          method,
          headers: { ...this.token ? { authorization: `Bearer ${this.token}` } : {}, ...body !== void 0 ? { "content-type": "application/json" } : {} },
          body: body !== void 0 ? JSON.stringify(body) : void 0,
          signal: opts.signal
        });
        if (res.status === 204) return null;
        const json = await res.json().catch(() => ({}));
        if (res.ok && json.success !== false) return json.data;
        if (res.status >= 500 && attempt < retries) throw new ApiError(res.status, json.error?.code ?? "SERVER", json.error?.message ?? "server error");
        throw new ApiError(res.status, json.error?.code ?? "UNKNOWN", json.error?.message ?? `HTTP ${res.status}`, json.error?.details);
      } catch (e) {
        const retryable = e instanceof ApiError && e.status >= 500 || !(e instanceof ApiError) && !(e instanceof DOMException && e.name === "AbortError");
        if (!retryable || attempt >= retries) throw e;
        await sleep(Math.min(8e3, 500 * 2 ** attempt) + Math.random() * 300);
      }
    }
  }
  // ---- device flow (unauthenticated)
  deviceStart(body) {
    return this.req("POST", "/device/start", body);
  }
  deviceToken(deviceCode, me) {
    return this.req("POST", "/device/token", { deviceCode, ...me });
  }
  // ---- worker
  heartbeat(body) {
    return this.req("POST", "/worker/heartbeat", body);
  }
  /** Long-polls: the server holds the request up to `waitMs` and answers the moment a job is queued. */
  claim(kinds, waitMs = 0) {
    return this.req("POST", "/worker/jobs/claim", { kinds, waitMs }, { retries: 1 });
  }
  progress(jobId, stage, progress, message) {
    return this.req("POST", `/worker/jobs/${jobId}/progress`, { stage, progress, message }, { retries: 1 });
  }
  complete(jobId, result) {
    return this.req("POST", `/worker/jobs/${jobId}/complete`, result);
  }
  fail(jobId, errorCode, message, retryable) {
    return this.req("POST", `/worker/jobs/${jobId}/fail`, { errorCode, message: message.slice(0, 1900), retryable });
  }
  urls(jobId) {
    return this.req("POST", `/worker/jobs/${jobId}/urls`, {});
  }
};

// src/config.ts
import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

// ../../node_modules/.pnpm/env-paths@3.0.0/node_modules/env-paths/index.js
import path from "node:path";
import os from "node:os";
import process2 from "node:process";
var homedir = os.homedir();
var tmpdir = os.tmpdir();
var { env } = process2;
var macos = (name) => {
  const library = path.join(homedir, "Library");
  return {
    data: path.join(library, "Application Support", name),
    config: path.join(library, "Preferences", name),
    cache: path.join(library, "Caches", name),
    log: path.join(library, "Logs", name),
    temp: path.join(tmpdir, name)
  };
};
var windows = (name) => {
  const appData = env.APPDATA || path.join(homedir, "AppData", "Roaming");
  const localAppData = env.LOCALAPPDATA || path.join(homedir, "AppData", "Local");
  return {
    // Data/config/cache/log are invented by me as Windows isn't opinionated about this
    data: path.join(localAppData, name, "Data"),
    config: path.join(appData, name, "Config"),
    cache: path.join(localAppData, name, "Cache"),
    log: path.join(localAppData, name, "Log"),
    temp: path.join(tmpdir, name)
  };
};
var linux = (name) => {
  const username = path.basename(homedir);
  return {
    data: path.join(env.XDG_DATA_HOME || path.join(homedir, ".local", "share"), name),
    config: path.join(env.XDG_CONFIG_HOME || path.join(homedir, ".config"), name),
    cache: path.join(env.XDG_CACHE_HOME || path.join(homedir, ".cache"), name),
    // https://wiki.debian.org/XDGBaseDirectorySpecification#state
    log: path.join(env.XDG_STATE_HOME || path.join(homedir, ".local", "state"), name),
    temp: path.join(tmpdir, username, name)
  };
};
function envPaths(name, { suffix = "nodejs" } = {}) {
  if (typeof name !== "string") {
    throw new TypeError(`Expected a string, got ${typeof name}`);
  }
  if (suffix) {
    name += `-${suffix}`;
  }
  if (process2.platform === "darwin") {
    return macos(name);
  }
  if (process2.platform === "win32") {
    return windows(name);
  }
  return linux(name);
}

// src/config.ts
var paths = envPaths("capseasy", { suffix: "" });
var dirs = {
  config: paths.config,
  cache: process.env.CAPSEASY_CACHE ?? paths.cache,
  data: process.env.CAPSEASY_DATA ?? paths.data,
  logs: paths.log
};
var file = () => join(process.env.CAPSEASY_CONFIG ?? dirs.config, "config.json");
var DEFAULT_API = process.env.CAPSEASY_API ?? "https://captionseasy.vercel.app";
function ensureDirs() {
  for (const d of [dirs.config, dirs.cache, dirs.data, dirs.logs]) mkdirSync(d, { recursive: true });
}
function loadConfig() {
  const base = { apiBase: DEFAULT_API, whisperModel: "small" };
  try {
    if (existsSync(file())) return { ...base, ...JSON.parse(readFileSync(file(), "utf8")) };
  } catch {
  }
  return base;
}
function saveConfig(cfg) {
  mkdirSync(process.env.CAPSEASY_CONFIG ?? dirs.config, { recursive: true });
  writeFileSync(file(), JSON.stringify(cfg, null, 2), { mode: 384 });
  try {
    chmodSync(file(), 384);
  } catch {
  }
}

// src/login.ts
import { spawn as spawn2 } from "node:child_process";
import { hostname } from "node:os";

// src/log.ts
import { appendFileSync, mkdirSync as mkdirSync2 } from "node:fs";
import { join as join2 } from "node:path";
var ready = false;
var line = (level, msg) => `${(/* @__PURE__ */ new Date()).toISOString()} ${level.padEnd(5)} ${msg}`;
function write(level, msg) {
  const l = line(level, msg);
  (level === "error" ? console.error : console.log)(l);
  try {
    if (!ready) {
      mkdirSync2(dirs.logs, { recursive: true });
      ready = true;
    }
    appendFileSync(join2(dirs.logs, "companion.log"), l + "\n");
  } catch {
  }
}
var log = {
  info: (m) => write("info", m),
  warn: (m) => write("warn", m),
  error: (m) => write("error", m)
};

// src/system.ts
import { statfsSync } from "node:fs";
import { cpus, totalmem } from "node:os";

// src/ffmpeg.ts
import { spawn } from "node:child_process";
import { RenderInternals } from "@remotion/renderer";
function ffmpegPath() {
  return RenderInternals.getExecutablePath({ type: "ffmpeg", indent: false, logLevel: "error", binariesDirectory: null });
}
function ffprobePath() {
  return RenderInternals.getExecutablePath({ type: "ffprobe", indent: false, logLevel: "error", binariesDirectory: null });
}
function run(bin, args, opts = {}) {
  return new Promise((resolve2, reject) => {
    const child = spawn(bin, args, { windowsHide: true });
    let out = "";
    let tail = "";
    const onAbort = () => child.kill("SIGKILL");
    opts.signal?.addEventListener("abort", onAbort, { once: true });
    child.stdout.on("data", (d) => out += d.toString());
    child.stderr.on("data", (d) => {
      const s = d.toString();
      tail = (tail + s).slice(-3e3);
      if (opts.onStderr) {
        for (const l of s.split(/\r?\n|\r/)) if (l) opts.onStderr(l);
      }
    });
    child.on("error", reject);
    child.on("close", (code) => {
      opts.signal?.removeEventListener("abort", onAbort);
      if (opts.signal?.aborted) return reject(new DOMException("Aborted", "AbortError"));
      code === 0 ? resolve2(out) : reject(new Error(`${bin.split(/[\\/]/).pop()} exited with ${code}: ${tail.trim().split("\n").slice(-6).join("\n")}`));
    });
  });
}
function extractWav(input, output, signal) {
  return run(ffmpegPath(), ["-y", "-i", input, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", output], { signal });
}
async function probe(input) {
  const json = await run(ffprobePath(), ["-v", "error", "-print_format", "json", "-show_format", "-show_streams", input]);
  const j = JSON.parse(json);
  const v = j.streams?.find((s) => s.codec_type === "video");
  return {
    durationMs: Math.round(Number(j.format?.duration ?? 0) * 1e3),
    hasAudio: Boolean(j.streams?.some((s) => s.codec_type === "audio")),
    width: v?.width,
    height: v?.height
  };
}
function makeProxy(input, output, height, durationMs, onProgress, signal) {
  return run(
    ffmpegPath(),
    ["-y", "-i", input, "-vf", `scale=-2:${height}`, "-c:v", "libx264", "-preset", "veryfast", "-crf", "26", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", output],
    {
      signal,
      onStderr: (l) => {
        const m = /time=(\d+):(\d+):(\d+\.\d+)/.exec(l);
        if (m && durationMs > 0) onProgress(Math.min(1, (+m[1] * 3600 + +m[2] * 60 + +m[3]) * 1e3 / durationMs));
      }
    }
  );
}

// src/whisper.ts
import { execFile } from "node:child_process";
import { existsSync as existsSync2, mkdirSync as mkdirSync3, readdirSync, rmSync, writeFileSync as writeFileSync2 } from "node:fs";
import { join as join3 } from "node:path";
import { promisify } from "node:util";
import { downloadWhisperModel, installWhisperCpp, toCaptions, transcribe } from "@remotion/install-whisper-cpp";

// ../caption-engine/src/core/normalize.ts
var NOISE = /^\s*[\[(<*♪♫]+\s*(blank[_ ]?audio|music|silence|noise|applause|laughter|inaudible|no speech)?[^\])>*]*[\])>*♪♫]*\s*$/i;
function mergeSubwordTokens(tokens) {
  const out = [];
  for (const t of tokens) {
    const startsWord = /^\s/.test(t.text) || out.length === 0;
    const text = t.text.trim();
    if (!text) continue;
    const last = out[out.length - 1];
    if (!startsWord && last && !/[.!?]$/.test(last.text)) {
      last.text += text;
      last.endMs = Math.max(last.endMs, t.endMs);
      if (t.confidence != null) last.confidence = Math.min(last.confidence ?? 1, t.confidence);
    } else {
      out.push({ ...t, text });
    }
  }
  return out;
}
function normalizeTokens(input, opts = {}) {
  const minMs = opts.minWordMs ?? 40;
  const vocab = new Map((opts.vocabulary ?? []).map((v) => [v.toLowerCase(), v]));
  const cleaned = input.map((t) => ({ ...t, text: t.text.replace(/\s+/g, " ") })).filter((t) => t.text.trim() && !NOISE.test(t.text.trim()) && Number.isFinite(t.startMs) && Number.isFinite(t.endMs));
  cleaned.sort((a, b) => a.startMs - b.startMs || a.endMs - b.endMs);
  const words = [];
  let prevStart = 0;
  for (const t of cleaned) {
    let text = t.text.trim();
    if (opts.romanize && !isAscii(text)) text = opts.romanize(text);
    const canon = vocab.get(text.replace(/[^\p{L}\p{N}'-]/gu, "").toLowerCase());
    if (canon) text = text.replace(/[\p{L}\p{N}'-]+/u, canon);
    const start = Math.max(Math.round(t.startMs), prevStart);
    let end = Math.max(Math.round(t.endMs), start + minMs);
    if (opts.durationMs != null) {
      if (start >= opts.durationMs) continue;
      end = Math.min(end, opts.durationMs);
      if (end - start < 1) continue;
    }
    words.push({
      id: newId(),
      text,
      startMs: start,
      endMs: end,
      ...t.confidence != null ? { confidence: clamp01(t.confidence) } : {},
      source: { text: "asr" }
    });
    prevStart = start;
  }
  for (let i = 0; i < words.length - 1; i++) {
    const cur = words[i];
    const next = words[i + 1];
    if (cur.endMs > next.startMs) cur.endMs = Math.max(cur.startMs + 1, next.startMs);
  }
  return dropRepeatedHallucinations(words);
}
function dropRepeatedHallucinations(words, minRepeats = 4) {
  const norm = (w) => w.text.toLowerCase().replace(/[^\p{L}\p{N}]/gu, "");
  for (const n of [1, 2, 3, 4]) {
    for (let i = 0; i + n * minRepeats <= words.length; i++) {
      let reps = 1;
      while (i + (reps + 1) * n <= words.length && sameRun(words, i, i + reps * n, n, norm)) reps++;
      if (reps >= minRepeats) {
        return dropRepeatedHallucinations([...words.slice(0, i + n), ...words.slice(i + reps * n)], minRepeats);
      }
    }
  }
  return words;
}
function sameRun(w, a, b, n, norm) {
  for (let k = 0; k < n; k++) if (norm(w[a + k]) !== norm(w[b + k]) || !norm(w[a + k])) return false;
  return true;
}
var isAscii = (s) => /^[\x00-\x7F]*$/.test(s);
var clamp01 = (n) => Math.min(1, Math.max(0, n));
function fromWhisperCaptions(captions, opts) {
  return normalizeTokens(mergeSubwordTokens(captions), opts);
}

// ../caption-engine/src/core/filters.ts
var PROFANE = ["fuck", "fucking", "shit", "bitch", "asshole", "bastard", "dick", "cunt", "bullshit", "motherfucker", "damn"];
var PROFANE_SET = new Set(PROFANE);

// src/whisper.ts
var WHISPER_CPP_VERSION = "1.5.5";
var whisperDir = () => join3(dirs.data, "whisper-bin");
var modelsDir = () => join3(dirs.data, "whisper-models");
var exePath = () => join3(whisperDir(), process.platform === "win32" ? "main.exe" : "main");
var whisperInstalled = () => existsSync2(exePath());
var installing = null;
var WIN_ZIP_URL = "https://remotion-ffmpeg-binaries.s3.eu-central-1.amazonaws.com/whisper-bin-x64-1-5-5.zip";
var psQuote = (s) => `'${s.replace(/'/g, "''")}'`;
async function installWindows(to) {
  const res = await fetch(WIN_ZIP_URL);
  if (!res.ok) throw new Error(`download failed (HTTP ${res.status})`);
  const zip = join3(dirs.cache, "whisper-bin-x64.zip");
  writeFileSync2(zip, Buffer.from(await res.arrayBuffer()));
  try {
    await promisify(execFile)("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", `Expand-Archive -Force -LiteralPath ${psQuote(zip)} -DestinationPath ${psQuote(to)}`], { windowsHide: true });
  } finally {
    rmSync(zip, { force: true });
  }
}
function ensureWhisperBinary() {
  if (whisperInstalled()) return Promise.resolve();
  installing ??= (async () => {
    rmSync(whisperDir(), { recursive: true, force: true });
    mkdirSync3(dirs.cache, { recursive: true });
    mkdirSync3(dirs.data, { recursive: true });
    if (process.platform === "win32") {
      await installWindows(whisperDir());
    } else {
      const prev = process.cwd();
      try {
        process.chdir(dirs.cache);
        await installWhisperCpp({ to: whisperDir(), version: WHISPER_CPP_VERSION, printOutput: false });
      } finally {
        process.chdir(prev);
      }
    }
    if (!whisperInstalled()) throw new Error(`the whisper executable was not found at ${exePath()} after installing`);
    log.info("whisper.cpp installed");
  })().catch((e) => {
    installing = null;
    throw new Error(
      `Could not set up whisper.cpp: ${e instanceof Error ? e.message : e}. ` + (process.platform === "win32" ? "Check your internet connection and free disk space." : "It needs git and make (macOS: xcode-select --install; Linux: build-essential).")
    );
  });
  return installing;
}
async function ensureModel(model, onProgress, signal) {
  mkdirSync3(modelsDir(), { recursive: true });
  const r = await downloadWhisperModel({ model, folder: modelsDir(), printOutput: false, signal, onProgress: (downloaded, total) => onProgress?.(total ? downloaded / total : 0) });
  if (!r.alreadyExisted) log.info(`whisper model ${model} downloaded`);
}
function installedModels() {
  try {
    return readdirSync(modelsDir()).filter((f) => /^ggml-.*\.bin$/.test(f)).map((f) => f.replace(/^ggml-/, "").replace(/\.bin$/, ""));
  } catch {
    return [];
  }
}
async function transcribeWav(o) {
  await ensureWhisperBinary();
  const englishOnly = o.model.endsWith(".en");
  const json = await transcribe({
    inputPath: o.wavPath,
    whisperPath: whisperDir(),
    whisperCppVersion: WHISPER_CPP_VERSION,
    model: o.model,
    modelFolder: modelsDir(),
    tokenLevelTimestamps: true,
    language: englishOnly ? "en" : o.language,
    printOutput: false,
    signal: o.signal,
    onProgress: (p) => o.onProgress?.(p)
  });
  const { captions } = toCaptions({ whisperCppOutput: json });
  return { words: fromWhisperCaptions(captions, o.normalize), language: json.result?.language ?? (englishOnly ? "en" : o.language) };
}

// src/system.ts
var VERSION = "0.1.8";
function diskFreeGb(path2 = dirs.cache) {
  try {
    const s = statfsSync(path2);
    return Math.round(s.bavail * s.bsize / 1024 ** 3 * 10) / 10;
  } catch {
    return void 0;
  }
}
async function hasFfmpeg() {
  try {
    await run(ffmpegPath(), ["-version"]);
    return true;
  } catch {
    return false;
  }
}
async function buildCapabilities() {
  return {
    kinds: ["transcribe", "render", "proxy"],
    whisper: { installed: whisperInstalled(), models: installedModels() },
    cpuCores: cpus().length,
    ramGb: Math.round(totalmem() / 1024 ** 3 * 10) / 10,
    diskFreeGb: diskFreeGb(),
    ffmpeg: await hasFfmpeg()
  };
}

// src/login.ts
var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
function openBrowser(url) {
  try {
    const [cmd, args] = process.platform === "win32" ? ["cmd", ["/c", "start", "", url]] : process.platform === "darwin" ? ["open", [url]] : ["xdg-open", [url]];
    spawn2(cmd, args, { stdio: "ignore", detached: true }).unref();
  } catch {
  }
}
async function loginWithPairCode(cfg, opts) {
  ensureDirs();
  const apiBase = (opts.apiBase ?? cfg.apiBase).replace(/\/$/, "");
  const name = opts.name ?? cfg.workerName ?? hostname();
  const api = new CompanionApi(apiBase);
  for (let i = 0; i < 5; i++) {
    const r = await api.deviceToken(opts.pairCode, { workerName: name, platform: process.platform });
    if (r?.status === "approved" && r.token && r.workerId) {
      const next = { ...cfg, apiBase, workerId: r.workerId, token: r.token, workerName: name };
      saveConfig(next);
      log.info(`paired as "${name}" (one-click setup)`);
      console.log(`
  Connected! "${name}" is now linked to your CaptionsEasy account.
`);
      return next;
    }
    if (r?.status === "expired" || r?.status === "denied") break;
    await sleep2(1500);
  }
  throw new Error("This setup link has expired or was already used. Download a fresh one from the CaptionsEasy website.");
}
async function login(cfg, opts = {}) {
  ensureDirs();
  const apiBase = (opts.apiBase ?? cfg.apiBase).replace(/\/$/, "");
  const name = opts.name ?? cfg.workerName ?? hostname();
  const api = new CompanionApi(apiBase);
  const start = await api.deviceStart({ workerName: name, platform: process.platform, version: VERSION });
  if (!start) throw new Error("Could not start pairing.");
  console.log(`
  Pair this computer with your CapsEasy account

  1. Open:  ${start.verificationUrl}
  2. Check the code matches:  ${start.userCode}
  3. Click "Approve"
`);
  if (opts.open !== false) openBrowser(start.verificationUrl);
  const deadline = Date.now() + start.expiresInSeconds * 1e3;
  while (Date.now() < deadline) {
    await sleep2(start.intervalSeconds * 1e3);
    const r = await api.deviceToken(start.deviceCode);
    if (r?.status === "approved" && r.token && r.workerId) {
      const next = { ...cfg, apiBase, workerId: r.workerId, token: r.token, workerName: name };
      saveConfig(next);
      log.info(`paired as "${name}"`);
      console.log("\n  Paired! Start the companion with:  capseasy start\n");
      return next;
    }
    if (r?.status === "denied") throw new Error("Pairing was denied in the browser.");
    if (r?.status === "expired") break;
  }
  throw new Error("Pairing code expired. Run `capseasy login` again.");
}

// src/autostart.ts
import { execFileSync } from "node:child_process";
import { existsSync as existsSync3, mkdirSync as mkdirSync4, rmSync as rmSync2, writeFileSync as writeFileSync3 } from "node:fs";
import { homedir as homedir2 } from "node:os";
import { dirname, join as join4, resolve } from "node:path";
function launchCommand() {
  const entry = resolve(process.argv[1] ?? "");
  const cli = entry.endsWith(".ts") ? join4(dirname(entry), "..", "bin", "capseasy.mjs") : entry;
  return [process.execPath, cli];
}
var LABEL = "app.capseasy.companion";
function autostartPath() {
  if (process.platform === "win32") {
    const appData = process.env.APPDATA ?? join4(homedir2(), "AppData", "Roaming");
    return join4(appData, "Microsoft", "Windows", "Start Menu", "Programs", "Startup", "CapsEasy Companion.vbs");
  }
  if (process.platform === "darwin") return join4(homedir2(), "Library", "LaunchAgents", `${LABEL}.plist`);
  return join4(process.env.XDG_CONFIG_HOME ?? join4(homedir2(), ".config"), "systemd", "user", "capseasy-companion.service");
}
var xml = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
function autostartFile(platform, node, cli, logDir) {
  if (platform === "win32") {
    const q = (s) => s.replace(/"/g, '""');
    return `' CapsEasy Companion: starts at login, hidden. Remove with: capseasy autostart disable\r
CreateObject("WScript.Shell").Run """${q(node)}"" ""${q(cli)}"" start", 0, False\r
`;
  }
  if (platform === "darwin") {
    return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>${LABEL}</string>
  <key>ProgramArguments</key><array><string>${xml(node)}</string><string>${xml(cli)}</string><string>start</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict>
  <key>StandardOutPath</key><string>${xml(join4(logDir, "autostart.log"))}</string>
  <key>StandardErrorPath</key><string>${xml(join4(logDir, "autostart.log"))}</string>
</dict></plist>
`;
  }
  return `[Unit]
Description=CapsEasy Companion (local caption transcription and rendering)
After=network-online.target

[Service]
ExecStart="${node}" "${cli}" start
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
`;
}
function tryRun(cmd, args) {
  try {
    execFileSync(cmd, args, { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}
function enableAutostart(logDir) {
  const [node, cli] = launchCommand();
  const path2 = autostartPath();
  mkdirSync4(dirname(path2), { recursive: true });
  writeFileSync3(path2, autostartFile(process.platform, node, cli, logDir));
  let note = "It will start automatically the next time you log in.";
  if (process.platform === "darwin") {
    tryRun("launchctl", ["unload", path2]);
    if (tryRun("launchctl", ["load", "-w", path2])) note = "Started now and at every login.";
  } else if (process.platform === "linux") {
    if (tryRun("systemctl", ["--user", "daemon-reload"]) && tryRun("systemctl", ["--user", "enable", "--now", "capseasy-companion.service"])) note = "Started now and at every login.";
    else note = "Run: systemctl --user enable --now capseasy-companion.service";
  }
  return { path: path2, note };
}
function disableAutostart() {
  const path2 = autostartPath();
  if (!existsSync3(path2)) return false;
  if (process.platform === "darwin") tryRun("launchctl", ["unload", "-w", path2]);
  if (process.platform === "linux") tryRun("systemctl", ["--user", "disable", "--now", "capseasy-companion.service"]);
  rmSync2(path2, { force: true });
  return true;
}
var autostartEnabled = () => existsSync3(autostartPath());

// src/executors/proxy.ts
import { rmSync as rmSync3, statSync as statSync2 } from "node:fs";
import { join as join6 } from "node:path";

// src/transfer.ts
import { createWriteStream, existsSync as existsSync4, openAsBlob, renameSync, statSync, unlinkSync } from "node:fs";
import { basename } from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
async function downloadTo(url, dest, opts = {}) {
  if (opts.expectedSize && existsSync4(dest) && statSync(dest).size === opts.expectedSize) {
    opts.onProgress?.(1);
    return dest;
  }
  const res = await fetch(url, { signal: opts.signal });
  if (!res.ok || !res.body) throw new Error(`Download failed (HTTP ${res.status})`);
  const total = Number(res.headers.get("content-length") ?? 0);
  let seen = 0;
  const tmp = `${dest}.part`;
  const source = Readable.fromWeb(res.body);
  source.on("data", (c) => {
    seen += c.length;
    if (total) opts.onProgress?.(Math.min(1, seen / total));
  });
  try {
    await pipeline(source, createWriteStream(tmp), { signal: opts.signal });
    renameSync(tmp, dest);
  } catch (e) {
    try {
      unlinkSync(tmp);
    } catch {
    }
    throw e;
  }
  return dest;
}
async function uploadSigned(url, file2, contentType, signal) {
  const blob = await openAsBlob(file2, { type: contentType });
  const form = new FormData();
  form.append("cacheControl", "3600");
  form.append("", blob, basename(file2));
  const res = await fetch(url, { method: "PUT", body: form, headers: { "x-upsert": "true" }, signal });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Upload failed (HTTP ${res.status}) ${text.slice(0, 200)}`);
  }
}

// src/executors/context.ts
import { mkdirSync as mkdirSync5 } from "node:fs";
import { join as join5 } from "node:path";
var mediaCacheDir = () => {
  const d = join5(dirs.cache, "media");
  mkdirSync5(d, { recursive: true });
  return d;
};
var jobDir = (jobId) => {
  const d = join5(dirs.cache, "jobs", jobId);
  mkdirSync5(d, { recursive: true });
  return d;
};
var extOf = (mime) => ({ "video/mp4": "mp4", "video/quicktime": "mov", "video/webm": "webm", "video/x-matroska": "mkv" })[mime ?? ""] ?? "mp4";
var slice = (from, to, f) => Math.round(from + (to - from) * Math.max(0, Math.min(1, f)));

// src/executors/proxy.ts
async function runProxy(ctx) {
  const { claimed, signal, report } = ctx;
  const job = claimed.job.payload;
  const { sourceGet, previewPut } = claimed.urls;
  if (!sourceGet || !previewPut) throw new Error("Missing URLs for proxy job.");
  const source = join6(mediaCacheDir(), `${job.videoId}.${extOf(claimed.media?.mime)}`);
  await report("Downloading video", 3);
  await downloadTo(sourceGet, source, { signal, onProgress: (f) => void report("Downloading video", slice(3, 25, f)) });
  const dir = jobDir(claimed.job.id);
  const out = join6(dir, "preview.mp4");
  try {
    const info = await probe(source);
    await makeProxy(source, out, job.targetHeight, info.durationMs, (f) => void report("Creating preview", slice(25, 85, f)), signal);
    if (statSync2(out).size === 0) throw new Error("Preview file came out empty.");
    await report("Uploading preview", 88);
    await uploadSigned(previewPut, out, "video/mp4", signal);
    await ctx.api.complete(claimed.job.id, { kind: "proxy", previewPath: "server-computed" });
  } finally {
    rmSync3(dir, { recursive: true, force: true });
  }
}

// src/executors/render.ts
import { existsSync as existsSync5, rmSync as rmSync4, statSync as statSync4 } from "node:fs";
import { cpus as cpus2 } from "node:os";
import { join as join7 } from "node:path";
import { fileURLToPath } from "node:url";
import { ensureBrowser, makeCancelSignal, renderMedia, selectComposition } from "@remotion/renderer";

// src/media-server.ts
import { createReadStream, statSync as statSync3 } from "node:fs";
import { createServer } from "node:http";
import { basename as basename2 } from "node:path";
var MIME = { mp4: "video/mp4", mov: "video/quicktime", webm: "video/webm", mkv: "video/x-matroska" };
async function serveFile(filePath) {
  const size = statSync3(filePath).size;
  const ext = filePath.split(".").pop()?.toLowerCase() ?? "mp4";
  const type = MIME[ext] ?? "application/octet-stream";
  const server = createServer((req, res) => {
    const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range ?? "");
    let start = 0;
    let end = size - 1;
    if (range) {
      if (range[1]) start = Number(range[1]);
      if (range[2]) end = Math.min(size - 1, Number(range[2]));
      if (!range[1] && range[2]) {
        start = Math.max(0, size - Number(range[2]));
        end = size - 1;
      }
      if (start > end || start >= size) {
        res.writeHead(416, { "content-range": `bytes */${size}` }).end();
        return;
      }
      res.writeHead(206, { "content-range": `bytes ${start}-${end}/${size}`, "accept-ranges": "bytes", "content-length": end - start + 1, "content-type": type, "access-control-allow-origin": "*" });
    } else {
      res.writeHead(200, { "accept-ranges": "bytes", "content-length": size, "content-type": type, "access-control-allow-origin": "*" });
    }
    if (req.method === "HEAD") return void res.end();
    createReadStream(filePath, { start, end }).on("error", () => res.destroy()).pipe(res);
  });
  await new Promise((resolve2) => server.listen(0, "127.0.0.1", resolve2));
  const { port } = server.address();
  return {
    url: `http://127.0.0.1:${port}/${encodeURIComponent(basename2(filePath))}`,
    close: () => new Promise((resolve2) => server.close(() => resolve2()))
  };
}

// src/executors/render.ts
var FRAME_TIMEOUT_MS = 12e4;
var sitePromise = null;
function getSite() {
  sitePromise ??= (async () => {
    const shipped = process.env.CAPSEASY_SITE ?? fileURLToPath(new URL("./site", import.meta.url));
    if (existsSync5(join7(shipped, "index.html"))) return shipped;
    const entryPoint = process.env.CAPSEASY_ENTRY ?? fileURLToPath(new URL("../../../compositions/src/entry.ts", import.meta.url));
    log.info("bundling caption composition...");
    const t0 = Date.now();
    const { bundle } = await import("@remotion/bundler");
    const site = await bundle({ entryPoint, outDir: join7(dirs.cache, "site"), onProgress: () => void 0 });
    log.info(`composition bundled in ${((Date.now() - t0) / 1e3).toFixed(1)}s`);
    return site;
  })().catch((e) => {
    sitePromise = null;
    throw e;
  });
  return sitePromise;
}
var OUT = {
  mp4: { ext: "mp4", mime: "video/mp4" },
  mov_alpha: { ext: "mov", mime: "video/quicktime" },
  webm_alpha: { ext: "webm", mime: "video/webm" },
  png: { ext: "png", mime: "image/png" }
};
async function runRender(ctx) {
  const { claimed, signal, report } = ctx;
  const job = claimed.job.payload;
  const burn = job.format === "mp4";
  const started = Date.now();
  const dir = jobDir(claimed.job.id);
  let media = null;
  try {
    let src = null;
    if (burn) {
      if (!claimed.urls.sourceGet) throw new Error("No source video URL was provided for this job.");
      const source = join7(mediaCacheDir(), `${job.sourceVideoId}.${extOf(claimed.media?.mime)}`);
      await report("Downloading video", 2);
      await downloadTo(claimed.urls.sourceGet, source, { signal, onProgress: (f) => void report("Downloading video", slice(2, 12, f)) });
      media = await serveFile(source);
      src = media.url;
    }
    await report("Preparing renderer", 13);
    await ensureBrowser();
    const serveUrl = await getSite();
    const inputProps = {
      src,
      media: { width: claimed.media?.width || job.width, height: claimed.media?.height || job.height, fps: job.fps, durationMs: claimed.media?.durationMs ?? 0, rotation: 0 },
      doc: job.docSnapshot,
      style: job.style,
      settings: job.settings,
      mode: burn ? "burn" : "overlay"
    };
    const composition = await selectComposition({ serveUrl, id: burn ? "CaptionedVideo" : "CaptionsOverlay", inputProps, timeoutInMilliseconds: FRAME_TIMEOUT_MS });
    const { ext, mime } = OUT[job.format];
    const output = join7(dir, `export.${ext}`);
    const { cancelSignal, cancel } = makeCancelSignal();
    signal.addEventListener("abort", () => cancel(), { once: true });
    await report("Rendering", 15);
    const last = composition.durationInFrames - 1;
    const frameRange = job.range ? [Math.max(0, Math.min(last, Math.floor(job.range.startMs / 1e3 * composition.fps))), Math.max(0, Math.min(last, Math.ceil(job.range.endMs / 1e3 * composition.fps) - 1))] : void 0;
    const srcW = claimed.media?.width || job.width;
    const scale = srcW ? Math.min(1, job.width / srcW) : 1;
    const common = { composition, serveUrl, inputProps, outputLocation: output, cancelSignal, frameRange, scale, timeoutInMilliseconds: FRAME_TIMEOUT_MS, concurrency: Math.max(1, Math.floor(cpus2().length / 2)) };
    const onProgress = ({ progress }) => void report("Rendering", slice(15, 88, progress));
    if (job.format === "mp4") {
      await renderMedia({ ...common, codec: "h264", crf: job.crf, pixelFormat: "yuv420p", onProgress });
    } else if (job.format === "mov_alpha") {
      await renderMedia({ ...common, codec: "prores", proResProfile: "4444", pixelFormat: "yuva444p10le", imageFormat: "png", onProgress });
    } else {
      await renderMedia({ ...common, codec: "vp8", pixelFormat: "yuva420p", imageFormat: "png", onProgress });
    }
    const size = statSync4(output).size;
    if (size === 0) throw new Error("The renderer produced an empty file.");
    if (!claimed.urls.exportPut) throw new Error("No upload URL was provided for the export.");
    await report("Uploading export", 90);
    await uploadSigned(claimed.urls.exportPut, output, mime, signal);
    await ctx.api.complete(claimed.job.id, {
      kind: "render",
      path: "server-computed",
      size,
      durationMs: frameRange ? (frameRange[1] - frameRange[0] + 1) / composition.fps * 1e3 : composition.durationInFrames / composition.fps * 1e3,
      renderMs: Date.now() - started
    });
  } finally {
    await media?.close();
    rmSync4(dir, { recursive: true, force: true });
  }
}

// src/executors/transcribe.ts
import { rmSync as rmSync5 } from "node:fs";
import { join as join8 } from "node:path";

// ../../node_modules/.pnpm/any-ascii@0.3.3/node_modules/any-ascii/block.js
function block(blockNum) {
  switch (blockNum) {
    case 0:
      return `																																																																																																																																																																 	!	c	GBP	$	Y	|	S	"	(C)	a	<<	!		(R)	-	deg	+-	2	3	'	u	P	-	,	1	o	>>	1/4	1/2	3/4	?	A	A	A	A	A	A	Ae	C	E	E	E	E	I	I	I	I	D	N	O	O	O	O	O	*	O	U	U	U	U	Y	Th	ss	a	a	a	a	a	a	ae	c	e	e	e	e	i	i	i	i	d	n	o	o	o	o	o	/	o	u	u	u	u	y	th	y`;
    case 1:
      return "A	a	A	a	A	a	C	c	C	c	C	c	C	c	D	d	D	d	E	e	E	e	E	e	E	e	E	e	G	g	G	g	G	g	G	g	H	h	H	h	I	i	I	i	I	i	I	i	I	i	IJ	ij	J	j	K	k	q	L	l	L	l	L	l	L	l	L	l	N	n	N	n	N	n	'n	Ng	ng	O	o	O	o	O	o	Oe	oe	R	r	R	r	R	r	S	s	S	s	S	s	S	s	T	t	T	t	T	t	U	u	U	u	U	u	U	u	U	u	U	u	W	w	Y	y	Y	Z	z	Z	z	Z	z	s	b	B	B	b	6	6	O	C	c	D	D	D	d	z	E	E	E	F	f	G	G	hw	I	I	K	k	l	l	W	N	n	O	O	o	Gh	gh	P	p	R	2	2	Sh	sh	t	T	t	T	U	u	U	V	Y	y	Z	z	Zh	`	`	zh	dz	5	5	ts	w	c	x	qc	q	DZ	Dz	dz	LJ	Lj	lj	NJ	Nj	nj	A	a	I	i	O	o	U	u	U	u	U	u	U	u	U	u	e	A	a	A	a	Ae	ae	G	g	G	g	K	k	O	o	O	o	Zh	zh	j	DZ	Dz	dz	G	g	Hw	W	N	n	A	a	Ae	ae	O	o";
    case 2:
      return "A	a	A	a	E	e	E	e	I	i	I	i	O	o	O	o	R	r	R	r	U	u	U	u	S	s	T	t	Y	y	H	h	N	d	Ou	ou	Z	z	A	a	E	e	O	o	O	o	O	o	O	o	Y	y	l	n	t	j	db	qp	A	C	c	L	T	s	z	'	'	B	U	A	E	e	J	j	Q	q	R	r	Y	y	a	a	a	b	o	c	d	d	e	e	er	e	e	er	o	j	g	g	g	g	u	y	h	h	i	i	i	l	l	l	lzh	w	w	m	n	n	n	o	oe	u	f	r	r	r	r	r	r	i	r	r	s	sh	j	i	sh	t	t	u	u	v	a	w	y	y	z	z	zh	zh	'	`	x	q	pc	b	oe	g	h	j	k	l	q	'	`	dz	dzh	dz	ts	tsh	tc	fng	ls	lz	ww	]]	y	y	h	h	j	r	r	r	r	w	y	'	''	`	'	`	'	`	'	`	<	>	^	v	^	^	'	-	'	`	,	_	`	'	:	-	'	`	+	+	+	-	^	.	.	,	~	\"	r	x	g	l	s	x	`	5	4	3	2	1	3	7	_	=	''	v	^	<	>	.	`	``	''	~	:	'	'	,	,	_	_	<";
    case 3:
      return `																																																																																																			a	e	i	o	u	c	d	h	m	r	t	v	x	H	h	S	s	'	,	W	w			i	s	s.	s.	;	J					'	"'	A	;	E	I	I		O		Y	O	i	A	V	G	D	E	Z	I	Th	I	K	L	M	N	X	O	P	R		S	T	Y	F	Ch	Ps	O	I	Y	a	e	i	i	y	a	v	g	d	e	z	i	th	i	k	l	m	n	x	o	p	r	s	s	t	y	f	ch	ps	o	i	y	o	y	o	&	b	th	Y	Y	Y	ph	p	&	Q	q	St	st	W	w	Q	q	S	s	Sh	sh	F	f	X	x	H	h	J	j	C	c	Ti	ti	k	r	s	j	Th	e	e	Sh	sh	S	S	s	r.	S	S.	S.`;
    case 4:
      return "E	E	Dj	G	Ie	Dz	I	I	J	Lj	Nj	C	K	I	U	Dzh	A	B	V	G	D	E	Zh	Z	I	Y	K	L	M	N	O	P	R	S	T	U	F	Kh	Ts	Ch	Sh	Shch	'	Y	'	E	Yu	Ya	a	b	v	g	d	e	zh	z	i	y	k	l	m	n	o	p	r	s	t	u	f	kh	ts	ch	sh	shch	'	y	'	e	yu	ya	e	e	dj	g	ie	dz	i	i	j	lj	nj	c	k	i	u	dzh	O	o	E	e	Ie	ie	E	e	Ie	ie	O	o	Io	io	Ks	ks	Ps	ps	F	f	Y	y	Y	y	U	u	O	o	O	o	Ot	ot	Q	q	1000	.				.	100000	1000000	Jh	jh	'	'	Rh	rh	G	g	Gh	gh	Gh	gh	J	j	Z	z	Q	q	G	g	Q	q	Q	q	Ng	ng	Ng	ng	Ph	ph	W	w	S	s	Th	th	U	u	U	u	H	h	Ts	ts	J	j	C	c	H	h	Ch	ch	Ch	ch	H	Gi	gi	Q	q	Lh	lh	Ng	ng	Nh	nh	Dzh	dzh	Mh	mh	h	A	a	A	a	Ae	ae	E	e	A	a	E	e	Dzh	dzh	J	j	Dz	dz	I	i	I	i	O	o	O	o	Y	y	A	a	U	u	U	u	U	u	Tsh	tsh	Gh	gh	Y	y	Xh	xh	X	x	H	h";
    case 5:
      return "D	d	Dj	dj	Zj	zj	Dz	dz	Lj	lj	Nj	nj	Sj	sj	Tj	tj	A	a	L	l	Lkh	lkh	Rkh	rkh	A	a	Q	q	W	w	Q	q	L	l	N	n	Ph	ph	'	'	Ny	ny	Dzh	dzh	Dch	dch	L	l		A	B	G	D	E	Z	E	Y	T'	Zh	I	L	Kh	Ts	K	H	Dz	Gh	Ch	M	Y	N	Sh	O	Ch'	P	J	Rr	S	V	T	R	Ts'	W	P'	K'	O	F			`	'	*	!	,	?	.	a	a	b	g	d	e	z	e	y	t'	zh	i	l	kh	ts	k	h	dz	gh	ch	m	y	n	sh	o	ch'	p	j	rr	s	v	t	r	ts'	w	p'	k'	o	f	ev	h	.	-			*	*	Dram																																	e	e	a	o	i	e	e	a	a	o	o	u			-		|	h		.	`	`	^	o									'	v	g	d	h	v	z	h	t	y	kh	kh	l	m	m	n	n	s	'	f	f	ts	ts	k	r	s	t					YYY	v	oy	ey	'	\"";
    case 6:
      return "#	sn.	^	#	sm.	#	cbrt	4rt	r	%0	%00	Af	,	/	^	*							i					;		.	.	?	y	'	a	'	u'	'	i'		b	h	t	th	j	h	kh	d	dh	r	z	s	sh	s	d	t	dh	`	gh	g	g	y	i	i		f	q	k	l	m	n	h	w	a	y				a	u	i			a	'	'	i		e	e	o	e	e	o	a	u'	0	1	2	3	4	5	6	7	8	9	%	.	,	*	b	q	a	'	a	u'	e	a	o	u	i	t	th	b	t	t	p	th	bh	dz	dz	n	j	ts	ch	ch	d	d	d	dd	dh	dh	dh	d	d	r	r	r	r	r	zh	d	zh	r	sh	s	ch	ts	ch	th	ng	f	f	p	v	v	ph	q	g	k	k	g	g	ng	kp	g	gg	n	g	g	g	l	l	l	l	n	n	n	n	ny	h	n	e	h	h	h	o	o	o	u	u	u	u	v	y	ey	e	v	e	ny	e	e'	.	e								#	#											^					d	r	0	1	2	3	4	5	6	7	8	9	s	l	n	&	m.	h";
    case 7:
      return "*	.	.	!	!	:	:	:	;	?	.	/	\\	+		.	'	'	b	g	j	d	d	h	w	z	h	t	d	y	yh	k	l	m	n	s	s	`	p	p	s	q	r	sh	t	bh	gh	dh	a	a	a	o	u	a	e	e	i	e	i	i	i	u	u	o			h			h	h							zh	kh	ph	'y	p	p	c	ny	p	c	ng	c	dd	d	r	s	ng	ng	g	p	v	g	g	k	b	mb	n	n	n	sl	r	z	s	j	c	s	z	j	a	aa	i	ii	y	o	oo	e	ee	ch	s	s	g	h	sh	n	r	b	lh	k		v	m	f	dh	th	l	g	gn	s	d	z	t	y	p	j	ch	th'	h'	kh	dh'	x	sh'	s'	l'	t'	z'	'	gh	q	w	a	aa	i	ee	u	oo	e	ey	o	oa		n															0	1	2	3	4	5	6	7	8	9	a	e	i	e	u	o	o		n	b	p	t	j	c	d	r	rr	s	gb	f	k	l	n	m	ny	n	h	w	y	ny	j	c	r								n		'	`	o	*	,	!	-			.	D	T";
    case 8:
      return "'	b	g	d	h	w	z	h	t	y	k	l	m	n	s	`	f	s	q	r	sh	t	`	`			y	y	e	e	a	a	a	a	a	a	a	a	u	u	i	i	i	o					;	:	..	<.	<:	?	.	-<	-.	-:	=:	|:	/	.	...		a	b	g	d	h	u	z	h	t	i	k	l	m	n	s	`	p	s	q	r	sh	t	d	kd	`	'					,		n	j	n	t	n	n	bh	r	l	l	s						'	'	'	'	'	'	'	'	'	'	'	'	'	'	'	'	'	'	'	'	u	y	y	.	.	nj	c	th	th	g	.		LE	pt						e							a	a	b	b	c	t	vb	gb	zl	mv	y	ny	r	w	y		dz	ts	kh	u	z	n	k	q	mb	mp	tt	nr	ny	f	q	n	ph	th	th	ch	kh	gy	ky	n	n	l	gr																										#	e	o	ou	e	on	oun	en							a	u	i	u	e	a	i	o	u	e	e	un	on	o	o";
    case 9:
      return "m	m	m	h	a	a	a	i	i	u	u	r	l	e	e	e	ai	o	o	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	n	p	ph	b	bh	m	y	r	r	l	l	l	v	s	s	s	h	o	o	'	'	a	i	i	u	u	r	r	e	e	e	ai	o	o	o	au		e	a	Om					e	u	u	q	kh	g	z	r	rh	f	y	r	l	l	l	,	.	0	1	2	3	4	5	6	7	8	9	.	'	a	o	o	a	u	u	d	zh	y	g	j	'	d	b	*	m	m	h		a	a	i	i	u	u	r	l			e	ai			o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n		p	ph	b	bh	m	y	r		l				s	s	s	h			'	'	a	i	i	u	u	r	r			e	ai			o	au		t									u					r	rh		y	r	l	l	l			0	1	2	3	4	5	6	7	8	9	r	v	Rs	Rs	1	2	3	1	3	/	^	g	m	.	'";
    case 10:
      return "	m	m	h		a	a	i	i	u	u					e	ai			o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n		p	ph	b	bh	m	y	r		l	l		v	s		s	h			'		a	i	i	u	u					e	ai			o	au													kh	g	z	r		ph								0	1	2	3	4	5	6	7	8	9	m	'			*	y	.											m	m	h		a	a	i	i	u	u	r	l	e		e	ai	o		o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n		p	ph	b	bh	m	y	r		l	l		v	s	s	s	h			'	'	a	i	i	u	u	r	r	e		e	ai	o		o	au				Om																r	l	l	l			0	1	2	3	4	5	6	7	8	9	.	Rs								zh				'	'	'";
    case 11:
      return "	m	m	h		a	a	i	i	u	u	r	l			e	ai			o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n		p	ph	b	bh	m	y	r		l	l		v	s	s	s	h			'	'	a	i	i	u	u	r	r			e	ai			o	au										i	u					r	rh		y	r	l	l	l			0	1	2	3	4	5	6	7	8	9	^	w	1	2	3	1	2	3											m	k		a	a	i	i	u	u				e	e	ai		o	o	au	k				n	c		j		n	t				n	t				n	n	p				m	y	r	r	l	l	l	v	s	s	s	h					a	i	i	u	u				e	e	ai		o	o	au				Om							u															0	1	2	3	4	5	6	7	8	9	10	100	1000	N	M	V	-	+	-	Rs	#";
    case 12:
      return "m	n	m	h	m	a	a	i	i	u	u	r	l		e	e	ai		o	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n		p	ph	b	bh	m	y	r	r	l	l	l	v	s	s	s	h			'	'	a	i	i	u	u	r	r		e	e	ai		o	o	au									'	i		c	z	r			n			r	l	l	l			0	1	2	3	4	5	6	7	8	9								*	0	1	2	3	1	2	3	t	m	m	m	h	*	a	a	i	i	u	u	r	l		e	e	ai		o	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n		p	ph	b	bh	m	y	r	r	l	l		v	s	s	s	h			'	'	a	i	i	u	u	r	r		e	e	ai		o	o	au									'	i							n	l		r	l	l	l			0	1	2	3	4	5	6	7	8	9		h	h	m";
    case 13:
      return "m	m	m	h	m	a	a	i	i	u	u	r	l		e	e	ai		o	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	n	p	ph	b	bh	m	y	r	r	l	l	l	v	s	s	s	h	t			'	a	i	i	u	u	r	r		e	e	ai		o	o	au		r	p					m	y	l	u	2	4	12	16	32	48	64	i	r	l	l	l			0	1	2	3	4	5	6	7	8	9	10	100	1000	80	160	240	20	40	60	d	n	n	r	l	l	k		m	m	h		a	a	ae	ae	i	i	u	u	r	r	l	l	e	e	ai	o	o	au				k	kh	g	gh	n	ng	c	ch	j	jh	n	jn	nj	t	th	d	dh	n	nd	t	th	d	dh	n		nd	p	ph	b	bh	m	mb	y	r		l			v	s	s	s	h	l	f									a	ae	ae	i	i	u		u		r	e	e	ai	o	o	au	u							0	1	2	3	4	5	6	7	8	9			r	l	~";
    case 14:
      return "	k	kh	kh	kh	kh	kh	ng	ch	ch	ch	s	ch	y	d	t	th	th	th	n	d	t	th	th	th	n	b	p	ph	f	ph	f	ph	m	y	r	rue	l	lue	w	s	s	s	h	l	o	h	.	a	a	a	am	i	i	ue	ue	u	u						B	e	ae	o	ai	ai		-							m		*	0	1	2	3	4	5	6	7	8	9	#	@																																						k	kh		kh		gh	ng	ch	ch	x		jh	gn	n	t	th	d	dh	n	d	t	th	th	dh	n	b	p	ph	f	ph	f	bh	m	y	r		l		v	s	s	s	h	l		h	...	a	a	a	am	i	i	u	u	ou	ou		o	l	y			e	e	o	ai	ai		-							o			0	1	2	3	4	5	6	7	8	9			n	m	g	gn";
    case 15:
      return "Om	@	@	@	@	#	$	%	!	*	*	-	-	,	.	;	|	|	/	*	:	*	*	*			o	oo	ooo	x	xx	ox	0	1	2	3	4	5	6	7	8	9	1-	2-	3-	4-	5-	6-	7-	8-	9-	0-	=		^		*		<	>	(	)			k	kh	g	gh	ng	c	ch	j		ny	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	ts	tsh	dz	dzh	w	zh	z	'	y	r	l	sh	s	s	h		ks	r	q	r						i	i	u	u	r	r	l	l	e	ai	o	au	m	h	i	i	m	m		`			h	h			h	h	h	h	k	kh	g	gh	ng	c	ch	j		ny	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	ts	tsh	dz	dzh	w	zh	z	'	y	r	l	sh	s	s	h		ks	w	y	r		*	*	*	*	*	*	*	*		*	*	*	*	*	*		xo	xxx	*	*	:	@	#	+	+	+	+	~	~";
    case 16:
      return "k	kh	g	gh	n	c	ch	j	jh	n	nn	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	h	l	'	'	i	i	u	u	e	e	o	o	a	a	i	i	u	u	e	ai	i	ao	e	m					y	r	v	h	ss	0	1	2	3	4	5	6	7	8	9	,	.	n*	r*	l*	e*	s	s	r	r	l	l	r	r	l	l	n	jh	b	b	n	m	l	sh	o			s	pw	o	u						n	yw	ghw	i	o	u	e	k	kh	g	c	z	n	d	n	ph	f	b	x	h	v	a	e	e	ai								f		0	1	2	3	4	5	6	7	8	9			a	ai	1	!	A	B	G	D	E	V	Z	T	I	K'	L	M	N	O	P'	Zh	R	S	T'	U	P	K	Gh	Q'	Sh	Ch	Ts	Dz	Ts'	Ch'	Kh	J	H	E	Y	W	X	O		E						Ae			a	b	g	d	e	v	z	t	i	k'	l	m	n	o	p'	zh	r	s	t'	u	p	k	gh	q'	sh	ch	ts	dz	ts'	ch'	kh	j	h	e	y	w	x	o	f	e	`	g	`	*	n	ae	`	w";
    case 17:
      return "g	kk	n	d	tt	l	m	b	pp	s	ss		j	jj	ch	k	t	p	h	ng	nn	nd	nb	dg	ln	ll	lh	r	mb	w	bg	bn	bd	bs	bsg	bsd	bsb	bss	bsj	bj	bch	bt	bp	v	ff	sg	sn	sd	sl	sm	sb	sbg	sss	s	sj	sch	sk	st	sp	sh	s	ss	s	ss	z	g	d	m	b	s	z		j	ch	t	p	ng	j	j	jj	j	jj	chk	chh	ch	ch	pb	f	hh	q	gd	ns	nj	nh	dl			a	ae	ya	yae	eo	e	yeo	ye	o	wa	wae	oe	yo	u	wo	we	wi	yu	eu	ui	i	ao	au	yao	yayo	eoo	eou	eoeu	yeoo	yeou	oeo	oe	oye	oo	ou	yoya	yoyae	yoyeo	yoo	yoi	ua	uae	ueoeu	uye	uu	yua	yueo	yue	yuyeo	yuye	yuu	yui	euu	eueu	uiu	ia	iya	io	iu	ieu	io	o	oeo	ou	oi	yo	aeu	yau	yeoya	oya	oyae	g	kk	gs	n	nj	nh	d	l	lg	lm	lb	ls	lt	lp	lh	m	b	bs	s	ss	ng	j	ch	k	t	p	h	gl	gsg	ng	nd	ns	nz	nt	dg	dl	lgs	ln	ld	ldh	ll	lmg	lms	lbs	lbh	lv	lss	lz	lk	lq	mg	ml	mb	ms	mss	mz	mch	mh	w	bl	bp	bh	v	sg	sd	sl	sb	z	ngg	ngkk	ngng	ngk	ng	ngs	ngz	pb	f	hn	hl	hm	hb	q	gn	gb	gch	gk	gh	nn";
    case 18:
      return "ha	hu	hi	ha	he	h	ho	hoa	le	lu	li	la	le	l	lo	lwa	ha	hu	hi	ha	he	h	ho	hwa	me	mu	mi	ma	me	m	mo	mwa	se	su	si	sa	se	s	so	swa	re	ru	ri	ra	re	r	ro	rwa	se	su	si	sa	se	s	so	swa	she	shu	shi	sha	she	sh	sho	shwa	k'e	k'u	k'i	k'a	k'e	k'	k'o	k'oa	k'we		k'wi	k'wa	k'we	k'wi			k'e	k'u	k'i	k'a	k'e	k'	k'o		k'we		k'wi	k'wa	k'we	k'wi			be	bu	bi	ba	be	b	bo	bwa	ve	vu	vi	va	ve	v	vo	vwa	te	tu	ti	ta	te	t	to	twa	che	chu	chi	cha	che	ch	cho	chwa	ha	hu	hi	ha	he	h	ho	hoa	hwe		hwi	hwa	hwe	hwi			ne	nu	ni	na	ne	n	no	nwa	nye	nyu	nyi	nya	nye	ny	nyo	nywa	'a	'u	'i	'a	'e	'	'o	'wa	ke	ku	ki	ka	ke	k	ko	koa	kwe		kwi	kwa	kwe	kwi			he	hu	hi	ha	he	h	ho		hwe		hwi	hwa	hwe	hwi			we	wu	wi	wa	we	w	wo	woa	`a	`u	`i	`a	`e	`	`o		ze	zu	zi	za	ze	z	zo	zwa	zhe	zhu	zhi	zha	zhe	zh	zho	zhwa	ye	yu	yi	ya	ye	y	yo	yoa	de	du	di	da	de	d	do	dwa	d'e	d'u	d'i	d'a	d'e	d'	d'o	d'wa";
    case 19:
      return "je	ju	ji	ja	je	j	jo	jwa	ge	gu	gi	ga	ge	g	go	goa	gwe		gwi	gwa	gwe	gwi			nge	ngu	ngi	nga	nge	ng	ngo	ngwa	t'e	t'u	t'i	t'a	t'e	t'	t'o	t'wa	ch'e	ch'u	ch'i	ch'a	ch'e	ch'	ch'o	ch'wa	p'e	p'u	p'i	p'a	p'e	p'	p'o	p'wa	ts'e	ts'u	ts'i	ts'a	ts'e	ts'	ts'o	ts'wa	ts'e	ts'u	ts'i	ts'a	ts'e	ts'	ts'o	ts'oa	fe	fu	fi	fa	fe	f	fo	fwa	pe	pu	pi	pa	pe	p	po	pwa	rya	mya	fya						+	 	.	,	;	,	:	?	#	1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70	80	90	100	10000				mwe	mwi	mwe	mwi	bwe	bwi	bwe	bwi	fwe	fwi	fwe	fwi	pwe	pwi	pwe	pwi																	A	E	I	O	U	V	Ga	Ka	Ge	Gi	Go	Gu	Gv	Ha	He	Hi	Ho	Hu	Hv	La	Le	Li	Lo	Lu	Lv	Ma	Me	Mi	Mo	Mu	Na	Hna	Nah	Ne	Ni	No	Nu	Nv	Qua	Que	Qui	Quo	Quu	Quv	Sa	S	Se	Si	So	Su	Sv	Da	Ta	De	Te	Di	Ti	Do	Du	Dv	Dla	Tla	Tle	Tli	Tlo	Tlu	Tlv	Tsa	Tse	Tsi	Tso	Tsu	Tsv	Wa	We	Wi	Wo	Wu	Wv	Ya	Ye	Yi	Yo	Yu	Yv	Mv			ye	yi	yo	yu	yv	mv";
    case 20:
      return "-	e	iy	i	ii	o	oo	oo	e	i	a	aa	we	we	wi	wi	wii	wii	wo	wo	woo	woo	wo	wa	wa	waa	waa	wa	ai	w	'	t	k	sh	s	n	w	'	h	w	c	n	l	e	i	o	a	pe	piy	pi	pii	po	poo	poo	he	hi	pa	paa	pwe	pwe	pwi	pwi	pwii	pwii	pwo	pwo	pwoo	pwoo	pwa	pwa	pwaa	pwaa	pwa	p	p	h	te	tiy	ti	tii	to	too	too	de	di	ta	taa	twe	twe	twi	twi	twii	twii	two	two	twoo	twoo	twa	twa	twaa	twaa	twa	t	t'e	t'i	t'o	t'a	ke	kiy	ki	kii	ko	koo	koo	ka	kaa	kwe	kwe	kwi	kwi	kwii	kwii	kwo	kwo	kwoo	kwoo	kwa	kwa	kwaa	kwaa	kwa	k	kw	k'e	k'i	k'o	k'a	ce	ciy	ci	cii	co	coo	coo	ca	caa	cwe	cwe	cwi	cwi	cwii	cwii	cwo	cwo	cwoo	cwoo	cwa	cwa	cwaa	cwaa	cwa	c	c	me	miy	mi	mii	mo	moo	moo	ma	maa	mwe	mwe	mwi	mwi	mwii	mwii	mwo	mwo	mwoo	mwoo	mwa	mwa	mwaa	mwaa	mwa	m	m	mw	m	m	ne	niy	ni	nii	no	noo	noo	na	naa	nwe	nwe	nwa	nwa	nwaa	nwaa	nwa	n	ng	nw	le	liy	li	lii	lo	loo	loo	la	laa	lwe	lwe	lwi	lwi	lwii	lwii	lwo	lwo	lwoo	lwoo	lwa	lwa	lwaa	lwaa	l	l	l	se	siy	si	sii	so	soo	soo	sa	saa	swe	swe	swi	swi	swii	swii	swo	swo	swoo	swoo";
    case 21:
      return "swa	swa	swaa	swaa	swa	s	s	sw	s	sk	skw	sw	spwa	stwa	skwa	scwa	she	shi	shii	sho	shoo	sha	shaa	shwe	shwe	shwi	shwi	shwii	shwii	shwo	shwo	shwoo	shwoo	shwa	shwa	shwaa	shwaa	sh	ye	yiy	yi	yii	yo	yoo	yoo	ya	yaa	ywe	ywe	ywi	ywi	ywii	ywii	ywo	ywo	ywoo	ywoo	ywa	ywa	ywaa	ywaa	ywa	y	y	y	yi	re	re	li	riy	ri	rii	ro	roo	lo	ra	raa	la	rwaa	rwaa	r	r	r	fe	fiy	fi	fii	fo	foo	fa	faa	fwaa	fwaa	f	the	the	thi	thi	thii	thii	tho	thoo	tha	thaa	thwaa	thwaa	th	tthe	tthi	ttho	ttha	**	te	ti	to	ta	hai	hi	hii	hu	huu	ha	haa	h	h	hk	qiy	qi	qii	qu	quu	qa	qaa	q	tle	tli	tlo	tla	re	ri	ro	ra	ngiy	ngi	ngii	ngu	nguu	nga	ngaa	ng	nng	she	shi	sho	sha	the	thi	tho	tha	th	hli	hlii	hlu	hluu	hla	hlaa	hl	the	thi	thii	tho	thoo	tha	thaa	th	b	e	i	o	a	we	wi	wo	wa	ne	ni	no	na	ke	ki	ko	ka	ge	gi	go	ga	khoo	kho	khu	khe	khi	kha	ghoo	gho	ghu	ghe	ghi	gha	woo	wo	wu	we	wi	wa	whoo	who	whu	whe	whi	wha	too	to	tu	te	ti	ta	t'oo	t'o	t'u	t'e	t'i	t'a	boo	bo	bu	be	bi	ba	p	goo	go	gu	ge	gi	ga	koo	ko	ku	ke	ki	ka	k'oo	k'o	k'u	k'e	k'i";
    case 22:
      return "k'a	k'	noo	no	nu	ne	ni	na	moo	mo	mu	me	mi	ma	yoo	yo	yu	ye	yi	ya	joo	jo	jo	ju	je	ji	ji	ja	ch'oo	ch'o	ch'u	ch'e	ch'i	ch'a	loo	lo	lu	le	li	la	dloo	dlo	dlu	dle	dli	dla	lhoo	lho	lhu	lhe	lhi	lha	tloo	tlo	tlu	tle	tli	tla	tl'oo	tl'o	tl'u	tl'e	tl'i	tl'a	zoo	zo	zu	ze	zi	za	z	z	dzoo	dzo	dzu	dze	dzi	dza	soo	so	su	se	si	sa	shoo	sho	shu	she	shi	sha	sh	choo	cho	chu	che	chi	cha	tsoo	tso	tsu	tse	tsi	tsa	ts'oo	ts'o	ts'u	ts'e	ts'i	ts'a	X	.	qai	ngai	nngi	nngii	nngu	nnguu	nnga	nngaa	thwe	thwi	thwii	thwo	thwoo	thwa	thwaa	th	w	 	b	l	f	s	n	h	d	t	c	q	m	g	ng	z	r	a	o	u	e	i	ea	oi	ui	ia	ae	p	>	<				f	v	u	y	y	w	th	dh	a	o	a	ae	a	a	o	o	o	r	k	c	k	g	ng	g	g	w	h	h	h	h	n	n	n	i	e	j	j	a	a	i	p	z	s	s	s	c	z	t	t	d	b	b	p	p	e	m	m	m	l	l	ng	ng	d	o	ea	io	q	k	k	st	r	r	y	q	x	.	:	+	17	18	19	k	sh	oo	o	i	e	a	ae";
    case 23:
      return "a	i	u	k	g	ng	t	d	n	p	b	m	y	r	l	w	s	h	i	u												r	a	i	u	k	g	ng	t	d	n	p	b	m	y	r	l	w	s	h	i	u		,	.										a	i	u	k	g	ng	t	d	n	p	b	m	y	r	l	w	s	h	i	u													a	i	u	k	g	ng	t	d	n	p	b	m	y		l	w	s		i	u													k	kh	k	kh	ng	ch	chh	ch	chh	nh	d	th	d	th	n	t	th	t	th	n	b	ph	p	ph	m	y	r	l	v	s	s	s	h	l	'	'	'a	e	ei	o	o	ou	au	rue	rueu	lue	lueu	ae	ai	ao	ao	ov			a	e	ei	oe	eu	o	ou	uo	aeu	oea	ie	e	ae	ai	ao	au	am	ah	ak			a	r		!		a				.	#	:	-	-Lo-	*	@	CR	'				0	1	2	3	4	5	6	7	8	9							0	1	2	3	4	5	6	7	8	9";
    case 24:
      return "@	...	,	.	:	*	-	-	,	.	-						0	1	2	3	4	5	6	7	8	9							a	e	i	o	u	o	u	e	n	ng	b	p	h	g	m	l	s	x	t	d	q	j	y	r	w	f	k	k	c	z	h	r	lh	zh	ch		e	i	o	u	o	u	ng	b	p	h	g	m	t	d	q	j	c	y	v	k	g	h	j	ny	z	e	i	y	u	u	ng	k	g	h	p	x	t	d	j	f	g	h	c	z	r	ch	zh	i	k	r	f	zh	x								m	h	h	h	h	3	9	a	i	k	ng	ts	t	th	d	n	t	d	p	ph	s	zh	z	'	t	zh	gh	ng	ts	dzh	t	dh	t	dh	s	c	zh	z	w	y	bh		lh						oy	ay	aay	way	poy	pay	pwoy	tay	kay	kway	may	noy	nay	lay	soy	say	shoy	shay	shwoy	yoy	yay	ray	nwi	nwi	nwii	nwii	nwo	nwo	nwoo	nwoo	rwe	rwi	rwii	rwo	rwoo	rwa	p	t	k	c	m	n	s	sh	w	w	y	'	rwe	loo	laa	thwe	thwa	tthwe	tthoo	tthaa	tlwe	tloo	shwe	shoo	goo	gwo	goo	gaa	gwa	joo	jwe	l	r	s";
    case 25:
      return "	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	jn	tr		a	i	u	e	ai	o	au	e	o	y	r	v					k	n	m	t	n	p	m	r	l	h	'						lo				!	?	0	1	2	3	4	5	6	7	8	9	g	h	ng	z	s	y	d	t	l	b	p	m	f	w	hh	'	k	c	n	aa	i	e	ae	u	o	oa	ue	oe	aue	ai																					g	k	ng	g	k	ng	z	s	y	z	s	y	d	t	n	d	t	n	b	p	m	b	p	m	f	w	l	f	w	l	h	dd	bb	h	dd	bb	gw	kw	gw	kw	sw	sw					'	aa	i	u	u	e	ae	o	oa	ue	ai	aai	ui	oi	oai	uei	ii	w	ng	n	m	k	t	p									0	1	2	3	4	5	6	7	8	9	1				lae	laew	08	1.	2.	3.	4.	5.	6.	7.	8.	9.	10.	11.	12.	13.	14.	15.	88	.1	.2	.3	.4	.5	.6	.7	.8	.9	.10	.11	.12	.13	.14	.15";
    case 26:
      return "k	g	ng	ngk	p	b	m	mp	t	d	n	nr	c	j	ny	nc	y	r	l	w	s		h	i	u	e	o	e			\\	*	k	kh	kh	k	kh	kh	ng	ch	s	ch	s	s	ny	t	th	d	th	n	t	th	t	th	n	b	p	ph	f	p	f	ph	m	ny	y	h	lue	l	lue	w	s	s	s	h	l		h	i	i	u	u	e	o	lae	th	r	l	lng	ng	ng	p	th	m	b	s			a	a	a	a	i	i	ue	ue	u	u	o	o	oy	e	ae	o	ai	ai	o	m							-				.	0	1	2	3	4	5	6	7	8	9							0	1	2	3	4	5	6	7	8	9							w.	ww.	s.	*	*	*	^	-	,	.	;	:	@	ch.																		w	w												g	r	t";
    case 27:
      return "m	ng	ng	r	h	a	a	i	i	u	u	re	ro	le	lo	e	ai	o	au	k	kh	g	gh	ng	c	ch	j	jh	ny	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	w	s	s	s	h	'	a	i	i	u	u	re	ro	le	lo	e	ai	o	au	e	o		q	x	ts	f	v	z	sy	jny		,	.	0	1	2	3	4	5	6	7	8	9	*	@	.	:	,	.	-	a	e	u	ng	r	i	e	u	ai	h										^	^	^	^	^	^	^	^	^	**	@@	~	ng	r	h	a	i	u	e	o	e	eu	k	q	g	ng	c	j	z	ny	t	d	n	p	f	v	b	m	y	r	l	w	s	x	h	y	r	l	i	u	e	o	e	eu			m	w	kh	sy	0	1	2	3	4	5	6	7	8	9	'	reu	leu	bh	k	m			h	h	h	b	b	p	p	n	n	w	w	w	g	g	j	d	r	r	m	m	t	t	s	s	s	y	y	ng	l	l	ny	c	nd	mb	i	u	'	e	e	e	i	i	o	o	u	u	ng	h											*	+	|	)";
    case 28:
      return "k	kl	kh	g	gl	ng	c	ch	j	ny	t	th	d	n	p	pl	ph	f	fl	b	bl	m	ml	ts	tsh	z	y	r	l	h	hl	v	s	sh	w		y	r	a	i	o	o	u	u	e	k	m	l	n	p	r	t	ng	ng		'				,	.	.	.	.	0	1	2	3	4	5	6	7	8	9				t	th	d	0	1	2	3	4	5	6	7	8	9	a	t	g	m	l	a	k	j	m	w	i	s	h	n	r	u	c	d	n	y	e	p	d	n	r	o	t	b	n	h	m		m			'	,	.	v	d	o	s	t	t	'	e	u	Tj	tj						A	B	G	D	E	V	Z	T	I	K'	L	M	N	O	P'	Zh	R	S	T'	U	P	K	Gh	Q'	Sh	Ch	Ts	Dz	Ts'	Ch'	Kh	J	H	E	Y	W	X	O	F	E	`	G	`			Ae	`	W	.	*	;	,	L	K	D	B												\"															h	h	h	h	h	h	h	m	m	m	m	m	m	m	m	m	h	h		h	h";
    case 29:
      return "a	ae	ae	b	c	d	d	e	e	i	j	k	l	m	n	o	o	o	o	o	oe	ou	o	o	p	r	r	t	u	u	u	w	v	w	z	zh	`	`	g	l	p	r	ps	l	A	Ae	B	B	D	E	E	G	H	I	J	K	L	M	N	N	O	Ou	P	R	T	U	W	a	a	a	ae	b	d	e	e	e	e	g	i	k	m	ng	o	o	o	o	p	t	u	u	w	v	`	v	g	d	f	ch	i	r	u	v	v	g	r	f	ch	ue	b	d	f	m	n	p	r	r	s	t	z	g	n	g	th	i	i	p	u	u	b	d	f	g	k	l	m	n	p	r	s	sh	v	x	z	a	a	d	e	e	e	e	i	o	sh	u	zh	a	c	c	d	e	f	j	g	y	i	i	i	i	j	l	l	l	m	w	n	n	n	o	f	s	sh	t	u	u	u	v	a	z	z	z	zh	th											r									a	ae	ao	av	c	d	d	g	g	k	l	l	m	n	n	r	r	s	s	z	a	b	b	e	f	l	o	p	sh	u	w	a	o	u";
    case 30:
      return "A	a	B	b	B	b	B	b	C	c	D	d	D	d	D	d	D	d	D	d	E	e	E	e	E	e	E	e	E	e	F	f	G	g	H	h	H	h	H	h	H	h	H	h	I	i	I	i	K	k	K	k	K	k	L	l	L	l	L	l	L	l	M	m	M	m	M	m	N	n	N	n	N	n	N	n	O	o	O	o	O	o	O	o	P	p	P	p	R	r	R	r	R	r	R	r	S	s	S	s	S	s	S	s	S	s	T	t	T	t	T	t	T	t	U	u	U	u	U	u	U	u	U	u	V	v	V	v	W	w	W	w	W	w	W	w	W	w	X	x	X	x	Y	y	Z	z	Z	z	Z	z	h	t	w	y	a'	s	s.	s.	Ss	d	A	a	A	a	A	a	A	a	A	a	A	a	A	a	A	a	A	a	A	a	A	a	A	a	E	e	E	e	E	e	E	e	E	e	E	e	E	e	E	e	I	i	I	i	O	o	O	o	O	o	O	o	O	o	O	o	O	o	O	o	O	o	O	o	O	o	O	o	U	u	U	u	U	u	U	u	U	u	U	u	U	u	Y	y	Y	y	Y	y	Y	y	Ll	ll	V	v	Y	y";
    case 31:
      return "a	ha	a	ha	a	ha	a	ha	A	Ha	A	Ha	A	Ha	A	Ha	e	he	e	he	e	he			E	He	E	He	E	He			i	hi	i	hi	i	hi	i	hi	I	Hi	I	Hi	I	Hi	I	Hi	i	hi	i	hi	i	hi	i	hi	I	Hi	I	Hi	I	Hi	I	Hi	o	ho	o	ho	o	ho			O	Ho	O	Ho	O	Ho			y	hy	y	hy	y	hy	y	hy		Hy		Hy		Hy		Hy	o	ho	o	ho	o	ho	o	ho	O	Ho	O	Ho	O	Ho	O	Ho	a	a	e	e	i	i	i	i	o	o	y	y	o	o			a	ha	a	ha	a	ha	a	ha	A	Ha	A	Ha	A	Ha	A	Ha	i	hi	i	hi	i	hi	i	hi	I	Hi	I	Hi	I	Hi	I	Hi	o	ho	o	ho	o	ho	o	ho	O	Ho	O	Ho	O	Ho	O	Ho	a	a	a	a	a		a	a	A	A	A	A	A	'	i	'	~	\"~	i	i	i		i	i	E	E	I	I	I	'`	''	'~	i	i	i	i			i	i	I	I	I	I		h`	h'	h~	y	y	y	y	r	rh	y	y	Y	Y	Y	Y	Rh	\"`	\"'	`			o	o	o		o	o	O	O	O	O	O	'	h";
    case 32:
      return " 	 	 	 	 	 	 	 	 	 	 						-	-	-	-	-	-	||	_	'	'	'	'	\"	\"	\"	\"	+	++	*	*	.	..	...	-	 	 						 	%0	%00	'	''	'''	`	``	```	^	<	>	*	!!	!?	-	_	-	^	***	-	/	[	]	??	?!	!?	&	P	<	>	*	;	_	**	./.	~	_	*	:	''''	:	*	:	:	+	:	:	 																	0	i			4	5	6	7	8	9	+	-	=	(	)	n	0	1	2	3	4	5	6	7	8	9	+	-	=	(	)		a	e	o	x	e	h	k	l	m	n	p	s	t				CE	C	Cr	F	L	m	N	Pts	Rs	W	NIS	d	EUR	K	T	Dr	Pf	P	G	A	HRN	C	lt	Sm	T	Rs	TL	M	Manat	Rb	Lari	BTC	Som";
    case 33:
      return "a/c	a/s	C	C	CL	c/o	c/u	E	g	F	g	H	H	H	h	h	I	I	L	l	#	N	No	(P)	p	P	Q	R	R	R	Rx	R	SM	TEL	TM	V	Z	oz	Ohm	Mho	Z	i	K	A	B	C	e	e	E	F	F	M	o	a	b	g	d	i	Q	FAX	p	g	G	P	S	G	L	L	Y	D	d	e	i	j	PL	&	P	A/S	f	Sh	1/7	1/9	1/10	1/3	2/3	1/5	2/5	3/5	4/5	1/6	5/6	1/8	3/8	5/8	7/8	1/	I	II	III	IV	V	VI	VII	VIII	IX	X	XI	XII	L	C	D	M	i	ii	iii	iv	v	vi	vii	viii	ix	x	xi	xii	l	c	d	m	(|)	|))	((|))	C	c	6	L	|)))	(((|)))	0/3	2	3					<	^	>	v	:left_right_arrow:	:arrow_up_down:	:arrow_upper_left:	:arrow_upper_right:	:arrow_lower_right:	:arrow_lower_left:	<	>	<	>	<	^	>	v	<	>	<	^	>	v	|	:leftwards_arrow_with_hook:	:arrow_right_hook:	<	>	~	-	v	<	>	<	>	v	<	<	>	\\	=	<	>	<	<	^	^	>	>	v	v	=	|	=	<	^	>	v	=	=	<	-	>	<	^	>	v	-	|	\\	/	\\	/	<	>	<	>	^	v	<	^	>	v	<	>	<	^	>	v	^	^	^	^	^	^	>	\\	\\	|	>	|	>	<	>	-	<	>	-	<	>	-";
    case 34:
      return "V	C	d	E	E	0	^	D	E	E	E	E	E	E	#	P	U	S	-	-+	+	/	\\	*	*	*	sqrt	cbrt	4rt	~	inf	L	<	<	<	|	|	||	||	^	v	^	v	S	S	SSS	S	SS	SSS	S	S	S	:	:	:	::	_	-:	-	~	~	~	~	~	~	~	-~	~	~	~=	=	=	~	~	~	~	~=	=	=	=	=	=	=	=	:=	=:	=	=	=	=	=	=	=	=	=	=	=	=	=	=	<=	>=	<=	>=	<	>	<<	>>	()	=	<	>	<	>	<~	>~	<	>	=	=	=	=	<	>	<	>	<	>	<	>	<	>	<	>	<	>	<	>	<	>	v	v	v	[	]	[	]	^	v	+	-	x	/	.	o	*	=	-	+	-	x	.	+	+	+	+	+	+	+	+	+	+	+	+	+	+	<	>	<	>	<	>	-	-	-	+	T	v	^	v	<	/	^	v	^	v	*	*	*	*	><	><	><	>	<	~=	v	^	<	>	^	v	+	#	<	>	<<<	>>>	=	=	=<	=>	<	>	<	>	[	]	[	]	<	>	<	>	<	>	<	>	|	-	/	\\	+	+	+	+	+	+	+	+	+	+	+	+	+	E";
    case 35:
      return "0	~	^	^	v	^	^	~	[	]	[	]	+	+	+	+	-	*	*	*	*	*	+	#	#	-	:watch:	:hourglass:	+	+	+	+	(	)	(	)	^	*	>	x	:keyboard:	<	>	<	#	*	*	*	*	*	*	*	*	*	I	#	=	:	*	*	*	*	*	/	\\	/	\\	<	>	<	>	<	>	0	*	*	v	*	*	^	^	*	*	^	*	*	v	v	'	*	*	*	*	*	'	*	:	*	*	*	*	*	*	*	~	>	,	*	0	|	;	=	?	v	^	i	r	o	a	e	i	o	a	NAK	+	*	*	|	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	#	.	<	>	#	#	(	(	(	)	)	)	[	[	[	]	]	]	{	{	{	|	}	}	}	|	-	{	{	S	S	[	]	][	/	|	|	-	-	-	-	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	'	<	:eject:	|	-	-	-	-	-	-	3	4	5	+	-	(	)	{	}	[	]	#	#	-	#	*	*	E	:fast_forward:	:rewind:	:arrow_double_up:	:arrow_double_down:	:track_next:	:track_previous:	:play_pause:	:alarm_clock:	:stopwatch:	:timer:	:hourglass_flowing_sand:	<	>	^	v	:pause_button:	:stop_button:	:record_button:	*	*	*	*	<";
    case 36:
      return "NUL	SOH	STX	ETX	EOT	ENQ	ACK	BEL	BS	HT	LF	VT	FF	CR	SO	SI	DLE	DC1	DC2	DC3	DC4	NAK	SYN	ETB	CAN	EM	SUB	ESC	FS	GS	RS	US	SP	DEL	b	_	NL	/	?	#	#	#																							<	>	]	|	*	*	:	;	<	=	%																						1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	(1)	(2)	(3)	(4)	(5)	(6)	(7)	(8)	(9)	(10)	(11)	(12)	(13)	(14)	(15)	(16)	(17)	(18)	(19)	(20)	1.	2.	3.	4.	5.	6.	7.	8.	9.	10.	11.	12.	13.	14.	15.	16.	17.	18.	19.	20.	(a)	(b)	(c)	(d)	(e)	(f)	(g)	(h)	(i)	(j)	(k)	(l)	(m)	(n)	(o)	(p)	(q)	(r)	(s)	(t)	(u)	(v)	(w)	(x)	(y)	(z)	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	0	11	12	13	14	15	16	17	18	19	20	1	2	3	4	5	6	7	8	9	10	0";
    case 37:
      return "-	-	|	|	-	-	|	|	-	-	|	|	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	-	-	|	|	-	|	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	/	\\	X	-	|	-	|	-	|	-	|	-	|	-	|	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	:black_small_square:	:white_small_square:	#	#	#	#	#	#	^	^	^	^	:arrow_forward:	>	>	>	>	>	v	v	v	v	:arrow_backward:	<	<	<	<	<	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	(	)	*	*	*	*	*	*	*	*	*	*	/	\\	/	\\	*	#	#	#	#	#	^	^	^	*	#	#	#	#	*	*	*	*	/	\\	\\	:white_medium_square:	:black_medium_square:	:white_medium_small_square:	:black_medium_small_square:	/";
    case 38:
      return ":sunny:	:cloud:	:umbrella2:	:snowman2:	:comet:	*	*	*	*	*	*	*	0	180	:telephone:	@	#	:ballot_box_with_check:	x	X	:umbrella:	:coffee:	W	B	:shamrock:	*	<	>	<	:point_up:	>	v	:skull_crossbones:	Z	:radioactive:	:biohazard:	+	+	:orthodox_cross:	ChR.	+	+	:star_and_crescent:	*	*	*	:peace:	:yin_yang:	Qian	Dui	Li	Zhen	Xun	Kan	Gen	Kun	:wheel_of_dharma:	:frowning2:	:relaxed:	:)	*	)	(	Mercury	:female_sign:	Earth	:male_sign:	Jupiter	Saturn	Uranus	Neptune	Pluto	:aries:	:taurus:	:gemini:	:cancer:	:leo:	:virgo:	:libra:	:scorpius:	:sagittarius:	:capricorn:	:aquarius:	:pisces:	K	Q	R	B	N	P	k	q	r	b	n	:chess_pawn:	:spades:	H	D	:clubs:	S	:hearts:	:diamonds:	C	:hotsprings:	#	#	#	#	b	#	#	+	+	*	1	2	3	4	5	6	7	*	:recycle:	*	*	:infinity:	:wheelchair:	1	2	3	4	5	6	*	*	*	*	YangYao	YinYao	TaiYang	ShaoYin	ShaoYang	TaiYin	*	*	:hammer_pick:	:anchor:	:crossed_swords:	:medical_symbol:	:scales:	:alembic:	*	:gear:	*	:atom:	:fleur_de_lis:	*	>	<	:warning:	:zap:	*	*	*	*	*	:transgender_symbol:	*	*	:white_circle:	:black_circle:	*	*	*	*	:coffin:	:urn:	*	*	*	*	*	*	*	*	30	150	135	:soccer:	:baseball:	*	M	K	m	k	:snowman:	:partly_sunny:	*	*	:thunder_cloud_rain:	w	b	#	X	*	:ophiuchus:	:pick:	*	:helmet_with_cross:	*	:chains:	:no_entry:	*	*	*	*	*	*	v	*	X	\\	*	*	*	Uranus	*	*	*	*	*	+	:shinto_shrine:	:church:	*	*	*	*	*	:mountain:	:beach_umbrella:	:fountain:	:golf:	:ferry:	:sailboat:	#	:skier:	:ice_skate:	:person_bouncing_ball:	:tent:	*	*	:fuelpump:	*	*";
    case 39:
      return `<	<	:scissors:	<	<	:white_check_mark:	@	@	:airplane:	:envelope:	:fist:	:raised_hand:	:v:	:writing_hand:	\\	:pencil2:	/	>	:black_nib:	v	:heavy_check_mark:	X	:heavy_multiplication_x:	x	x	+	+	+	+	:cross:	+	+	+	:star_of_david:	*	*	*	*	*	*	:sparkles:	*	*	*	*	*	*	*	*	*	*	:eight_spoked_asterisk:	:eight_pointed_black_star:	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	:snowflake:	*	*	:sparkle:	*	*	*	*	:x:	*	:negative_squared_cross_mark:	#	#	#	#	:question:	:grey_question:	:grey_exclamation:	*	:exclamation:	|	|	|	'	'	"	"	'	"	P	!	:heart_exclamation:	:heart:	*	*	*	(	)	(	)	<	>	<	>	<	>	(	)	{	}	1	2	3	4	5	6	7	8	9	10	1	2	3	4	5	6	7	8	9	10	1	2	3	4	5	6	7	8	9	10	>	:heavy_plus_sign:	:heavy_minus_sign:	:heavy_division_sign:	\\	>	/	>	>	>	>	>	>	:arrow_right:	>	>	>	>	>	>	>	>	>	>	>	>	>	>	:curly_loop:	>	>	>	\\	>	/	\\	>	/	>	>	>	>	>	:loop:	^	^	T	<	>	{	}	v	\\<	>/	|	/	)	\\	^	v	#	^	w	>	<	*	*	*	T	T	#	+	-	-	-	+	#	#	#	#	#	#	[	]	<	>	<<	>>	[	]	(	)	^	v	<	>	>	<	>	-	<	>	-	<	>	<	>	>`;
    case 40:
      return " 	a	,	b	'	k	;	l	@	c	i	f	st	m	s	p	*	e	:	h	in	o	!	r	^	d	j	g	ar	n	t	q	+	ch	en	gh	-	u	?	v	_	sh	ow	ed	ing	x	the	and	1	wh	.	ou	\"	z	`	of	|	th	w	er	#	y	with	for	{7}	A	{27}	B	{37}	K	{237}	L	{47}	C	I	F	{347}	M	S	P	{57}	E	{257}	H	{357}	O	{2357}	R	{457}	D	J	G	{3457}	N	T	Q	{67}	{167}	{267}	{1267}	{367}	U	{2367}	V	{467}	{1467}	{2467}	{12467}	{3467}	X	{23467}	{123467}	{567}	{1567}	{2567}	{12567}	{3567}	Z	{23567}	{123567}	{4567}	{14567}	W	{124567}	{34567}	Y	{234567}	{1234567}	{8}	{18}	{28}	{128}	{38}	{138}	{238}	{1238}	{48}	{148}	{248}	{1248}	{348}	{1348}	{2348}	{12348}	{58}	{158}	{258}	{1258}	{358}	{1358}	{2358}	{12358}	{458}	{1458}	{2458}	{12458}	{3458}	{13458}	{23458}	{123458}	{68}	{168}	{268}	{1268}	{368}	{1368}	{2368}	{12368}	{468}	{1468}	{2468}	{12468}	{3468}	{13468}	{23468}	{123468}	{568}	{1568}	{2568}	{12568}	{3568}	{13568}	{23568}	{123568}	{4568}	{14568}	{24568}	{124568}	{34568}	{134568}	{234568}	{1234568}	{78}	{178}	{278}	{1278}	{378}	{1378}	{2378}	{12378}	{478}	{1478}	{2478}	{12478}	{3478}	{13478}	{23478}	{123478}	{578}	{1578}	{2578}	{12578}	{3578}	{13578}	{23578}	{123578}	{4578}	{14578}	{24578}	{124578}	{34578}	{134578}	{234578}	{1234578}	{678}	{1678}	{2678}	{12678}	{3678}	{13678}	{23678}	{123678}	{4678}	{14678}	{24678}	{124678}	{34678}	{134678}	{234678}	{1234678}	{5678}	{15678}	{25678}	{125678}	{35678}	{135678}	{235678}	{1235678}	{45678}	{145678}	{245678}	{1245678}	{345678}	{1345678}	{2345678}	{12345678}";
    case 41:
      return ">	>	<	>	-	>	<	>	v	^	^	v	<	>	<	>	>	>	^	v	>	>	>	>	>	<	>	<	>	<	>	<	>	\\	/	\\	/	\\	/	X	X	X	X	X	X	X	X	X	X	X	X	>	:arrow_heading_up:	:arrow_heading_down:	<	>	<	>	<	>	-	+	<	>	<	>	=	=	=	>	<	>	-	^	-	-	|	|	-	|	-	|	<	>	^	v	<	>	^	v	<	>	^	v	<	>	^	v	<	^	>	v	=	=	=	=	<	<	>	>	|	|	>	>	>	<	>	>	<	<	>	>	<	<	<	>	^	v	|||	*	:	{	}	(	)	(	)	<	>	[	]	[	]	[	]	<	>	<	>	>	<	[	]	:	|	>	^	^	<	<	>	^	>	>	<	>	^	^	^	^	^	^	^	^	^	^	0	0	0	0	0	*	*	*	*	*	*	*	*	*	*	*	<	>	*	*	/	\\	*	o	#	#	^	^	^	^	#	<	>	*	*	*	*	*	*	*	{	}	{{	}}	*	*	*	*	#	<	E	#	#	#	#	#	^	^	#	#	*	*	+	+	+	+	+	+	:>	\\	/	\\	/	\\	++	+++	<	>	+	-";
    case 42:
      return "*	+	x	.	+	^	v	M	W	X	S	S	SSSS	S	S	S	S	S	S	S	S	S	S	S	S	S	S	S	S	><	<	;	>>	|	+	+	+	+	+	+	+	-	-	-	-	(+	+)	x	x	x	x	*	(x	x)	x	x	/	+	-	x	-	-	;	U	^	v	v	^	^	v	X	0	X	0	w	m	v	^	^	v	*	^	v	^	v	M	W	v	^	X	^	v	^	v	^	^	^	v	v	v	<	>	=	=	#	#	~	~	~	=	=	=	=	=+	+=	=~	::=	==	===	=	=	<	>	?<	>?	<=	>=	<=	>=	<=	>=	<=	>=	<	>	<	>	<	>	=	=	<	>	~	~	=	=	=	=	=<	=>	=<	=>	=<	=>	=<	=>	~<	~>	<	>	<<	>>	<<	><	><	<	>	<	>	<	>	<	>	=	<	>	<	>	<	>	<	>	<	>	<	>	<<	>>	<	>	<	>	<	>	<	>	<	>	<	>	<	>	<	>	[	]	<	>	<	>	-	-	<	>	><	><	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	+	-	-	|	|	|	|	||	||	|||	|||	:	<<<	>>>	<=	>=	///	|||	//	|	|";
    case 43:
      return "/	\\	\\	/	-	:arrow_left:	:arrow_up:	:arrow_down:	/	\\	\\	/	-	|	v	^	v	^	-	-	\\	\\	|	|	-	-	#	:black_large_square:	:white_large_square:	-	-	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	<	<	<	<	<	<	<	<	<	<	<	<	<	<	<	<	<	<	<	>	>	<	>	>	>	<	<	<	>	v	/	\\	:star:	*	*	*	*	:o:	*	*	*	*	/	\\	/	\\	>	>	<	^	>	v	-	|	\\	/	\\	/	<	^	>	v	>	<	<	^	>	v			\\	/	\\	/	<	^	>	v	=	|	=	|	=	|	<	^	>	v	<	^	>	v	<	^	>	v	<	>	<	>	*	>		A	<	^	>	v	<	^	>	v	<	>	<	>	^	^	v	v	<	>	<	>	^	^	v	v	<	>	<	>	^	^	v	v	^	^	*	*	*	x	x	x	*	*	*	*	*	^	v	<	>	Neptune	^	v	*	*	*	*	+	?	+	Pluto	Pluto	Pluto	Pluto	*	*	*	*	*	*	*	*	*	Cupido	Hades	Zeus	Kronos	Apollon	Admetos	Vulcanus	Poseidon	*	*	*	*	<	^	>	v	*	*	*	V	N	Q	N2	100	D3	*	*	*	*	*	*	#";
    case 44:
      return "A	B	V	G	D	E	Zh	Dz	Z	I	J	I	G	K	L	M	N	O	P	R	S	T	U	F	H	O	P	Sht	C	Ch	Sh	U	I	E	H	Ju	E	E	Jo	Je	O	Jo	Th	U	I	A	M	Ch	a	b	v	g	d	e	zh	dz	z	i	j	i	g	k	l	m	n	o	p	r	s	t	u	f	h	o	p	sht	c	ch	sh	u	i	e	h	ju	e	e	jo	je	o	jo	th	u	i	a	m	ch	L	l	L	P	R	a	t	H	h	K	k	Z	z	A	M	A	A	v	W	w	v	H	h	o	e	r	o	e	j	V	S	Z	A	a	B	b	G	g	D	d	E	e	6	6	Z	z	E	e	Th	th	I	i	K	k	L	l	M	m	N	n	Ks	ks	O	o	P	p	R	r	S	s	T	t	U	u	Ph	ph	Kh	kh	Ps	ps	O	o	'	'	`	`	E	e	K	k	N	n	N	n	O	o	900	900	Sh	sh	Sh	sh	Sh	sh	X	x	H	h	H	h	H	h	H	h	H	h	H	h	J	j	Dj	dj	C	c	C	c	Ng	ng	Ny	ny	W	w	&	MR.	PR.	STRS.	TR.	KhR.	CS.	Sh	sh	J	j	n			X	x						\\\\	/.	.\\	//	.5	.	'";
    case 45:
      return "a	b	g	d	e	v	z	t	i	k'	l	m	n	o	p'	zh	r	s	t'	u	p	k	gh	q'	sh	ch	ts	dz	ts'	ch'	kh	j	h	e	y	w	x	o		e						ae			a	b	b	g	g	dj	dj	d	d	d	d	e	f	k	k	k	h	h	h	h	'	x	x	q	q	i	j	j	j	l	m	n	gn	ng	p	u	r	r	gh	gh	gh	s	s	c	t	t	tc	t	v	w	y	z	z	z	e	o								w	 																loa	moa	roa	soa	shoa	boa	toa	choa	noa	nyoa	'oa	zoa	doa	d'oa	joa	t'oa	ch'oa	p'oa	poa	ngwe	ngwi	ngwe	ngwi										she	shu	shi	sha	she	sh	sho		che	chu	chi	cha	che	ch	cho		zhe	zhu	zhi	zha	zhe	zh	zho		ch'e	ch'u	ch'i	ch'a	ch'e	ch'	ch'o		k'ye	k'yu	k'yi	k'ya	k'ye	k'y	k'yo		kye	kyu	kyi	kya	kye	ky	kyo		hye	hyu	hyi	hya	hye	hy	hyo		gye	gyu	gyi	gya	gye	gy	gyo		b	v	g	d	zh	z	k	l	m	n	o	p	r	s	t	kh	ts	ch	sh	shch	f	st	a	e	dj	u	e	yu	ia	e	o	io";
    case 46:
      return `+	+	+	+	+	+	+	+	+	+	+	*	\\	/	#	_	_	_	,	/	/	/	>	=	!?	/	-	~	\\	/	~	~	[	]	[	]	[	]	(	)	((	))	:	:	::	+	?	'	*	-	,	-	,	;	+	+	+	S	--	---	.	:	|	C	=	,	"	-	:	.	:	.	.	;	/	+++	,	P	;	/	+	+	&	!	?	[	]	[	]	(	)	(	)	-																																			Bing	Han	Yi	Yi	Yi	Ren	Jiong	Ji	Dao	Dao	Bu	Jie	Xiao	Xiao	Wang	Wang	Wang	Wang	Ji	Yao	Ji	Ji	Xin	Xin	Shou	Pu		Wu	Ri	Yue	Dai	Wu	Shi	Shui	Shui	Huo	Zhao	Zhao	Qiang	Niu	Quan	Yu	Pi	Mu	Shi	Shi	Zhu	Mi	Mi	Wang	Wang	Wang	Wang	Wang	Yang	Yang	Yang	Lao	Yu	Yu	Rou	Jiu	Cao	Cao	Cao	Hu	Yi	Ya	Ya	Jian	Jiao	Jiao	Yan	Bei	Zu	Che	Chuo	Chuo	Chuo	Yi	Jin	Chang	Chang	Chang	Men	Fu	Fu	Yu	Qing	Wei	Ye	Feng	Fei	Shi	Shi	Shi	Shi	Shou	Ma	Gu	Gui	Yu	Niao	Lu	Mai	Huang	Min	Qi	Qi	Chi	Chi	Long	Long	Gui	Gui	Gui`;
    case 47:
      return "Yi	Gun	Zhu	Pie	Yi	Jue	Er	Tou	Ren	Er	Ru	Ba	Jiong	Mi	Bing	Ji	Kan	Dao	Li	Bao	Bi	Fang	Xi	Shi	Bu	Jie	Han	Si	You	Kou	Wei	Tu	Shi	Zhi	Sui	Xi	Da	Nu	Zi	Mian	Cun	Xiao	Wang	Shi	Che	Shan	Chuan	Gong	Ji	Jin	Gan	Yao	Yan	Yin	Gong	Yi	Gong	Ji	Shan	Chi	Xin	Ge	Hu	Shou	Zhi	Pu	Wen	Dou	Jin	Fang	Wu	Ri	Yue	Yue	Mu	Qian	Zhi	Dai	Shu	Wu	Bi	Mao	Shi	Qi	Shui	Huo	Zhao	Fu	Yao	Qiang	Pian	Ya	Niu	Quan	Xuan	Yu	Gua	Wa	Gan	Sheng	Yong	Tian	Pi	Ne	Bo	Bai	Pi	Min	Mu	Mao	Shi	Shi	Shi	Rou	He	Xue	Li	Zhu	Mi	Mi	Fou	Wang	Yang	Yu	Lao	Er	Lei	Er	Yu	Rou	Chen	Zi	Zhi	Jiu	She	Chuan	Zhou	Gen	Se	Cao	Hu	Chong	Xue	Xing	Yi	Ya	Jian	Jiao	Yan	Gu	Dou	Shi	Zhi	Bei	Chi	Zou	Zu	Shen	Che	Xin	Chen	Chuo	Yi	You	Bian	Li	Jin	Chang	Men	Fu	Li	Zhui	Yu	Qing	Fei	Mian	Ge	Wei	Jiu	Yin	Ye	Feng	Fei	Shi	Shou	Xiang	Ma	Gu	Gao	Biao	Dou	Chang	Li	Gui	Yu	Niao	Lu	Lu	Mai	Ma	Huang	Shu	Hei	Zhi	Min	Ding	Gu	Shu	Bi	Qi	Chi	Long	Gui	Yue																											+	+	+	+	+	+	+	+	+	+	+	+	+	+	~	~";
    case 48:
      return ` 	,	.	"	(JIS)	-	/	0	<	>	<<	>>	[	]	[	]	[(	)]	@	=	[	]	[(	)]	[	]	[	]	~	"	"	"	@	1	2	3	4	5	6	7	8	9							:wavy_dash:	<	<'	/	/'	\\	@	XX	10	20	30	-	Masu	:part_alternation_mark:	~	#		a	a	i	i	u	u	e	e	o	o	ka	ga	ki	gi	ku	gu	ke	ge	ko	go	sa	za	shi	ji	su	zu	se	ze	so	zo	ta	da	chi	ji	t	tsu	zu	te	de	to	do	na	ni	nu	ne	no	ha	ba	pa	hi	bi	pi	fu	bu	pu	he	be	pe	ho	bo	po	ma	mi	mu	me	mo	ya	ya	yu	yu	yo	yo	ra	ri	ru	re	ro	wa	wa	i	e	o	n	vu	ka	ka			'	\`	'	\`	-	-'	yori	=	a	a	i	i	u	u	e	e	o	o	ka	ga	ki	gi	ku	gu	ke	ge	ko	go	sa	za	shi	ji	su	zu	se	ze	so	zo	ta	da	chi	ji	t	tsu	zu	te	de	to	do	na	ni	nu	ne	no	ha	ba	pa	hi	bi	pi	fu	bu	pu	he	be	pe	ho	bo	po	ma	mi	mu	me	mo	ya	ya	yu	yu	yo	yo	ra	ri	ru	re	ro	wa	wa	i	e	o	n	vu	ka	ka	va	vi	ve	vo	-		-	-'	koto`;
    case 49:
      return "					b	p	m	f	d	t	n	l	g	k	h	j	q	x	zh	ch	sh	r	z	c	s	a	o	e	e	ai	ei	ao	ou	an	en	ang	eng	er	i	u	u	v	ng	gn	i	e	n		g	kk	gs	n	nj	nh	d	tt	l	lg	lm	lb	ls	lt	lp	lh	m	b	pp	bs	s	ss		j	jj	ch	k	t	p	h	a	ae	ya	yae	eo	e	yeo	ye	o	wa	wae	oe	yo	u	wo	we	wi	yu	eu	ui	i		nn	nd	ns	nz	lgs	ld	lbs	lz	lq	mb	ms	mz	w	bg	bd	bsg	bsd	bj	bt	v	ff	sg	sn	sd	sb	sj	z		ng	ngs	ngz	f	hh	q	yoya	yoyae	yoi	yuyeo	yuye	yui	o	oi		-	re	1	2	3	4	A	B	C	I	II	III	IV	a	b	c	b	j	ji	g	e	enn	oo	onn	ir	ann	inn	unn	m	ng	ainn	aunn	am	om	ong	inn	p	t	k	h	v	dl	y	k	gw	kw	eu	a	T	WG	XG	BXG	SW	HZZ	HZG	HP	HZWG	SZWG	HZT	HZZP	HPWG	HZW	HZZZ	N	H	S	P	SP	D	HZ	HG	SZ	SWZ	ST	SG	PD	PZ	TN	SZZ	SWG	HXWG	HZZZG	PG	Q	HXG	SZP										-	k	s	s	t	n	h	h	h	h	h	m	r	r	r	r	r";
    case 50:
      return "(g)	(n)	(d)	(l)	(m)	(b)	(s)	()	(j)	(ch)	(k)	(t)	(p)	(h)	(Ga)	(Na)	(Da)	(La)	(Ma)	(Ba)	(Sa)	(A)	(Ja)	(Cha)	(Ka)	(Ta)	(Pa)	(Ha)	(Ju)	(OJeon)	(OHu)		(1)	(2)	(3)	(4)	(5)	(6)	(7)	(8)	(9)	(10)	(Yue)	(Huo)	(Shui)	(Mu)	(Jin)	(Tu)	(Ri)	(Zhu)	(You)	(She)	(Ming)	(Te)	(Cai)	(Zhu)	(Lao)	(Dai)	(Hu)	(Xue)	(Jian)	(Qi)	(Zi)	(Xie)	(Ji)	(Xiu)	(Zi)	(Zhi)	Wen	You	Wen	Zheng	10	20	30	40	50	60	70	80	PTE	21	22	23	24	25	26	27	28	29	30	31	32	33	34	35	g	n	d	l	m	b	s		j	ch	k	t	p	h	Ga	Na	Da	La	Ma	Ba	Sa	A	Ja	Cha	Ka	Ta	Pa	Ha	ChamGo	JuUi	U	(K)	(1)	(2)	(3)	(4)	(5)	(6)	(7)	(8)	(9)	(10)	Yue	Huo	Shui	Mu	Jin	Tu	Ri	Zhu	You	She	Ming	Te	Cai	Zhu	Lao	Mi	Nan	Nu	Shi	You	Yin	Zhu	Xiang	Xiu	Xie	Zheng	Shang	Zhong	Xia	Zuo	You	Yi	Zong	Xue	Jian	Qi	Zi	Xie	Ye	36	37	38	39	40	41	42	43	44	45	46	47	48	49	50	1M	2M	3M	4M	5M	6M	7M	8M	9M	10M	11M	12M	Hg	erg	eV	LTD	a	i	u	e	o	ka	ki	ku	ke	ko	sa	shi	su	se	so	ta	chi	tsu	te	to	na	ni	nu	ne	no	ha	hi	fu	he	ho	ma	mi	mu	me	mo	ya	yu	yo	ra	ri	ru	re	ro	wa	i	e	o	Reiwa";
    case 51:
      return "apartment	alpha	ampere	are	inning	inch	won	escudo	acre	ounce	ohm	kai-ri	carat	calorie	gallon	gamma	giga	guinea	curie	guilder	kilo	kilogram	kilometer	kilowatt	gram	gram ton	cruzeiro	krone	case	koruna	co-op	cycle	centime	shilling	centi	cent	dozen	deci	dollar	ton	nano	knot	heights	percent	parts	barrel	piaster	picul	pico	building	farad	feet	bushel	franc	hectare	peso	pfennig	hertz	pence	page	beta	point	volt	hon	pound	hall	horn	micro	mile	mach	mark	mansion	micron	milli	millibar	mega	megaton	meter	yard	yard	yuan	liter	lira	rupee	ruble	rem	roentgen	watt	0H	1H	2H	3H	4H	5H	6H	7H	8H	9H	10H	11H	12H	13H	14H	15H	16H	17H	18H	19H	20H	21H	22H	23H	24H	hPa	da	AU	bar	oV	pc	dm	dm2	dm3	IU	Heisei	Showa	Taisho	Meiji	Inc.	pA	nA	uA	mA	kA	KB	MB	GB	cal	kcal	pF	nF	uF	ug	mg	kg	Hz	kHz	MHz	GHz	THz	ul	ml	dl	kl	fm	nm	um	mm	cm	km	mm2	cm2	m2	km2	mm3	cm3	m3	km3	m/s	m/s2	Pa	kPa	MPa	GPa	rad	rad/s	rad/s2	ps	ns	us	ms	pV	nV	uV	mV	kV	MV	pW	nW	uW	mW	kW	MW	kOhm	MOhm	a.m.	Bq	cc	cd	C/kg	Co.	dB	Gy	ha	HP	in	KK	KM	kt	lm	ln	log	lx	mb	mil	mol	PH	p.m.	PPM	PR	sr	Sv	Wb	V/m	A/m	1D	2D	3D	4D	5D	6D	7D	8D	9D	10D	11D	12D	13D	14D	15D	16D	17D	18D	19D	20D	21D	22D	23D	24D	25D	26D	27D	28D	29D	30D	31D	gal";
    case 52:
      return "Qiu	Tian	Ki	Zim	Kua	Wu	Yin	Gau	Jap	Ding	Si	Tou	Yi	Zaau	Man	Ng	Nou	Dung	Ziu	Ho	Hang	Jau	Xie	Lou	Mai	Dau	Ng	Jau	Chou	Keoi	Kei	Fei	Jyu	Nuo	Fau	Fu	Dan	Co	Geoi	Dai	Xu	Xing	Si	Xiong	Liu	Lin	Xiang	Yong	Xin	Zhen	Dai	Wu	Pan	Ru	Ci	Ma	Qian	Yi	Yin	Nei	Cheng	Feng	Wun	Sau	Taai	Zhuo	Fang	Ao	Wu	Zuo	Hing	Zhou	Dong	Su	Yi	Qiong	Kuang	Lei	Nao	Zhu	Shu	Zat	Cim	Zeon	Xu	Seoi	Zung	Shen	Jie	Die	Nuo	Su	Yi	Long	Ying	Beng	Gin	Zik	Koek	Lan	Miao	Yi	Li	Ji	Yu	Luo	Chai	Nim	Gu	Bei	Hun	Xu	Hui	Rao	Naam	Zhou	Cam	Han	Xi	Tai	Yao	Hui	Jun	Ma	Lue	Tang	Yao	Zhao	Zhai	Yu	Zhuo	Er	Ran	Qi	Chi	Wu	Han	Tang	Se	Si	Qiong	Lei	Sa	Hon	Seon	Kui	Pu	Ta	Shu	Yang	Ou	Tai	Syu	Mian	Yin	Diao	Yu	Mie	Jun	Niao	Xie	You	Joek	Jing	Che	Feng	Lei	Li	Sin	Luo	Sek	Ji	Wong	Kon	Fui	Jip	Quan	Zik	Cai	Liang	Gu	Mao	Gung	Gua	Sui	Din	Mong	Mao	Man	Quan	Shi	Li	Buk	Wang	Kou	Du	Zhen	Ting	Leon	Juk	Bing	Huo	Dong	Gong	Cheng	Cung	Qin	Jiong	Lu	Xing	Cat	Nan	Xie	Mit	Bi	Jie	Su	Hung	Gong	Gung	You	Xing	Qia	Pi	Dian	Fu	Luo	Qia	Qia	Tang	Bai	Gan	Ci	Xuan	Lang	Fu	Fu	She	Diao	Li	Hua	Tou	Pian	Di	Ruan	E	Qie	Yi	Zhuo	Rui	Jian	Gong	Chi	Chong	Xi	Syu";
    case 53:
      return "Lue	Deng	Lin	Jue	Su	Xiao	Zan	Put	Fei	Zhu	Zhan	Jian	Zou	Chua	Xie	Li	Cim	Chi	Xi	Jian	Gaa	Ji	Gaa	Fei	Chu	Beng	Jie	Kit	Ba	Liang	Kuai	Sai	Xia	Bie	Jue	Lei	Xin	Bai	Yang	Lu	Bei	E	Lu	Lung	Coek	Che	Nuo	Xuan	Heng	Yu	Gwai	Gui	Yi	Xuan	Gong	Lou	Ti	Le	Shi	Pei	Sun	Yao	Xian	Zou	Wai	Que	Yin	Xi	Zhi	Jia	Hu	La	Yi	Ke	Fu	Qin	Ai	Deoi	Ke	Chu	Xie	Chu	Wei	Cin	Teng	Huan	Su	You	Caam	Jun	Zhao	Xu	Shi	Si	Shua	Kui	Shuang	He	Gai	Yan	Qiu	Shen	Hua	Xi	Fan	Pang	Dan	Fang	Gong	Ao	Fu	Ne	Xue	You	Hua	Hung	Chen	Guo	N	Hua	Li	Fa	Xiao	Pou	Hung	Si	Siu	Wo	Le	Lin	Yi	Hou	Shu	Xu	Qu	Er	Lou	Kei	Xun	Gaai	Sau	Dau	Gaai	Nie	Wei	Xie	Ti	Hong	Tun	Nie	Nie	Yin	Zhen	Gaa	Fu	Gu	Jing	Mei	Wai	Shou	Nuo	Ye	Qi	Tou	Han	Jun	Dong	Hun	Lu	Ju	Huo	Ling	Sau	Tian	Lun	Tung	Tung	Je	Jyu	Jyu	Man	Ge	Yan	Shi	Xue	Pen	Chun	Niu	Duo	Ze	E	Xie	You	E	Sheng	Wen	Ku	Hu	Ge	Xia	Man	Lue	Ji	Hou	Zhi	Zaai	Gaa	Wai	Haap	Bai	Ai	Zhui	Qian	Gou	Dan	Bei	Bo	Chu	Li	Xiao	Xiu	Gou	Po	Zyu	Ci	Jing	Hong	Ti	Cu	Kuo	Lao	Zhi	Xie	Xi	Pei	Qie	Zha	Xi	Gang	Ze	Cong	Ji	Huo	Ta	Yan	Xu	Po	Sai	Haam	Wai	Saap	Guo	Ye	Xiang	Xue	He";
    case 54:
      return "Zuo	Yi	Ci	Je	Leng	Xian	Tai	Rong	Yi	Zhi	Xi	Xian	Ju	Ji	Han	Dou	Pao	Li	Zung	Lan	Sai	Han	Yan	Qu	Lyun	Yan	Han	Kan	Chi	Nie	Huo	Coeng	Bi	Xia	Weng	Xuan	Wan	You	Qin	Xu	Nie	Bi	Hao	Jing	Ao	Ao	Jik	Coeng	Zhen	Tan	Ju	Kyu	Zuo	Bu	Jie	Ai	Zang	Ci	Fa	In	Haau	Zoi	Jyu	Nie	Liu	Mei	Dui	Bang	Bi	Bao	Wang	Chu	Xia	Tian	Chang	Gei	Suk	Duo	Wei	Fu	Duo	Yu	Ye	Kui	Wei	Kuai	Jyu	Wei	Yao	Long	Xing	Bu	Chi	Xie	Nie	Lang	Yi	Zong	Man	Zhang	Xia	Gun	Xie	Lau	Ji	Liao	Yi	Ji	Yin	Kyut	Da	Yi	Xie	Hao	Yong	Kan	Chan	Tai	Tang	Zhi	Bao	Meng	Kui	Chan	Lei	Sik	Xi	Hei	Xi	Qiao	Nang	Yun	Zi	Long	Fu	Zong	Ngoi	Gu	Kai	Diao	Hua	Kui	Heoi	Gao	Tao	Ling	Shan	Lai	Nie	Fu	Gao	Qie	Ban	Jia	Kong	Xi	Yu	Zhui	Shen	Chuo	Xiao	Ji	Nu	Xiao	Yi	Yu	Yi	Yan	Shen	Ran	Hao	Sa	Jun	You	Daam	Xin	Pei	Qiu	Chan	Ka	Bu	Dong	Si	Er	Si	Mao	Yun	Ji	Ko	Qiao	Xiong	Pao	Chu	Peng	Nuo	Jie	Yi	Er	Duo	Zong	Haau	Jiu	Duo	Nei	Mau	Qie	Lu	Qiu	Sou	Can	Dou	Xi	Feng	Yi	Suo	Qie	Po	Xin	Tong	Xin	You	Bei	Long	Wun	Haan	Wan	Sau	Yun	Li	Ta	Lan	Man	Qiang	Zhou	Yan	Xi	Lu	Xi	Sao	Fan	Fan	Wei	Fa	Yi	Nao	Cheng	Tan	Ji	Shu	Pian	An	Kua	Cha	Saan	Xian	Zhi";
    case 55:
      return "Soeng	Caa	Feng	Lian	Xun	Xu	Mi	Hui	Mu	Yong	Zhan	Yi	Nou	Tang	Xi	Yun	Shu	Fu	Yi	Da	Ging	Lian	Cao	Can	Ju	Lu	Su	Nen	Ao	An	Qian	Haam	Cui	Cong	Leoi	Ran	Nian	Mai	Xin	Yue	Nai	Ao	Shen	Ma	Daam	Dong	Lan	Xi	Yue	Zhi	Weng	Huai	Meng	Niao	Wan	Mi	Nie	Qu	Zan	Lian	Zhi	Zi	Hai	Xu	Hao	Xuan	Zhi	Mian	Chun	Gou	Hei	Chun	Luan	Zhu	Shou	Liao	Jiu	Xie	Ding	Jie	Rong	Mang	Geoi	Ke	Yao	Ning	Yi	Lang	Yong	Yin	Yan	Su	Sik	Lin	Ya	Mao	Ming	Zui	Yu	Yi	Gou	Mi	Jun	Wen	Jyun	Kang	Dian	Long	Wu	Xing	Cui	Qiao	Mian	Meng	Qin	Sam	Wan	De	Ai	Cam	Bian	Nou	Lian	Jin	Yu	Chui	Zuo	Bo	Hui	Yao	Tui	Ji	An	Luo	Ji	Wei	Bo	Za	Xu	Nian	Yun	Jyun	Ba	Zhe	Ju	Wei	Xie	Qi	Yi	Xie	Ci	Qiu	Du	Niao	Qi	Ji	Tui	Cik	Song	Dian	Lao	Zhan	Zi	Fan	Yin	Cen	Ji	Hui	Zi	Lan	Nao	Ju	Qin	Dai	Shutsu	Jie	Xu	Cong	Yong	Dou	Chi	Tou	Min	Huang	Sui	Ke	Zu	Hao	Cheng	Xue	Ni	Chi	Lian	An	Mu	Si	Xiang	Yang	Hua	Cuo	Qiu	Lao	Fu	Dui	Mang	Lang	Tuo	Han	Mang	Bo	Qun	Qi	Han	Giu	Long	Bin	Tiao	Ze	Qi	Zan	Mi	Pei	Zhan	Xiang	Gang	Kwai	Qi	Sung	Lu	Cam	Yun	E	Duan	Min	Wei	Quan	Sou	Min	Tu	Ngaak	Ming	Yao	Jue	Li	Kuai	Gang	Yuan	Da	Gou	Lao	Lou	Qian	Ao	Biao	Yong	Mang";
    case 56:
      return "Dao	Shin	Ao	Dik	Xi	Fu	Dan	Jiu	Run	Tong	Qu	E	Qi	Ji	Ji	Hua	Jiao	Zui	Biao	Meng	Bai	Wei	Yi	Ao	Yu	Hao	Dui	Wo	Ni	Cuan	Zing	Li	Lu	Niao	Huai	Li	Soeng	Lu	Feng	Mi	Yu	Fong	Ju	Faan	Hau	Zhan	Peng	Yi	Gaa	Ji	Bi	Jap	Ren	Huang	Fan	Ge	Ku	Jie	Sha	Hei	Si	Tong	Yuan	Zi	Bi	Kua	Li	Huang	Xun	Nuo	Fong	Zhe	Wen	Xian	Qia	Ye	Mao	Mok	Saam	Shu	Zin	Qiao	Zhun	Kun	Wu	Ying	Chuang	Ti	Lian	Bi	Gou	Mang	Xie	Feng	Lou	Zao	Zheng	Chu	Man	Long	Jip	Yin	Pin	Zheng	Jian	Luan	Nie	Yi	Gei	Ji	Ji	Zhai	Yu	Jiu	Huan	Zhi	La	Ling	Zhi	Ben	Zha	Ju	Dan	Liao	Yi	Zhao	Xian	Chi	Ci	Chi	Yan	Lang	Dou	Long	Chan	Jin	Tui	Cha	Ai	Chi	Aa	Ying	Zhe	Tou	Waa	Tui	Cha	Yao	Zong	Yo	Pan	Qiao	Lian	Qin	Lu	Yan	Kang	Su	Yi	Chan	Jiong	Jiang	Bai	Jing	Zoi	Dong	Go	Juan	Han	Di	Wu	Saan	Hong	Tou	Chi	Diao	Bi	Nei	Xun	Lu	Sai	Xie	Bi	Seoi	Bi	San	Xian	Rui	Bie	Er	Juan	Hau	Zhen	Bei	E	Yu	Qu	Zan	Mi	Yi	Si	Gung	Man	Daan	Shan	Tai	Mu	Jing	Bian	Rong	Ceng	Can	Ding	Daai	Taai	Wu	Keoi	Di	Tong	Ta	Xing	Song	Duo	Xi	Tao	Zung	Ti	Shan	Jian	Zhi	Wei	Yin	Gu	Lam	Huan	Zhong	Qi	Zong	Naam	Xie	Xie	Ze	Wei	Mou	Wong	Ta	Zhan	Ning	Jeoi	Jing	Xin	Yi	Ren	Shu	Cha	Zhuo";
    case 57:
      return "Mong	Mian	Ji	Fang	Pei	Ai	Fan	Ao	Qin	Qia	Xiao	Fen	Gan	Qiao	Ge	Tong	Chan	You	Gao	Ben	Fu	Chu	Zhu	Taai	Zhou	On	Hang	Nin	Jue	Chong	Cha	Kong	Lie	Li	Yu	Paang	Yu	Hai	Li	Hou	Gong	Ke	Yuan	De	Hui	Giu	Guang	Jiong	Zuo	Fu	Qie	Bei	Che	Ci	Mang	Han	Xi	Qiu	Huang	Tung	Gip	Chou	San	Yan	Zhi	De	Te	Men	Ling	Shou	Tui	Can	Die	Che	Peng	Yi	Ju	Ji	Lai	Tian	Yuan	O	Cai	Qi	Yu	Lian	Cong	Man	Gip	Zung	Yu	Ji	Wei	Mi	Sui	Xie	Xu	Chi	Qiu	Hui	Ging	Yu	Qie	Shun	Shui	Duo	Lou	Deon	Pang	Tai	Zhou	Yin	Sao	Fei	Chen	Yuan	Yi	Hun	Se	Ye	Min	Fen	He	Cik	Yin	Ce	Ni	Ao	Feng	Lian	Chang	Chan	Ma	Die	Hu	Lu	Oi	Yi	Hua	Zha	Hu	E	Huo	Sun	Ni	Xian	Li	Xian	Yan	Long	Men	Jin	Ji	Jyu	Bian	Yu	Huo	Miao	Chou	Mai	Deoi	Le	Jie	Wei	Yi	Xuan	Xi	Can	Lan	Yin	Xie	Za	Luo	Ling	Qian	Huo	Jian	Wo	Zoi	Zoi	Ge	Zhu	Die	Yong	Ji	Yang	Ru	Xi	Shuang	Yu	Yi	Qian	Ji	Qu	Tian	Shou	Qian	Mu	Jin	Mao	Yin	Gai	Po	Xuan	Mao	Fang	Ya	Gang	Song	Hui	Yu	Gua	Guai	Liu	E	Zi	Zi	Bi	Wa	Laam	Lie		Bat	Kuai	Mei	Hai	Yin	Zhu	Chong	Xian	Xuan	So	Qiu	Pei	Gui	Er	Gong	Qiong	Hu	Lao	Li	Chen	San	Zhuo	Wo	Pou	Keng	Tun	Peng	Te	Ta	Zhuo	Biao	Gu	Hu	So";
    case 58:
      return "Bing	Zhi	Dong	Dui	Zhou	Nei	Lin	Po	Ji	Min	Wei	Che	Gou	Bang	Ru	Tan	Bu	Zong	Kui	Lao	Han	Ying	Zhi	Jie	Xing	Xie	Xun	Shan	Qian	Xie	Su	Hai	Mi	Hun	Pi	Jung	Hui	Na	Song	Ben	Chou	Jie	Huang	Lan	Jyun	Hu	Dou	Huo	Gun	Yao	Ce	Gui	Jian	Jian	Dao	Jin	Ma	Hui	Mian	Can	Lue	Pi	Yang	Ju	Ju	Que	Huk	Qian	Shai	Cau	Jiu	Huo	Yun	Da	Xuan	Xiao	Fei	Ce	Ye	Hak	Den	Saap	Qin	Hui	Tun	Ling	Qiang	Xi	Ni	Sai	Meng	Tuan	Lan	Hao	Ci	Zhai	Ao	Luo	Mie	Ki	Fu	Sen	Xie	Bo	Hui	Qing	Xie	Zat	Hei	Bo	Qian	Po	Jiao	Jue	Kun	Song	Ju	E	Nie	Qian	Die	Die	Pei	Qi	Zhi	Qi	Zhui	Ku	Yu	Qin	Ku	He	Fu	Geng	Di	Xian	Gui	He	Qun	Han	Tong	Bo	Shan	Bi	Lu	Ye	Ni	Chuai	San	Diao	Lu	Tou	Lian	Ke	San	Zhen	Chuai	Lian	Mao	Deon	Qian	Kai	Shao	Xiao	Bi	Zha	Yin	Xi	Shan	Su	Sa	Rui	Chuo	Lu	Ling	Cha	Zaai	Huan			Jia	Ban	Hu	Dou	Shin	Lou	Ju	Juan	Ke	Suo	Luo	Zhe	Ding	Duan	Zhu	Yan	Pang	Cha	Ji	Jyu	Jyu	Ngai	Yi	Zin	Syun	You	Hui	Yao	Yao	Zhi	Gong	Qi	Gen	Gwong	Zi	Hou	Mi	Fu	Hu	Guang	Tan	Di	Tou	Yan	Bun	Dung	Qu	Man	Chang	Ming	Tao	Bao	An	Ceon	Zung	Xian	Ceon	Si	Ci	Mao	Lang	Nan	Bei	Chen	Ko	Fei	Zhou	Ji	Jie	Shu	Sik	Kun	Die	Lu	Soeng	Zeoi";
    case 59:
      return "Hoeng	Caap	Yu	Tai	Chan	Man	Min	Huan	Wen	Nuan	Huan	Hou	Jing	Bo	Xian	Li	Jin	Gwok	Mang	Piao	Hao	Yang	Kai	Xian	Su	Wei	Che	Xi	Jin	Ceng	He	Fen	Shai	Ling	Hei	Dui	Qi	Pu	Yue	Bo	Haak	Hui	Die	Yan	Ju	Jiao	Nan	Lie	Yu	Ti	Tian	Wu	Hong	Xiao	Hao	Kwan	Tiao	Zheng	Tang	Huang	Fu	Ngok	Tyun	Tun	Sai	Reng	Jiao	Gong	Xin	Saam	Naai	Yuan	Jue	Hua	Sik	Bang	Mou	Cat	Gang	Wei	Daai	Mei	Si	Bian	Lu	Qu	Doi	Ming	Ge	Zhe	Lu	Pai	Rong	Qiu	Lie	Gong	Xian	Xi	Xin	Man	Niao	Fu	Zaak	Zau	Xie	Lie	Fu	Cuo	Zhuo	Ba	Zuo	Zhe	Zui	He	Ji	Haau	Jian	Din	Fong	Naam	Tu	Xian	Yan	Tang	Ta	Di	Jue	Ang	Han	Xiao	Ju	Wei	Bang	Zhui	Nie	Tian	Nai	Hap	Mau	You	Mian	Zin	Bui	Nai	Sheng	Cha	Yan	Gen	Chong	Ruan	Jia	Qin	Mao	E	Li	Chi	Zang	He	Jie	Nian	Wing	Guan	Hou	Gai	Cung	Ben	Suo	Wu	Ji	Xi	Qiong	He	Weng	Xian	Jie	Hun	Pi	Shen	Chou	Zhen	Sau	Zhan	Shuo	Ji	Song	Zhi	Ben	Sou	Sin	Pun	Lang	Bi	Xuan	Pei	Dai	Qi	Zhi	Pi	Chan	Bi	Su	Huo	Hen	Jiong	Chuan	Jiang	Nen	Gu	Fang	Zoeng	Mik	Ta	Cui	Xi	De	Xian	Kuan	Zhe	Ta	Hu	Cui	Lu	Juan	Lu	Qian	Pao	Zhen	Fan	Li	Cao	Qi	Ciu	Suk	Ti	Ling	Qu	Lian	Lu	Shu	Gong	Zhe	Pao	Jin	Qing	Jung	Dung	Zong	Pu	Jin	Biao	Jian	Gun	Goi	Bin	Zao	Lie";
    case 60:
      return "Li	Luo	Shen	Mian	Jian	Di	Bei		Lian	Zeon	Xian	Pin	Que	Long	Zui	Gou	Jue	Shan	Xue	Laam	Xie	Hei	Lan	Qi	Yi	Nuo	Li	Yue	Din	Yi	Chi	Ji	Hang	Xie	Keng	Zi	He	Xi	Qu	Hai	Xia	Hai	Gui	Chan	Xun	Xu	Shen	Kou	Xia	Sha	Yu	Ya	Pou	Zu	You	Zi	Lian	Xian	Xia	Yi	Sha	Yan	Jiao	Xi	Chi	Shi	Kang	Yin	Hei	Yi	Xi	Se	Jin	Ye	You	Que	Ye	Luan	Kun	Zheng	Zing	Seoi	Ho	Ling	Xie	Gwai	Cui	Xiu	An	Xiu	Can	Chuan	Zha	Sei	Yi	Pi	Ku	Sheng	Lang	Tui	Xi	Ling	Qi	Wo	Lian	Du	Men	Lan	Wei	Duan	Kuai	Ai	Zai	Hui	Yi	Mo	Zi	Fen	Peng	Zaap	Bi	Li	Lu	Luo	Hai	Zhen	Gai	Que	Zhen	Kong	Cheng	Jiu	Jue	Ji	Ling	Dung	Shao	Que	Rui	Chuo	Neng	Zhi	Lou	Pao	Gam	Seoi	Bao	Rong	Xian	Lei	Xiao	Fu	Qu	Sho	Sha	Zhi	Tan	Rong	Su	Ying	Mao	Nai	Bian	Shu	Shuai	Tang	Han	Sao	Rong	Taap	Deng	Pu	Jiao	Tan	Taap	Ran	Ning	Lie	Die	Die	Zhong	Siu	Lu	Dan	Xi	Gui	Ji	Ni	Yi	Nian	Yu	Wang	Guo	Ze	Yan	Cui	Xian	Jiao	Tou	Fu	Pei	Jyut	You	Qiu	Ya	Bu	Bian	Shi	Zha	Yi	Bian	Jau	Dui	Lan	Yi	Chai	Chong	Xuan	Xu	Yu	Xiu	Hong	Cung	Hung	Ta	Guo	Kiu	Lou	Suk	Long	Xie	Che	Jian	Tan	Pi	Zan	Xuan	Xian	Niao	San		Joeng	Taai	Hak	Mi	Ji	Nou	Hu	Hua	Wang	You	Ze	Bi	Mi	Qiang	Xie";
    case 61:
      return "Fan	Yi	Tan	Lei	Yong	Siu	Jin	She	Yin	Ji	En	Su	Gu	Sing	Nai	Wang	Mian	Su	Yi	Shai	Ji	Ji	Luo	You	Mao	Zha	Sui	Zhi	Bian	Li	Tou	Hau	Haam	Hoeng	Cung	Ji	Cyu	Qiao	Guan	Xi	Zhen	Yong	Nie	Jun	Xie	Yao	Xie	Zhi	Neng	Sam	Si	Long	Chen	Mi	Que	Dan	Shan	Mai	Zip	Syu	Su	Xie	Bo	Ding	Zu	Fong	Shu	She	Han	Tan	Gao	Tim	Gu	Lam	Na	Mi	Xun	Men	Jian	Cui	Jue	He	Fei	Shi	Che	Shen	Nu	Ping	Man		Fu	Sin	Naam	Yi	Chou	Mei	Ku	Bao	Lei	Ke	Sha	Mi	Sui	Ge	Pi	Yi	Xian	Ni	Ying	Zhu	Chun	Feng	Xu	Piao	Wu	Liao	Cang	Zou	Zuo	Bian	Yao	Huan	Pai	Xiu	Se	Lei	Qing	Xiao	Jiao	Guo	Wong	Mou	Yan	Xue	Zhu	Heng	Ying	Xi	Can	Jeoi	Lian	Xian	Huan	Yin	Jing	Lian	Shan	Cang	Bei	Jian	Shu	Fan	Dian	Jeoi	Ba	Yu	En	Jing	Nang	Lei	Yi	Dai	Gau	Chan	Chao	Gan	Jin	Nen	Hai	Jam	Pui	Liao	Mo	You	Siu	Liu	Han	Bun	Yong	Jin	Chi	Ren	Nong	Ceon	Hip	Hong	Tian	Fung	Ai	Gua	Biao	Bo	Qiong	Jung	Shu	Chui	Hui	Chao	Fu	Hui	E	Wei	Fen	Tan	Zau	Lun	He	Yong	Hui	En	Yu	Zong	Yan	Qiu	Zhao	Jiong	Tai	Zin	Ting	Bou	Jik	Dat	Hau	Tui	Lin	Jiong	Zha	Xing	Hu	Zing	Xu	Jyun	Fung	Hei	Cui	Qing	Mo	Fung	Zao	Beng	Chi	Hung	Dung	Yan	Ge	Mo	Bei	Juan	Die	Zhao	Saat	Wu	Yan	Sin	Jue	Xian";
    case 62:
      return "Tai	Han	Seoi	Dian	Ji	Jie	Kao	Zuan	Ziu	Xie	Lai	Fan	Huo	Xi	Nie	Mi	Ran	Cuan	Yin	Mi	Hon	Jue	Qu	Tong	Wan	Zhe	Li	Shao	Kong	Xian	Zhe	Zhi	Tiao	Shu	Bei	Ye	Pian	Chan	Hu	Ken	Jiu	An	Chun	Qian	Bei	Ba	Fen	Ke	Tuo	Tuo	Zuo	Ling	Sek	Gui	Yan	Shi	Hou	Lie	Sha	Si	Fung	Bei	Ren	Du	Bo	Liang	Qian	Fei	Ji	Zong	Hui	He	Li	Yuan	Yue	Xiu	Chan	Di	Lei	Jin	Chong	Si	Pu	Yao	Jiang	Huan	Huan	Tao	Ru	Weng	Ying	Rao	Yin	Shi	Yin	Jue	Tun	Xuan	Jia	Zhong	Qie	Zhu	Diao	Yo	You	Hing	Saan	Yi	Shi	Yi	Mo	Kyu	Gwong	Que	Xiao	Wu	Geng	Ying	Ting	Shi	Ni	Geng	Ta	Wo	Ju	Chan	Piao	Zhuo	Hu	Nao	Yan	Gou	Yu	Hou	Ban	Si	Chi	Hu	Yang	Weng	Xian	Pin	Rong	Lou	Lao	Shan	Xiao	Ze	Hai	Fan	Han	Chan	Zhan	Sat	Ta	Zhu	Nong	Han	Yu	Zhuo	You	Li	Huo	Xi	Xian	Chan	Lian	Hiu	Si	Jiu	Pu	Qiu	Gong	Zi	Yu	Lung	Si	Reng	Niu	Mei	Ba	Jiu	Dau	Xu	Ping	Bian	Mao	Fat	Pat	Pei	Gwing	Yi	Yu	Gwai	Ping	Qu	Bao	Hui	Jyun	Cyun	Hau	Bu	Mang	La	Tu	Wu	Li	Ling	Ceon	Ji	Jun	Zou	Duo	Jue	Dai	Bei	Sam	Juk	Pang	Ji	Cung	La	Bin	Sui	Tu	Xue	Si	Sam	Gik	Jau	Jyu	Duo	Jyun	Gim	Sui	Bi	Tu	Se	Can	Tu	Mian	Jin	Lu	Lei	Maan	Zhan	Bi	Ji	Zen	Xuan	Li	Deon	Taam	Sui	Yong	Shu";
    case 63:
      return "Daat	Ji	E	Laap	Gei	Gwong	Ying	Qiong	Luo	Zhen	Tun	Gu	Yu	Lei	Bo	Nei	Pian	Lian	Tang	Lian	Wen	Dang	Li	Ting	Wa	Zhou	Gang	Xing	Ang	Fan	Peng	Bo	Tuo	Shu	Yi	Bo	Qie	Tou	Gong	Tong	Han	Cheng	Jie	Huan	Xing	Dian	Chai	Dong	Pi	Ruan	Lie	Sheng	Ou	Di	Yu	Chuan	Rong	Kang	Tang	Cong	Piao	Chuang	Lu	Tong	Zheng	Li	Sa	Pan	Si	Dang	Dang	Hu	Yi	Xian	Xie	Luo	Liu	Ham	Tan	Gan	Ken	Tan	Sang	San	Jeoi	You	Nan	Din	Gang	Jun	Chi	Gou	Wan	Li	Liu	Lie	Xia	Bei	An	Yu	Ju	Rou	Xun	Zi	Cuo	Can	Zeng	Yong	Fu	Ruan	Sing	Xi	Shu	Jiao	Jiao	Xu	Zhang	Zong	Gei	Shui	Chen	Fan	Ji	Zhi	Jan	Gu	Wu	Ka	Qie	Shu	Hai	Tuo	Du	Zi	Ran	Mu	Fu	Ling	Ji	Xiu	Xuan	Nai	Ya	Jie	Li	Da	Ru	Yuan	Lu	Shen	Li	Liang	Geng	Xin	Xie	Qin	Qie	Che	You	Bu	Kuang	Que	Ai	Qin	Qiang	Chu	Pei	Kuo	Yi	Guai	Sheng	Pian	Gaai	Zhou	Huang	Hui	Hu	Bei	Ngou	Zi	Zha	Ji	Gu	Xi	Gao	Chai	Ma	Zhu	Tui	Zhui	Xian	Lang	Baan	Hiu	Zing	Zhi	Ai	Xian	Guo	Xi	Yo	Tui	Can	Sao	Xian	Jie	Fen	Qun	Ceoi	Yao	Dao	Jia	Lei	Yan	Lu	Tui	Ying	Pi	Luo	Li	Bie	Hoeng	Mao	Bai	Huang	Dau	Yao	He	Chun	He	Ning	Chou	Li	Tang	Huan	Bi	Ba	Che	Yang	Da	Ao	Xue	Ki	Zi	Da	Ran	Bang	Cuo	Wan	Ta	Bao	Gan	Yan	Xi	Zhu	Ya";
    case 64:
      return "Fan	You	An	Tui	Meng	She	Jin	Gu	Ji	Qiao	Jiao	Yan	Xi	Kan	Mian	Xuan	Shan	Wo	Qian	Huan	Ren	Zhen	Tian	Jue	Xie	Qi	Ang	Mei	Gu	Bei	Tao	Fan	Ju	Chan	Shun	Bi	Mao	Shuo	Gu	Hong	Hua	Luo	Hang	Jia	Quan	Gai	Huang	Bu	Gu	Feng	Mu	Ai	Ying	Shun	Liang	Jie	Chi	Jie	Chou	Ping	Chen	Yan	Du	Di	Dai	Liang	Xian	Biao	Xing	Meng	Ye	Mi	Qi	Qi	Wo	Xie	Yu	Qia	Cheng	Yao	Ying	Yang	Ji	Zong	Xuan	Min	Lou	Kai	Yao	Yan	Sun	Gui	Huang	Ying	Sheng	Cha	Lian	Sim	Xuan	Chuan	Che	Ni	Qu	Miao	Huo	Yu	Zhan	Hu	Ceng	Biao	Qian	Xi	Jiang	Kou	Mai	Mang	Zhan	Bian	Ji	Jue	Nang	Bi	Shi	Shuo	Mo	Lie	Mie	Mo	Xi	Chan	Qu	Jiao	Huo	Xian	Xu	Niu	Tong	Hou	Yu	Jau	Chong	Bo	Zuan	Diao	Zhuo	Ji	Qia	Kwai	Xing	Hui	Shi	Ku	Sai	Dui	Yao	Yu	Bang	Jie	Zhe	Jia	Shi	Di	Dong	Ci	Fu	Min	Zhen	Zhen	Cik	Yan	Qiao	Hang	Gong	Qiao	Lue	Guai	La	Rui	Fa	Cuo	Yan	Gong	Jie	Guai	Guo	Suo	Wo	Zheng	Nie	Diao	Lai	Ta	Cui	Ya	Gun	Mong	Ging	Di	Kei	Mian	Jie	Min	Ju	Yu	Zhen	Zhao	Zha	Xing	Dat	Ban	He	Gou	Hong	Lao	Wu	Bo	Keng	Lu	Cu	Lian	Yi	Qiao	Shu	Saan	Xuan	Jin	Qin	Hui	Su	Chuang	Dun	Long	Koeng	Nao	Tan	Dan	Wei	Gan	Da	Li	Ca	Xian	Pan	La	Zhu	Niao	Huai	Ying	Xian	Lan	Mo	Ba	Buk	Gui	Bi	Fu";
    case 65:
      return "Huo	Yi	Liu	Yang	Yin	Juan	Huo	Cheng	Dou	E	Zi	Yan	Zhui	Zha	Qi	Yu	Quan	Huo	Nie	Huang	Ju	She	Jyu	Jyun	Peng	Ming	Cao	Lou	Li	Chuang	Zai	Cui	Shan	Dan	Qi	Suk	Lai	Ling	Liao	Reng	Yu	Yi	Diao	Qi	Yi	Nian	Fu	Jian	Ya	Fang	Rui	Xian	Jyut	Lai	Bi	Shi	Po	Nian	Zhi	Tao	Tian	Tian	Ru	Yi	Lie	An	He	Qiong	Li	Gui	Zi	Su	Yuan	Ya	Cha	Wan	Juan	Ting	You	Hui	Jian	Rui	Mang	Ju	Zi	Ju	An	Sui	Lai	Hun	Quan	Chang	Duo	Kong	Ne	Can	Ti	Xu	Jiu	Huang	Qi	Jie	Mao	Yan	Hoeng	Zhi	Tui	Loek	Ai	Pang	Cang	Tang	En	Hun	Qi	Chu	Suo	Zhuo	Nou	Tu	Shen	Lou	Biao	Li	Man	Xin	Cen	Huang	Mei	Gao	Lian	Dao	Zhan	Zi	Cou	Fung	Zhi	Ba	Cui	Qiu	Kai	Long	Xian	Fei	Guo	Cheng	Jiu	E	Chong	Yue	Hong	Yao	Ya	Yao	Tong	Zha	You	Xue	Yao	Ke	Huan	Lang	Yue	Chen	Cyun	Cyun	Shen	Wo	Ning	Ming	Hong	Chuang	Yun	Xuan	Jin	Zhuo	Yu	Tan	Kang	Qiong	Gwai	Cheng	Jiu	Xue	Zheng	Chong	Pan	Qiao	Wo	Qu	Lan	Yi	Rong	Si	Qian	Si	Hat	Fa	Sap	Meng	Hua	Baak	Gwong	Hai	Qiao	Chu	Que	Dui	Li	Ba	Jie	Xu	Luo	Seoi	Yun	Zhong	Hu	Yin	Pok	Zhi	Qian	Zim	Gan	Jian	Zhu	Zhu	Ku	Nie	Rui	Ze	Ang	Zhi	Gong	Yi	Chi	Ji	Zhu	Lao	Ren	Rong	Zheng	Na	Ce	Zin	Sai	Yi	Jue	Bie	Cheng	Jun	Dou	Wei	Yi	Zhe	Yan	Cuk";
    case 66:
      return "San	Lun	Ping	Zhao	Han	Yu	Dai	Zhao	Fei	Sha	Ling	Ta	Qu	Mang	Ye	Bao	Gui	Gua	Nan	Ge	Gaa	Shi	Ke	Suo	Ci	Zhou	Tai	Kuai	Qin	Xu	Du	Ce	Huan	Cong	Sai	Zheng	Qian	Jin	Zong	Wei	Haan	Gim	Xi	Na	Pu	Sou	Ju	Zhen	Shao	Tao	Ban	Ta	Qian	Weng	Rong	Luo	Hu	Sou	Zhong	Pu	Mie	Jin	Shao	Mi	Shu	Ling	Lei	Jiang	Leng	Zhi	Diao	Zaam	San	Gu	Fan	Mei	Sui	Jian	Tang	Xie	Ku	Wu	Fan	Luo	Can	Ceng	Ling	Yi	Cong	Yun	Meng	Yu	Zhi	Yi	Dan	Huo	Wei	Tan	Se	Xie	Sou	Song	Qian	Liu	Yi	Au	Lei	Li	Fei	Lie	Lin	Xian	Xiao	Ou	Mi	Xian	Rang	Zhuan	Shuang	Yan	Bian	Ling	Hong	Qi	Liao	Ban	Bi	Hu	Hu	Shin	Ce	Pei	Qiong	Ming	Jiu	Bu	Mei	San	Wei	Zong	Bei	Li	Quan	Sam	Hun	Xiang	Zing	Shi	Ying	Ken	Nan	Huang	Jiu	Yan	Deoi	Sa	Tuan	Xie	Zhe	Men	Xi	Man	Zoeng	Huang	Tan	Xiao	Ye	Bi	Luo	Fan	Li	Cui	Chua	Dao	Di	Kuang	Chu	Xian	Chan	Mi	Qian	Qiu	Zhen	Zi	U	Cin	Hu	Gan	Chi	Guai	Mu	Bo	Hua	Geng	Yao	Mao	Wang	Ngau	Wu	Jik	Ru	Xue	Zheng	Min	Jiang	O	Zhan	Zuo	Yue	Lie	Syu	Zhou	Bi	Ren	Yu	Gin	Chuo	Er	Yi	Mi	Qing	Ei	Wang	Ji	Bu	Syu	Bie	Fan	Yue	Li	Fan	Qu	Fu	Er	E	Zheng	Tian	Yu	Jin	Qi	Ju	Lai	Che	Bei	Niu	Yi	Xu	Mou	Xun	Fu	Cau	Nin	Ting	Beng	Zha	Wei";
    case 67:
      return "Ke	Yao	Ou	Xiao	Geng	Tang	Gui	Hui	Ta	Gong	Yao	Da	Qi	Jin	Lue	Mi	Mi	Jian	Lu	Fan	Ou	Mi	Jie	Fu	Bie	Huang	Su	Yao	Nie	Jin	Lian	Bo	Jian	Ti	Ling	Zuan	Shi	Yin	Dao	Chou	Ca	Mie	Yan	Lan	Chong	Jiao	Shuang	Quan	Nie	Luo	Fan	Shi	Luo	Zhu	Zi	Chou	Juan	Jiong	Er	Yi	Rui	Cai	Ren	Fu	Lan	Sui	Yu	You	Dian	Ling	Zhu	Ta	Ping	Zhai	Jiao	Chui	Bu	Kou	Cun	Jyun	Han	Han	Mou	Hu	Gong	Di	Fu	Xuan	Mi	Mei	Lang	Gu	Zhao	Ta	Yu	Zong	Li	Lu	Wu	Lei	Ji	Li	Li	Zong	Po	Yang	Wa	Tuo	Peng	Zong	Zhao	Gui	In	Xu	Nai	Que	Wei	Zheng	Dong	Wei	Bo	Zin	Huan	Xuan	Zan	Li	Yan	Huang	Xue	Hu	Bao	Ran	Xiao	Po	Liao	Zhou	Yi	Xu	Luo	Kao	Chu	Fu	Na	Han	Chao	Lu	Zhan	Ta	Fu	Hong	Zeng	Qiao	Su	Pin	Guan	Lou	Hun	Chu	Ze	Er	Er	Ruan	Qi	Si	Ju	Gaak	Yan	Bang	Ye	Zi	Ne	Chuang	Ba	Cao	Ti	Han	Zuo	Ba	Zhe	Wa	Geng	Bi	Er	Zhu	Wu	Wen	Zhi	Zhou	Lu	Wen	Gun	Qiu	La	Zai	Sou	Mian	Di	Qi	Cao	Piao	Lian	Shi	Long	Su	Qi	Yuan	Feng	Xu	Jue	Di	Pian	Guan	Niu	Ren	Zhen	Gai	Pi	Tan	Chao	Chun	He	Zhuan	Mo	Bie	Qi	Shi	Bi	Jue	Si	Taam	Gua	Na	Hui	Xi	Er	Xiu	Mou	Zyu	Xi	Zhi	Run	Ju	Ti	Zhe	Shao	Meng	Bi	Han	Yu	Xian	Pang	Neng	Can	Bu	Ho	Qi";
    case 68:
      return "Ji	Zhuo	Lu	Jun	Xian	Xi	Cai	Wen	Zhi	Zi	Kun	Cong	Tian	Chu	Di	Chun	Qiu	Zhe	Zha	Rou	Bin	Ji	Xi	Zhu	Jue	Ge	Ji	Da	Chen	Suo	Ruo	Xiang	Huang	Qi	Zhu	Sun	Chai	Weng	Ke	Kao	Gu	Gai	Fan	Cong	Cao	Zhi	Chan	Lei	Xiu	Zhai	Zhe	Yu	Gui	Gong	Zan	Dan	Huo	Sou	Tan	Gu	Xi	Man	Duo	Ao	Pi	Wu	Ai	Meng	Pi	Meng	Yang	Zhi	Bo	Ying	Wei	Rang	Lan	Yan	Chan	Quan	Zhen	Pu	Dou	Tai	Fei	Shu	Zit	Dang	Cuo	Tan	Tian	Chi	Ta	Jia	Shun	Huang	Liao	Caa	Gotsu	Chen	Jin	E	Gou	Fu	Duo	Gu	E	Beng	Tao	Di	Do	Di	Bu	Wan	Zhao	Lun	Qi	Mu	Qian	Gin	Zong	Sou	Han	You	Zhou	Ta	Zek	Su	Bu	Xi	Jiang	Cao	Fu	Teng	Che	Fu	Fei	Wu	Xi	Yang	Ming	Pang	Mang	Seng	Meng	Cao	Tiao	Kai	Bai	Xiao	Xin	Qi	Seoi	Cong	Shao	Huan	Niu	Xiao	Chen	Dan	Feng	Yin	Ang	Ran	Ri	Man	Fan	Qu	Shi	He	Bian	Dai	Mo	Deng	Gong	Jyun	Kuang	Zing	Cha	Duo	You	Hao	Tin	Gua	Xue	Lei	Jin	Qi	Qu	Wang	Yi	Liao	Gat	Dang	Yan	Yi	Yin	Qi	Zhe	Xi	Yi	Ye	Wu	Zhi	Zhi	Han	Chuo	Fu	Chun	Ping	Kuai	Chou	Haau	Tuo	Qiong	Cong	Gao	Kua	Qu	Qu	Zhi	Meng	Li	Zhou	Ta	Zhi	Gu	Liang	Hu	La	Dian	Ci	Ying	Zi	Sakikusa	Qi	Zhuo	Cha	Mao	Du	Yin	Chai	Rui	Hen	Ruan	Fu	Lai	Xing	Jian	Yi	Mei	Kau	Mang	Ji	Suo	Han";
    case 69:
      return "Seoi	Li	Zi	Zu	Yao	Ge	Li	Qi	Gong	Li	Bing	Suo	Gou	Duk	Su	Chou	Jian	Xie	Bei	Xu	Jing	Pu	Ling	Xiang	Zuo	Diao	Chun	Qing	Nan	Zhai	Lu	Yi	Shao	Yu	Hua	Li	Pa	Siu	Mui	Li	Ung	Cik	Shuang	So	Yi	Ning	Si	Ku	Fu	Yi	Deng	Ran	Ce	Gaan	Ti	Qin	Biao	Sui	Wei	Dun	Se	Ai	Qi	Zun	Kuan	Fei	Jyun	Yin	Zing	Sao	Dou	Hui	Xie	Ze	Tan	Tang	Zhi	Yi	Fu	E	Fuk	Jun	Jia	Cha	Xian	Man	Syun	Bi	Ling	Jie	Kui	Jia	Ceoi	Cheng	Lang	Xing	Fei	Lu	Zha	He	Ji	Ni	Ying	Xiao	Teng	Lao	Ze	Kui	Goeng	Qian	Ju	Piao	Fan	Tou	Lin	Mi	Zhuo	Xie	Hu	Mi	Jie	Za	Cong	Li	Ran	Zhu	Yin	Han	Hiu	Yi	Luan	Yue	Ran	Ling	Niang	Yu	Nue	Heoi	Yi	Nue	Yi	Qian	Xia	Chu	Yin	Mi	Xi	Na	Kan	Zu	Xia	Yan	Tu	Ti	Wu	Suo	Yin	Chong	Zhou	Mang	Yuan	Nu	Miao	Zao	Wan	Li	Qu	Na	Shi	Bi	Zi	Bang	Gaap	Juan	Xiang	Kui	Pai	Kuang	Xun	Zha	Yao	Kun	Hui	Xi	E	Yang	Tiao	You	Jue	Li	Jyun	Li	Cheng	Ji	Hu	Zhan	Fu	Chang	Guan	Ju	Meng	Chang	Tan	Mou	Xing	Li	Yan	Sou	Shi	Yi	Bing	Cong	Hou	Wan	Di	Ji	Ge	Han	Bo	Xiu	Liu	Can	Can	Yi	Xuan	Yan	Zao	Han	Yong	Zong	Fung	Kang	Yu	Qi	Zhe	Ma	Fung	Waan	Shuang	Jin	Guan	Pu	Lin	Dang	Ting	Jiang	La	Yi	Yong	Ci	Yan	Jie	Xun	Wei	Xian	Ning";
    case 70:
      return "Fu	Ge	Zim	Mo	Zhu	Nai	Xian	Wen	Li	Can	Mie	Jian	Ni	Chai	Wan	Xu	Nu	Mai	Zui	Kan	Ka	Hang	Haam		Yu	Wei	Zhu	Gei	Gan	Yi	Maa	Diao	Fu	Bi	Zhu	Zi	Shu	Xia	Ni	Joeng	Jiao	Xun	Chong	Nou	Rong	Zhi	Sang	So	Shan	Yu	Zam	Jin	Zung	Lu	Han	Bie	Yi	Zui	Zhan	Yu	Wan	Ni	Guan	Jue	Beng	Can	Zung	Duo	Qi	Yao	Kui	Ruan	Hou	Xun	Xie	Syun	Kui	Fei	Xie	Bo	Ke	Cui	Xu	Bai	Ou	Zong	Bang	Ti	Chu	Chi	Niao	Guan	Feng	Xie	Deng	Wei	Jue	Kui	Zeng	Sa	Duo	Ling	Meng	Fan	Guo	Meng	Long	Kei	Ying	Hin	Guan	Cu	Li	Du	Cin	Biao	Qian	Xi	Nung	De	De	Xian	Lian	Ci	Shao	Xie	Shi	Wei	Cam	Cam	He	You	Lu	Lai	Ying	Sheng	Juan	Qi	Jian	Yun	Gou	Qi	Cong	Lin	Ji	Mai	Chuang	Nian	Bin	Li	Ling	Gang	Cheng	Xuan	Xian	Hu	Bi	Zu	Dai	Dai	Hun	Sai	Che	Ti	Jyu	Nuo	Zhi	Liu	Fei	Jiao	Guan	Xi	Lin	Xuan	Reng	Tao	Pi	Xin	Shan	Zhi	Wa	Tou	Tian	Yi	Xie	Pi	Yao	Yao	Nu	Hao	Nin	Yin	Fan	Nan	Yao	Wan	Yuan	Xia	Zhou	Yuan	Shi	Mian	Xi	Ji	Tao	Fei	Xue	Ni	Ci	Mi	Bian	Gaam	Na	Yu	E	Zhi	Ren	Xu	Lue	Hui	Xun	Nao	Han	Jia	Dou	Hua	Tu	Ping	Cu	Xi	Song	Mi	Xin	Wu	Qiong	Zhang	Tao	Xing	Jiu	Ju	Hun	Ti	Man	Yan	Ji	Shou	Lei	Wan	Che	Can	Jie	You	Hui	Zha	Su	Ge";
    case 71:
      return "Nao	Xi	Hou	Dui	Chi	Wei	Zhe	Gun	Chao	Chi	Zao	Hui	Luan	Liao	Lao	Tuo	Hui	Wu	Ao	She	Sui	Mai	Tan	Xin	Jing	An	Ta	Chan	Wei	Tuan	Ji	Chen	Che	Yu	Xian	Xin	Hung	Daan	Seon	Nao	Waan	Yan	Qiu	Jiang	Song	Jun	Liao	Ju	Hou	Man	Lie	Jyut	Chu	Chi	Xiang	Qin	Mei	Shu	Chai	Chi	Gu	Yu	Yin	Syu	Liu	Lao	Shu	Zhe	Shuang	Hui	Fat	Fui	E	Mung	Sha	Zong	Jue	Jun	Tuan	Lou	Wei	Chong	Zhu	Lie	Fun	Zhe	Zhao	Kyu	Yi	Chu	Ni	Bo	Suan	Yi	Hao	Ya	Huan	Man	Man	Qu	Lao	Hao	Zhong	Min	Xian	Zhen	Shu	Zuo	Zhu	Gou	Xuan	Yi	Zhi	Xie	Jin	Can	Zai	Bu	Liang	Zhi	Ji	Wan	Guan	Ju	Jing	Ai	Fu	Gui	Hou	Yan	Ruan	Zhi	Biao	Yi	Suo	Die	Gui	Sheng	Xun	Chen	She	Qing	Coeng	Si	Chun	Hong	Dong	Cheng	Wei	Ru	Shu	Cai	Ji	Za	Qi	Yan	Fu	Yu	Fu	Po	Zhi	Tan	Zuo	Che	Qu	You	He	Hou	Gui	E	Jiang	Yun	Tou	Cun	Tu	Fu	Zuo	Hu	Ngo	Bo	Zhao	Jue	Tang	Jue	Fu	Huang	Chun	Yong	Chui	Suo	Chi	Qian	Cai	Xiao	Man	Can	Qi	Jian	Bi	Ji	Zhi	Zhu	Qu	Zhan	Ji	Bian	Zaan	Li	Li	Yue	Quan	Cheng	Fu	Cha	Tang	Shi	Hang	Qie	Qi	Bo	Na	Tou	Chu	Cu	Yue	Zhi	Chen	Chu	Bi	Meng	Ba	Tian	Min	Lie	Feng	Cheng	Qiu	Tiao	Fu	Kuo	Jian	Seki	Cung	Cuk	Zhen	Qiu	Zuo	Chi	Kui	Lie	Bei	Du	Wu	So	Zhuo	Lu";
    case 72:
      return "Tang	Zai	Chu	Liang	Tian	Kun	Chang	Jue	Tu	Huan	Fei	Bi	Daap	Xia	Wo	Ji	Qu	Kui	Hu	Qiu	Sui	Cai	Zi	Qiu	Pi	Pang	Wa	Yao	Rong	Xun	Cu	Die	Chi	Cuo	Meng	Xuan	Duo	Bie	Zhe	Chu	Chan	Gui	Duan	Zou	Deng	Lai	Teng	Yue	Quan	Zhu	Ling	Chen	Zhen	Fu	She	Tiao	Kua	Ai	Man	Qiong	Shu	Hai	Shan	Wai	Zhan	Long	Jiu	Li	Gei	Chun	Rong	Yue	Jue	Kang	Fan	Qi	Hong	Fu	Lu	Hong	Tuo	Min	Tian	Juan	Qi	Zheng	Qing	Gong	Tian	Lang	Mao	Yin	Lu	Yuan	Ju	Pi	Hang	Xie	Bian	Hun	Zhu	Rong	Sang	Wu	Cha	Keng	Shan	Peng	Man	Xiu	Zung	Cong	Keng	Zhuan	Chan	Si	Chong	Sui	Bei	Kai	Mit	Zhi	Wei	Min	Ling	Zuan	Nie	Ling	Qi	Yue	Lip	Yi	Xi	Chen	Jung	Rong	Chen	Nong	You	Ji	Bo	Fang	Ki	Dau	Cu	Di	Jiao	Yu	He	Xu	Yu	Qu	Sau	Bai	Geng	Jiong	Gwai	Ya	Shu	You	Song	Ye	Cang	Yao	Shu	Yan	Shuai	Liao	Cong	Yu	Bo	Sui	Cin	Yan	Lei	Lin	Ti	Du	Yue	Ji	Cin	Yun	Bong	Daan	Ju	Ju	Chu	Chen	Gong	Xiang	Xian	An	Gui	Yu	Lei	Se	Tu	Chen	Xing	Qiu	Hang	Saa	Dang	Cai	Di	Yan	Zi	Gung	Ying	Chan	Gwai	Li	Suo	Ma	Ma	Gou	Tang	Pei	Lou	Qi	Cuo	Tu	E	Can	Jie	Yi	Ji	Dang	Jue	Bi	Lei	Yi	Chun	Chun	Po	Li	Zai	Tai	Po	Cu	Ju	Xu	Fan	Si	Xu	Er	Huo	Zhu	Ran	Fa	Juan	Han	Liang	Zhi	Mi	Yu";
    case 73:
      return "Joek	Cen	Mei	Yin	Mian	Tu	Kui	Sau	Hei	Mi	Rong	Yu	Qiang	Mi	Ju	Pi	Jin	Wang	Ji	Meng	Jian	Xue	Bao	Gan	Chan	Li	Li	Qiu	Dun	Ying	Yun	Chen	Zhi	Ran	Baat	Lue	Kai	Gui	Yue	Hui	Pi	Cha	Duo	Chan	Sha	Shi	She	Xing	Ying	Shi	Chi	Ye	Han	Fei	Ye	Yan	Zuan	Sou	Jin	Duo	Xian	Guan	Tao	Qie	Chan	Han	Meng	Yue	Cu	Qian	Jin	Shan	Mu	Yuan	Coeng	Peng	Zheng	Zhi	Chun	Yu	Mou	Mai	Jiang	Qi	Su	Pie	Tian	Kuan	Cu	Sui	Co	Jie	Jian	Ao	Jiao	Ye	Shin	Ye	Long	Zao	Bao	Lian	Ceoi	Huan	Lu	Wei	Xian	Tie	Bo	Zheng	Zhu	Bei	Meng	Xie	Ou	You		Xiao	Li	Zha	Mi	Ngit	Ye	Mou	Mat	Po	Xie	Lai	Jyu	Bong	Shan	Zhuo	Wai	Shan	Jue	Ji	Jie	Sei	Niao	Ao	Chu	Wu	Guan	Xie	Ting	Xue	Dang	Zhan	Tan	Peng	Xie	Xu	Xian	Si	Kua	Zheng	Wu	Huo	Run	Chuai	Du	Huan	Kuo	Fu	Chuai	Xian	Qin	Qie	Lan	Man	Ya	Ying	Que	Hang	Chun	Zhi	Gau	Wei	Yan	Xiang	Yi	Ni	Zheng	Chuai	Jyu	Shi	Ding	Zi	Jue	Xu	Yuan	Zung	Gwang	Xu	Dao	Tian	Ge	Yi	Hong	Yi	Sai	Li	Ku	Xian	Sui	Xi	Xuan	Fung	Gwok	Di	Lai	Zhou	Nian	Cheng	Jian	Bi	Zhuan	Ling	Hao	Bang	Tang	Chi	Ma	Xian	Shuan	Yong	Qu	In	Pu	Hui	Wei	Yi	Ye	Gam	Che	Hao	Bin	Si	Xian	Chan	Hun	Kyu	Han	Ci	Zhi	Qi	Kui	Rou	Gu	Ying	Xiong	Gap	Hu	Cui	Syu	Que";
    case 74:
      return "Di	Wu	Qiu	Aan	Yan	Liao	Bi	Soeng	Bin	Yo	Yuan	Nue	Bao	Ying	Hong	Ci	Qia	Ti	Yu	Lei	Bao	U	Ji	Fu	Xian	Cen	Hu	Se	Beng	Qing	Yu	Wa	Ai	Han	Dan	Ge	Di	Huo	Pang		Zhui	Ling	Mai	Mai	Lian	Xiao	Xue	Zhen	Po	Fu	Nou	Xi	Dui	Dan	Yun	Xian	Yin	Shu	Dui	Beng	Hu	Fei	Fei	Za	Bei	Fei	Xian	Shi	Mian	Zhan	Zhan	Zhan	Hui	Fu	Wan	Mo	Qiao	Liao	Cim	Mie	Hu	Hong	Yu	Qi	Duo	Ang	Saa	Ba	Di	Xuan	Di	Bi	Zhou	Pao	Tie	Yi	Ting	Jia	Zhi	Tu	Xie	Dan	Tiao	Xie	Chang	Yuan	Guan	Liang	Beng	Gei	Lu	Ji	Xuan	Shu	Du	Sou	Hu	Yun	Chan	Bang	Rong	E	Weng	Ba	Feng	Yu	Zhe	Fen	Guan	Bu	Ge	Dun	Huang	Du	Ti	Bo	Qian	Lie	Long	Wei	Zhan	Lan	Sui	Na	Bi	Tuo	Zhu	Die	Bu	Ju	Po	Xia	Wei	Po	Da	Fan	Chan	Hu	Za	Zai	Sei	Zai	Zai	Zai	Fan	Xie	Hong	Chi	Bao	Yin	Gaa	Jing	Bo	Ruan	Chou	Ying	Yi	Gai	Kun	Yun	Zhen	Ya	Ju	Hou	Min	Bai	Ge	Bian	Zhuo	Hao	Zhen	Sheng	Gen	Bi	Duo	Chun	Chua	San	Cheng	Ran	Chen	Mao	Pei	Wei	Pi	Fu	Zhuo	Qi	Lin	Yi	Men	Wu	Qi	Die	Chen	Xia	He	Sang	Gua	Hou	Ao	Fu	Qiao	Hun	Pi	Yan	Si	Xi	Ming	Kui	Ge	Hou	Ao	San	Shuang	Lou	Zhen	Hui	Chan		Lin	Na	Han	Du	Jin	Mian	Fan	E	Chao	Hong	Hong	Yu	Xue	Pao	Bi	Chao";
    case 75:
      return "You	Yi	Xue	Sa	Xu	Li	Li	Yuan	Dui	Huo	Sha	Leng	Pou	Hu	Guo	Bu	Rui	Wei	Sou	An	Yu	Xiang	Heng	Yang	Xiao	Yao	Han	Bi	Ci	Heng	Tao	Liu	Fei	Zhu	Tou	Xi	Zan	Yi	Dou	Yuan	Jiu	Sai	Bo	Ti	Ying	Tou	Yi	Nian	Shao	Ben	Gou	Ban	Mo	Gai	En	She	Caan	Zhi	Yang	Jian	Yuan	Shui	Ti	Wei	Xun	Zhi	Yi	Ren	Shi	Hu	Ne	Ye	Jian	Sui	Ying	Bao	Hu	Hu	Ye	Bin	Yang	Lian	Xi	En	Dui	Zan	Zhu	Ying	Ying	Jin	Chuang	Dan	Liu	Kuai	Yi	Ye	Jian	En	Ning	Ci	Qian	Xue	Bo	Mi	Shui	Mo	Liang	Qi	Qi	Shou	Fu	Bo	Beng	Bie	Yi	Wei	Huan	Fan	Qi	Mao	Fu	Ang	Ang	Fu	Qi	Qun	Tuo	Yi	Bo	Pian	Ba	Keoi	Xuan	Jyut	Pei	Yu	Chi	Lu	Yi	Li	Kyu	Niao	Xi	Wu	Gwing	Lei	Pu	Zhuo	Zui	Zhuo	Chang	An	Er	Yu	Leng	Fu	Zha	Hun	Chun	Sou	Bi	Bi	Zha	Song	He	Li	Giu	Han	Zai	Gu	Cheng	Lou	Mo	Mi	Mai	Ao	Zhe	Zhu	Huang	Fan	Deng	Tong	Biu	Du	Wo	Wei	Ji	Chi	Lin	Biao	Long	Jian	Nie	Luo	Shen	On	Gua	Nie	Yi	Ku	Wan	Wa	Qia	Bo	Kao	Ling	Gan	Gua	Hai	Kuang	Heng	Kui	Ze	Ting	Lang	Bi	Huan	Po	Yao	Wan	Ti	Sui	Kua	Dui	Ao	Jian	Mo	Kui	Kuai	An	Ma	Qing	Qiao	Hou	Kao	Hao	Duo	Xian	Nai	Suo	Jie	Pi	Pa	Song	Chang	Nie	Man	Song	Ci	Xian	Kuo	Gou	Di	Pou	Tiao	Zu";
    case 76:
      return "Wo	Fei	Cai	Peng	Sai	Sou	Rou	Qi	Cuo	Pan	Bo	Man	Zong	Ci	Kui	Ji	Lan	Sou	Meng	Mian	Pan	Lu	Zuan	Jiu	Liu	Yi	Wen	Li	Li	Zeng	Zhu	Hun	Shen	Chi	Xing	Wang	Dong	Huo	Pi	Hu	Mei	Che	Mei	Chao	Ju	Nou	Ji	Yi	Ru	Ling	Ya	Ding	Qi	Zi	Mong	Bang	Gong	Ze	Jie	Yu	Qin	Bei	Ba	Tuo	Yang	Qiao	You	Zhi	Jie	Mo	Sheng	Shan	Qi	Shan	Mi	Gong	Yi	Geng	Geng	Tou	Fu	Xue	Ye	Ting	Tiao	Mou	Liu	Can	Li	Shu	Lu	Huo	Cuo	Pai	Liu	Ju	Zhan	Ju	Zheng	Zu	Xian	Zhi	Zeoi	Gyun	La	Mong	Biu	La	Xu	Geng	E	Mu	Zhong	Ti	Yuan	Zhan	Geng	Weng	Lang	Yu	Sou	Zha	Hai	Hua	Zhan	Chang	Lou	Chan	Zhi	Wei	Xuan	Zao	Min	Gui	Su	Cuk	Maa	Si	Duo	Cen	Kuan	Teng	Nei	Lao	Lu	Yi	Xie	Yan	Qing	Pu	Chou	Xian	Guan	Jie	Lai	Meng	Ye	Cong	Li	Yin	Chun	Qiu	Teng	Yu	Zau	Gau	Dai	Du	Hong	Si	Xi		Qi	Ci	Yuan	Ji	Yun	Fang	Gong	Hang	Zhen	Que	Jyun	Niu	Jie	Pi	Gan	Xuan	Sheng	Shi	Qiao	Ci	Die	Bo	Diao	Wan	Ci	Zhi	Bai	Wu	Bao	Dan	Ba	Tong	Gyun	Gong	Jiu	Gui	Ci	You	Yuan	Lao	Ju	Fu	Nie	E	E	Xing	Kan	Yan	Tu	Pou	Beng	Ming	Shui	Yan	Qi	Yuan	Bie	Ling	Xuan	Hou	Huang	Yao	Juan	Kui	E	Ji	Mo	Chong	Bao	Wu	Zhen	Xu	Ta	Chi	Xi	Cong	Ma	Kou	Yan	Can	Au	He	Deng	Ran";
    case 77:
      return "Tong	Yu	Xiang	Nao	Shun	Fen	Pu	Ling	Ao	Huan	Yi	Huan	Meng	Ying	Lei	Yan	Bao	Die	Ling	Shi	Jiao	Lie	Jing	Ju	Ti	Pi	Gang	Xiao	Wai	Chuai	Di	Huan	Yao	Li	Mi	Hu	Sheng	Jia	Yin	Wei	Jyun	Piao	Lu	Ling	Yi	Cai	Shan	Hu	Shu	Tuo	Mo	Hua	Tie	Bing	Peng	Hun	Fu	Guo	Bu	Li	Chan	Pi	Cuo	Meng	Suo	Qiang	Zhi	Kuang	Bi	Ao	Meng	Xian	Ku	Tou	Tuan	Wei	Xian	Tan	Tuan	Lao	Chan	Ni	Ni	Li	Dong	Ju	Qian	Bo	Shai	Zha	Tao	Qian	Nong	Yi	Jing	Gan	Di	Jian	Mei	Da	Jian	Yu	Xie	Zai	Mang	Li	Gun	Xun	Ta	Zhe	Yang	Tuan	Shang	Xi	Qiao	Wei	Ying	Chua	Qu	Wa	Shu	Zhi	Ting	Gu	Shang	Ca	Fu	Tie	Ta	Ta	Zhuo	Han	Ping	He	Zhui	Zhou	Bo	Liu	Nu	Xi	Pao	Di	He	Ti	Wai	Ti	Qi	Ji	Chi	Ba	Jin	Ke	Li	Ju	Qu	La	Gu	Qia	Qi	Xian	Jian	Shi	Jian	Ai	Hua	Zha	Ze	Yao	Zhan	Ji	Cha	Yan	Jian	Wong	Yan	Ki	Jiao	Tong	Nan	Yue	Ceoi	Chi	De	Jiao	Mo	Zuo					Yu		Qian	Kun	Zhun	Meng	Xu	Song	Shi	Bi	XiaoChu	Lu	Tai	Pi	TongRen	DaYou	Qian	Yu	Sui	Gu	Lin	Guan	ShiKe	Bi	Bo	Fu	WuWang	DaChu	Yi	DaGuo	Kan	Li	Xian	Heng	Dun	DaZhuang	Jin	MingYi	JiaRen	Kui	Jian	Xie	Sun	Yi	Guai	Gou	Cui	Sheng	Kun	Jing	Ge	Ding	Zhen	Gen	Jian	GuiMei	Feng	Lu	Xun	Dui	Huan	Jie	ZhongFu	XiaoGuo	JiJi	WeiJi";
    case 78:
      return "Yi	Ding	Kao	Qi	Shang	Xia	Han	Wan	Zhang	San	Shang	Xia	Ji	Bu	Yu	Mian	Gai	Chou	Chou	Zhuan	Qie	Pi	Shi	Shi	Qiu	Bing	Ye	Cong	Dong	Si	Cheng	Diu	Qiu	Liang	Diu	You	Liang	Yan	Bing	Sang	Gun	Jiu	Ge	Ya	Qiang	Zhong	Ji	Jie	Feng	Guan	Chuan	Chan	Lin	Zhuo	Zhu	Ba	Wan	Dan	Wei	Zhu	Jing	Li	Ju	Pie	Fu	Yi	Yi	Nai	Wu	Jiu	Jiu	Tuo	Me	Yi	Yi	Zhi	Wu	Zha	Hu	Fa	Le	Yin	Ping	Pang	Qiao	Hu	Guai	Cheng	Cheng	Yi	Yin	Ya	Mie	Jiu	Qi	Ye	Xi	Xiang	Gai	Jiu	Xia	Hu	Shu	Dou	Shi	Ji	Nang	Jia	Ju	Shi	Mao	Hu	Mai	Luan	Zi	Ru	Xue	Yan	Fu	Sha	Na	Gan	Suo	Yu	Cui	Zhe	Qian	Zhi	Gui	Gan	Luan	Lin	Yi	Jue	Le	Ma	Yu	Zheng	Shi	Shi	Er	Chu	Yu	Kui	Yu	Yun	Hu	Qi	Wu	Jing	Si	Sui	Gen	Gen	Ya	Xie	Ya	Qi	Ya	Ji	Tou	Wang	Kang	Da	Jiao	Hai	Yi	Chan	Heng	Mu	Ye	Xiang	Jing	Ting	Liang	Xiang	Jing	Ye	Qin	Bo	You	Xie	Dan	Lian	Duo	Wei	Ren	Ren	Ji	Ji	Wang	Yi	Shen	Ren	Le	Ding	Ze	Jin	Pu	Chou	Ba	Zhang	Jin	Jie	Bing	Reng	Cong	Fo	San	Lun	Bing	Cang	Zi	Shi	Ta	Zhang	Fu	Xian	Xian	Tuo	Hong	Tong	Ren	Qian	Gan	Ge	Bo	Dai	Ling	Yi	Chao	Chang	Sa	Chang	Yi	Mu	Men	Ren	Fan	Chao	Yang	Qian	Zhong	Pi	Wo	Wu	Jian	Jia	Yao	Feng	Cang	Ren	Wang	Fen	Di	Fang";
    case 79:
      return "Zhong	Qi	Pei	Yu	Diao	Dun	Wu	Yi	Xin	Kang	Yi	Ji	Ai	Wu	Ji	Fu	Fa	Xiu	Jin	Pi	Dan	Fu	Tang	Zhong	You	Huo	Hui	Yu	Cui	Yun	San	Wei	Chuan	Che	Ya	Qian	Shang	Chang	Lun	Cang	Xun	Xin	Wei	Zhu	Ze	Xian	Nu	Bo	Gu	Ni	Ni	Xie	Ban	Xu	Ling	Zhou	Shen	Qu	Ci	Beng	Si	Jia	Pi	Yi	Si	Yi	Zheng	Dian	Han	Mai	Dan	Zhu	Bu	Qu	Bi	Zhao	Ci	Wei	Di	Zhu	Zuo	You	Yang	Ti	Zhan	He	Bi	Tuo	She	Yu	Yi	Fu	Zuo	Gou	Ning	Tong	Ni	Xian	Qu	Yong	Wa	Qian	Shi	Ka	Bao	Pei	Hui	He	Lao	Xiang	Ge	Yang	Bai	Fa	Ming	Jia	Nai	Bing	Ji	Hen	Huo	Gui	Quan	Tiao	Jiao	Ci	Yi	Shi	Xing	Shen	Tuo	Kan	Zhi	Gai	Lai	Yi	Chi	Kua	Guang	Li	Yin	Shi	Mi	Zhu	Xu	You	An	Lu	Mou	Er	Lun	Dong	Cha	Chi	Xun	Gong	Zhou	Yi	Ru	Cun	Xia	Si	Dai	Lu	Ta	Jiao	Zhen	Ce	Qiao	Kuai	Chai	Ning	Nong	Jin	Wu	Hou	Jiong	Cheng	Zhen	Zuo	Chou	Qin	Lu	Ju	Shu	Ting	Shen	Tui	Bo	Nan	Xiao	Bian	Tui	Yu	Xi	Cu	E	Qiu	Xu	Guang	Ku	Wu	Jun	Yi	Fu	Liang	Zu	Qiao	Li	Yong	Hun	Jing	Qian	San	Pei	Su	Fu	Xi	Li	Fu	Ping	Bao	Yu	Qi	Xia	Xin	Xiu	Yu	Di	Che	Chou	Zhi	Yan	Lia	Li	Lai	Si	Jian	Xiu	Fu	Huo	Ju	Xiao	Pai	Jian	Biao	Chu	Fei	Feng	Ya	An	Bei	Yu	Xin	Bi	Hu";
    case 80:
      return "Chang	Zhi	Bing	Jiu	Yao	Cui	Lia	Wan	Lai	Cang	Zong	Ge	Guan	Bei	Tian	Shu	Shu	Men	Dao	Tan	Jue	Chui	Xing	Peng	Tang	Hou	Yi	Qi	Ti	Gan	Jing	Jie	Sui	Chang	Jie	Fang	Zhi	Kong	Juan	Zong	Ju	Qian	Ni	Lun	Zhuo	Wo	Luo	Song	Leng	Hun	Dong	Zi	Ben	Wu	Ju	Nai	Cai	Jian	Zhai	Ye	Zhi	Sha	Qing	Ning	Ying	Cheng	Qian	Yan	Ruan	Zhong	Chun	Jia	Ji	Wei	Yu	Bing	Ruo	Ti	Wei	Pian	Yan	Feng	Tang	Wo	E	Xie	Che	Sheng	Kan	Di	Zuo	Cha	Ting	Bei	Xie	Huang	Yao	Zhan	Chou	Yan	You	Jian	Xu	Zha	Ci	Fu	Bi	Zhi	Zong	Mian	Ji	Yi	Xie	Xun	Cai	Duan	Ce	Zhen	Ou	Tou	Tou	Bei	Za	Lou	Jie	Wei	Fen	Chang	Kui	Sou	Zhi	Su	Xia	Fu	Yuan	Rong	Li	Nu	Yun	Jiang	Ma	Bang	Dian	Tang	Hao	Jie	Xi	Shan	Qian	Jue	Cang	Chu	San	Bei	Xiao	Yong	Yao	Tan	Suo	Yang	Fa	Bing	Jia	Dai	Zai	Tang	Gu	Bin	Chu	Nuo	Can	Lei	Cui	Yong	Zao	Zong	Beng	Song	Ao	Chuan	Yu	Zhai	Zu	Shang	Chuang	Jing	Chi	Sha	Han	Zhang	Qing	Yan	Di	Xie	Lou	Bei	Piao	Jin	Lian	Lu	Man	Qian	Xian	Tan	Ying	Dong	Zhuan	Xiang	Shan	Qiao	Jiong	Tui	Zun	Pu	Xi	Lao	Chang	Guang	Liao	Qi	Cheng	Chan	Wei	Ji	Bo	Hui	Chuan	Tie	Dan	Jiao	Jiu	Seng	Fen	Xian	Ju	E	Jiao	Jian	Tong	Lin	Bo	Gu	Xian	Su	Xian	Jiang	Min	Ye	Jin	Jia	Qiao	Pi	Feng	Zhou	Ai	Sai";
    case 81:
      return "Yi	Jun	Nong	Chan	Yi	Dang	Jing	Xuan	Kuai	Jian	Chu	Dan	Jiao	Sha	Zai	Can	Bin	An	Ru	Tai	Chou	Chai	Lan	Ni	Jin	Qian	Meng	Wu	Ning	Qiong	Ni	Chang	Lie	Lei	Lu	Kuang	Bao	Yu	Biao	Zan	Zhi	Si	You	Hao	Qing	Chen	Li	Teng	Wei	Long	Chu	Chan	Rang	Shu	Hui	Li	Luo	Zan	Nuo	Tang	Yan	Lei	Nang	Er	Wu	Yun	Zan	Yuan	Xiong	Chong	Zhao	Xiong	Xian	Guang	Dui	Ke	Dui	Mian	Tu	Chang	Er	Dui	Er	Jin	Tu	Si	Yan	Yan	Shi	Sap	Dang	Qian	Dou	Fen	Mao	Shen	Dou	Baak	Jing	Li	Huang	Ru	Wang	Nei	Quan	Liang	Yu	Ba	Gong	Liu	Xi	Han	Lan	Gong	Tian	Guan	Xing	Bing	Qi	Ju	Dian	Zi	Fen	Yang	Jian	Shou	Ji	Yi	Ji	Chan	Jiong	Mao	Ran	Nei	Yuan	Mao	Gang	Ran	Ce	Jiong	Ce	Zai	Gua	Jiong	Mao	Zhou	Mao	Gou	Xu	Mian	Mi	Rong	Yin	Xie	Kan	Jun	Nong	Yi	Mi	Shi	Guan	Meng	Zhong	Ju	Yuan	Ming	Kou	Lin	Fu	Xie	Mi	Bing	Dong	Tai	Gang	Feng	Bing	Hu	Chong	Jue	Hu	Kuang	Ye	Leng	Pan	Fu	Min	Dong	Xian	Lie	Qia	Jian	Jing	Sou	Mei	Tu	Qi	Gu	Zhun	Song	Jing	Liang	Qing	Diao	Ling	Dong	Gan	Jian	Yin	Cou	Ai	Li	Chuang	Ming	Zhun	Cui	Si	Duo	Jin	Lin	Lin	Ning	Xi	Du	Ji	Fan	Fan	Fan	Feng	Ju	Chu	Zheng	Feng	Mu	Zhi	Fu	Feng	Ping	Feng	Kai	Huang	Kai	Gan	Deng	Ping	Qian	Xiong	Kuai	Tu	Ao	Chu	Ji	Dang	Han	Han	Zao";
    case 82:
      return "Dao	Diao	Dao	Ren	Ren	Chuang	Fen	Qie	Yi	Ji	Kan	Qian	Cun	Chu	Wen	Ji	Dan	Xing	Hua	Wan	Jue	Li	Yue	Lie	Liu	Ze	Gang	Chuang	Fu	Chu	Qu	Diao	Shan	Min	Ling	Zhong	Pan	Bie	Jie	Jie	Pao	Li	Shan	Bie	Chan	Jing	Gua	Geng	Dao	Chuang	Kui	Ku	Duo	Er	Zhi	Shua	Quan	Sha	Ci	Ke	Jie	Gui	Ci	Gui	Kai	Duo	Ji	Ti	Jing	Lou	Luo	Ze	Yuan	Cuo	Xue	Kei	La	Qian	Sha	Chuang	Gua	Jian	Cuo	Li	Ti	Fei	Pou	Chan	Qi	Chuang	Zi	Gang	Wan	Bo	Ji	Duo	Qing	Shan	Du	Jian	Ji	Bo	Yan	Ju	Huo	Sheng	Jian	Duo	Duan	Wu	Gua	Fu	Sheng	Jian	Ge	Da	Kai	Chuang	Chuan	Chan	Tuan	Lu	Li	Peng	Shan	Piao	Kou	Jiao	Gua	Qiao	Jue	Hua	Zha	Zhuo	Lian	Ju	Pi	Liu	Gui	Jiao	Gui	Jian	Jian	Tang	Huo	Ji	Jian	Yi	Jian	Zhi	Chan	Jian	Mo	Li	Zhu	Li	Ya	Quan	Ban	Gong	Jia	Wu	Mai	Lie	Jin	Keng	Xie	Zhi	Dong	Zhu	Nu	Jie	Qu	Shao	Yi	Zhu	Mo	Li	Jin	Lao	Lao	Juan	Kou	Yang	Wa	Xiao	Mou	Kuang	Jie	Lie	He	Shi	Ke	Jin	Gao	Bo	Min	Chi	Lang	Yong	Yong	Mian	Ke	Xun	Juan	Qing	Lu	Bu	Meng	Chi	Lei	Kai	Mian	Dong	Xu	Xu	Kan	Wu	Yi	Xun	Weng	Sheng	Lao	Mu	Lu	Piao	Shi	Ji	Qin	Jiang	Chao	Quan	Xiang	Yi	Jue	Fan	Juan	Tong	Ju	Dan	Xie	Mai	Xun	Xun	Lu	Li	Che	Rang	Quan	Bao	Shao	Yun	Jiu	Bao	Gou	Wu";
    case 83:
      return "Yun	Wen	Xiong	Gai	Gai	Bao	Cong	Yi	Xiong	Peng	Ju	Tao	Ge	Pu	E	Pao	Fu	Gong	Da	Jiu	Gong	Bi	Hua	Bei	Nao	Shi	Fang	Jiu	Yi	Za	Jiang	Kang	Jiang	Kuang	Hu	Xia	Qu	Fan	Gui	Qie	Zang	Kuang	Fei	Hu	Yu	Gui	Kui	Hui	Dan	Gui	Lian	Lian	Suan	Du	Jiu	Jue	Xi	Pi	Qu	Yi	Ke	Yan	Bian	Ni	Qu	Shi	Xun	Qian	Nian	Sa	Zu	Sheng	Wu	Hui	Ban	Shi	Xi	Wan	Hua	Xie	Wan	Bei	Zu	Zhuo	Xie	Dan	Mai	Nan	Dan	Ji	Bo	Shuai	Bo	Kuang	Bian	Bu	Zhan	Ka	Lu	You	Lu	Xi	Gua	Wo	Xie	Jie	Jie	Wei	Ang	Qiong	Zhi	Mao	Yin	Wei	Shao	Ji	Que	Luan	Chi	Juan	Xie	Xu	Jin	Que	Wu	Ji	E	Qing	Xi	San	Chang	Wei	E	Ting	Li	Zhe	Han	Li	Ya	Ya	Yan	She	Di	Zha	Pang	Ya	Qie	Ya	Zhi	Ce	Mang	Ti	Li	She	Hou	Ting	Zui	Cuo	Fei	Yuan	Ce	Yuan	Xiang	Yan	Li	Jue	Sha	Dian	Chu	Jiu	Jin	Ao	Gui	Yan	Si	Li	Chang	Lan	Li	Yan	Yan	Yuan	Si	Gong	Lin	Rou	Qu	Qu	Er	Lei	Du	Xian	Zhuan	San	Can	Can	Can	Can	Ai	Dai	You	Cha	Ji	You	Shuang	Fan	Shou	Guai	Ba	Fa	Ruo	Shi	Shu	Zhuo	Qu	Shou	Bian	Xu	Xia	Pan	Sou	Ji	Wei	Sou	Die	Rui	Cong	Kou	Gu	Ju	Ling	Gua	Dao	Kou	Zhi	Jiao	Zhao	Ba	Ding	Ke	Tai	Chi	Shi	You	Qiu	Po	Ye	Hao	Si	Tan	Chi	Le	Diao	Ji	Liao	Hong";
    case 84:
      return "Mie	Xu	Mang	Chi	Ge	Xuan	Yao	Zi	He	Ji	Diao	Cun	Tong	Ming	Hou	Li	Tu	Xiang	Zha	Xia	Ye	Lu	A	Ma	Ou	Huo	Yi	Jun	Chou	Lin	Tun	Yin	Fei	Bi	Qin	Qin	Jie	Bu	Fou	Ba	Dun	Fen	E	Han	Ting	Keng	Shun	Qi	Hong	Zhi	Yin	Wu	Wu	Chao	Na	Xue	Xi	Chui	Dou	Wen	Hou	Hong	Wu	Gao	Ya	Jun	Lu	E	Ge	Mei	Dai	Men	Cheng	Wu	Gao	Fu	Jiao	Hong	Chi	Sheng	Na	Tun	M	Yi	Dai	Ou	Li	Bei	Yuan	Guo	Wen	Qiang	Wu	E	Shi	Juan	Pen	Wen	Ne	M	Ling	Ran	You	Di	Zhou	Shi	Zhou	Tie	Xi	Yi	Qi	Ping	Zi	Gu	Ci	Wei	Xu	He	Nao	Xia	Pei	Yi	Xiao	Shen	Hu	Ming	Da	Qu	Ju	Han	Za	Tuo	Duo	Pou	Pao	Bi	Fu	Yang	He	Za	He	Hai	Jiu	Yong	Fu	Da	Zhou	Wa	Ka	Gu	Ka	Zuo	Bu	Long	Dong	Ning	Ta	Si	Xian	Huo	Qi	Er	E	Guang	Zha	Xi	Yi	Lie	Zi	Mie	Mi	Zhi	Yao	Ji	Zhou	Ge	Shu	Zan	Xiao	Hai	Hui	Kua	Huai	Tao	Xian	E	Xuan	Xiu	Guo	Yan	Lao	Yi	Ai	Pin	Shen	Tong	Hong	Xiong	Duo	Wa	Ha	Zai	You	Die	Pai	Xiang	Ai	Gen	Kuang	Ya	Da	Xiao	Bi	Hui	Nian	Hua	Xing	Kuai	Duo	Fen	Ji	Nong	Mou	Yo	Hao	Yuan	Long	Pou	Mang	Ge	O	Chi	Shao	Li	Na	Zu	He	Ku	Xiao	Xian	Lao	Bo	Zhe	Zha	Liang	Ba	Mie	Lie	Sui	Fu	Bu	Han	Heng	Geng	Shuo	Ge";
    case 85:
      return "You	Yan	Gu	Gu	Bei	Han	Suo	Chun	Yi	Ai	Jia	Tu	Xian	Wan	Li	Xi	Tang	Zuo	Qiu	Che	Wu	Zao	Ya	Dou	Qi	Di	Qin	Mai	Mo	Hong	Dou	Qu	Lao	Liang	Suo	Zao	Huan	Lang	Sha	Ji	Zu	Wo	Feng	Jin	Hu	Qi	Shou	Wei	Shua	Chang	Er	Li	Qiang	An	Ze	Yo	Nian	Yu	Tian	Lai	Sha	Xi	Tuo	Hu	Ai	Zhao	Nou	Ken	Zhuo	Zhuo	Shang	Di	Heng	Lin	A	Cai	Xiang	Tun	Wu	Wen	Cui	Sha	Gu	Qi	Qi	Tao	Dan	Dan	Ye	Zi	Bi	Cui	Chuai	He	Ya	Qi	Zhe	Fei	Liang	Xian	Pi	Sha	La	Ze	Ying	Gua	Pa	Zhe	Se	Zhuan	Nie	Guo	Luo	Yan	Di	Quan	Chan	Bo	Ding	Lang	Xiao	Ju	Tang	Chi	Ti	An	Jiu	Dan	Ka	Yong	Wei	Nan	Shan	Yu	Zhe	La	Jie	Hou	Han	Die	Zhou	Chai	Wai	Nuo	Yu	Yin	Za	Yao	O	Mian	Hu	Yun	Chuan	Hui	Huan	Huan	Xi	He	Ji	Kui	Zhong	Wei	Sha	Xu	Huang	Duo	Nie	Xuan	Liang	Yu	Sang	Chi	Qiao	Yan	Dan	Pen	Can	Li	Yo	Zha	Wei	Miao	Ying	Pen	Bu	Kui	Xi	Yu	Jie	Lou	Ku	Zao	Hu	Ti	Yao	He	Sha	Xiu	Qiang	Se	Yong	Su	Hong	Xie	Ai	Suo	Ma	Cha	Hai	Ke	Da	Sang	Chen	Ru	Sou	Wa	Ji	Pang	Wu	Qian	Shi	Ge	Zi	Jie	Lao	Weng	Wa	Si	Chi	Hao	Suo	Gaa	Hai	Suo	Qin	Nie	He	Zhi	Sai	Ng	Ge	Na	Dia	Ai	Qiang	Tong	Bi	Ao	Ao	Lian	Zui	Zhe	Mo	Sou	Sou	Tan";
    case 86:
      return "Di	Qi	Jiao	Chong	Jiao	Kai	Tan	Shan	Cao	Jia	Ai	Xiao	Piao	Lou	Ga	Gu	Xiao	Hu	Hui	Guo	Ou	Xian	Ze	Chang	Xu	Po	De	Ma	Ma	Hu	Lei	Du	Ga	Tang	Ye	Beng	Ying	Sai	Jiao	Mi	Xiao	Hua	Mai	Ran	Zuo	Peng	Lao	Xiao	Ji	Zhu	Chao	Kui	Zui	Xiao	Si	Hao	Fu	Liao	Qiao	Xi	Chu	Chan	Dan	Hei	Xun	E	Zun	Fan	Chi	Hui	Zan	Chuang	Cu	Dan	Yu	Tun	Ceng	Jiao	Ye	Xi	Qi	Hao	Lian	Xu	Deng	Hui	Yin	Pu	Jue	Qin	Xun	Nie	Lu	Si	Yan	Ying	Da	Zhan	O	Zhou	Jin	Nong	Hui	Xie	Qi	E	Zao	Yi	Shi	Jiao	Yuan	Ai	Yong	Xue	Kuai	Yu	Pen	Dao	Ga	Hm	Dun	Dang	Xin	Sai	Pi	Pi	Yin	Zui	Ning	Di	Lan	Ta	Huo	Ru	Hao	Xia	Ye	Duo	Pi	Chou	Ji	Jin	Hao	Ti	Chang	Xun	Me	Ca	Ti	Lu	Hui	Bo	You	Nie	Yin	Hu	Me	Hong	Zhe	Li	Liu	Hai	Nang	Xiao	Mo	Yan	Li	Lu	Long	Mo	Dan	Chen	Pin	Pi	Xiang	Huo	Mo	Xi	Duo	Ku	Yan	Chan	Ying	Rang	Dian	La	Ta	Xiao	Jue	Chuo	Huan	Huo	Zhuan	Nie	Xiao	Ca	Li	Chan	Chai	Li	Yi	Luo	Nang	Za	Su	Xi	Zen	Jian	Za	Zhu	Lan	Nie	Nang	Lan	Lo	Wei	Hui	Yin	Qiu	Si	Nin	Jian	Hui	Xin	Yin	Nan	Tuan	Tuan	Dun	Kang	Yuan	Jiong	Pian	Yun	Cong	Hu	Hui	Yuan	E	Guo	Kun	Cong	Tong	Tu	Wei	Lun	Guo	Qun	Ri	Ling	Gu	Guo	Tai	Guo	Tu	You";
    case 87:
      return "Guo	Yin	Hun	Pu	Yu	Han	Yuan	Lun	Quan	Yu	Qing	Guo	Chui	Wei	Yuan	Quan	Ku	Pu	Yuan	Yuan	Ya	Tu	Tu	Tu	Tuan	Lue	Hui	Yi	Huan	Luan	Luan	Tu	Ya	Tu	Ting	Sheng	Pu	Lu	Kuai	Ya	Zai	Wei	Ge	Tuo	Wu	Gui	Pi	Yi	De	Qian	Qian	Zhen	Zhuo	Dang	Qia	Xia	Shan	Kuang	Chang	Qi	Nie	Mo	Ji	Jia	Zhi	Zhi	Ban	Xun	Yi	Qin	Mei	Jun	Rong	Tun	Fang	Ben	Ben	Tan	Kan	Huai	Zuo	Keng	Bi	Jing	Di	Jing	Ji	Kuai	Di	Jing	Jian	Tan	Li	Ba	Wu	Fen	Zhui	Po	Ban	Tang	Kun	Qu	Tan	Zhi	Tuo	Gan	Ping	Dian	Gua	Ni	Tai	Pi	Jiong	Yang	Fo	Ao	Lu	Qiu	Mu	Ke	Gou	Xue	Ba	Di	Che	Ling	Zhu	Fu	Hu	Zhi	Chui	La	Long	Long	Lu	Ao	Dai	Pao	Min	Xing	Dong	Ji	He	Lu	Ci	Chi	Lei	Gai	Yin	Hou	Dui	Zhao	Fu	Guang	Yao	Duo	Duo	Gui	Cha	Yang	Yin	Fa	Gou	Yuan	Die	Xie	Ken	Shang	Shou	E	Bing	Dian	Hong	Ya	Kua	Da	Ka	Dang	Kai	Hang	Nao	An	Xing	Xian	Yuan	Bang	Fu	Ba	Yi	Yin	Han	Xu	Chui	Qin	Geng	Ai	Beng	Fang	Que	Yong	Jun	Jia	Di	Mai	Lang	Juan	Cheng	Shan	Jin	Zhe	Lie	Lie	Bu	Cheng	Hua	Bu	Shi	Xun	Guo	Jiong	Ye	Nian	Di	Yu	Bu	Ya	Quan	Sui	Pi	Qing	Wan	Ju	Lun	Zheng	Kong	Tang	Dong	Dai	Tan	An	Cai	Chu	Beng	Kan	Zhi	Duo	Yi	Zhi	Yi	Pei	Ji	Zhun	Qi	Sao	Ju	Ni";
    case 88:
      return "Ku	Ke	Tang	Kun	Ni	Jian	Dui	Jin	Gang	Yu	E	Peng	Gu	Tu	Leng	Fang	Ya	Qian	Kun	An	Shen	Duo	Nao	Tu	Cheng	Yin	Hun	Bi	Lian	Guo	Die	Zhuan	Hou	Bao	Bao	Yu	Di	Mao	Jie	Ruan	E	Geng	Kan	Zong	Yu	Huang	E	Yao	Yan	Bao	Ji	Mei	Chang	Du	Tuo	Yin	Feng	Zhong	Jie	Jin	Heng	Gang	Chun	Jian	Ping	Lei	Xiang	Huang	Leng	Duan	Wan	Xuan	Ji	Ji	Kuai	Ying	Ta	Cheng	Yong	Kai	Su	Su	Shi	Mi	Ta	Weng	Cheng	Tu	Tang	Que	Zhong	Li	Zhong	Bang	Sai	Zang	Dui	Tian	Wu	Zheng	Xun	Ge	Zhen	Ai	Gong	Yan	Kan	Tian	Yuan	Wen	Xie	Liu	Hai	Lang	Chang	Peng	Beng	Chen	Lu	Lu	Ou	Qian	Mei	Mo	Zhuan	Shuang	Shu	Lou	Chi	Man	Biao	Jing	Ce	Shu	Zhi	Zhang	Kan	Yong	Dian	Chen	Zhi	Xi	Guo	Qiang	Jin	Di	Shang	Mu	Cui	Yan	Ta	Zeng	Qian	Qiang	Liang	Wei	Zhui	Qiao	Zeng	Xu	Shan	Shan	Ba	Pu	Kuai	Dong	Fan	Que	Mo	Dun	Dun	Zun	Di	Sheng	Duo	Duo	Tan	Deng	Mu	Fen	Huang	Tan	Da	Ye	Zhu	Jian	Ao	Qiang	Ji	Qiao	Ken	Yi	Pi	Bi	Dian	Jiang	Ye	Yong	Xue	Tan	Lan	Ju	Huai	Dang	Rang	Qian	Xun	Xian	Xi	He	Ai	Ya	Dao	Hao	Ruan	Jin	Lei	Kuang	Lu	Yan	Tan	Wei	Huai	Long	Long	Rui	Li	Lin	Rang	Chan	Xun	Yan	Lei	Ba	Wan	Shi	Ren	San	Zhuang	Zhuang	Sheng	Yi	Mai	Ke	Zhu	Zhuang	Hu	Hu	Kun	Yi	Hu	Xu	Kun	Shou	Mang	Zun";
    case 89:
      return "Shou	Yi	Zhi	Gu	Chu	Jiang	Feng	Bei	Zhai	Bian	Sui	Qun	Ling	Fu	Cuo	Xia	Xiong	Xie	Nao	Xia	Kui	Xi	Wai	Yuan	Mao	Su	Duo	Duo	Ye	Qing	Wai	Gou	Gou	Qi	Meng	Meng	Yin	Huo	Chen	Da	Ze	Tian	Tai	Fu	Guai	Yao	Yang	Hang	Gao	Shi	Tao	Tai	Tou	Yan	Bi	Yi	Kua	Jia	Duo	Hua	Kuang	Yun	Jia	Ba	En	Lian	Huan	Di	Yan	Pao	Juan	Qi	Nai	Feng	Xie	Fen	Dian	Quan	Kui	Zou	Huan	Qi	Kai	Zha	Ben	Yi	Jiang	Tao	Zang	Ben	Xi	Huang	Fei	Diao	Xun	Beng	Dian	Ao	She	Weng	Ha	Ao	Wu	Ao	Jiang	Lian	Duo	Yun	Jiang	Shi	Fen	Huo	Bi	Luan	Duo	Nu	Nu	Ding	Nai	Qian	Jian	Ta	Jiu	Nuan	Cha	Hao	Xian	Fan	Ji	Shuo	Ru	Fei	Wang	Hong	Zhuang	Fu	Ma	Dan	Ren	Fu	Jing	Yan	Hai	Wen	Zhong	Pa	Du	Ji	Keng	Zhong	Yao	Jin	Yun	Miao	Fou	Chi	Yue	Zhuang	Niu	Yan	Na	Xin	Fen	Bi	Yu	Tuo	Feng	Yuan	Fang	Wu	Yu	Gui	Du	Ba	Ni	Zhou	Zhuo	Zhao	Da	Nai	Yuan	Tou	Xian	Zhi	E	Mei	Mo	Qi	Bi	Shen	Qie	E	He	Xu	Fa	Zheng	Min	Ban	Mu	Fu	Ling	Zi	Zi	Shi	Ran	Shan	Yang	Man	Jie	Gu	Si	Xing	Wei	Zi	Ju	Shan	Pin	Ren	Yao	Dong	Jiang	Shu	Ji	Gai	Xiang	Hua	Juan	Jiao	Gou	Lao	Jian	Jian	Yi	Nian	Zhi	Ji	Ji	Xian	Heng	Guang	Jun	Kua	Yan	Ming	Lie	Pei	E	You	Yan	Cha	Shen	Yin	Shi	Gui	Quan	Zi";
    case 90:
      return "Song	Wei	Hong	Wa	Lou	Ya	Rao	Jiao	Luan	Ping	Xian	Shao	Li	Cheng	Xie	Mang	Fu	Suo	Mei	Wei	Ke	Chuo	Chuo	Ting	Niang	Xing	Nan	Yu	Na	Pou	Nei	Juan	Shen	Zhi	Han	Di	Zhuang	E	Pin	Tui	Xian	Mian	Wu	Yan	Wu	Ai	Yan	Yu	Si	Yu	Wa	Li	Xian	Ju	Qu	Zhui	Qi	Xian	Zhuo	Dong	Chang	Lu	Ai	E	E	Lou	Mian	Cong	Pou	Ju	Po	Cai	Ling	Wan	Biao	Xiao	Shu	Qi	Hui	Fan	Wo	Rui	Tan	Fei	Fei	Jie	Tian	Ni	Quan	Jing	Hun	Jing	Qian	Dian	Xing	Hu	Wan	Lai	Bi	Yin	Zhou	Chuo	Fu	Jing	Lun	An	Lan	Kun	Yin	Ya	Ju	Li	Dian	Xian	Hua	Hua	Ying	Chan	Shen	Ting	Dang	Yao	Wu	Nan	Ruo	Jia	Tou	Xu	Yu	Wei	Di	Rou	Mei	Dan	Ruan	Qin	Hui	Wo	Qian	Chun	Miao	Fu	Jie	Duan	Yi	Zhong	Mei	Huang	Mian	An	Ying	Xuan	Jie	Wei	Mei	Yuan	Zheng	Qiu	Shi	Xie	Tuo	Lian	Mao	Ran	Si	Pian	Wei	Wa	Cu	Hu	Ao	Jie	Bao	Xu	Tou	Gui	Chu	Yao	Pi	Xi	Yuan	Ying	Rong	Ru	Chi	Liu	Mei	Pan	Ao	Ma	Gou	Kui	Qin	Jia	Sao	Zhen	Yuan	Jie	Rong	Ming	Ying	Ji	Su	Niao	Xian	Tao	Pang	Lang	Nao	Bao	Ai	Pi	Pin	Yi	Piao	Yu	Lei	Xuan	Man	Yi	Zhang	Kang	Yong	Ni	Li	Di	Gui	Yan	Jin	Zhuan	Chang	Ze	Han	Nen	Lao	Mo	Zhe	Hu	Hu	Ao	Nen	Qiang	Ma	Pie	Gu	Wu	Qiao	Tuo	Zhan	Miao	Xian	Xian	Mo	Liao	Lian	Hua";
    case 91:
      return "Gui	Deng	Zhi	Xu	Yi	Hua	Xi	Kui	Rao	Xi	Yan	Chan	Jiao	Mei	Fan	Fan	Xian	Yi	Hui	Jiao	Fu	Shi	Bi	Shan	Sui	Qiang	Lian	Huan	Xin	Niao	Dong	Yi	Can	Ai	Niang	Ning	Ma	Tiao	Chou	Jin	Ci	Yu	Pin	Rong	Ru	Nai	Yan	Tai	Ying	Qian	Niao	Yue	Ying	Mian	Bi	Mo	Shen	Xing	Ni	Du	Liu	Yuan	Lan	Yan	Shuang	Ling	Jiao	Niang	Lan	Xian	Ying	Shuang	Hui	Quan	Mi	Li	Luan	Yan	Zhu	Lan	Zi	Jie	Jue	Jue	Kong	Yun	Ma	Zi	Cun	Sun	Fu	Bei	Zi	Xiao	Xin	Meng	Si	Tai	Bao	Ji	Gu	Nu	Xue	You	Zhuan	Hai	Luan	Sun	Nao	Mie	Cong	Qian	Shu	Chan	Ya	Zi	Ni	Fu	Zi	Li	Xue	Bo	Ru	Nai	Nie	Nie	Ying	Luan	Mian	Ning	Rong	Ta	Gui	Zhai	Qiong	Yu	Shou	An	Tu	Song	Wan	Rou	Yao	Hong	Yi	Jing	Zhun	Mi	Zhu	Dang	Hong	Zong	Guan	Zhou	Ding	Wan	Yi	Bao	Shi	Shi	Chong	Shen	Ke	Xuan	Shi	You	Huan	Yi	Tiao	Shi	Xian	Gong	Cheng	Qun	Gong	Xiao	Zai	Zha	Bao	Hai	Yan	Xiao	Jia	Shen	Chen	Rong	Huang	Mi	Kou	Kuan	Bin	Su	Cai	Zan	Ji	Yuan	Ji	Yin	Mi	Kou	Qing	He	Zhen	Jian	Fu	Ning	Bing	Huan	Mei	Qin	Han	Yu	Shi	Ning	Jin	Ning	Zhi	Yu	Bao	Kuan	Ning	Qin	Mo	Cha	Ju	Gua	Qin	Hu	Wu	Liao	Shi	Ning	Zhai	Shen	Wei	Xie	Kuan	Hui	Liao	Jun	Huan	Yi	Yi	Bao	Qin	Chong	Bao	Feng	Cun	Dui	Si	Xun	Dao	Lu	Dui	Shou";
    case 92:
      return "Po	Feng	Zhuan	Fu	She	Ke	Jiang	Jiang	Zhuan	Wei	Zun	Xun	Shu	Dui	Dao	Xiao	Jie	Shao	Er	Er	Er	Ga	Jian	Shu	Chen	Shang	Shang	Mo	Ga	Chang	Liao	Xian	Xian	Kun	Wang	Wang	You	Liao	Liao	Yao	Mang	Wang	Wang	Wang	Ga	Yao	Duo	Kui	Zhong	Jiu	Gan	Gu	Gan	Tui	Gan	Gan	Shi	Yin	Chi	Kao	Ni	Jin	Wei	Niao	Ju	Pi	Ceng	Xi	Bi	Ju	Jie	Tian	Qu	Ti	Jie	Wu	Diao	Shi	Shi	Ping	Ji	Xie	Zhen	Xie	Ni	Zhan	Xi	Wei	Man	E	Lou	Ping	Ti	Fei	Shu	Xie	Tu	Lu	Lu	Xi	Ceng	Lu	Ju	Xie	Ju	Jue	Liao	Jue	Shu	Xi	Che	Tun	Ni	Shan	Wa	Xian	Li	E	Hui	Hui	Long	Yi	Qi	Ren	Wu	Han	Shen	Yu	Chu	Sui	Qi	Ren	Yue	Ban	Yao	Ang	Ya	Wu	Jie	E	Ji	Qian	Fen	Wan	Qi	Cen	Qian	Qi	Cha	Jie	Qu	Gang	Xian	Ao	Lan	Dao	Ba	Zuo	Zuo	Yang	Ju	Gang	Ke	Gou	Xue	Po	Li	Tiao	Qu	Yan	Fu	Xiu	Jia	Ling	Tuo	Pi	Ao	Dai	Kuang	Yue	Qu	Hu	Po	Min	An	Tiao	Ling	Chi	Ping	Dong	Han	Kui	Xiu	Mao	Tong	Xue	Yi	Bian	He	Ba	Luo	E	Fu	Xun	Die	Lu	En	Er	Gai	Quan	Dong	Yi	Mu	Shi	An	Wei	Huan	Zhi	Mi	Lie	Ji	Tong	Wei	You	Qia	Xia	Li	Yao	Jiao	Zheng	Luan	Jiao	E	E	Yu	Xie	Bu	Qiao	Qun	Feng	Feng	Nao	Li	You	Xian	Rong	Dao	Shen	Cheng	Tu	Geng	Jun	Gao	Xia	Yin	Wu";
    case 93:
      return "Lang	Kan	Lao	Lai	Xian	Que	Kong	Chong	Chong	Ta	Lin	Hua	Ju	Lai	Qi	Min	Kun	Kun	Zu	Gu	Cui	Ya	Ya	Gang	Lun	Lun	Leng	Jue	Duo	Zheng	Guo	Yin	Dong	Han	Zheng	Wei	Xiao	Pi	Yan	Song	Jie	Beng	Zu	Ku	Dong	Zhan	Gu	Yin	Zi	Ze	Huang	Yu	Wai	Yang	Feng	Qiu	Yang	Ti	Yi	Zhi	Shi	Zai	Yao	E	Zhu	Kan	Lu	Yan	Mei	Han	Ji	Ji	Huan	Ting	Sheng	Mei	Qian	Wu	Yu	Zong	Lan	Ke	Yan	Yan	Wei	Zong	Cha	Sui	Rong	Ke	Qin	Yu	Qi	Lou	Tu	Dui	Xi	Weng	Cang	Dang	Rong	Jie	Kai	Liu	Wu	Song	Qiao	Zi	Wei	Beng	Dian	Cuo	Qian	Yong	Nie	Cuo	Ji	Shi	Ruo	Song	Zong	Jiang	Liao	Kang	Chan	Die	Cen	Ding	Tu	Lou	Zhang	Zhan	Zhan	Ao	Cao	Qu	Qiang	Cui	Zui	Dao	Dao	Xi	Yu	Pei	Long	Xiang	Ceng	Bo	Qin	Jiao	Yan	Lao	Zhan	Lin	Liao	Liao	Jin	Deng	Duo	Zun	Jiao	Gui	Yao	Jiao	Yao	Jue	Shan	Yi	Xue	Nao	Ye	Ye	Yi	Nie	Xian	Ji	Xie	Ke	Xi	Di	Ao	Zui	Wei	Yi	Rong	Dao	Ling	Jie	Yu	Yue	Yin	Ru	Jie	Li	Gui	Long	Long	Dian	Rong	Xi	Ju	Chan	Ying	Kui	Yan	Wei	Nao	Quan	Chao	Cuan	Luan	Dian	Dian	Nie	Yan	Yan	Yan	Kui	Yan	Chuan	Kuai	Chuan	Zhou	Huang	Jing	Xun	Chao	Chao	Lie	Gong	Zuo	Qiao	Ju	Gong	Ju	Wu	Pu	Pu	Cha	Qiu	Qiu	Ji	Yi	Si	Ba	Zhi	Zhao	Xiang	Yi	Jin	Xun	Juan	Ba	Xun	Jin	Fu";
    case 94:
      return "Za	Bi	Shi	Bu	Ding	Shuai	Fan	Nie	Shi	Fen	Pa	Zhi	Xi	Hu	Dan	Wei	Zhang	Tang	Dai	Mo	Pei	Pa	Tie	Bo	Lian	Zhi	Zhou	Bo	Zhi	Di	Mo	Yi	Yi	Ping	Qia	Juan	Ru	Shuai	Dai	Zhen	Shui	Qiao	Zhen	Shi	Qun	Xi	Bang	Dai	Gui	Chou	Ping	Zhang	San	Wan	Dai	Wei	Chang	Sha	Qi	Ze	Guo	Mao	Du	Hou	Zheng	Xu	Mi	Wei	Wo	Fu	Yi	Bang	Ping	Die	Gong	Pan	Huang	Tao	Mi	Jia	Teng	Hui	Zhong	Shan	Man	Mu	Biao	Guo	Ze	Mu	Bang	Zhang	Jing	Chan	Fu	Zhi	Hu	Fan	Chuang	Bi	Bi	Zhang	Mi	Qiao	Chan	Fen	Meng	Bang	Chou	Mie	Chu	Jie	Xian	Lan	Gan	Ping	Nian	Jian	Bing	Bing	Xing	Gan	Yao	Huan	You	You	Ji	Guang	Pi	Ting	Ze	Guang	Zhuang	Mo	Qing	Bi	Qin	Dun	Chuang	Gui	Ya	Bai	Jie	Xu	Lu	Wu	Zhuang	Ku	Ying	Di	Pao	Dian	Ya	Miao	Geng	Ci	Fu	Tong	Pang	Fei	Xiang	Yi	Zhi	Tiao	Zhi	Xiu	Du	Zuo	Xiao	Tu	Gui	Ku	Mang	Ting	You	Bu	Bing	Cheng	Lai	Bi	Ji	An	Shu	Kang	Yong	Tuo	Song	Shu	Qing	Yu	Yu	Miao	Sou	Ce	Xiang	Fei	Jiu	E	Wei	Liu	Sha	Lian	Lang	Sou	Zhi	Bu	Qing	Jiu	Jiu	Jin	Ao	Kuo	Lou	Yin	Liao	Dai	Lu	Yi	Chu	Chan	Tu	Si	Xin	Miao	Chang	Wu	Fei	Guang	Ku	Kuai	Bi	Qiang	Xie	Lin	Lin	Liao	Lu	Ji	Ying	Xian	Ting	Yong	Li	Ting	Yin	Xun	Yan	Ting	Di	Pai	Jian	Hui	Nai	Hui	Gong	Nian";
    case 95:
      return "Kai	Bian	Yi	Qi	Nong	Fen	Ju	Yan	Yi	Zang	Bi	Yi	Yi	Er	San	Shi	Er	Shi	Shi	Gong	Diao	Yin	Hu	Fu	Hong	Wu	Tui	Chi	Jiang	Ba	Shen	Di	Zhang	Jue	Tao	Fu	Di	Mi	Xian	Hu	Chao	Nu	Jing	Zhen	Yi	Mi	Quan	Wan	Shao	Ruo	Xuan	Jing	Diao	Zhang	Jiang	Qiang	Peng	Dan	Qiang	Bi	Bi	She	Dan	Jian	Gou	Ge	Fa	Bi	Kou	Jian	Bie	Xiao	Dan	Guo	Jiang	Hong	Mi	Guo	Wan	Jue	Ji	Ji	Gui	Dang	Lu	Lu	Tuan	Hui	Zhi	Hui	Hui	Yi	Yi	Yi	Yi	Yue	Yue	Shan	Xing	Wen	Tong	Yan	Yan	Yu	Chi	Cai	Biao	Diao	Bin	Peng	Yong	Piao	Zhang	Ying	Chi	Chi	Zhuo	Tuo	Ji	Pang	Zhong	Yi	Wang	Che	Bi	Di	Ling	Fu	Wang	Zheng	Cu	Wang	Jing	Dai	Xi	Xun	Hen	Yang	Huai	Lu	Hou	Wang	Cheng	Zhi	Xu	Jing	Tu	Cong	Zhi	Lai	Cong	De	Pai	Xi	Dong	Ji	Chang	Zhi	Cong	Zhou	Lai	Yu	Xie	Jie	Jian	Shi	Jia	Bian	Huang	Fu	Xun	Wei	Pang	Yao	Wei	Xi	Zheng	Piao	Ti	De	Zheng	Zhi	Bie	De	Chong	Che	Jiao	Hui	Jiao	Hui	Mei	Long	Xiang	Bao	Qu	Xin	Xin	Bi	Yi	Le	Ren	Dao	Ding	Gai	Ji	Ren	Ren	Chan	Tan	Te	Te	Gan	Qi	Shi	Cun	Zhi	Wang	Mang	Xi	Fan	Ying	Tian	Min	Wen	Zhong	Chong	Wu	Ji	Wu	Xi	Jia	You	Wan	Cong	Song	Kuai	Yu	Bian	Zhi	Qi	Cui	Chen	Tai	Tun	Qian	Nian	Hun	Xiong	Niu	Kuang	Xian	Xin	Kang	Hu	Kai	Fen";
    case 96:
      return "Huai	Tai	Song	Wu	Ou	Chang	Chuang	Ju	Yi	Bao	Chao	Min	Pei	Zuo	Zen	Yang	Ju	Ban	Nu	Nao	Zheng	Pa	Bu	Tie	Hu	Hu	Ju	Da	Lian	Si	Chou	Di	Dai	Yi	Tu	You	Fu	Ji	Peng	Xing	Yuan	Ni	Guai	Fu	Xi	Bi	You	Qie	Xuan	Cong	Bing	Huang	Xu	Chu	Bi	Shu	Xi	Tan	Yong	Zong	Dui	Mo	Zhi	Yi	Shi	Nen	Xun	Shi	Xi	Lao	Heng	Kuang	Mou	Zhi	Xie	Lian	Tiao	Huang	Die	Hao	Kong	Gui	Heng	Xi	Jiao	Shu	Si	Hu	Qiu	Yang	Hui	Hui	Chi	Jia	Yi	Xiong	Guai	Lin	Hui	Zi	Xu	Chi	Shang	Nu	Hen	En	Ke	Dong	Tian	Gong	Quan	Xi	Qia	Yue	Peng	Ken	De	Hui	E	Xiao	Tong	Yan	Kai	Ce	Nao	Yun	Mang	Yong	Yong	Yuan	Pi	Kun	Qiao	Yue	Yu	Tu	Jie	Xi	Zhe	Lin	Ti	Han	Hao	Qie	Ti	Bu	Yi	Qian	Hui	Xi	Bei	Man	Yi	Heng	Song	Quan	Cheng	Kui	Wu	Wu	You	Li	Liang	Huan	Cong	Yi	Yue	Li	Nin	Nao	E	Que	Xuan	Qian	Wu	Min	Cong	Fei	Bei	De	Cui	Chang	Men	Li	Ji	Guan	Guan	Xing	Dao	Qi	Kong	Tian	Lun	Xi	Kan	Gun	Ni	Qing	Chou	Dun	Guo	Zhan	Jing	Wan	Yuan	Jin	Ji	Lan	Yu	Huo	He	Quan	Tan	Ti	Ti	Nie	Wang	Chuo	Hu	Hun	Xi	Chang	Xin	Wei	Hui	E	Suo	Zong	Jian	Yong	Dian	Ju	Can	Cheng	De	Bei	Qie	Can	Dan	Guan	Duo	Nao	Yun	Xiang	Zhui	Die	Huang	Chun	Qiong	Re	Xing	Ce	Bian	Min	Zong	Ti";
    case 97:
      return "Qiao	Chou	Bei	Xuan	Wei	Ge	Qian	Wei	Yu	Yu	Bi	Xuan	Huan	Min	Bi	Yi	Mian	Yong	Kai	Dang	Yin	E	Chen	Mao	Qia	Ke	Yu	Ai	Qie	Yan	Nuo	Gan	Yun	Zong	Sai	Leng	Fen	Ying	Kui	Kui	Que	Gong	Yun	Su	Su	Qi	Yao	Song	Huang	Ji	Gu	Ju	Chuang	Ni	Xie	Kai	Zheng	Yong	Cao	Xun	Shen	Bo	Kai	Yuan	Xi	Hun	Yong	Yang	Li	Sao	Tao	Yin	Ci	Xu	Qian	Tai	Huang	Yun	Shen	Ming	Gong	She	Cong	Piao	Mu	Mu	Guo	Chi	Can	Can	Can	Cui	Min	Te	Zhang	Tong	Ao	Shuang	Man	Guan	Que	Zao	Jiu	Hui	Kai	Lian	Ou	Song	Qin	Yin	Lu	Shang	Wei	Tuan	Man	Qian	She	Yong	Qing	Kang	Di	Zhi	Lou	Juan	Qi	Qi	Yu	Ping	Liao	Cong	You	Chong	Zhi	Tong	Cheng	Qi	Qu	Peng	Bei	Bie	Qiong	Jiao	Zeng	Chi	Lian	Ping	Kui	Hui	Qiao	Cheng	Yin	Yin	Xi	Xi	Dan	Tan	Duo	Dui	Dui	Su	Jue	Ce	Xiao	Fan	Fen	Lao	Lao	Chong	Han	Qi	Xian	Min	Jing	Liao	Wu	Can	Jue	Cu	Xian	Tan	Sheng	Pi	Yi	Chu	Xian	Nao	Dan	Tan	Jing	Song	Han	Jiao	Wei	Xuan	Dong	Qin	Qin	Ju	Cao	Ken	Xie	Ying	Ao	Mao	Yi	Lin	Se	Jun	Huai	Men	Lan	Ai	Lin	Yan	Kuo	Xia	Chi	Yu	Yin	Dai	Meng	Ai	Meng	Dui	Qi	Mo	Lan	Men	Chou	Zhi	Nuo	Nuo	Yan	Yang	Bo	Zhi	Kuang	Kuang	You	Fu	Liu	Mie	Cheng	Hui	Chan	Meng	Lan	Huai	Xuan	Rang	Chan	Ji	Ju	Huan	She	Yi";
    case 98:
      return "Lian	Nan	Mi	Tang	Jue	Gang	Gang	Zhuang	Ge	Yue	Wu	Jian	Xu	Shu	Rong	Xi	Cheng	Wo	Jie	Ge	Jian	Qiang	Huo	Qiang	Zhan	Dong	Qi	Jia	Die	Zei	Jia	Ji	Zhi	Kan	Ji	Kui	Gai	Deng	Zhan	Qiang	Ge	Jian	Jie	Yu	Jian	Yan	Lu	Hu	Zhan	Xi	Xi	Chuo	Dai	Qu	Hu	Hu	Hu	E	Shi	Ti	Mao	Hu	Li	Fang	Suo	Bian	Dian	Jiong	Shang	Yi	Yi	Shan	Hu	Fei	Yan	Shou	Shou	Cai	Zha	Qiu	Le	Pu	Ba	Da	Reng	Fan	Ru	Zai	Tuo	Zhang	Diao	Kang	Yu	Ku	Han	Shen	Cha	Tuo	Gu	Kou	Wu	Den	Qian	Zhi	Ren	Kuo	Men	Sao	Yang	Niu	Ban	Che	Rao	Xi	Qian	Ban	Jia	Yu	Fu	Ao	Xi	Pi	Zhi	Zhi	E	Den	Zhao	Cheng	Ji	Yan	Kuang	Bian	Chao	Ju	Wen	Hu	Yue	Jue	Ba	Qin	Dan	Zheng	Yun	Wan	Ne	Yi	Shu	Zhua	Pou	Tou	Dou	Kang	Zhe	Pou	Fu	Pao	Ba	Ao	Ze	Tuan	Kou	Lun	Qiang	Yun	Hu	Bao	Bing	Zhi	Peng	Nan	Bu	Pi	Tai	Yao	Zhen	Zha	Yang	Bao	He	Ni	Ye	Di	Chi	Pi	Jia	Mo	Mei	Chen	Ya	Chou	Qu	Min	Chu	Jia	Fu	Zha	Zhu	Dan	Chai	Mu	Nian	La	Fu	Pao	Ban	Pai	Lin	Na	Guai	Qian	Ju	Ta	Ba	Tuo	Tuo	Ao	Ju	Zhuo	Pan	Zhao	Bai	Bai	Di	Ni	Ju	Kuo	Long	Jian	Qia	Yong	Lan	Ning	Bo	Ze	Qian	Hen	Kuo	Shi	Jie	Zheng	Nin	Gong	Gong	Quan	Shuan	Cun	Za	Kao	Yi	Xie	Ce	Hui	Pin	Zhuai	Shi	Na";
    case 99:
      return "Bai	Chi	Gua	Zhi	Kuo	Duo	Duo	Zhi	Qie	An	Nong	Zhen	Ge	Jiao	Kua	Dong	Na	Tiao	Lie	Zha	Lu	Die	Wa	Jue	Lie	Ju	Zhi	Luan	Ya	Wo	Ta	Xie	Nao	Dang	Jiao	Zheng	Ji	Hui	Xian	Yu	Ai	Tuo	Nuo	Cuo	Bo	Geng	Ti	Zhen	Cheng	Sa	Sa	Keng	Mei	Nong	Ju	Peng	Jian	Yi	Ting	Shan	Rua	Wan	Xie	Cha	Feng	Jiao	Wu	Jun	Jiu	Tong	Kun	Huo	Tu	Zhuo	Pou	Lu	Ba	Han	Shao	Nie	Juan	Ze	Shu	Ye	Jue	Bu	Wan	Bu	Zun	Ye	Zhai	Lu	Sou	Tuo	Lao	Sun	Bang	Jian	Huan	Dao	Wei	Wan	Qin	Peng	She	Lie	Min	Men	Fu	Bai	Ju	Dao	Wo	Ai	Juan	Yue	Zong	Chen	Chui	Jie	Tu	Ben	Na	Nian	Ruo	Zuo	Wo	Qi	Xian	Cheng	Dian	Sao	Lun	Qing	Gang	Duo	Shou	Diao	Pou	Di	Zhang	Hun	Ji	Tao	Qia	Qi	Pai	Shu	Qian	Ling	Ye	Ya	Jue	Zheng	Liang	Gua	Yi	Huo	Yan	Zheng	Lue	Cai	Tan	Che	Bing	Jie	Ti	Kong	Tui	Yan	Cuo	Zhou	Ju	Tian	Qian	Ken	Bai	Pa	Jie	Lu	Guai	Ming	Jie	Zhi	Dan	Meng	Chan	Sao	Guan	Peng	Yuan	Nuo	Jian	Zheng	Jiu	Jian	Yu	Yan	Kui	Nan	Hong	Rou	Pi	Wei	Sai	Zou	Xuan	Miao	Ti	Nie	Cha	Shi	Zong	Zhen	Yi	Xun	Yong	Bian	Yang	Huan	Yan	Zan	An	Xu	Ya	Wo	Ke	Chuai	Ji	Ti	La	La	Chen	Kai	Jiu	Jiu	Tu	Jie	Hui	Gen	Chong	Xiao	Die	Xie	Yuan	Qian	Ye	Cha	Zha	Bei	Yao	Wei	Beng	Lan	Wen	Qin";
    case 100:
      return "Chan	Ge	Lou	Zong	Gen	Jiao	Gou	Qin	Rong	Que	Chou	Chuai	Zhan	Sun	Sun	Bo	Chu	Rong	Bang	Cuo	Sao	Ke	Yao	Dao	Zhi	Nu	La	Jian	Sou	Qiu	Gao	Xian	Shuo	Sang	Jin	Mie	E	Chui	Nuo	Shan	Ta	Zha	Tang	Pan	Ban	Da	Li	Tao	Hu	Zhi	Wa	Hua	Qian	Wen	Qiang	Tian	Zhen	E	Xie	Nuo	Quan	Cha	Zha	Ge	Wu	En	She	Kang	She	Shu	Bai	Yao	Bin	Sou	Tan	Sa	Chan	Suo	Jiu	Chong	Chuang	Guai	Bing	Feng	Shuai	Di	Qi	Sou	Zhai	Lian	Cheng	Chi	Guan	Lu	Luo	Lou	Zong	Gai	Hu	Zha	Chuang	Tang	Hua	Cui	Nai	Mo	Jiang	Gui	Ying	Zhi	Ao	Zhi	Nie	Man	Chan	Kou	Chu	She	Tuan	Jiao	Mo	Mo	Zhe	Can	Keng	Biao	Jiang	Yao	Gou	Qian	Liao	Ji	Ying	Jue	Pie	Pie	Lao	Dun	Xian	Ruan	Gui	Zan	Yi	Xian	Cheng	Cheng	Sa	Nao	Hong	Si	Han	Guang	Da	Zun	Nian	Lin	Zheng	Hui	Zhuang	Jiao	Ji	Cao	Dan	Dan	Che	Bo	Che	Jue	Fu	Liao	Ben	Fu	Qiao	Bo	Cuo	Zhuo	Zhuan	Wei	Pu	Qin	Dun	Nian	Hua	Xie	Lu	Jiao	Cuan	Ta	Han	Qiao	Wo	Jian	Gan	Yong	Lei	Nang	Lu	Shan	Zhuo	Ze	Pu	Chuo	Ji	Dang	Se	Cao	Qing	Qing	Huan	Jie	Qin	Kuai	Dan	Xie	Ka	Pi	Bo	Ao	Ju	Ye	E	Meng	Sou	Mi	Ji	Tai	Zhuo	Dao	Xing	Lan	Ca	Ju	Ye	Ru	Ye	Ye	Ni	Wo	Jie	Bin	Ning	Ge	Zhi	Zhi	Kuo	Mo	Jian	Xie	Lie	Tan	Bai	Sou	Lu	Lue	Rao	Ti";
    case 101:
      return "Pan	Yang	Lei	Ca	Shu	Zan	Nian	Xian	Jun	Huo	Li	La	Huan	Ying	Lu	Long	Qian	Qian	Zan	Qian	Lan	Xian	Ying	Mei	Rang	Chan	Weng	Cuan	Xie	She	Luo	Jun	Mi	Chi	Zan	Luan	Tan	Zuan	Li	Dian	Wa	Dang	Jiao	Jue	Lan	Li	Nang	Zhi	Gui	Gui	Qi	Xun	Pu	Pu	Shou	Kao	You	Gai	Yi	Gong	Gan	Ban	Fang	Zheng	Po	Dian	Kou	Min	Wu	Gu	He	Ce	Xiao	Mi	Chu	Ge	Di	Xu	Jiao	Min	Chen	Jiu	Shen	Duo	Yu	Chi	Ao	Bai	Xu	Jiao	Duo	Lian	Nie	Bi	Chang	Dian	Duo	Yi	Gan	San	Ke	Yan	Dun	Ji	Tou	Xiao	Duo	Jiao	Jing	Yang	Xia	Min	Shu	Ai	Qiao	Ai	Zheng	Di	Zhen	Fu	Shu	Liao	Qu	Xiong	Yi	Jiao	Shan	Jiao	Zhuo	Yi	Lian	Bi	Li	Xiao	Xiao	Wen	Xue	Qi	Qi	Zhai	Bin	Jue	Zhai	Lang	Fei	Ban	Ban	Lan	Yu	Lan	Wei	Dou	Sheng	Liao	Jia	Hu	Xie	Jia	Yu	Zhen	Jiao	Wo	Tiao	Dou	Jin	Chi	Yin	Fu	Qiang	Zhan	Qu	Zhuo	Zhan	Duan	Cuo	Si	Xin	Zhuo	Zhuo	Qin	Lin	Zhuo	Chu	Duan	Zhu	Fang	Chan	Hang	Yu	Shi	Pei	You	Mei	Pang	Qi	Zhan	Mao	Lu	Pei	Pi	Liu	Fu	Fang	Xuan	Jing	Jing	Ni	Zu	Zhao	Yi	Liu	Shao	Jian	Yu	Yi	Qi	Zhi	Fan	Piao	Fan	Zhan	Kuai	Sui	Yu	Wu	Ji	Ji	Ji	Huo	Ri	Dan	Jiu	Zhi	Zao	Xie	Tiao	Xun	Xu	Ga	La	Gan	Han	Tai	Di	Xu	Chan	Shi	Kuang	Yang	Shi	Wang	Min	Min	Tun	Chun	Wu";
    case 102:
      return "Yun	Bei	Ang	Ze	Ban	Jie	Kun	Sheng	Hu	Fang	Hao	Gui	Chang	Xuan	Ming	Hun	Fen	Qin	Hu	Yi	Xi	Xin	Yan	Ze	Fang	Tan	Shen	Ju	Yang	Zan	Bing	Xing	Ying	Xuan	Po	Zhen	Ling	Chun	Hao	Mei	Zuo	Mo	Bian	Xu	Hun	Zhao	Zong	Shi	Shi	Yu	Fei	Die	Mao	Ni	Chang	Wen	Dong	Ai	Bing	Ang	Zhou	Long	Xian	Kuang	Tiao	Chao	Shi	Huang	Huang	Xuan	Kui	Xu	Jiao	Jin	Zhi	Jin	Shang	Tong	Hong	Yan	Gai	Xiang	Shai	Xiao	Ye	Yun	Hui	Han	Han	Jun	Wan	Xian	Kun	Zhou	Xi	Cheng	Sheng	Bu	Zhe	Zhe	Wu	Wan	Hui	Hao	Chen	Wan	Tian	Zhuo	Zui	Zhou	Pu	Jing	Xi	Shan	Ni	Xi	Qing	Qi	Jing	Gui	Zheng	Yi	Zhi	An	Wan	Lin	Liang	Chang	Wang	Xiao	Zan	Fei	Xuan	Geng	Yi	Xia	Yun	Hui	Xu	Min	Kui	Ye	Ying	Shu	Wei	Shu	Qing	Mao	Nan	Jian	Nuan	An	Yang	Chun	Yao	Suo	Pu	Ming	Jiao	Kai	Gao	Weng	Chang	Qi	Hao	Yan	Li	Ai	Ji	Ji	Men	Zan	Xie	Hao	Mu	Mo	Cong	Ni	Zhang	Hui	Bao	Han	Xuan	Chuan	Liao	Xian	Tan	Jing	Pie	Lin	Tun	Xi	Yi	Ji	Huang	Dai	Ye	Ye	Li	Tan	Tong	Xiao	Fei	Shen	Zhao	Hao	Yi	Xiang	Xing	Shen	Jiao	Bao	Jing	Yan	Ai	Ye	Ru	Shu	Meng	Xun	Yao	Pu	Li	Chen	Kuang	Die	Liao	Yan	Huo	Lu	Xi	Rong	Long	Nang	Luo	Luan	Shai	Tang	Yan	Zhu	Yue	Yue	Qu	Ye	Geng	Ye	Hu	He	Shu	Cao	Cao	Sheng	Man	Ceng	Ceng	Ti";
    case 103:
      return "Zui	Can	Xu	Hui	Yin	Qie	Fen	Pi	Yue	You	Ruan	Peng	Fen	Fu	Ling	Fei	Qu	Ti	Nu	Tiao	Shuo	Zhen	Lang	Lang	Zui	Ming	Huang	Wang	Tun	Chao	Ji	Qi	Ying	Zong	Wang	Tong	Lang	Lao	Meng	Long	Mu	Deng	Wei	Mo	Ben	Zha	Shu	Shu	Mu	Zhu	Ren	Ba	Pu	Duo	Duo	Dao	Li	Gui	Ji	Jiu	Bi	Xiu	Cheng	Ci	Sha	Ru	Za	Quan	Qian	Yu	Gan	Wu	Cha	Shan	Xun	Fan	Wu	Zi	Li	Xing	Cai	Cun	Ren	Biao	Tuo	Di	Zhang	Mang	Chi	Yi	Gai	Gong	Du	Li	Qi	Shu	Gang	Tiao	Jie	Mian	Wan	Lai	Jiu	Mang	Yang	Ma	Miao	Si	Yuan	Hang	Fei	Bei	Jie	Dong	Gao	Yao	Xian	Chu	Chun	Pa	Shu	Hua	Xin	Chou	Zhu	Chou	Song	Ban	Song	Ji	Wo	Jin	Gou	Ji	Mao	Pi	Bi	Wang	Ang	Fang	Fen	Yi	Fu	Nan	Xi	Hu	Ya	Dou	Xin	Zhen	Yao	Lin	Rui	E	Mei	Zhao	Guo	Zhi	Cong	Yun	Hua	Sheng	Shu	Zao	Di	Li	Lu	Jian	Cheng	Song	Qiang	Feng	Zhan	Xiao	Xian	Ku	Ping	Tai	Xi	Zhi	Guai	Xiao	Jia	Jia	Gou	Bao	Mo	Yi	Ye	Ye	Shi	Nie	Bi	Tuo	Yi	Ling	Bing	Ni	La	He	Ban	Fan	Zhong	Dai	Ci	Yang	Fu	Bai	Mou	Gan	Qi	Ran	Rou	Mao	Shao	Song	Zhe	Xia	You	Shen	Gui	Tuo	Zha	Nan	Ning	Yong	Di	Zhi	Zha	Cha	Dan	Gu	Bu	Jiu	Ao	Fu	Jian	Ba	Duo	Ke	Nai	Zhu	Bi	Liu	Chai	Shan	Si	Zhu	Pei	Shi	Guai	Zha	Yao	Cheng	Jiu	Shi";
    case 104:
      return "Zhi	Liu	Mei	Li	Rong	Zha	Zao	Biao	Zhan	Zhi	Long	Dong	Lu	Sheng	Li	Lan	Yong	Shu	Xun	Shuan	Qi	Zhen	Qi	Li	Yi	Xiang	Zhen	Li	Se	Gua	Kan	Ben	Ren	Xiao	Bai	Ren	Bing	Zi	Chou	Yi	Ci	Xu	Zhu	Jian	Zui	Er	Er	You	Fa	Gong	Kao	Lao	Zhan	Lie	Yin	Yang	He	Gen	Yi	Shi	Ge	Zai	Luan	Fu	Jie	Heng	Gui	Tao	Guang	Wei	Kuang	Ru	An	An	Juan	Yi	Zhuo	Ku	Zhi	Qiong	Tong	Sang	Sang	Huan	Jie	Jiu	Xue	Duo	Zhui	Yu	Zan	Lung	Ying	Jie	Liu	Zhan	Ya	Rao	Zhen	Dang	Qi	Qiao	Hua	Gui	Jiang	Zhuang	Xun	Suo	Sha	Zhen	Bei	Ting	Kuo	Jing	Po	Ben	Fu	Rui	Tong	Jue	Xi	Lang	Liu	Feng	Qi	Wen	Jun	Gan	Su	Liang	Qiu	Ting	You	Mei	Bang	Long	Peng	Zhuang	Di	Xuan	Tu	Zao	Ao	Gu	Bi	Di	Han	Zi	Zhi	Ren	Bei	Geng	Jian	Huan	Wan	Nuo	Jia	Tiao	Ji	Xiao	Lu	Hun	Shao	Chen	Fen	Song	Meng	Wu	Li	Li	Dou	Qin	Ying	Suo	Ju	Ti	Xie	Kun	Zhuo	Shu	Chan	Fan	Wei	Jing	Li	Bin	Xia	Fo	Tao	Zhi	Lai	Lian	Jian	Zhuo	Ling	Li	Qi	Bing	Lun	Cong	Qian	Mian	Qi	Qi	Cai	Gun	Chan	De	Fei	Pai	Bang	Bei	Hun	Zong	Cheng	Zao	Ji	Li	Peng	Yu	Yu	Gu	Jun	Dong	Tang	Gang	Wang	Di	Cuo	Fan	Cheng	Zhan	Qi	Yuan	Yan	Yu	Quan	Yi	Sen	Ren	Chui	Leng	Qi	Zhuo	Fu	Ke	Lai	Zou	Zou	Zhao	Guan	Fen	Fen	Shen	Qing	Ni";
    case 105:
      return "Wan	Guo	Lu	Hao	Jie	Yi	Chou	Ju	Ju	Cheng	Zuo	Liang	Qiang	Zhi	Zhui	Ya	Ju	Bei	Jiao	Zhuo	Zi	Bin	Peng	Ding	Chu	Chang	Men	Hua	Jian	Gui	Xi	Du	Qian	Dao	Gui	Dian	Luo	Zhi	Quan	Ming	Fu	Geng	Peng	Shan	Yi	Tuo	Sen	Duo	Ye	Fu	Wei	Wei	Duan	Jia	Zong	Jian	Yi	Shen	Xi	Yan	Yan	Chuan	Jian	Chun	Yu	He	Zha	Wo	Pian	Bi	Yao	Huo	Xu	Ruo	Yang	La	Yan	Ben	Hui	Kui	Jie	Kui	Si	Feng	Xie	Tuo	Zhi	Jian	Mu	Mao	Chu	Hu	Hu	Lian	Leng	Ting	Nan	Yu	You	Mei	Song	Xuan	Xuan	Yang	Zhen	Pian	Die	Ji	Jie	Ye	Chu	Dun	Yu	Zou	Wei	Mei	Ti	Ji	Jie	Kai	Qiu	Ying	Rou	Huang	Lou	Le	Quan	Xiang	Pin	Shi	Gai	Tan	Lan	Wen	Yu	Chen	Lu	Ju	Shen	Chu	Bi	Xie	Jia	Yi	Zhan	Fu	Nuo	Mi	Lang	Rong	Gu	Jian	Ju	Ta	Yao	Zhen	Bang	Sha	Yuan	Zi	Ming	Su	Jia	Yao	Jie	Huang	Gan	Fei	Zha	Qian	Ma	Sun	Yuan	Xie	Rong	Shi	Zhi	Cui	Wen	Ting	Liu	Rong	Tang	Que	Zhai	Si	Sheng	Ta	Ke	Xi	Gu	Qi	Gao	Gao	Sun	Pan	Tao	Ge	Chun	Dian	Nou	Ji	Shuo	Gou	Chui	Qiang	Cha	Qian	Huai	Mei	Xu	Gang	Gao	Zhuo	Tuo	Qiao	Yang	Dian	Jia	Kan	Zui	Dao	Long	Bin	Zhu	Sang	Xi	Ji	Lian	Hui	Yong	Qian	Guo	Gai	Gai	Tuan	Hua	Qi	Sen	Cui	Peng	You	Hu	Jiang	Hu	Huan	Gui	Nie	Yi	Gao	Kang	Gui	Gui	Cao	Man	Jin";
    case 106:
      return "Di	Zhuang	Le	Lang	Chen	Cong	Li	Xiu	Qing	Shuang	Fan	Tong	Guan	Ze	Su	Lei	Lu	Liang	Mi	Lou	Chao	Su	Ke	Chu	Tang	Biao	Lu	Jiu	Zhe	Zha	Shu	Zhang	Man	Mo	Niao	Yang	Tiao	Peng	Zhu	Sha	Xi	Quan	Heng	Jian	Cong	Ji	Yan	Qiang	Xue	Ying	Er	Xun	Zhi	Qiao	Zui	Cong	Pu	Shu	Hua	Kui	Zhen	Zun	Yue	Shan	Xi	Chun	Dian	Fa	Gan	Mo	Wu	Qiao	Rao	Lin	Liu	Qiao	Xian	Run	Fan	Zhan	Tuo	Liao	Yun	Shun	Dun	Cheng	Tang	Meng	Ju	Cheng	Su	Jue	Jue	Dian	Hui	Ji	Nuo	Xiang	Tuo	Ning	Rui	Zhu	Tong	Zeng	Fen	Qiong	Ran	Heng	Qian	Gu	Liu	Lao	Gao	Chu	Xi	Sheng	Zi	San	Ji	Dou	Jing	Lu	Jian	Chu	Yuan	Ta	Shu	Jiang	Tan	Lin	Nong	Yin	Xi	Hui	Shan	Zui	Xuan	Cheng	Gan	Ju	Zui	Yi	Qin	Pu	Yan	Lei	Feng	Hui	Dang	Ji	Sui	Bo	Ping	Cheng	Chu	Zhua	Gui	Ji	Jie	Jia	Qing	Zhai	Jian	Qiang	Dao	Yi	Biao	Song	She	Lin	Li	Cha	Meng	Yin	Tao	Tai	Mian	Qi	Tuan	Bin	Huo	Ji	Qian	Ni	Ning	Yi	Gao	Kan	Yin	Nou	Qing	Yan	Qi	Mi	Zhao	Gui	Chun	Ji	Kui	Po	Deng	Chu	Ge	Mian	You	Zhi	Huang	Qian	Lei	Lei	Sa	Lu	Li	Cuan	Lu	Mie	Hui	Ou	Lu	Zhi	Gao	Du	Yuan	Li	Fei	Zhuo	Sou	Lian	Jiang	Chu	Qing	Zhu	Lu	Yan	Li	Zhu	Chen	Jie	E	Su	Huai	Nie	Yu	Long	Lai	Jiao	Xian	Gui	Ju	Xiao	Ling	Ying	Jian	Yin	You	Ying";
    case 107:
      return "Xiang	Nong	Bo	Chan	Lan	Ju	Shuang	She	Wei	Cong	Quan	Qu	Cang	Jiu	Yu	Luo	Li	Cuan	Luan	Dang	Jue	Yan	Lan	Lan	Zhu	Lei	Li	Ba	Nang	Yu	Ling	Guang	Qian	Ci	Huan	Xin	Yu	Yi	Qian	Ou	Xu	Chao	Chu	Qi	Kai	Yi	Jue	Xi	Xu	He	Yu	Kui	Lang	Kuan	Shuo	Xi	Ai	Qi	Qi	Xu	Chi	Qin	Kuan	Kan	Kuan	Kan	Chuan	Sha	Gua	Yin	Xin	Xie	Yu	Qian	Xiao	Ye	Ge	Wu	Tan	Jin	Ou	Hu	Ti	Huan	Xu	Pen	Xi	Xiao	Chua	She	Shan	Han	Chu	Yi	E	Yu	Chuo	Huan	Zhi	Zheng	Ci	Bu	Wu	Qi	Bu	Bu	Wai	Ju	Qian	Chi	Se	Chi	Se	Zhong	Sui	Sui	Li	Ze	Yu	Li	Gui	Dai	E	Si	Jian	Zhe	Mo	Mo	Yao	Mo	Cu	Yang	Tian	Sheng	Dai	Shang	Xu	Xun	Shu	Can	Jue	Piao	Qia	Qiu	Su	Qing	Yun	Lian	Yi	Fou	Zhi	Ye	Can	Hun	Dan	Ji	Die	Zhen	Yun	Wen	Chou	Bin	Ti	Jin	Shang	Yin	Diao	Jiu	Hui	Cuan	Yi	Dan	Du	Jiang	Lian	Bin	Du	Jian	Jian	Shu	Ou	Duan	Zhu	Yin	Qing	Yi	Sha	Qiao	Ke	Xiao	Xun	Dian	Hui	Hui	Gu	Qiao	Ji	Yi	Ou	Hui	Duan	Yi	Xiao	Wu	Guan	Mu	Mei	Mei	Ai	Jie	Du	Yu	Bi	Bi	Bi	Pi	Pi	Bi	Chan	Mao	Hao	Cai	Pi	Lie	Jia	Zhan	Sai	Mu	Tuo	Xun	Er	Rong	Xian	Ju	Mu	Hao	Qiu	Dou	Sha	Tan	Pei	Ju	Duo	Cui	Bi	San	San	Mao	Sai	Shu	Shu	Tuo	He	Jian	Ta	San";
    case 108:
      return "Lu	Mu	Mao	Tong	Rong	Chang	Pu	Lu	Zhan	Sao	Zhan	Meng	Lu	Qu	Die	Shi	Di	Min	Jue	Mang	Qi	Pie	Nai	Qi	Dao	Xian	Chuan	Fen	Yang	Nei	Bin	Fu	Shen	Dong	Qing	Qi	Yin	Xi	Hai	Yang	An	Ya	Ke	Qing	Ya	Dong	Dan	Lu	Qing	Yang	Yun	Yun	Shui	Shui	Zheng	Bing	Yong	Dang	Shui	Le	Ni	Tun	Fan	Jiu	Ting	Zhi	Qiu	Bin	Ze	Mian	Cuan	Hui	Diao	Han	Cha	Zhuo	Chuan	Wan	Fan	Da	Xi	Tuo	Mang	Qiu	Qi	Shan	Pin	Han	Qian	Wu	Wu	Xun	Si	Ru	Gong	Jiang	Chi	Wu	Tu	Jiu	Tang	Zhi	Zhi	Qian	Mi	Gu	Wang	Jing	Jing	Rui	Jun	Hong	Tai	Quan	Ji	Bian	Bian	Gan	Wen	Zhong	Fang	Xiong	Jue	Hu	Niu	Qi	Fen	Xu	Xu	Qin	Yi	Wo	Yun	Yuan	Hang	Yan	Shen	Chen	Dan	You	Dun	Hu	Huo	Qi	Mu	Nu	Mei	Da	Mian	Mi	Chong	Pang	Bi	Sha	Zhi	Pei	Pan	Zhui	Za	Gou	Liu	Mei	Ze	Feng	Ou	Li	Lun	Cang	Feng	Wei	Hu	Mo	Mei	Shu	Ju	Za	Tuo	Tuo	Tuo	He	Li	Mi	Yi	Fa	Fei	You	Tian	Zhi	Zhao	Gu	Zhan	Yan	Si	Kuang	Jiong	Ju	Xie	Qiu	Yi	Jia	Zhong	Quan	Po	Hui	Mi	Ben	Ze	Zhu	Le	You	Gu	Hong	Gan	Fa	Mao	Si	Hu	Ping	Ci	Fan	Zhi	Su	Ning	Cheng	Ling	Pao	Bo	Qi	Si	Ni	Ju	Sa	Zhu	Sheng	Lei	Xuan	Jue	Fu	Pan	Min	Tai	Yang	Ji	Yong	Guan	Beng	Xue	Long	Lu	Dan	Luo	Xie	Po	Ze	Jing	Yin";
    case 109:
      return "Pan	Jie	Ye	Hui	Hui	Zai	Cheng	Yin	Wei	Hou	Jian	Yang	Lie	Si	Ji	Er	Xing	Fu	Sa	Qi	Zhi	Yin	Wu	Xi	Kao	Zhu	Jiang	Luo	Luo	An	Dong	Ti	Mou	Lei	Yi	Mi	Quan	Jin	Po	Wei	Xiao	Xie	Hong	Xu	Su	Kuang	Tao	Qie	Ju	Er	Zhou	Ru	Ping	Xun	Xiong	Zhi	Guang	Huan	Ming	Huo	Wa	Qia	Pai	Wu	Qu	Liu	Yi	Jia	Jing	Qian	Jiang	Jiao	Zhen	Shi	Zhuo	Ce	Fa	Hui	Ji	Liu	Chan	Hun	Hu	Nong	Xun	Jin	Lie	Qiu	Wei	Zhe	Jun	Han	Bang	Mang	Zhuo	You	Xi	Bo	Dou	Huan	Hong	Yi	Pu	Ying	Lan	Hao	Lang	Han	Li	Geng	Fu	Wu	Lian	Chun	Feng	Yi	Yu	Tong	Lao	Hai	Jin	Jia	Chong	Jiong	Mei	Sui	Cheng	Pei	Xian	Shen	Tu	Kun	Ping	Nie	Han	Jing	Xiao	She	Nian	Tu	Yong	Xiao	Xian	Ting	E	Su	Tun	Juan	Cen	Ti	Li	Shui	Si	Lei	Shui	Tao	Du	Lao	Lai	Lian	Wei	Wo	Yun	Huan	Di	Heng	Run	Jian	Zhang	Se	Fu	Guan	Xing	Shou	Shuan	Ya	Chuo	Zhang	Ye	Kong	Wo	Han	Tuo	Dong	He	Wo	Ju	She	Liang	Hun	Ta	Zhuo	Dian	Qie	De	Juan	Zi	Xi	Xiao	Qi	Gu	Guo	Yan	Lin	Tang	Zhou	Peng	Hao	Chang	Shu	Qi	Fang	Zhi	Lu	Nao	Ju	Tao	Cong	Lei	Zhe	Peng	Fei	Song	Tian	Pi	Dan	Yu	Ni	Yu	Lu	Gan	Mi	Jing	Ling	Lun	Yin	Cui	Qu	Huai	Yu	Nian	Shen	Biao	Chun	Hu	Yuan	Lai	Hun	Qing	Yan	Qian	Tian	Miao	Zhi	Yin	Bo";
    case 110:
      return "Ben	Yuan	Wen	Ruo	Fei	Qing	Yuan	Ke	Ji	She	Yuan	Se	Lu	Zi	Du	Yi	Jian	Mian	Pai	Xi	Yu	Yuan	Shen	Shen	Rou	Huan	Zhu	Jian	Nuan	Yu	Qiu	Ting	Qu	Du	Fan	Zha	Bo	Wo	Wo	Di	Wei	Wen	Ru	Xie	Ce	Wei	He	Gang	Yan	Hong	Xuan	Mi	Ke	Mao	Ying	Yan	You	Hong	Miao	Sheng	Mei	Zai	Hun	Nai	Gui	Chi	E	Pai	Mei	Lian	Qi	Qi	Mei	Tian	Cou	Wei	Can	Tuan	Mian	Hui	Mo	Xu	Ji	Pen	Jian	Jian	Hu	Feng	Xiang	Yi	Yin	Zhan	Shi	Jie	Cheng	Huang	Tan	Yu	Bi	Min	Shi	Tu	Sheng	Yong	Ju	Dong	Tuan	Jiao	Jiao	Qiu	Yan	Tang	Long	Huo	Yuan	Nan	Ban	You	Quan	Zhuang	Liang	Chan	Xian	Chun	Nie	Zi	Wan	Shi	Man	Ying	La	Kui	Feng	Jian	Xu	Lou	Wei	Gai	Bo	Ying	Po	Jin	Yan	Tang	Yuan	Suo	Yuan	Lian	Yao	Meng	Zhun	Cheng	Ke	Tai	Da	Wa	Liu	Gou	Sao	Ming	Zha	Shi	Yi	Lun	Ma	Pu	Wei	Li	Zai	Wu	Xi	Wen	Qiang	Ze	Shi	Su	Ai	Qin	Sou	Yun	Xiu	Yin	Rong	Hun	Su	Suo	Ni	Ta	Shi	Ru	Ai	Pan	Chu	Chu	Pang	Weng	Cang	Mie	Ge	Dian	Hao	Huang	Xi	Zi	Di	Zhi	Xing	Fu	Jie	Hua	Ge	Zi	Tao	Teng	Sui	Bi	Jiao	Hui	Gun	Yin	Gao	Long	Zhi	Yan	She	Man	Ying	Chun	Lu	Lan	Luan	Yao	Bin	Tan	Yu	Xiu	Hu	Bi	Biao	Zhi	Jiang	Kou	Shen	Shang	Di	Mi	Ao	Lu	Hu	Hu	You	Chan	Fan	Yong	Gun	Man";
    case 111:
      return "Qing	Yu	Piao	Ji	Ya	Chao	Qi	Xi	Ji	Lu	Lou	Long	Jin	Guo	Cong	Lou	Zhi	Gai	Qiang	Li	Yan	Cao	Jiao	Cong	Chun	Tuan	Ou	Teng	Ye	Xi	Mi	Tang	Mo	Shang	Han	Lian	Lan	Wa	Chi	Gan	Feng	Xuan	Yi	Man	Zi	Mang	Kang	Luo	Peng	Shu	Zhang	Zhang	Chong	Xu	Huan	Huo	Jian	Yan	Shuang	Liao	Cui	Ti	Yang	Jiang	Cong	Ying	Hong	Xiu	Shu	Guan	Ying	Xiao	Zong	Kun	Xu	Lian	Zhi	Wei	Pi	Yu	Jiao	Po	Dang	Hui	Jie	Wu	Pa	Ji	Pan	Wei	Su	Qian	Qian	Xi	Lu	Xi	Xun	Dun	Huang	Min	Run	Su	Liao	Zhen	Cong	Yi	Zhe	Wan	Shan	Tan	Chao	Xun	Kui	Ye	Shao	Tu	Zhu	Sa	Hei	Bi	Shan	Chan	Chan	Shu	Tong	Pu	Lin	Wei	Se	Se	Cheng	Jiong	Cheng	Hua	Jiao	Lao	Che	Gan	Cun	Hong	Si	Shu	Peng	Han	Yun	Liu	Hong	Fu	Hao	He	Xian	Jian	Shan	Xi	Yu	Lu	Lan	Ning	Yu	Lin	Mian	Zao	Dang	Huan	Ze	Xie	Yu	Li	Shi	Xue	Ling	Wan	Zi	Yong	Hui	Can	Lian	Dian	Ye	Ao	Huan	Zhen	Chan	Man	Dan	Dan	Yi	Sui	Pi	Ju	Ta	Qin	Ji	Zhuo	Lian	Nong	Guo	Jin	Fen	Se	Ji	Sui	Hui	Chu	Ta	Song	Ding	Se	Zhu	Lai	Bin	Lian	Mi	Shi	Shu	Mi	Ning	Ying	Ying	Meng	Jin	Qi	Bi	Ji	Hao	Ru	Cui	Wo	Tao	Yin	Yin	Dui	Ci	Huo	Qing	Lan	Jun	Ai	Pu	Zhuo	Wei	Bin	Gu	Qian	Ying	Bin	Kuo	Fei	Cang	Me	Jian	Wei	Luo	Zan	Lu	Li";
    case 112:
      return "You	Yang	Lu	Si	Zhi	Ying	Du	Wang	Hui	Xie	Pan	Shen	Biao	Chan	Mo	Liu	Jian	Pu	Se	Cheng	Gu	Bin	Huo	Xian	Lu	Qin	Han	Ying	Rong	Li	Jing	Xiao	Ying	Sui	Wei	Xie	Huai	Xue	Zhu	Long	Lai	Dui	Fan	Hu	Lai	Shu	Ling	Ying	Mi	Ji	Lian	Jian	Ying	Fen	Lin	Yi	Jian	Yue	Chan	Dai	Rang	Jian	Lan	Fan	Shuang	Yuan	Zhuo	Feng	She	Lei	Lan	Cong	Qu	Yong	Qian	Fa	Guan	Jue	Yan	Hao	Ying	Sa	Zan	Luan	Yan	Li	Mi	Shan	Tan	Dang	Jiao	Chan	Ying	Hao	Ba	Zhu	Lan	Lan	Nang	Wan	Luan	Xun	Xian	Yan	Gan	Yan	Yu	Huo	Biao	Mie	Guang	Deng	Hui	Xiao	Xiao	Hui	Hong	Ling	Zao	Zhuan	Jiu	Zha	Xie	Chi	Zhuo	Zai	Zai	Can	Yang	Qi	Zhong	Fen	Niu	Jiong	Wen	Pu	Yi	Lu	Chui	Pi	Kai	Pan	Yan	Kai	Pang	Mu	Chao	Liao	Que	Kang	Dun	Guang	Xin	Zhi	Guang	Guang	Wei	Qiang	Bian	Da	Xia	Zheng	Zhu	Ke	Zhao	Fu	Ba	Xie	Xie	Ling	Zhuo	Xuan	Ju	Tan	Pao	Jiong	Pao	Tai	Tai	Bing	Yang	Tong	Shan	Zhu	Zha	Dian	Wei	Shi	Lian	Chi	Huang	Zhou	Hu	Shuo	Lan	Ting	Jiao	Xu	Heng	Quan	Lie	Huan	Yang	Xiu	Xiu	Xian	Yin	Wu	Zhou	Yao	Shi	Wei	Tong	Mie	Zai	Kai	Hong	Lao	Xia	Zhu	Xuan	Zheng	Po	Yan	Hui	Guang	Che	Hui	Kao	Ju	Fan	Shao	Ye	Hui	Gwaan	Tang	Jin	Re	Lie	Xi	Fu	Jiong	Xie	Pu	Ting	Zhuo	Ting	Wan	Hai	Peng	Lang	Yan	Xu	Feng	Chi	Rong";
    case 113:
      return "Hu	Xi	Shu	He	Xun	Ku	Juan	Xiao	Xi	Yan	Han	Zhuang	Jun	Di	Xie	Ji	Wu	Yan	Lu	Han	Yan	Huan	Men	Ju	Tao	Bei	Fen	Lin	Kun	Hun	Tun	Xi	Cui	Wu	Hong	Chao	Fu	Wo	Jiao	Cong	Feng	Ping	Qiong	Ruo	Xi	Qiong	Xin	Chao	Yan	Yan	Yi	Jue	Yu	Gang	Ran	Pi	Xiong	Gang	Sheng	Chang	Shao	Xiong	Nian	Geng	Wei	Chen	He	Kui	Zhong	Duan	Xia	Hui	Feng	Lian	Xuan	Xing	Huang	Jiao	Jian	Bi	Ying	Zhu	Wei	Tuan	Shan	Xi	Nuan	Nuan	Chan	Yan	Jiong	Jiong	Yu	Mei	Sha	Wei	Zha	Jin	Qiong	Rou	Mei	Huan	Xu	Zhao	Wei	Fan	Qiu	Sui	Yang	Lie	Zhu	Jie	Zao	Gua	Bao	Hu	Yun	Nan	Shi	Liang	Bian	Gou	Tui	Tang	Chao	Shan	En	Bo	Huang	Xie	Xi	Wu	Xi	Yun	He	He	Xi	Yun	Xiong	Nai	Shan	Qiong	Yao	Xun	Mi	Lian	Ying	Wu	Rong	Gong	Yan	Qiang	Liu	Xi	Bi	Biao	Cong	Lu	Jian	Shu	Yi	Lou	Peng	Sui	Yi	Teng	Jue	Zong	Yun	Hu	Yi	Zhi	Ao	Wei	Liu	Han	Ou	Re	Jiong	Man	Kun	Shang	Cuan	Zeng	Jian	Xi	Xi	Xi	Yi	Xiao	Chi	Huang	Chan	Ye	Tan	Ran	Yan	Xun	Qiao	Jun	Deng	Dun	Shen	Jiao	Fen	Si	Liao	Yu	Lin	Tong	Shao	Fen	Fan	Yan	Xun	Lan	Mei	Tang	Yi	Jiong	Men	Jing	Jiao	Ying	Yu	Yi	Xue	Lan	Tai	Zao	Can	Sui	Xi	Que	Zong	Lian	Hui	Zhu	Xie	Ling	Wei	Yi	Xie	Zhao	Hui	Da	Nong	Lan	Ru	Xian	He	Xun	Jin	Chou	Dao	Yao";
    case 114:
      return "He	Lan	Biao	Rong	Li	Mo	Bao	Ruo	Lu	La	Ao	Xun	Kuang	Shuo	Liao	Li	Lu	Jue	Liao	Yan	Xi	Xie	Long	Ye	Can	Rang	Yue	Lan	Cong	Jue	Chong	Guan	Ju	Che	Mi	Tang	Lan	Zhu	Lan	Ling	Cuan	Yu	Zhao	Zhao	Pa	Zheng	Pao	Cheng	Yuan	Ai	Wei	Han	Jue	Jue	Fu	Ye	Ba	Die	Ye	Yao	Zu	Shuang	Er	Pan	Chuang	Ke	Zang	Die	Qiang	Yong	Qiang	Pian	Ban	Pan	Chao	Jian	Pai	Du	Chuang	Yu	Zha	Bian	Die	Bang	Bo	Chuang	You	You	Du	Ya	Cheng	Niu	Niu	Pin	Jiu	Mou	Ta	Mu	Lao	Ren	Mang	Fang	Mao	Mu	Gang	Wu	Yan	Ge	Bei	Si	Jian	Gu	You	Ge	Sheng	Mu	Di	Qian	Quan	Quan	Zi	Te	Xi	Mang	Keng	Qian	Wu	Gu	Xi	Li	Li	Pou	Ji	Gang	Zhi	Ben	Quan	Chun	Du	Ju	Jia	Jian	Feng	Pian	Ke	Ju	Kao	Chu	Xi	Bei	Luo	Jie	Ma	San	Wei	Mao	Dun	Tong	Qiao	Jiang	Xi	Li	Du	Lie	Pai	Piao	Bo	Xi	Chou	Wei	Kui	Chou	Quan	Quan	Ba	Fan	Qiu	Ji	Chai	Zhuo	An	Ge	Zhuang	Guang	Ma	You	Kang	Bo	Hou	Ya	Yin	Huan	Zhuang	Yun	Kuang	Niu	Di	Kuang	Zhong	Mu	Bei	Pi	Ju	Yi	Sheng	Pao	Xia	Tuo	Hu	Ling	Fei	Pi	Ni	Yao	You	Gou	Xue	Ju	Dan	Bo	Ku	Xian	Ning	Huan	Hen	Jiao	He	Zhao	Ji	Xun	Shan	Ta	Rong	Shou	Tong	Lao	Du	Xia	Shi	Kuai	Zheng	Yu	Sun	Yu	Bi	Mang	Xi	Juan	Li	Xia	Yin	Suan	Lang	Bei	Zhi	Yan";
    case 115:
      return "Sha	Li	Han	Xian	Jing	Pai	Fei	Xiao	Bai	Qi	Ni	Biao	Yin	Lai	Lie	Jian	Qiang	Kun	Yan	Guo	Zong	Mi	Chang	Yi	Zhi	Zheng	Ya	Meng	Cai	Cu	She	Lie	Dian	Luo	Hu	Zong	Gui	Wei	Feng	Wo	Yuan	Xing	Zhu	Mao	Wei	Chuan	Xian	Tuan	Ya	Nao	Xie	Jia	Hou	Bian	You	You	Mei	Cha	Yao	Sun	Bo	Ming	Hua	Yuan	Sou	Ma	Yuan	Dai	Yu	Shi	Hao	Qiang	Yi	Zhen	Cang	Hao	Man	Jing	Jiang	Mo	Zhang	Chan	Ao	Ao	Hao	Cui	Ben	Jue	Bi	Bi	Huang	Pu	Lin	Xu	Tong	Yao	Liao	Shuo	Xiao	Shou	Dun	Jiao	Ge	Juan	Du	Hui	Kuai	Xian	Xie	Ta	Xian	Xun	Ning	Bian	Huo	Nou	Meng	Lie	Nao	Guang	Shou	Lu	Ta	Xian	Mi	Rang	Huan	Nao	Luo	Xian	Qi	Jue	Xuan	Miao	Zi	Lu	Lu	Yu	Su	Wang	Qiu	Ga	Ding	Le	Ba	Ji	Hong	Di	Chuan	Gan	Jiu	Yu	Qi	Yu	Yang	Ma	Hong	Wu	Fu	Wen	Jie	Ya	Bin	Bian	Bang	Yue	Jue	Men	Jue	Wan	Jian	Mei	Dan	Pin	Wei	Huan	Xian	Qiang	Ling	Dai	Yi	An	Ping	Dian	Fu	Xuan	Xi	Bo	Ci	Gou	Jia	Shao	Po	Ci	Ke	Ran	Sheng	Shen	Yi	Zu	Jia	Min	Shan	Liu	Bi	Zhen	Zhen	Jue	Fa	Long	Jin	Jiao	Jian	Li	Guang	Xian	Zhou	Gong	Yan	Xiu	Yang	Xu	Luo	Su	Zhu	Qin	Yin	Xun	Bao	Er	Xiang	Yao	Xia	Heng	Gui	Chong	Xu	Ban	Pei	Lao	Dang	Ying	Hun	Wen	E	Cheng	Di	Wu	Wu	Cheng	Jun	Mei	Bei	Ting	Xian	Chu";
    case 116:
      return "Han	Xuan	Yan	Qiu	Xuan	Lang	Li	Xiu	Fu	Liu	Ya	Xi	Ling	Li	Jin	Lian	Suo	Suo	Feng	Wan	Dian	Pin	Zhan	Se	Min	Yu	Ju	Chen	Lai	Min	Sheng	Wei	Tian	Chu	Zuo	Beng	Cheng	Hu	Qi	E	Kun	Chang	Qi	Beng	Wan	Lu	Cong	Guan	Yan	Diao	Bei	Lin	Qin	Pi	Pa	Que	Zhuo	Qin	Fa	Jin	Qiong	Du	Jie	Hun	Yu	Mao	Mei	Chun	Xuan	Ti	Xing	Dai	Rou	Min	Jian	Wei	Ruan	Huan	Xie	Chuan	Jian	Zhuan	Chang	Lian	Quan	Xia	Duan	Yuan	Ya	Nao	Hu	Ying	Yu	Huang	Rui	Se	Liu	Shi	Rong	Suo	Yao	Wen	Wu	Zhen	Jin	Ying	Ma	Tao	Liu	Tang	Li	Lang	Gui	Tian	Qiang	Cuo	Jue	Zhao	Yao	Ai	Bin	Shu	Chang	Kun	Zhuan	Cong	Jin	Yi	Cui	Cong	Qi	Li	Jing	Suo	Qiu	Xuan	Ao	Lian	Men	Zhang	Yin	Ye	Ying	Wei	Lu	Wu	Deng	Xiu	Zeng	Xun	Qu	Dang	Lin	Liao	Qiong	Su	Huang	Gui	Pu	Jing	Fan	Jin	Liu	Ji	Hui	Jing	Ai	Bi	Can	Qu	Zao	Dang	Jiao	Gun	Tan	Hui	Huan	Se	Sui	Tian	Chu	Yu	Jin	Lu	Bin	Shu	Wen	Zui	Lan	Xi	Zi	Xuan	Ruan	Wo	Gai	Lei	Du	Li	Zhi	Rou	Li	Zan	Qiong	Ti	Gui	Sui	La	Long	Lu	Li	Zan	Lan	Ying	Mi	Xiang	Qiong	Guan	Dao	Zan	Huan	Gua	Bo	Die	Bo	Hu	Zhi	Piao	Ban	Rang	Li	Wa	Sap	Xiang	Qian	Ban	Pen	Fang	Dan	Weng	Ou	Fan	Hou	Wa	Hu	Ling	Yi	Ping	Ci	Bai	Juan	Chang	Chi	Lei	Dang	Meng	Bu";
    case 117:
      return "Zhui	Ping	Bian	Zhou	Zhen	Lei	Ci	Ying	Qi	Xian	Lou	Di	Ou	Meng	Zhuan	Beng	Lin	Zeng	Wu	Pi	Dan	Weng	Ying	Yan	Gan	Dai	Shen	Tian	Tian	Han	Chang	Sheng	Qing	Shen	Chan	Chan	Rui	Sheng	Su	Shen	Yong	Shuai	Lu	Fu	Yong	Beng	Feng	Ning	Tian	You	Jia	Shen	Zha	Dian	Fu	Nan	Dian	Ping	Ting	Hua	Ting	Zhen	Zai	Meng	Bi	Bi	Liu	Xun	Liu	Chang	Mu	Yun	Fan	Fu	Geng	Tian	Jie	Jie	Quan	Wei	Fu	Tian	Mu	Duo	Pan	Jiang	Wa	Da	Nan	Liu	Ben	Zhen	Chu	Mu	Mu	Ce	Tian	Gai	Bi	Da	Zhi	Lue	Qi	Lue	Pan	Yi	Fan	Hua	She	Yu	Mu	Jun	Yi	Liu	She	Die	Chou	Hua	Dang	Zhui	Ji	Wan	Jiang	Cheng	Chang	Tun	Lei	Ji	Cha	Liu	Die	Tuan	Lin	Jiang	Jiang	Chou	Pi	Die	Die	Pi	Jie	Dan	Shu	Shu	Zhi	Yi	Ne	Nai	Ding	Bi	Jie	Liao	Gang	Ge	Jiu	Zhou	Xia	Shan	Xu	Nue	Li	Yang	Chen	You	Ba	Jie	Jue	Qi	Xia	Cui	Bi	Yi	Li	Zong	Chuang	Feng	Zhu	Pao	Pi	Gan	Ke	Ci	Xue	Zhi	Dan	Zhen	Fa	Zhi	Teng	Ju	Ji	Fei	Ju	Shan	Jia	Xuan	Zha	Bing	Nie	Zheng	Yong	Jing	Quan	Teng	Tong	Yi	Jie	Wei	Hui	Tan	Yang	Chi	Zhi	Hen	Ya	Mei	Dou	Jing	Xiao	Tong	Tu	Mang	Pi	Xiao	Suan	Fu	Li	Zhi	Cuo	Duo	Wu	Sha	Lao	Shou	Huan	Xian	Yi	Beng	Zhang	Guan	Tan	Fei	Ma	Lin	Chi	Ji	Tian	An	Chi	Bi	Bi	Min	Gu	Dui	E	Wei";
    case 118:
      return "Yu	Cui	Ya	Zhu	Cu	Dan	Shen	Zhong	Chi	Yu	Hou	Feng	La	Yang	Chen	Tu	Yu	Guo	Wen	Huan	Ku	Jia	Yin	Yi	Lou	Sao	Jue	Chi	Xi	Guan	Yi	Wen	Ji	Chuang	Ban	Hui	Liu	Chai	Shou	Nue	Dian	Da	Bie	Tan	Zhang	Biao	Shen	Cu	Luo	Yi	Zong	Chou	Zhang	Zhai	Sou	Se	Que	Diao	Lou	Lou	Mo	Qin	Yin	Ying	Huang	Fu	Liao	Long	Qiao	Liu	Lao	Xian	Fei	Dan	Yin	He	Ai	Ban	Xian	Guan	Gui	Nong	Yu	Wei	Yi	Yong	Pi	Lei	Li	Shu	Dan	Lin	Dian	Lin	Lai	Bie	Ji	Chi	Yang	Xuan	Jie	Zheng	Me	Li	Huo	Lai	Ji	Dian	Xuan	Ying	Yin	Qu	Yong	Tan	Dian	Luo	Luan	Luan	Bo	Bo	Gui	Ba	Fa	Deng	Fa	Bai	Bai	Bie	Ji	Zao	Zao	Mao	De	Pa	Jie	Huang	Gui	Ci	Ling	Gao	Mo	Ji	Jiao	Peng	Gao	Ai	E	Hao	Han	Bi	Wan	Chou	Qian	Xi	Ai	Xiao	Hao	Huang	Hao	Ze	Cui	Hao	Xiao	Ye	Po	Hao	Jiao	Ai	Xing	Huang	Li	Piao	He	Jiao	Pi	Gan	Pao	Zhou	Jun	Qiu	Cun	Que	Zha	Gu	Jun	Jun	Zhou	Zha	Gu	Zhao	Du	Min	Qi	Ying	Yu	Bei	Zhao	Zhong	Pen	He	Ying	He	Yi	Bo	Wan	He	Ang	Zhan	Yan	Jian	He	Yu	Kui	Fan	Gai	Dao	Pan	Fu	Qiu	Sheng	Dao	Lu	Zhan	Meng	Li	Jin	Xu	Jian	Pan	Guan	An	Lu	Xu	Zhou	Dang	An	Gu	Li	Mu	Ding	Gan	Xu	Mang	Wang	Zhi	Qi	Yuan	Tian	Xiang	Dun	Xin	Xi	Pan	Feng	Dun	Min";
    case 119:
      return "Ming	Sheng	Shi	Yun	Mian	Pan	Fang	Miao	Dan	Mei	Mao	Kan	Xian	Kou	Shi	Yang	Zheng	Yao	Shen	Huo	Da	Zhen	Kuang	Ju	Shen	Yi	Sheng	Mei	Mo	Zhu	Zhen	Zhen	Mian	Shi	Yuan	Die	Ni	Zi	Zi	Chao	Zha	Xuan	Bing	Mi	Long	Sui	Tong	Mi	Die	Di	Ne	Ming	Xuan	Chi	Kuang	Juan	Mou	Zhen	Tiao	Yang	Yan	Mo	Zhong	Mo	Zhe	Zheng	Mei	Suo	Shao	Han	Huan	Di	Cheng	Cuo	Juan	E	Man	Xian	Xi	Kun	Lai	Jian	Shan	Tian	Gun	Wan	Leng	Shi	Qiong	Lie	Ya	Jing	Zheng	Li	Lai	Sui	Juan	Shui	Sui	Du	Bi	Pi	Mu	Hun	Ni	Lu	Yi	Jie	Cai	Zhou	Yu	Hun	Ma	Xia	Xing	Hui	Gun	Zai	Chun	Jian	Mei	Du	Hou	Xuan	Tian	Kui	Gao	Rui	Mao	Xu	Fa	Wo	Miao	Chou	Kui	Mi	Weng	Kou	Dang	Chen	Ke	Sou	Xia	Qiong	Mo	Ming	Man	Fen	Ze	Zhang	Yi	Diao	Kou	Mo	Shun	Cong	Lou	Chi	Man	Piao	Cheng	Gui	Meng	Wan	Run	Pie	Xi	Qiao	Pu	Zhu	Deng	Shen	Shun	Liao	Che	Xian	Kan	Ye	Xu	Tong	Mou	Lin	Gui	Jian	Ye	Ai	Hui	Zhan	Jian	Gu	Zhao	Qu	Mei	Chou	Sao	Ning	Xun	Yao	Huo	Meng	Mian	Pin	Mian	Lei	Kuang	Jue	Xuan	Mian	Huo	Lu	Meng	Long	Guan	Man	Xi	Chu	Tang	Kan	Zhu	Mao	Jin	Jin	Yu	Shuo	Ze	Jue	Shi	Yi	Shen	Zhi	Hou	Shen	Ying	Ju	Zhou	Jiao	Cuo	Duan	Ai	Jiao	Zeng	Yue	Ba	Shi	Ding	Qi	Ji	Zi	Gan	Wu	Zhe	Ku	Gang	Xi	Fan	Kuang";
    case 120:
      return "Dang	Ma	Sha	Dan	Jue	Li	Fu	Min	E	Hua	Kang	Zhi	Qi	Kan	Jie	Bin	E	Ya	Pi	Zhe	Yan	Sui	Zhuan	Che	Dun	Wa	Yan	Jin	Feng	Fa	Mo	Zha	Ju	Yu	Ke	Tuo	Tuo	Di	Zhai	Zhen	E	Fu	Mu	Zhu	La	Bian	Nu	Ping	Peng	Ling	Pao	Le	Po	Bo	Po	Shen	Za	Ai	Li	Long	Tong	Yong	Li	Kuang	Chu	Keng	Quan	Zhu	Kuang	Gui	E	Nao	Qia	Lu	Hui	Ai	Ge	Yin	Xing	Yan	Dong	Peng	Xi	Lao	Hong	Shuo	Xia	Qiao	Qing	Wei	Qiao	Yi	Keng	Xiao	Que	Chan	Lang	Hong	Yu	Xiao	Xia	Mang	Luo	Yong	Che	Che	Wo	Liu	Ying	Mang	Que	Yan	Sha	Kun	Yu	Chi	Hua	Lu	Chen	Jian	Nue	Song	Zhuo	Keng	Peng	Yan	Zhui	Kong	Cheng	Qi	Zong	Qing	Lin	Jun	Bo	Ding	Hun	Diao	Jian	He	Lu	Ai	Sui	Que	Leng	Bei	Yin	Dui	Wu	Qi	Lun	Wan	Dian	Nao	Bei	Qi	Chen	Ruan	Yan	Die	Ding	Zhou	Tuo	Jie	Ying	Bian	Ke	Bi	Wei	Shuo	Zhen	Duan	Xia	Dang	Ti	Nao	Peng	Jian	Di	Tan	Cha	Tian	Qi	Dun	Feng	Xuan	Que	Que	Ma	Gong	Nian	Su	E	Ci	Liu	Si	Tang	Bang	Hua	Pi	Wei	Sang	Lei	Cuo	Tian	Xia	Xi	Lian	Pan	Wei	Yun	Dui	Zhe	Ke	La	Zhuan	Yao	Gun	Zhuan	Chan	Qi	Ao	Peng	Liu	Lu	Kan	Chuang	Chen	Yin	Lei	Biao	Qi	Mo	Qi	Cui	Zong	Qing	Chuo	Lun	Ji	Shan	Lao	Qu	Zeng	Deng	Jian	Xi	Lin	Ding	Tan	Huang	Pan	Za	Qiao	Di	Li";
    case 121:
      return "Jian	Jiao	Xi	Zhang	Qiao	Dun	Jian	Yu	Zhui	He	Ke	Ze	Lei	Jie	Chu	Ye	Que	Dang	Yi	Jiang	Pi	Pi	Yu	Pin	E	Ai	Ke	Jian	Yu	Ruan	Meng	Pao	Ci	Bo	Yang	Ma	Ca	Xian	Kuang	Lei	Lei	Zhi	Li	Li	Fan	Que	Pao	Ying	Li	Long	Long	Mo	Bo	Shuang	Guan	Lan	Ca	Yan	Shi	Shi	Li	Reng	She	Yue	Si	Qi	Ta	Ma	Xie	Yao	Xian	Qi	Qi	Zhi	Beng	Dui	Zhong	Ren	Yi	Shi	You	Zhi	Tiao	Fu	Fu	Mi	Zu	Zhi	Suan	Mei	Zuo	Qu	Hu	Zhu	Shen	Sui	Ci	Chai	Mi	Lu	Yu	Xiang	Wu	Tiao	Piao	Zhu	Gui	Xia	Zhi	Ji	Gao	Zhen	Gao	Shui	Jin	Shen	Gai	Kun	Di	Dao	Huo	Tao	Qi	Gu	Guan	Zui	Ling	Lu	Bing	Jin	Dao	Zhi	Lu	Chan	Bi	Zhe	Hui	You	Xi	Yin	Zi	Huo	Zhen	Fu	Yuan	Wu	Xian	Yang	Zhi	Yi	Mei	Si	Di	Bei	Zhuo	Zhen	Yong	Ji	Gao	Tang	Si	Ma	Ta	Fu	Xuan	Qi	Yu	Xi	Ji	Si	Chan	Dan	Gui	Sui	Li	Nong	Mi	Dao	Li	Rang	Yue	Ti	Zan	Lei	Rou	Yu	Yu	Li	Xie	Qin	He	Tu	Xiu	Si	Ren	Tu	Zi	Cha	Gan	Yi	Xian	Bing	Nian	Qiu	Qiu	Zhong	Fen	Hao	Yun	Ke	Miao	Zhi	Jing	Bi	Zhi	Yu	Mi	Ku	Ban	Pi	Ni	Li	You	Zu	Pi	Bo	Ling	Mo	Cheng	Nian	Qin	Yang	Zuo	Zhi	Zhi	Shu	Ju	Zi	Huo	Ji	Cheng	Tong	Zhi	Huo	He	Yin	Zi	Zhi	Jie	Ren	Du	Yi	Zhu	Hui	Nong	Fu";
    case 122:
      return "Xi	Gao	Lang	Fu	Xun	Shui	Lu	Kun	Gan	Jing	Ti	Cheng	Tu	Shao	Shui	Ya	Lun	Lu	Gu	Zuo	Ren	Zhun	Bang	Bai	Ji	Zhi	Zhi	Kun	Leng	Peng	Ke	Bing	Chou	Zui	Yu	Su	Lue	Xiang	Yi	Xi	Bian	Ji	Fu	Pi	Nuo	Jie	Zhong	Zong	Xu	Cheng	Dao	Wen	Xian	Zi	Yu	Ji	Xu	Zhen	Zhi	Dao	Jia	Ji	Gao	Gao	Gu	Rong	Sui	Rong	Ji	Kang	Mu	Can	Mei	Zhi	Ji	Lu	Su	Ji	Ying	Wen	Qiu	Se	He	Yi	Huang	Qie	Ji	Sui	Xiao	Pu	Jiao	Zhuo	Tong	Zui	Lu	Sui	Nong	Se	Hui	Rang	Nuo	Yu	Pin	Ji	Tui	Wen	Cheng	Huo	Kuang	Lu	Biao	Se	Rang	Zhuo	Li	Cuan	Xue	Wa	Jiu	Qiong	Xi	Qiong	Kong	Yu	Shen	Jing	Yao	Chuan	Zhun	Tu	Lao	Qie	Zhai	Yao	Bian	Bao	Yao	Bing	Wa	Zhu	Jiao	Qiao	Diao	Wu	Gui	Yao	Zhi	Chuang	Yao	Tiao	Jiao	Chuang	Jiong	Xiao	Cheng	Kou	Cuan	Wo	Dan	Ku	Ke	Zhuo	Xu	Su	Guan	Kui	Dou	Zhuo	Yin	Wo	Wa	Ya	Yu	Ju	Qiong	Yao	Yao	Tiao	Chao	Yu	Tian	Diao	Ju	Liao	Xi	Wu	Kui	Chuang	Zhao	Kuan	Kuan	Long	Cheng	Cui	Liao	Zao	Cuan	Qiao	Qiong	Dou	Zao	Long	Qie	Li	Chu	Shi	Fu	Qian	Chu	Hong	Qi	Hao	Sheng	Fen	Shu	Miao	Qu	Zhan	Zhu	Ling	Long	Bing	Jing	Jing	Zhang	Bai	Si	Jun	Hong	Tong	Song	Jing	Diao	Yi	Shu	Jing	Qu	Jie	Ping	Duan	Li	Zhuan	Ceng	Deng	Cun	Wai	Jing	Kan	Jing	Zhu	Zhu	Le	Peng	Yu	Chi	Gan";
    case 123:
      return "Mang	Zhu	Wan	Du	Ji	Jiao	Ba	Suan	Ji	Qin	Zhao	Sun	Ya	Zhui	Yuan	Hu	Hang	Xiao	Cen	Bi	Bi	Jian	Yi	Dong	Shan	Sheng	Da	Di	Zhu	Na	Chi	Gu	Li	Qie	Min	Bao	Tiao	Si	Fu	Ce	Ben	Fa	Da	Zi	Di	Ling	Ze	Nu	Fu	Gou	Fan	Jia	Gan	Fan	Shi	Mao	Po	Ti	Jian	Qiong	Long	Min	Bian	Luo	Gui	Qu	Chi	Yin	Yao	Xian	Bi	Qiong	Kuo	Deng	Xiao	Jin	Quan	Sun	Ru	Fa	Kuang	Zhu	Tong	Ji	Da	Hang	Ce	Zhong	Kou	Lai	Bi	Shai	Dang	Zheng	Ce	Fu	Yun	Tu	Pa	Li	Lang	Ju	Guan	Jian	Han	Tong	Xia	Zhi	Cheng	Suan	Shi	Zhu	Zuo	Xiao	Shao	Ting	Ce	Yan	Gao	Kuai	Gan	Chou	Kuang	Gang	Yun	Ou	Qian	Xiao	Jian	Pou	Lai	Zou	Bi	Bi	Bi	Ge	Tai	Guai	Yu	Jian	Dao	Gu	Chi	Zheng	Qing	Sha	Zhou	Lu	Bo	Ji	Lin	Suan	Jun	Fu	Zha	Gu	Kong	Qian	Qian	Jun	Chui	Guan	Yuan	Ce	Zu	Bo	Ze	Qie	Tuo	Luo	Dan	Xiao	Ruo	Jian	Xuan	Bian	Sun	Xiang	Xian	Ping	Zhen	Xing	Hu	Yi	Zhu	Yue	Chun	Lu	Wu	Dong	Shuo	Ji	Jie	Huang	Xing	Mei	Fan	Chuan	Zhuan	Pian	Feng	Zhu	Huang	Qie	Hou	Qiu	Miao	Qian	Gu	Kui	Shi	Lou	Yun	He	Tang	Yue	Chou	Gao	Fei	Ruo	Zheng	Gou	Nie	Qian	Xiao	Cuan	Long	Peng	Du	Li	Bi	Zhuo	Chu	Shai	Chi	Zhu	Qiang	Long	Lan	Jian	Bu	Li	Hui	Bi	Di	Cong	Yan	Peng	Can	Zhuan	Pi	Piao	Dou	Yu	Mie	Tuan";
    case 124:
      return "Ze	Shai	Gui	Yi	Hu	Chan	Kou	Cu	Ping	Zao	Ji	Gui	Su	Lou	Ce	Lu	Nian	Suo	Cuan	Diao	Suo	Le	Duan	Zhu	Xiao	Bo	Mi	Shai	Dang	Liao	Dan	Dian	Fu	Jian	Min	Kui	Dai	Jiao	Deng	Huang	Sun	Lao	Zan	Xiao	Lu	Shi	Zan	Qi	Pai	Qi	Pai	Gan	Ju	Lu	Lu	Yan	Bo	Dang	Sai	Zhua	Gou	Qian	Lian	Bu	Zhou	Lai	Shi	Lan	Kui	Yu	Yue	Hao	Zhen	Tai	Ti	Nie	Chou	Ji	Yi	Qi	Teng	Zhuan	Zhou	Fan	Sou	Zhou	Qian	Zhuo	Teng	Lu	Lu	Jian	Tuo	Ying	Yu	Lai	Long	Qie	Lian	Lan	Qian	Yue	Zhong	Qu	Lian	Bian	Duan	Zuan	Li	Si	Luo	Ying	Yue	Zhuo	Yu	Mi	Di	Fan	Shen	Zhe	Shen	Nu	He	Lei	Xian	Zi	Ni	Cun	Zhang	Qian	Zhai	Bi	Ban	Wu	Sha	Kang	Rou	Fen	Bi	Cui	Yin	Zhe	Mi	Tai	Hu	Ba	Li	Gan	Ju	Po	Mo	Cu	Zhan	Zhou	Chi	Su	Tiao	Li	Xi	Su	Hong	Tong	Zi	Ce	Yue	Zhou	Lin	Zhuang	Bai	Lao	Fen	Er	Qu	He	Liang	Xian	Fu	Liang	Can	Jing	Li	Yue	Lu	Ju	Qi	Cui	Bai	Zhang	Lin	Zong	Jing	Guo	Hua	San	San	Tang	Bian	Rou	Mian	Hou	Xu	Zong	Hu	Jian	Zan	Ci	Li	Xie	Fu	Nuo	Bei	Gu	Xiu	Gao	Tang	Qiu	Jia	Cao	Zhuang	Tang	Mi	San	Fen	Zao	Kang	Jiang	Mo	San	San	Nuo	Xi	Liang	Jiang	Kuai	Bo	Huan	Shu	Zong	Xian	Nuo	Tuan	Nie	Li	Zuo	Di	Nie	Tiao	Lan	Mi	Si	Jiu	Xi	Gong	Zheng	Jiu	You";
    case 125:
      return "Ji	Cha	Zhou	Xun	Yue	Hong	Yu	He	Wan	Ren	Wen	Wen	Qiu	Na	Zi	Tou	Niu	Fou	Ji	Shu	Chun	Pi	Zhen	Sha	Hong	Zhi	Ji	Fen	Yun	Ren	Dan	Jin	Su	Fang	Suo	Cui	Jiu	Za	Ba	Jin	Fu	Zhi	Qi	Zi	Chou	Hong	Za	Lei	Xi	Fu	Xie	Shen	Bo	Zhu	Qu	Ling	Zhu	Shao	Gan	Yang	Fu	Tuo	Zhen	Dai	Chu	Shi	Zhong	Xian	Zu	Jiong	Ban	Qu	Mo	Shu	Zui	Kuang	Jing	Ren	Hang	Xie	Jie	Zhu	Chou	Gua	Bai	Jue	Kuang	Hu	Ci	Huan	Geng	Tao	Jie	Ku	Jiao	Quan	Gai	Luo	Xuan	Beng	Xian	Fu	Gei	Dong	Rong	Tiao	Yin	Lei	Xie	Juan	Xu	Gai	Die	Tong	Si	Jiang	Xiang	Hui	Jue	Zhi	Jian	Juan	Chi	Mian	Zhen	Lu	Cheng	Qiu	Shu	Bang	Tong	Xiao	Huan	Qin	Geng	Xiu	Ti	Tou	Xie	Hong	Xi	Fu	Ting	Sui	Dui	Kun	Fu	Jing	Hu	Zhi	Yan	Jiong	Feng	Ji	Xu	Ren	Zong	Chen	Duo	Li	Lu	Liang	Chou	Quan	Shao	Qi	Qi	Zhun	Qi	Wan	Qian	Xian	Shou	Wei	Qing	Tao	Wan	Gang	Wang	Beng	Zhui	Cai	Guo	Cui	Lun	Liu	Qi	Zhan	Bi	Chuo	Ling	Mian	Qi	Qie	Tian	Zong	Gun	Zou	Xi	Zi	Xing	Liang	Jin	Fei	Rui	Min	Yu	Zong	Fan	Lu	Xu	Ying	Shang	Qi	Xu	Xiang	Jian	Ke	Xian	Ruan	Mian	Ji	Duan	Chong	Di	Min	Miao	Yuan	Xie	Bao	Si	Qiu	Bian	Huan	Geng	Cong	Mian	Wei	Fu	Wei	Tou	Gou	Miao	Xie	Lian	Zong	Bian	Yun	Yin	Ti	Gua	Zhi	Yun	Cheng	Chan	Dai";
    case 126:
      return "Xia	Yuan	Zong	Xu	Sheng	Wei	Geng	Xuan	Ying	Jin	Yi	Zhui	Ni	Bang	Gu	Pan	Zhou	Jian	Ci	Quan	Shuang	Yun	Xia	Cui	Xi	Rong	Tao	Fu	Yun	Chen	Gao	Ru	Hu	Zai	Teng	Xian	Su	Zhen	Zong	Tao	Huang	Cai	Bi	Feng	Cu	Li	Suo	Yan	Xi	Zong	Lei	Juan	Qian	Man	Zhi	Lu	Mu	Piao	Lian	Mi	Xuan	Zong	Ji	Shan	Sui	Fan	Lu	Beng	Yi	Sao	Mou	Yao	Qiang	Hun	Xian	Ji	Sha	Xiu	Ran	Xuan	Sui	Qiao	Zeng	Zuo	Zhi	Shan	San	Lin	Yu	Fan	Liao	Chuo	Zun	Jian	Rao	Chan	Rui	Xiu	Hui	Hua	Zuan	Xi	Qiang	Yun	Da	Sheng	Hui	Xi	Se	Jian	Jiang	Huan	Zao	Cong	Xie	Jiao	Bi	Dan	Yi	Nong	Sui	Yi	Shai	Xu	Ji	Bin	Qian	Lan	Pu	Xun	Zuan	Qi	Peng	Yao	Mo	Lei	Xie	Zuan	Kuang	You	Xu	Lei	Xian	Chan	Jiao	Lu	Chan	Ying	Cai	Rang	Xian	Zui	Zuan	Luo	Li	Dao	Lan	Lei	Lian	Si	Jiu	Yu	Hong	Zhou	Xian	He	Yue	Ji	Wan	Kuang	Ji	Ren	Wei	Yun	Hong	Chun	Pi	Sha	Gang	Na	Ren	Zong	Lun	Fen	Zhi	Wen	Fang	Zhu	Zhen	Niu	Shu	Xian	Gan	Xie	Fu	Lian	Zu	Shen	Xi	Zhi	Zhong	Zhou	Ban	Fu	Chu	Shao	Yi	Jing	Dai	Bang	Rong	Jie	Ku	Rao	Die	Hang	Hui	Gei	Xuan	Jiang	Luo	Jue	Jiao	Tong	Geng	Xiao	Juan	Xiu	Xi	Sui	Tao	Ji	Ti	Ji	Xu	Ling	Ying	Xu	Qi	Fei	Chuo	Shang	Gun	Sheng	Wei	Mian	Shou	Beng	Chou	Tao	Liu	Quan	Zong	Zhan	Wan	Lu";
    case 127:
      return "Zhui	Zi	Ke	Xiang	Jian	Mian	Lan	Ti	Miao	Ji	Yun	Hui	Si	Duo	Duan	Bian	Xian	Gou	Zhui	Huan	Di	Lu	Bian	Min	Yuan	Jin	Fu	Ru	Zhen	Feng	Cui	Gao	Chan	Li	Yi	Jian	Bin	Piao	Man	Lei	Ying	Suo	Mou	Sao	Xie	Liao	Shan	Zeng	Jiang	Qian	Qiao	Huan	Jiao	Zuan	Fou	Xie	Gang	Fou	Que	Fou	Qi	Bo	Ping	Xiang	Zhao	Gang	Ying	Ying	Qing	Xia	Guan	Zun	Tan	Cheng	Qi	Weng	Ying	Lei	Tan	Lu	Guan	Wang	Wang	Gang	Wang	Han	Luo	Luo	Fu	Shen	Fa	Gu	Zhu	Ju	Mao	Gu	Min	Gang	Ba	Gua	Ti	Juan	Fu	Shen	Yan	Zhao	Zui	Gua	Zhuo	Yu	Zhi	An	Fa	Lan	Shu	Si	Pi	Ma	Liu	Ba	Fa	Li	Chao	Wei	Bi	Ji	Zeng	Chong	Liu	Ji	Juan	Mi	Zhao	Luo	Pi	Ji	Ji	Luan	Yang	Mi	Qiang	Da	Mei	Yang	You	You	Fen	Ba	Gao	Yang	Gu	Qiang	Zang	Gao	Ling	Yi	Zhu	Di	Xiu	Qiang	Yi	Xian	Rong	Qun	Qun	Qiang	Huan	Suo	Xian	Yi	Yang	Qiang	Qian	Yu	Geng	Jie	Tang	Yuan	Xi	Fan	Shan	Fen	Shan	Lian	Lei	Geng	Nou	Qiang	Chan	Yu	Gong	Yi	Chong	Weng	Fen	Hong	Chi	Chi	Cui	Fu	Xia	Ben	Yi	La	Yi	Pi	Ling	Liu	Zhi	Qu	Xi	Xie	Xiang	Xi	Xi	Ke	Qiao	Hui	Hui	Xiao	Sha	Hong	Jiang	Di	Cui	Fei	Dao	Sha	Chi	Zhu	Jian	Xuan	Chi	Pian	Zong	Wan	Hui	Hou	He	He	Han	Ao	Piao	Yi	Lian	Hou	Ao	Lin	Pen	Qiao	Ao	Fan	Yi	Hui	Xuan	Dao";
    case 128:
      return "Yao	Lao	Lao	Kao	Mao	Zhe	Qi	Gou	Gou	Gou	Die	Die	Er	Shua	Ruan	Nai	Nai	Duan	Lei	Ting	Zi	Geng	Chao	Hao	Yun	Ba	Pi	Yi	Si	Qu	Jia	Ju	Huo	Chu	Lao	Lun	Ji	Tang	Ou	Lou	Nou	Jiang	Pang	Zha	Lou	Ji	Lao	Huo	You	Mo	Huai	Er	Yi	Ding	Ye	Da	Song	Qin	Yun	Chi	Dan	Dan	Hong	Geng	Zhi	Pan	Nie	Dan	Zhen	Che	Ling	Zheng	You	Wa	Liao	Long	Zhi	Ning	Tiao	Er	Ya	Tie	Guo	Xu	Lian	Hao	Sheng	Lie	Pin	Jing	Ju	Bi	Di	Guo	Wen	Xu	Ping	Cong	Ding	Ni	Ting	Ju	Cong	Kui	Lian	Kui	Cong	Lian	Weng	Kui	Lian	Lian	Cong	Ao	Sheng	Song	Ting	Kui	Nie	Zhi	Dan	Ning	Qie	Ni	Ting	Ting	Long	Yu	Yu	Zhao	Si	Su	Yi	Su	Si	Zhao	Zhao	Rou	Yi	Lei	Ji	Qiu	Ken	Cao	Ge	Bo	Huan	Huang	Chi	Ren	Xiao	Ru	Zhou	Yuan	Du	Gang	Rong	Gan	Cha	Wo	Chang	Gu	Zhi	Han	Fu	Fei	Fen	Pei	Pang	Jian	Fang	Zhun	You	Na	Ang	Ken	Ran	Gong	Yu	Wen	Yao	Qi	Pi	Qian	Xi	Xi	Fei	Ken	Jing	Tai	Shen	Zhong	Zhang	Xie	Shen	Wei	Zhou	Die	Dan	Fei	Ba	Bo	Qu	Tian	Bei	Gua	Tai	Zi	Fei	Zhi	Ni	Ping	Zi	Fu	Pang	Zhen	Xian	Zuo	Pei	Jia	Sheng	Zhi	Bao	Mu	Qu	Hu	Ke	Chi	Yin	Xu	Yang	Long	Dong	Ka	Lu	Jing	Nu	Yan	Pang	Kua	Yi	Guang	Hai	Ge	Dong	Chi	Jiao	Xiong	Xiong	Er	An	Heng	Pian	Neng	Zi	Gui";
    case 129:
      return "Cheng	Tiao	Zhi	Cui	Mei	Xie	Cui	Xie	Mai	Mai	Ji	Xie	Nin	Kuai	Sa	Zang	Qi	Nao	Mi	Nong	Luan	Wan	Bo	Wen	Wan	Xiu	Jiao	Jing	You	Heng	Cuo	Lie	Shan	Ting	Mei	Chun	Shen	Qian	De	Juan	Cu	Xiu	Xin	Tuo	Pao	Cheng	Nei	Pu	Dou	Tuo	Niao	Nao	Pi	Gu	Luo	Li	Lian	Zhang	Cui	Jie	Liang	Shui	Pi	Biao	Lun	Pian	Lei	Kui	Chui	Dan	Tian	Nei	Jing	Nai	La	Ye	Yan	Ren	Shen	Chuo	Fu	Fu	Ju	Fei	Qiang	Wan	Dong	Pi	Guo	Zong	Ding	Wo	Mei	Ni	Zhuan	Chi	Cou	Luo	Ou	Di	An	Xing	Nao	Shu	Shuan	Nan	Yun	Zhong	Rou	E	Sai	Tu	Yao	Jian	Wei	Jiao	Yu	Jia	Duan	Bi	Chang	Fu	Xian	Ni	Mian	Wa	Teng	Tui	Bang	Qian	Lu	Wa	Shou	Tang	Su	Zhui	Ge	Yi	Bo	Liao	Ji	Pi	Xie	Gao	Lu	Bin	Ou	Chang	Lu	Guo	Pang	Chuai	Biao	Jiang	Fu	Tang	Mo	Xi	Zhuan	Lu	Jiao	Ying	Lu	Zhi	Xue	Cun	Lin	Tong	Peng	Ni	Chuai	Liao	Cui	Gui	Xiao	Teng	Fan	Zhi	Jiao	Shan	Hu	Cui	Run	Xiang	Sui	Fen	Ying	Shan	Zhua	Dan	Kuai	Nong	Tun	Lian	Bi	Yong	Jue	Chu	Yi	Juan	La	Lian	Sao	Tun	Gu	Qi	Cui	Bin	Xun	Nao	Wo	Zang	Xian	Biao	Xing	Kuan	La	Yan	Lu	Huo	Za	Luo	Qu	Zang	Luan	Ni	Za	Chen	Qian	Wo	Guang	Zang	Lin	Guang	Zi	Jiao	Nie	Chou	Ji	Gao	Chou	Mian	Nie	Zhi	Zhi	Ge	Jian	Die	Zhi	Xiu	Tai	Zhen	Jiu	Xian	Yu	Cha";
    case 130:
      return "Yao	Yu	Chong	Xi	Xi	Jiu	Yu	Yu	Xing	Ju	Jiu	Xin	She	She	She	Jiu	Shi	Tan	Shu	Shi	Tian	Tan	Pu	Pu	Guan	Hua	Tian	Chuan	Shun	Xia	Wu	Zhou	Dao	Chuan	Shan	Yi	Fan	Pa	Tai	Fan	Ban	Chuan	Hang	Fang	Ban	Bi	Lu	Zhong	Jian	Cang	Ling	Zhu	Ze	Duo	Bo	Xian	Ge	Chuan	Xia	Lu	Qiong	Pang	Xi	Kua	Fu	Zao	Feng	Li	Shao	Yu	Lang	Ting	Yu	Wei	Bo	Meng	Nian	Ju	Huang	Shou	Ke	Bian	Mu	Die	Dao	Bang	Cha	Yi	Sou	Cang	Cao	Lou	Dai	Xue	Yao	Chong	Deng	Dang	Qiang	Lu	Yi	Ji	Jian	Huo	Meng	Qi	Lu	Lu	Chan	Shuang	Gen	Liang	Jian	Jian	Se	Yan	Fu	Ping	Yan	Yan	Cao	Cao	Yi	Le	Ting	Jiao	Ai	Nai	Tiao	Jiao	Jie	Peng	Wan	Yi	Chai	Mian	Mi	Gan	Qian	Yu	Yu	Shao	Xiong	Du	Hu	Qi	Mang	Zi	Hui	Sui	Zhi	Xiang	Bi	Fu	Tun	Wei	Wu	Zhi	Qi	Shan	Wen	Qian	Ren	Fu	Kou	Jie	Lu	Xu	Ji	Qin	Qi	Yan	Fen	Ba	Rui	Xin	Ji	Hua	Hua	Fang	Wu	Jue	Gou	Zhi	Yun	Qin	Ao	Chu	Mao	Ya	Fei	Reng	Hang	Cong	Yin	You	Bian	Yi	Qie	Wei	Li	Pi	E	Xian	Chang	Cang	Zhu	Su	Ti	Yuan	Ran	Ling	Tai	Shao	Di	Miao	Qing	Li	Yong	Ke	Mu	Bei	Bao	Gou	Min	Yi	Yi	Ju	Pie	Ruo	Ku	Ning	Ni	Bo	Bing	Shan	Xiu	Yao	Xian	Ben	Hong	Ying	Zha	Dong	Ju	Die	Nie	Gan	Hu	Ping	Mei	Fu	Sheng	Gu	Bi	Wei";
    case 131:
      return "Fu	Zhuo	Mao	Fan	Jia	Mao	Mao	Ba	Ci	Mo	Zi	Di	Chi	Ji	Jing	Long	Cong	Niao	Yuan	Xue	Ying	Qiong	Ge	Ming	Li	Rong	Yin	Gen	Qian	Chai	Chen	Yu	Hao	Zi	Lie	Wu	Ji	Gui	Ci	Jian	Ci	Gou	Guang	Mang	Cha	Jiao	Jiao	Fu	Yu	Zhu	Zi	Jiang	Hui	Yin	Cha	Fa	Rong	Ru	Chong	Mang	Tong	Zhong	Qian	Zhu	Xun	Huan	Fu	Quan	Gai	Da	Jing	Xing	Chuan	Cao	Jing	Er	An	Qiao	Chi	Ren	Jian	Ti	Huang	Ping	Li	Jin	Lao	Shu	Zhuang	Da	Jia	Rao	Bi	Ce	Qiao	Hui	Ji	Dang	Zi	Rong	Hun	Xing	Luo	Ying	Xun	Jin	Sun	Yin	Mai	Hong	Zhou	Yao	Du	Wei	Li	Dou	Fu	Ren	Yin	He	Bi	Bu	Yun	Di	Tu	Sui	Sui	Cheng	Chen	Wu	Bie	Xi	Geng	Li	Pu	Zhu	Mo	Li	Zhuang	Zuo	Tuo	Qiu	Sha	Suo	Chen	Peng	Ju	Mei	Meng	Xing	Jing	Che	Shen	Jun	Yan	Ting	You	Cuo	Guan	Han	You	Cuo	Jia	Wang	Su	Niu	Shao	Xian	Lang	Fu	E	Mo	Wen	Jie	Nan	Mu	Kan	Lai	Lian	Shi	Wo	Tu	Xian	Huo	You	Ying	Ying	Gong	Chun	Mang	Mang	Ci	Wan	Jing	Di	Qu	Dong	Jian	Zou	Gu	La	Lu	Ju	Wei	Jun	Nie	Kun	He	Pu	Zai	Gao	Guo	Fu	Lun	Chang	Chou	Song	Chui	Zhan	Men	Cai	Ba	Li	Tu	Bo	Han	Bao	Qin	Juan	Xi	Qin	Di	Jie	Pu	Dang	Jin	Qiao	Tai	Geng	Hua	Gu	Ling	Fei	Qin	An	Wang	Beng	Zhou	Yan	Zu	Jian	Lin	Tan	Shu	Tian	Dao";
    case 132:
      return "Hu	Qi	He	Cui	Tao	Chun	Bi	Chang	Huan	Fei	Lai	Qi	Meng	Ping	Wei	Dan	Sha	Huan	Yan	Yi	Tiao	Qi	Wan	Ce	Nai	Zhen	Tuo	Jiu	Tie	Luo	Bi	Yi	Pan	Bo	Pao	Ding	Ying	Ying	Ying	Xiao	Sa	Qiu	Ke	Xiang	Wan	Yu	Yu	Fu	Lian	Xuan	Xuan	Nan	Ce	Wo	Chun	Xiao	Yu	Bian	Mao	An	E	Luo	Ying	Kuo	Kuo	Jiang	Mian	Zuo	Zuo	Zu	Bao	Rou	Xi	Ye	An	Qu	Jian	Fu	Lu	Jing	Pen	Feng	Hong	Hong	Hou	Yan	Tu	Zhu	Zi	Xiang	Ren	Ge	Qia	Qing	Mi	Huang	Shen	Pu	Gai	Dong	Zhou	Jian	Wei	Bo	Wei	Pa	Ji	Hu	Zang	Jia	Duan	Yao	Jun	Cong	Quan	Wei	Zhen	Kui	Ting	Hun	Xi	Shi	Qi	Lan	Zong	Yao	Yuan	Mei	Yun	Shu	Di	Zhuan	Guan	Ran	Xue	Chan	Kai	Kui	Hua	Jiang	Lou	Wei	Pai	You	Sou	Yin	Shi	Chun	Shi	Yun	Zhen	Lang	Ru	Meng	Li	Que	Suan	Yuan	Li	Ju	Xi	Bang	Chu	Xu	Tu	Liu	Huo	Dian	Qian	Zu	Po	Cuo	Yuan	Chu	Yu	Kuai	Pan	Pu	Pu	Na	Shuo	Xi	Fen	Yun	Zheng	Jian	Ji	Ruo	Cang	En	Mi	Hao	Sun	Zhen	Ming	Sou	Xu	Liu	Xi	Gu	Lang	Rong	Weng	Gai	Cuo	Shi	Tang	Luo	Ru	Suo	Xuan	Bei	Yao	Gui	Bi	Zong	Gun	Zuo	Tiao	Ce	Pei	Lan	Dan	Ji	Li	Shen	Lang	Yu	Ling	Ying	Mo	Diao	Tiao	Mao	Tong	Chu	Peng	An	Lian	Cong	Xi	Ping	Qiu	Jin	Chun	Jie	Wei	Tui	Cao	Yu	Yi	Zi	Liao	Bi	Lu	Xu";
    case 133:
      return "Bu	Zhang	Lei	Qiang	Man	Yan	Ling	Ji	Piao	Gun	Han	Di	Su	Lu	She	Shang	Di	Mie	Xun	Man	Bo	Di	Cuo	Zhe	Shen	Xuan	Wei	Hu	Ao	Mi	Lou	Cu	Zhong	Cai	Po	Jiang	Mi	Cong	Niao	Hui	Juan	Yin	Jian	Nian	Shu	Yin	Guo	Chen	Hu	Sha	Kou	Qian	Ma	Zang	Ze	Qiang	Dou	Lian	Lin	Kou	Ai	Bi	Li	Wei	Ji	Qian	Sheng	Bo	Meng	Ou	Chan	Dian	Xun	Jiao	Rui	Rui	Lei	Yu	Qiao	Chu	Hua	Jian	Mai	Yun	Bao	You	Qu	Lu	Rao	Hui	E	Ti	Fei	Jue	Zui	Fa	Ru	Fen	Kui	Shun	Rui	Ya	Xu	Fu	Jue	Dang	Wu	Dong	Si	Xiao	Xi	Long	Wen	Shao	Qi	Jian	Yun	Sun	Ling	Yu	Xia	Weng	Ji	Hong	Si	Nong	Lei	Xuan	Yun	Ao	Xi	Hao	Bao	Hao	Ai	Wei	Hui	Hui	Ji	Ci	Xiang	Wan	Mie	Yi	Leng	Jiang	Can	Shen	Qiang	Lian	Ke	Yuan	Da	Ti	Tang	Xue	Bi	Zhan	Sun	Xian	Fan	Ding	Xie	Gu	Xie	Shu	Jian	Hao	Hong	Sa	Xin	Xun	Yao	Bai	Sou	Shu	Xun	Dui	Pin	Wei	Ning	Chou	Mai	Ru	Piao	Tai	Ji	Zao	Chen	Zhen	Er	Ni	Ying	Gao	Cong	Xiao	Qi	Fa	Jian	Xu	Kui	Ji	Bian	Diao	Mi	Lan	Jin	Cang	Miao	Qiong	Qie	Xian	Liao	Ou	Xian	Su	Lu	Yi	Xu	Xie	Li	Yi	La	Lei	Jiao	Di	Zhi	Bei	Teng	Yao	Mo	Huan	Biao	Fan	Sou	Tan	Tui	Qiong	Qiao	Wei	Liu	Hui	Ou	Gao	Yun	Bao	Li	Shu	Chu	Ai	Lin	Zao	Xuan	Qin	Lai	Huo";
    case 134:
      return "Tuo	Wu	Rui	Rui	Qi	Heng	Lu	Su	Tui	Meng	Yun	Ping	Yu	Xun	Ji	Jiong	Xuan	Mo	Qiu	Su	Jiong	Peng	Nie	Bo	Rang	Yi	Xian	Yu	Ju	Lian	Lian	Yin	Qiang	Ying	Long	Tou	Hua	Yue	Ling	Qu	Yao	Fan	Mei	Han	Kui	Lan	Ji	Dang	Man	Lei	Lei	Hui	Feng	Zhi	Wei	Kui	Zhan	Huai	Li	Ji	Mi	Lei	Huai	Luo	Ji	Kui	Lu	Jian	Sa	Teng	Lei	Quan	Xiao	Yi	Luan	Men	Bie	Hu	Hu	Lu	Nue	Lu	Si	Xiao	Qian	Chu	Hu	Xu	Cuo	Fu	Xu	Xu	Lu	Hu	Yu	Hao	Jiao	Ju	Guo	Bao	Yan	Zhan	Zhan	Kui	Bin	Xi	Shu	Chong	Qiu	Diao	Ji	Qiu	Ding	Shi	Xia	Jue	Zhe	She	Yu	Han	Zi	Hong	Hui	Meng	Ge	Sui	Xia	Chai	Shi	Yi	Ma	Xiang	Fang	E	Ba	Chi	Qian	Wen	Wen	Rui	Bang	Pi	Yue	Yue	Jun	Qi	Tong	Yin	Qi	Can	Yuan	Jue	Hui	Qin	Qi	Zhong	Ya	Hao	Mu	Wang	Fen	Fen	Hang	Gong	Zao	Fu	Ran	Jie	Fu	Chi	Dou	Bao	Xian	Ni	Dai	Qiu	You	Zha	Ping	Chi	You	He	Han	Ju	Li	Fu	Ran	Zha	Gou	Pi	Pi	Xian	Zhu	Diao	Bie	Bing	Gu	Zhan	Qu	She	Tie	Ling	Gu	Dan	Gu	Ying	Li	Cheng	Qu	Mou	Ge	Ci	Hui	Hui	Mang	Fu	Yang	Wa	Lie	Zhu	Yi	Xian	Kuo	Jiao	Li	Yi	Ping	Qi	Ha	She	Yi	Wang	Mo	Qiong	Qie	Gui	Qiong	Zhi	Man	Lao	Zhe	Jia	Nao	Si	Qi	Xing	Jie	Qiu	Shao	Yong	Jia	Tui	Che	Bei	E	Han";
    case 135:
      return "Shu	Xuan	Feng	Shen	Shen	Fu	Xian	Zhe	Wu	Fu	Li	Lang	Bi	Chu	Yuan	You	Jie	Dan	Yan	Ting	Dian	Tui	Hui	Wo	Zhi	Song	Fei	Ju	Mi	Qi	Qi	Yu	Jun	La	Meng	Qiang	Si	Xi	Lun	Li	Die	Tiao	Tao	Kun	Han	Han	Yu	Bang	Fei	Pi	Wei	Dun	Yi	Yuan	Suo	Quan	Qian	Rui	Ni	Qing	Wei	Liang	Guo	Wan	Dong	E	Ban	Di	Wang	Can	Yang	Ying	Guo	Chan	Ding	La	Ke	Jie	Xie	Ting	Mao	Xu	Mian	Yu	Jie	Shi	Xuan	Huang	Yan	Bian	Rou	Wei	Fu	Yuan	Mei	Wei	Fu	Ru	Xie	You	Qiu	Mao	Xia	Ying	Shi	Chong	Tang	Zhu	Zong	Ti	Fu	Yuan	Kui	Meng	La	Du	Hu	Qiu	Die	Li	Wo	Yun	Qu	Nan	Lou	Chun	Rong	Ying	Jiang	Ban	Lang	Pang	Si	Xi	Ci	Xi	Yuan	Weng	Lian	Sou	Ban	Rong	Rong	Ji	Wu	Xiu	Han	Qin	Yi	Bi	Hua	Tang	Yi	Du	Nai	He	Hu	Gui	Ma	Ming	Yi	Wen	Ying	Teng	Zhong	Cang	Sao	Qi	Man	Tiao	Shang	Shi	Cao	Chi	Di	Ao	Lu	Wei	Zhi	Tang	Chen	Piao	Qu	Pi	Yu	Jian	Luo	Lou	Qin	Zhong	Yin	Jiang	Shuai	Wen	Xiao	Wan	Zhe	Zhe	Ma	Ma	Guo	Liu	Mao	Xi	Cong	Li	Man	Xiao	Chang	Zhang	Mang	Xiang	Mo	Zui	Si	Qiu	Te	Zhi	Peng	Peng	Jiao	Qu	Bie	Liao	Pan	Gui	Xi	Ji	Zhuan	Huang	Fei	Lao	Jue	Jue	Hui	Yin	Chan	Jiao	Shan	Nao	Xiao	Wu	Chong	Xun	Si	Chu	Cheng	Dang	Li	Xie	Shan	Yi	Jing	Da	Chan	Qi";
    case 136:
      return "Ci	Xiang	She	Luo	Qin	Ying	Chai	Li	Zei	Xuan	Lian	Zhu	Ze	Xie	Mang	Xie	Qi	Rong	Jian	Meng	Hao	Ru	Huo	Zhuo	Jie	Pin	He	Mie	Fan	Lei	Jie	La	Min	Li	Chun	Li	Qiu	Nie	Lu	Du	Xiao	Zhu	Long	Li	Long	Feng	Ye	Pi	Nang	Gu	Juan	Ying	Shu	Xi	Can	Qu	Quan	Du	Can	Man	Qu	Jie	Zhu	Zhuo	Xue	Huang	Nu	Pei	Nu	Xin	Zhong	Mai	Er	Ka	Mie	Xi	Xing	Yan	Kan	Yuan	Qu	Ling	Xuan	Shu	Xian	Tong	Xiang	Jie	Xian	Ya	Hu	Wei	Dao	Chong	Wei	Dao	Zhun	Heng	Qu	Yi	Yi	Bu	Gan	Yu	Biao	Cha	Yi	Shan	Chen	Fu	Gun	Fen	Shuai	Jie	Na	Zhong	Dan	Yi	Zhong	Zhong	Jie	Zhi	Xie	Ran	Zhi	Ren	Qin	Jin	Jun	Yuan	Mei	Chai	Ao	Niao	Hui	Ran	Jia	Tuo	Ling	Dai	Bao	Pao	Yao	Zuo	Bi	Shao	Tan	Ju	He	Xue	Xiu	Zhen	Yi	Pa	Bo	Di	Wa	Fu	Gun	Zhi	Zhi	Ran	Pan	Yi	Mao	Tuo	Na	Gou	Xuan	Zhe	Qu	Bei	Yu	Xi	Mi	Bo	Bo	Fu	Chi	Chi	Ku	Ren	Jiang	Qia	Jian	Bo	Jie	Er	Ge	Ru	Zhu	Gui	Yin	Cai	Lie	Ka	Xing	Zhuang	Dang	Xu	Kun	Ken	Niao	Shu	Jia	Kun	Cheng	Li	Juan	Shen	Pou	Ge	Yi	Yu	Zhen	Liu	Qiu	Qun	Ji	Yi	Bu	Zhuang	Shui	Sha	Qun	Li	Lian	Lian	Ku	Jian	Fou	Chan	Bi	Kun	Tao	Yuan	Ling	Chi	Chang	Chou	Duo	Biao	Liang	Shang	Pei	Pei	Fei	Yuan	Luo	Guo	Yan	Du	Ti	Zhi	Ju	Yi";
    case 137:
      return "Qi	Guo	Gua	Ken	Qi	Ti	Ti	Fu	Chong	Xie	Bian	Die	Kun	Duan	Xiu	Xiu	He	Yuan	Bao	Bao	Fu	Yu	Tuan	Yan	Hui	Bei	Chu	Lu	Pao	Dan	Yun	Ta	Gou	Da	Huai	Rong	Yuan	Ru	Nai	Jiong	Suo	Ban	Tui	Chi	Sang	Niao	Ying	Jie	Qian	Huai	Ku	Lian	Lan	Li	Zhe	Shi	Lu	Yi	Die	Xie	Xian	Wei	Biao	Cao	Ji	Qiang	Sen	Bao	Xiang	Bi	Fu	Jian	Zhuan	Jian	Cui	Ji	Dan	Za	Fan	Bo	Xiang	Xin	Bie	Rao	Man	Lan	Ao	Ze	Gui	Cao	Sui	Nong	Chan	Lian	Bi	Jin	Dang	Shu	Tan	Bi	Lan	Fu	Ru	Zhi	Dui	Shu	Wa	Shi	Bai	Xie	Bo	Chen	Lai	Long	Xi	Xian	Lan	Zhe	Dai	Ju	Zan	Shi	Jian	Pan	Yi	Lan	Ya	Xi	Xi	Yao	Feng	Tan	Fu	Fiao	Fu	Ba	He	Ji	Ji	Jian	Guan	Bian	Yan	Gui	Jue	Pian	Mao	Mi	Mi	Mie	Shi	Si	Chan	Luo	Jue	Mi	Tiao	Lian	Yao	Zhi	Jun	Xi	Shan	Wei	Xi	Tian	Yu	Lan	E	Du	Qin	Pang	Ji	Ming	Ying	Gou	Qu	Zhan	Jin	Guan	Deng	Jian	Luo	Qu	Jian	Wei	Jue	Qu	Luo	Lan	Shen	Di	Guan	Jian	Guan	Yan	Gui	Mi	Shi	Chan	Lan	Jue	Ji	Xi	Di	Tian	Yu	Gou	Jin	Qu	Jiao	Qiu	Jin	Cu	Jue	Zhi	Chao	Ji	Gu	Dan	Zi	Di	Shang	Hua	Quan	Ge	Shi	Jie	Gui	Gong	Chu	Jie	Hun	Qiu	Xing	Su	Ni	Ji	Lu	Zhi	Zha	Bi	Xing	Hu	Shang	Gong	Zhi	Xue	Chu	Xi	Yi	Li	Jue	Xi	Yan	Xi";
    case 138:
      return "Yan	Yan	Ding	Fu	Qiu	Qiu	Jiao	Hong	Ji	Fan	Xun	Diao	Hong	Chai	Tao	Xu	Jie	Yi	Ren	Xun	Yin	Shan	Qi	Tuo	Ji	Xun	Yin	E	Fen	Ya	Yao	Song	Shen	Yin	Xin	Jue	Xiao	Ne	Chen	You	Zhi	Xiong	Fang	Xin	Chao	She	Yan	Sa	Zhun	Xu	Yi	Yi	Su	Chi	He	Shen	He	Xu	Zhen	Zhu	Zheng	Gou	Zi	Zi	Zhan	Gu	Fu	Jian	Die	Ling	Di	Yang	Li	Nao	Pan	Zhou	Gan	Yi	Ju	Yao	Zha	Yi	Yi	Qu	Zhao	Ping	Bi	Xiong	Qu	Ba	Da	Zu	Tao	Zhu	Ci	Zhe	Yong	Xu	Xun	Yi	Huang	He	Shi	Cha	Xiao	Shi	Hen	Cha	Gou	Gui	Quan	Hui	Jie	Hua	Gai	Xiang	Wei	Shen	Zhou	Tong	Mi	Zhan	Ming	E	Hui	Yan	Xiong	Gua	Er	Bing	Tiao	Yi	Lei	Zhu	Kuang	Kua	Wu	Yu	Teng	Ji	Zhi	Ren	Cu	Lang	E	Kuang	Ei	Shi	Ting	Dan	Bei	Chan	You	Keng	Qiao	Qin	Shua	An	Yu	Xiao	Cheng	Jie	Xian	Wu	Wu	Gao	Song	Bu	Hui	Jing	Shuo	Zhen	Shuo	Du	Hua	Chang	Shui	Jie	Ke	Qu	Cong	Xiao	Sui	Wang	Xian	Fei	Chi	Ta	Yi	Ni	Yin	Diao	Pi	Zhuo	Chan	Chen	Zhun	Ji	Qi	Tan	Zhui	Wei	Ju	Qing	Dong	Zheng	Ze	Zou	Qian	Zhuo	Liang	Jian	Chu	Hao	Lun	Shen	Biao	Hua	Pian	Yu	Die	Xu	Pian	Shi	Xuan	Shi	Hun	Hua	E	Zhong	Di	Xie	Fu	Pu	Ting	Jian	Qi	Yu	Zi	Zhuan	Xi	Hui	Yin	An	Xian	Nan	Chen	Feng	Zhu	Yang	Yan	Huang	Xuan	Ge	Nuo	Qi";
    case 139:
      return "Mou	Ye	Wei	Xing	Teng	Zhou	Shan	Jian	Po	Kui	Huang	Huo	Ge	Ying	Mi	Xiao	Mi	Xi	Qiang	Chen	Xue	Ti	Su	Bang	Chi	Qian	Shi	Jiang	Yuan	Xie	He	Tao	Yao	Yao	Lu	Yu	Biao	Cong	Qing	Li	Mo	Mo	Shang	Zhe	Miu	Jian	Ze	Jie	Lian	Lou	Can	Ou	Gun	Xi	Zhuo	Ao	Ao	Jin	Zhe	Yi	Hu	Jiang	Man	Chao	Han	Hua	Chan	Xu	Zeng	Se	Xi	Zha	Dui	Zheng	Nao	Lan	E	Ying	Jue	Ji	Zun	Jiao	Bo	Hui	Zhuan	Wu	Zen	Zha	Shi	Qiao	Tan	Zen	Pu	Sheng	Xuan	Zao	Tan	Dang	Sui	Xian	Ji	Jiao	Jing	Zhan	Nang	Yi	Ai	Zhan	Pi	Hui	Hua	Yi	Yi	Shan	Rang	Nou	Qian	Dui	Ta	Hu	Zhou	Hao	Ai	Ying	Jian	Yu	Jian	Hui	Du	Zhe	Xuan	Zan	Lei	Shen	Wei	Chan	Li	Yi	Bian	Zhe	Yan	E	Chou	Wei	Chou	Yao	Chan	Rang	Yin	Lan	Chen	Xie	Nie	Huan	Zan	Yi	Dang	Zhan	Yan	Du	Yan	Ji	Ding	Fu	Ren	Ji	Jie	Hong	Tao	Rang	Shan	Qi	Tuo	Xun	Yi	Xun	Ji	Ren	Jiang	Hui	Ou	Ju	Ya	Ne	Xu	E	Lun	Xiong	Song	Feng	She	Fang	Jue	Zheng	Gu	He	Ping	Zu	Shi	Xiong	Zha	Su	Zhen	Di	Zhou	Ci	Qu	Zhao	Bi	Yi	Yi	Kuang	Lei	Shi	Gua	Shi	Jie	Hui	Cheng	Zhu	Shen	Hua	Dan	Gou	Quan	Gui	Xun	Yi	Zheng	Gai	Xiang	Cha	Hun	Xu	Zhou	Jie	Wu	Yu	Qiao	Wu	Gao	You	Hui	Kuang	Shuo	Song	Ei	Qing	Zhu	Zou	Nuo	Du	Zhuo	Fei	Ke	Wei";
    case 140:
      return "Yu	Shei	Shen	Diao	Chan	Liang	Zhun	Sui	Tan	Shen	Yi	Mou	Chen	Die	Huang	Jian	Xie	Xue	Ye	Wei	E	Yu	Xuan	Chan	Zi	An	Yan	Di	Mi	Pian	Xu	Mo	Dang	Su	Xie	Yao	Bang	Shi	Qian	Mi	Jin	Man	Zhe	Jian	Miu	Tan	Zen	Qiao	Lan	Pu	Jue	Yan	Qian	Zhan	Chen	Gu	Qian	Hong	Xia	Ji	Hong	Han	Hong	Xi	Xi	Huo	Liao	Han	Du	Long	Dou	Jiang	Qi	Chi	Li	Deng	Wan	Bi	Shu	Xian	Feng	Zhi	Zhi	Yan	Yan	Shi	Chu	Hui	Tun	Yi	Tun	Yi	Jian	Ba	Hou	E	Chu	Xiang	Huan	Jian	Ken	Gai	Ju	Fu	Xi	Bin	Hao	Yu	Zhu	Jia	Fen	Xi	Bo	Wen	Huan	Bin	Di	Zong	Fen	Yi	Zhi	Bao	Chai	An	Pi	Na	Pi	Gou	Na	You	Diao	Mo	Si	Xiu	Huan	Kun	He	Hao	Mo	An	Mao	Li	Ni	Bi	Yu	Jia	Tuan	Mao	Pi	Xi	Yi	Ju	Mo	Chu	Tan	Huan	Jue	Bei	Zhen	Yuan	Fu	Cai	Gong	Te	Yi	Hang	Wan	Pin	Huo	Fan	Tan	Guan	Ze	Zhi	Er	Zhu	Shi	Bi	Zi	Er	Gui	Pian	Bian	Mai	Dai	Sheng	Kuang	Fei	Tie	Yi	Chi	Mao	He	Bi	Lu	Lin	Hui	Gai	Pian	Zi	Jia	Xu	Zei	Jiao	Gai	Zang	Jian	Ying	Xun	Zhen	She	Bin	Bin	Qiu	She	Chuan	Zang	Zhou	Lai	Zan	Ci	Chen	Shang	Tian	Pei	Geng	Xian	Mai	Jian	Sui	Fu	Tan	Cong	Cong	Zhi	Ji	Zhang	Du	Jin	Xiong	Chun	Yun	Bao	Zai	Lai	Feng	Cang	Ji	Sheng	Yi	Zhuan	Fu	Gou	Sai	Ze	Liao";
    case 141:
      return "Yi	Bai	Chen	Wan	Zhi	Zhui	Biao	Yun	Zeng	Dan	Zan	Yan	Pu	Shan	Wan	Ying	Jin	Gan	Xian	Zang	Bi	Du	Shu	Yan	Shang	Xuan	Long	Gan	Zang	Bei	Zhen	Fu	Yuan	Gong	Cai	Ze	Xian	Bai	Zhang	Huo	Zhi	Fan	Tan	Pin	Bian	Gou	Zhu	Guan	Er	Jian	Ben	Shi	Tie	Gui	Kuang	Dai	Mao	Fei	He	Yi	Zei	Zhi	Jia	Hui	Zi	Lin	Lu	Zang	Zi	Gai	Jin	Qiu	Zhen	Lai	She	Fu	Du	Ji	Shu	Shang	Ci	Bi	Zhou	Geng	Pei	Dan	Lai	Feng	Zhui	Fu	Zhuan	Sai	Ze	Yan	Zan	Yun	Zeng	Shan	Ying	Gan	Chi	Xi	She	Nan	Tong	Xi	Cheng	He	Cheng	Zhe	Xia	Tang	Zou	Zou	Li	Jiu	Fu	Zhao	Gan	Qi	Shan	Qiong	Yin	Xian	Zi	Jue	Qin	Chi	Ci	Chen	Chen	Die	Ju	Chao	Di	Xi	Zhan	Jue	Yue	Qu	Ji	Chi	Chu	Gua	Xue	Zi	Tiao	Duo	Lie	Gan	Suo	Cu	Xi	Zhao	Su	Yin	Ju	Jian	Que	Tang	Chuo	Cui	Lu	Qu	Dang	Qiu	Zi	Ti	Qu	Chi	Huang	Qiao	Qiao	Jiao	Zao	Ti	Er	Zan	Zan	Zu	Pa	Bao	Ku	Ke	Dun	Jue	Fu	Chen	Jian	Fang	Zhi	Ta	Yue	Ba	Qi	Yue	Qiang	Tuo	Tai	Yi	Nian	Ling	Mei	Ba	Die	Ku	Tuo	Jia	Ci	Pao	Qia	Zhu	Ju	Dian	Zhi	Fu	Pan	Ju	Shan	Bo	Ni	Ju	Li	Gen	Yi	Ji	Duo	Xian	Jiao	Duo	Zhu	Quan	Kua	Zhuai	Gui	Qiong	Kui	Xiang	Chi	Lu	Pian	Zhi	Jia	Tiao	Cai	Jian	Da	Qiao	Bi	Xian	Duo	Ji	Ju	Ji	Shu	Tu";
    case 142:
      return "Chu	Jing	Nie	Xiao	Bu	Xue	Cun	Mu	Shu	Liang	Yong	Jiao	Chou	Qiao	Mou	Ta	Jian	Qi	Wo	Wei	Chuo	Jie	Ji	Nie	Ju	Nie	Lun	Lu	Leng	Huai	Ju	Chi	Wan	Quan	Ti	Bo	Zu	Qie	Yi	Cu	Zong	Cai	Zong	Peng	Zhi	Zheng	Dian	Zhi	Yu	Duo	Dun	Chuan	Yong	Zhong	Di	Zha	Chen	Chuai	Jian	Gua	Tang	Ju	Fu	Zu	Die	Pian	Rou	Nuo	Ti	Cha	Tui	Jian	Dao	Cuo	Qi	Ta	Qiang	Nian	Dian	Ti	Ji	Nie	Pan	Liu	Zan	Bi	Chong	Lu	Liao	Cu	Tang	Dai	Su	Xi	Kui	Ji	Zhi	Qiang	Di	Pan	Zong	Lian	Beng	Zao	Nian	Bie	Tui	Ju	Deng	Ceng	Xian	Fan	Chu	Zhong	Dun	Bo	Cu	Cu	Jue	Jue	Lin	Ta	Qiao	Jue	Pu	Liao	Dun	Cuan	Guan	Zao	Da	Bi	Bi	Zhu	Ju	Chu	Qiao	Dun	Chou	Ji	Wu	Yue	Nian	Lin	Lie	Zhi	Li	Zhi	Chan	Chu	Duan	Wei	Long	Lin	Xian	Wei	Zuan	Lan	Xie	Rang	Sa	Nie	Ta	Qu	Ji	Cuan	Cuo	Xi	Kui	Jue	Lin	Shen	Gong	Dan	Fen	Qu	Ti	Duo	Duo	Gong	Lang	Ren	Luo	Ai	Ji	Ju	Tang	Kong	Lao	Yan	Mei	Kang	Qu	Lou	Lao	Duo	Zhi	Yan	Ti	Dao	Ying	Yu	Che	Ya	Gui	Jun	Wei	Yue	Xin	Dai	Xuan	Fan	Ren	Shan	Kuang	Shu	Tun	Chen	Dai	E	Na	Qi	Mao	Ruan	Kuang	Qian	Zhuan	Hong	Hu	Qu	Kuang	Di	Ling	Dai	Ao	Zhen	Fan	Kuang	Yang	Peng	Bei	Gu	Gu	Pao	Zhu	Rong	E	Ba	Zhou	Zhi	Yao	Ke	Yi	Zhi	Shi	Ping";
    case 143:
      return "Er	Gong	Ju	Jiao	Guang	Lu	Kai	Quan	Zhou	Zai	Zhi	She	Liang	Yu	Shao	You	Wan	Yin	Zhe	Wan	Fu	Qing	Zhou	Ni	Leng	Zhe	Zhan	Liang	Zi	Hui	Wang	Chuo	Guo	Kan	Yi	Peng	Qian	Gun	Nian	Ping	Guan	Bei	Lun	Pai	Liang	Ruan	Rou	Ji	Yang	Xian	Chuan	Cou	Chun	Ge	You	Hong	Shu	Fu	Zi	Fu	Wen	Ben	Zhan	Yu	Wen	Tao	Gu	Zhen	Xia	Yuan	Lu	Jiao	Chao	Zhuan	Wei	Hun	Xue	Zhe	Jiao	Zhan	Bu	Lao	Fen	Fan	Lin	Ge	Se	Kan	Huan	Yi	Ji	Zhui	Er	Yu	Jian	Hong	Lei	Pei	Li	Li	Lu	Lin	Che	Ya	Gui	Xuan	Dai	Ren	Zhuan	E	Lun	Ruan	Hong	Gu	Ke	Lu	Zhou	Zhi	Yi	Hu	Zhen	Li	Yao	Qing	Shi	Zai	Zhi	Jiao	Zhou	Quan	Lu	Jiao	Zhe	Fu	Liang	Nian	Bei	Hui	Gun	Wang	Liang	Chuo	Zi	Cou	Fu	Ji	Wen	Shu	Pei	Yuan	Xia	Zhan	Lu	Zhe	Lin	Xin	Gu	Ci	Ci	Pi	Zui	Bian	La	La	Ci	Xue	Ban	Bian	Bian	Bian	Xue	Bian	Ban	Ci	Bian	Bian	Chen	Ru	Nong	Nong	Chan	Chuo	Chuo	Yi	Reng	Bian	Bian	Shi	Yu	Liao	Da	Chan	Gan	Qian	Yu	Yu	Qi	Xun	Yi	Guo	Mai	Qi	Za	Wang	Tu	Zhun	Ying	Da	Yun	Jin	Hang	Ya	Fan	Wu	Da	E	Hai	Zhe	Da	Jin	Yuan	Wei	Lian	Chi	Che	Ni	Tiao	Zhi	Yi	Jiong	Jia	Chen	Dai	Er	Di	Po	Zhu	Die	Ze	Tao	Shu	Tuo	Qu	Jing	Hui	Dong	You	Mi	Beng	Ji	Nai	Yi	Jie	Zhui	Lie	Xun";
    case 144:
      return "Tui	Song	Shi	Tao	Pang	Hou	Ni	Dun	Jiong	Xuan	Xun	Bu	You	Xiao	Qiu	Tou	Zhu	Qiu	Di	Di	Tu	Jing	Ti	Dou	Yi	Zhe	Tong	Guang	Wu	Shi	Cheng	Su	Zao	Qun	Feng	Lian	Suo	Hui	Li	Gu	Lai	Ben	Cuo	Jue	Beng	Huan	Dai	Lu	You	Zhou	Jin	Yu	Chuo	Kui	Wei	Ti	Yi	Da	Yuan	Luo	Bi	Nuo	Yu	Dang	Sui	Dun	Sui	Yan	Chuan	Chi	Ti	Yu	Shi	Zhen	You	Yun	E	Bian	Guo	E	Xia	Huang	Qiu	Dao	Da	Wei	Nan	Yi	Gou	Yao	Chou	Liu	Xun	Ta	Di	Chi	Yuan	Su	Ta	Qian	Ma	Yao	Guan	Zhang	Ao	Shi	Ca	Chi	Su	Zao	Zhe	Dun	Di	Lou	Chi	Cuo	Lin	Zun	Rao	Qian	Xuan	Yu	Yi	E	Liao	Ju	Shi	Bi	Yao	Mai	Xie	Sui	Hai	Zhan	Teng	Er	Miao	Bian	Bian	La	Li	Yuan	Yao	Luo	Li	Yi	Ting	Deng	Qi	Yong	Shan	Han	Yu	Mang	Ru	Qiong	Xi	Kuang	Fu	Kang	Bin	Fang	Xing	Na	Xin	Shen	Bang	Yuan	Cun	Huo	Xie	Bang	Wu	Ju	You	Han	Tai	Qiu	Bi	Pi	Bing	Shao	Bei	Wa	Di	Zou	Ye	Lin	Kuang	Gui	Zhu	Shi	Ku	Yu	Gai	He	Qie	Zhi	Ji	Huan	Hou	Xing	Jiao	Xi	Gui	Nuo	Lang	Jia	Kuai	Zheng	Lang	Yun	Yan	Cheng	Dou	Xi	Lu	Fu	Wu	Fu	Gao	Hao	Lang	Jia	Geng	Jun	Ying	Bo	Xi	Bei	Li	Yun	Bu	Xiao	Qi	Pi	Qing	Guo	Zhou	Tan	Zou	Ping	Lai	Ni	Chen	You	Bu	Xiang	Dan	Ju	Yong	Qiao	Yi	Dou	Yan	Mei";
    case 145:
      return "Ruo	Bei	E	Shu	Juan	Yu	Yun	Hou	Kui	Xiang	Xiang	Sou	Tang	Ming	Xi	Ru	Chu	Zi	Zou	Ye	Wu	Xiang	Yun	Hao	Yong	Bi	Mao	Chao	Fu	Liao	Yin	Zhuan	Hu	Qiao	Yan	Zhang	Man	Qiao	Xu	Deng	Bi	Xun	Bi	Zeng	Wei	Zheng	Mao	Shan	Lin	Po	Dan	Meng	Ye	Cao	Kuai	Feng	Meng	Zou	Kuang	Lian	Zan	Chan	You	Ji	Yan	Chan	Zan	Ling	Huan	Xi	Feng	Zan	Li	You	Ding	Qiu	Zhuo	Pei	Zhou	Yi	Gan	Yu	Jiu	Yan	Zui	Mao	Zhen	Xu	Dou	Zhen	Fen	Yuan	Fu	Yun	Tai	Tian	Qia	Tuo	Zuo	Han	Gu	Su	Po	Chou	Zai	Ming	Lao	Chuo	Chou	You	Tong	Zhi	Xian	Jiang	Cheng	Yin	Tu	Jiao	Mei	Ku	Suan	Lei	Pu	Zui	Hai	Yan	Shi	Niang	Wei	Lu	Lan	Yan	Tao	Pei	Zhan	Chun	Tan	Zui	Zhui	Cu	Kun	Ti	Xian	Du	Hu	Xu	Xing	Tan	Qiu	Chun	Yun	Po	Ke	Sou	Mi	Quan	Chou	Cuo	Yun	Yong	Ang	Zha	Hai	Tang	Jiang	Piao	Chen	Yu	Li	Zao	Lao	Yi	Jiang	Bu	Jiao	Xi	Tan	Fa	Nong	Yi	Li	Ju	Yan	Yi	Niang	Ru	Xun	Chou	Yan	Ling	Mi	Mi	Niang	Xin	Jiao	Shai	Mi	Yan	Bian	Cai	Shi	You	Shi	Shi	Li	Zhong	Ye	Liang	Xi	Jin	Jin	Ga	Yi	Liao	Dao	Zhao	Ding	Po	Qiu	Ba	Fu	Zhen	Zhi	Ba	Luan	Fu	Nai	Diao	Shan	Qiao	Kou	Chuan	Zi	Fan	Hua	Hua	Han	Gang	Qi	Mang	Ri	Di	Si	Xi	Yi	Chai	Shi	Tu	Xi	Nu	Qian	Qiu	Jian	Pi	Ye	Jin";
    case 146:
      return "Ba	Fang	Chen	Xing	Dou	Yue	Qian	Fu	Bu	Na	Xin	E	Jue	Dun	Gou	Yin	Qian	Ban	Sa	Ren	Chao	Niu	Fen	Yun	Yi	Qin	Pi	Guo	Hong	Yin	Jun	Diao	Yi	Zhong	Xi	Gai	Ri	Huo	Tai	Kang	Yuan	Lu	E	Qin	Duo	Zi	Ni	Tu	Shi	Min	Gu	Ke	Ling	Bing	Si	Gu	Bo	Pi	Yu	Si	Zuo	Bu	You	Tian	Jia	Zhen	Shi	Shi	Zhi	Ju	Chan	Shi	Shi	Xuan	Zhao	Bao	He	Bi	Sheng	Chu	Shi	Bo	Zhu	Chi	Za	Po	Tong	Qian	Fu	Zhai	Mao	Qian	Fu	Li	Yue	Pi	Yang	Ban	Bo	Jie	Gou	Shu	Zheng	Mu	Xi	Xi	Di	Jia	Mu	Tan	Huan	Yi	Si	Kuang	Ka	Bei	Jian	Tong	Xing	Hong	Jiao	Chi	Er	Ge	Bing	Shi	Mou	Jia	Yin	Jun	Zhou	Chong	Xiang	Tong	Mo	Lei	Ji	Yu	Xu	Ren	Zun	Zhi	Qiong	Shan	Chi	Xian	Xing	Quan	Pi	Tie	Zhu	Xiang	Ming	Kua	Yao	Xian	Xian	Xiu	Jun	Cha	Lao	Ji	Pi	Ru	Mi	Yi	Yin	Guang	An	Diu	You	Se	Kao	Qian	Luan	Si	Ai	Diao	Han	Rui	Shi	Keng	Qiu	Xiao	Zhe	Xiu	Zang	Ti	Cuo	Gua	Hong	Zhong	Tou	Lu	Mei	Lang	Wan	Xin	Yun	Bei	Wu	Su	Yu	Chan	Ding	Bo	Han	Jia	Hong	Cuan	Feng	Chan	Wan	Zhi	Si	Xuan	Hua	Yu	Tiao	Kuang	Zhuo	Lue	Xing	Qin	Shen	Han	Lue	Ye	Chu	Zeng	Ju	Xian	E	Mang	Pu	Li	Pan	Rui	Cheng	Gao	Li	Te	Bing	Zhu	Zhen	Tu	Liu	Zui	Ju	Chang	Yuan	Jian	Gang	Diao	Tao	Chang";
    case 147:
      return "Lun	Guo	Ling	Pi	Lu	Li	Qiang	Pou	Juan	Min	Zui	Peng	An	Pi	Xian	Ya	Zhui	Lei	A	Kong	Ta	Kun	Du	Nei	Chui	Zi	Zheng	Ben	Nie	Zong	Chun	Tan	Ding	Qi	Qian	Zhui	Ji	Yu	Jin	Guan	Mao	Chang	Tian	Xi	Lian	Tao	Gu	Cuo	Shu	Zhen	Lu	Meng	Lu	Hua	Biao	Ga	Lai	Ken	Fang	Wu	Nai	Wan	Zan	Hu	De	Xian	Pian	Huo	Liang	Fa	Men	Kai	Ying	Di	Lian	Guo	Xian	Du	Tu	Wei	Zong	Fu	Rou	Ji	E	Jun	Chen	Ti	Zha	Hu	Yang	Duan	Xia	Yu	Keng	Sheng	Huang	Wei	Fu	Zhao	Cha	Qie	Shi	Hong	Kui	Tian	Mou	Qiao	Qiao	Hou	Tou	Cong	Huan	Ye	Min	Jian	Duan	Jian	Song	Kui	Hu	Xuan	Zhe	Jie	Zhen	Bian	Zhong	Zi	Xiu	Ye	Mei	Pai	Ai	Jie	Qian	Mei	Suo	Da	Bang	Xia	Lian	Suo	Kai	Liu	Yao	Ye	Nou	Weng	Rong	Tang	Suo	Qiang	Li	Shuo	Chui	Bo	Pan	Da	Bi	Sang	Gang	Zi	Wu	Ying	Huang	Tiao	Liu	Kai	Sun	Sha	Sou	Wan	Hao	Zhen	Zhen	Lang	Yi	Yuan	Tang	Nie	Xi	Jia	Ge	Ma	Juan	Song	Zu	Suo	Xia	Feng	Wen	Na	Lu	Suo	Ou	Zu	Tuan	Xiu	Guan	Xuan	Lian	Shou	Ao	Man	Mo	Luo	Bi	Wei	Liu	Di	San	Zong	Yi	Lu	Ao	Keng	Qiang	Cui	Qi	Chang	Tang	Man	Yong	Chan	Feng	Jing	Biao	Shu	Lou	Xiu	Cong	Long	Zan	Jian	Cao	Li	Xia	Xi	Kang	Shuang	Beng	Zhang	Qian	Cheng	Lu	Hua	Ji	Pu	Hui	Qiang	Po	Lin	Se	Xiu	San	Cheng";
    case 148:
      return "Kui	Si	Liu	Nao	Huang	Pie	Sui	Fan	Qiao	Quan	Yang	Tang	Xiang	Jue	Jiao	Zun	Liao	Qie	Lao	Dui	Xin	Zan	Ji	Jian	Zhong	Deng	Ya	Ying	Dui	Jue	Nou	Zan	Pu	Tie	Fan	Cheng	Ding	Shan	Kai	Jian	Fei	Sui	Lu	Juan	Hui	Yu	Lian	Zhuo	Qiao	Jian	Zhuo	Lei	Bi	Tie	Huan	Ye	Duo	Guo	Dang	Ju	Fen	Da	Bei	Yi	Ai	Zong	Xun	Diao	Zhu	Heng	Zhui	Ji	Nie	He	Huo	Qing	Bin	Ying	Kui	Ning	Xu	Jian	Jian	Qian	Cha	Zhi	Mie	Li	Lei	Ji	Zuan	Kuang	Shang	Peng	La	Du	Shuo	Chuo	Lu	Biao	Bao	Lu	Xian	Kuan	Long	E	Lu	Xin	Jian	Lan	Bo	Jian	Yao	Chan	Xiang	Jian	Xi	Guan	Cang	Nie	Lei	Cuan	Qu	Pan	Luo	Zuan	Luan	Zao	Nie	Jue	Tang	Zhu	Lan	Jin	Ga	Yi	Zhen	Ding	Zhao	Po	Liao	Tu	Qian	Chuan	Shan	Sa	Fan	Diao	Men	Nu	Yang	Chai	Xing	Gai	Bu	Tai	Ju	Dun	Chao	Zhong	Na	Bei	Gang	Ban	Qian	Yao	Qin	Jun	Wu	Gou	Kang	Fang	Huo	Dou	Niu	Ba	Yu	Qian	Zheng	Qian	Gu	Bo	Ke	Po	Bu	Bo	Yue	Zuan	Mu	Tan	Jia	Dian	You	Tie	Bo	Ling	Shuo	Qian	Mao	Bao	Shi	Xuan	Ta	Bi	Ni	Pi	Duo	Xing	Kao	Lao	Er	Mang	Ya	You	Cheng	Jia	Ye	Nao	Zhi	Dang	Tong	Lu	Diao	Yin	Kai	Zha	Zhu	Xi	Ting	Diu	Xian	Hua	Quan	Sha	Ha	Diao	Ge	Ming	Zheng	Se	Jiao	Yi	Chan	Chong	Tang	An	Yin	Ru	Zhu	Lao	Pu	Wu	Lai	Te	Lian	Keng";
    case 149:
      return "Xiao	Suo	Li	Zeng	Chu	Guo	Gao	E	Xiu	Cuo	Lue	Feng	Xin	Liu	Kai	Jian	Rui	Ti	Lang	Qin	Ju	A	Qiang	Zhe	Nuo	Cuo	Mao	Ben	Qi	De	Ke	Kun	Chang	Xi	Gu	Luo	Chui	Zhui	Jin	Zhi	Xian	Juan	Huo	Pei	Tan	Ding	Jian	Ju	Meng	Zi	Qie	Ying	Kai	Qiang	Si	E	Cha	Qiao	Zhong	Duan	Sou	Huang	Huan	Ai	Du	Mei	Lou	Zi	Fei	Mei	Mo	Zhen	Bo	Ge	Nie	Tang	Juan	Nie	Na	Liu	Gao	Bang	Yi	Jia	Bin	Rong	Biao	Tang	Man	Luo	Beng	Yong	Jing	Di	Zu	Xuan	Liu	Chan	Jue	Liao	Pu	Lu	Dun	Lan	Pu	Cuan	Qiang	Deng	Huo	Lei	Huan	Zhuo	Lian	Yi	Cha	Biao	La	Chan	Xiang	Zhang	Chang	Jiu	Ao	Die	Qu	Liao	Mi	Zhang	Men	Ma	Shuan	Shan	Huo	Men	Yan	Bi	Han	Bi	Shan	Kai	Kang	Beng	Hong	Run	San	Xian	Xian	Jian	Min	Xia	Shui	Dou	Zha	Nao	Zhan	Peng	Xia	Ling	Bian	Bi	Run	Ai	Guan	Ge	Ge	Fa	Chu	Hong	Gui	Min	Se	Kun	Lang	Lu	Ting	Sha	Ju	Yue	Yue	Chan	Qu	Lin	Chang	Shai	Kun	Yan	Wen	Yan	E	Hun	Yu	Wen	Hong	Bao	Hong	Qu	Yao	Wen	Ban	An	Wei	Yin	Kuo	Que	Lan	Du	Quan	Feng	Tian	Nie	Ta	Kai	He	Que	Chuang	Guan	Dou	Qi	Kui	Tang	Guan	Piao	Kan	Xi	Hui	Chan	Pi	Dang	Huan	Ta	Wen	Ta	Men	Shuan	Shan	Yan	Han	Bi	Wen	Chuang	Run	Wei	Xian	Hong	Jian	Min	Kang	Men	Zha	Nao	Gui	Wen	Ta	Min	Lu	Kai";
    case 150:
      return "Fa	Ge	He	Kun	Jiu	Yue	Lang	Du	Yu	Yan	Chang	Xi	Wen	Hun	Yan	Yan	Chan	Lan	Qu	Hui	Kuo	Que	He	Tian	Ta	Que	Kan	Huan	Fu	Fu	Le	Dui	Xin	Qian	Wu	Gai	Zhi	Yin	Yang	Dou	E	Sheng	Ban	Pei	Keng	Yun	Ruan	Zhi	Pi	Jing	Fang	Yang	Yin	Zhen	Jie	Cheng	E	Qu	Di	Zu	Zuo	Dian	Ling	A	Tuo	Tuo	Pi	Bing	Fu	Ji	Lu	Long	Chen	Xing	Duo	Lou	Mo	Jiang	Shu	Duo	Xian	Er	Gui	Yu	Gai	Shan	Jun	Qiao	Xing	Chun	Fu	Bi	Xia	Shan	Sheng	Zhi	Pu	Dou	Yuan	Zhen	Chu	Xian	Dao	Nie	Yun	Xian	Pei	Fei	Zou	Yi	Dui	Lun	Yin	Ju	Chui	Chen	Pi	Ling	Tao	Xian	Lu	Sheng	Xian	Yin	Zhu	Yang	Reng	Xia	Chong	Yan	Yin	Shu	Di	Yu	Long	Wei	Wei	Nie	Dui	Sui	An	Huang	Jie	Sui	Yin	Gai	Yan	Hui	Ge	Yun	Wu	Wei	Ai	Xi	Tang	Ji	Zhang	Dao	Ao	Xi	Yin	Sa	Rao	Lin	Tui	Deng	Jiao	Sui	Sui	Ao	Xian	Fen	Ni	Er	Ji	Dao	Xi	Yin	Zhi	Hui	Long	Xi	Li	Li	Li	Zhui	He	Zhi	Sun	Juan	Nan	Yi	Que	Yan	Qin	Qian	Xiong	Ya	Ji	Gu	Huan	Zhi	Gou	Juan	Ci	Yong	Ju	Chu	Hu	Za	Luo	Yu	Chou	Diao	Sui	Han	Wo	Shuang	Guan	Chu	Za	Yong	Ji	Xi	Chou	Liu	Li	Nan	Xue	Za	Ji	Ji	Yu	Yu	Xue	Na	Fou	Se	Mu	Wen	Fen	Pang	Yun	Li	Chi	Yang	Ling	Lei	An	Bao	Wu	Dian	Dang	Hu	Wu	Diao";
    case 151:
      return "Xu	Ji	Mu	Chen	Xiao	Zha	Ting	Zhen	Pei	Mei	Ling	Qi	Zhou	Huo	Sha	Fei	Hong	Zhan	Yin	Ni	Zhu	Tun	Lin	Ling	Dong	Ying	Wu	Ling	Shuang	Ling	Xia	Hong	Yin	Mai	Mai	Yun	Liu	Meng	Bin	Wu	Wei	Kuo	Yin	Xi	Yi	Ai	Dan	Teng	Xian	Yu	Lu	Long	Dai	Ji	Pang	Yang	Ba	Pi	Wei	Feng	Xi	Ji	Mai	Meng	Meng	Lei	Li	Huo	Ai	Fei	Dai	Long	Ling	Ai	Feng	Li	Bao	He	He	He	Bing	Qing	Qing	Jing	Tian	Zhen	Jing	Cheng	Qing	Jing	Jing	Dian	Jing	Tian	Fei	Fei	Kao	Mi	Mian	Mian	Bao	Ye	Tian	Hui	Ye	Ge	Ding	Cha	Qian	Ren	Di	Du	Wu	Ren	Qin	Jin	Xue	Niu	Ba	Yin	Sa	Na	Mo	Zu	Da	Ban	Yi	Yao	Tao	Bei	Jie	Hong	Pao	Yang	Bing	Yin	Ge	Tao	Jie	Xie	An	An	Hen	Gong	Qia	Da	Qiao	Ting	Man	Ying	Sui	Tiao	Qiao	Xuan	Kong	Beng	Ta	Shang	Bing	Kuo	Ju	La	Xie	Rou	Bang	Eng	Qiu	Qiu	He	Qiao	Mu	Ju	Jian	Bian	Di	Jian	Wen	Tao	Gou	Ta	Bei	Xie	Pan	Ge	Bi	Kuo	Tang	Lou	Gui	Qiao	Xue	Ji	Jian	Jiang	Chan	Da	Hu	Xian	Qian	Du	Wa	Jian	Lan	Wei	Ren	Fu	Mei	Quan	Ge	Wei	Qiao	Han	Chang	Kuo	Rou	Yun	She	Wei	Ge	Bai	Tao	Gou	Yun	Gao	Bi	Wei	Sui	Du	Wa	Du	Wei	Ren	Fu	Han	Wei	Yun	Tao	Jiu	Jiu	Xian	Xie	Xian	Ji	Yin	Za	Yun	Shao	Le	Peng	Huang	Ying	Yun	Peng	An	Yin	Xiang";
    case 152:
      return "Hu	Ye	Ding	Qing	Kui	Xiang	Shun	Han	Xu	Yi	Xu	E	Song	Kui	Qi	Hang	Yu	Wan	Ban	Dun	Di	Dan	Pan	Po	Ling	Che	Jing	Lei	He	Qiao	E	E	Wei	Xie	Kuo	Shen	Yi	Yi	Hai	Dui	Yu	Ping	Lei	Fu	Jia	Tou	Hui	Kui	Jia	Luo	Ting	Cheng	Ying	Yun	Hu	Han	Jing	Tui	Tui	Pin	Lai	Tui	Zi	Zi	Chui	Ding	Lai	Tan	Han	Qian	Ke	Cui	Xuan	Qin	Yi	Sai	Ti	E	E	Yan	Wen	Kan	Yong	Zhuan	Yan	Xian	Xin	Yi	Yuan	Sang	Dian	Dian	Jiang	Kui	Lei	Lao	Piao	Wai	Man	Cu	Yao	Hao	Qiao	Gu	Xun	Yan	Hui	Chan	Ru	Meng	Bin	Xian	Pin	Lu	Lan	Nie	Quan	Ye	Ding	Qing	Han	Xiang	Shun	Xu	Xu	Wan	Gu	Dun	Qi	Ban	Song	Hang	Yu	Lu	Ling	Po	Jing	Jie	Jia	Ting	He	Ying	Jiong	Ke	Yi	Pin	Hui	Tui	Han	Ying	Ying	Ke	Ti	Yong	E	Zhuan	Yan	E	Nie	Man	Dian	Sang	Hao	Lei	Chan	Ru	Pin	Quan	Feng	Biao	Gua	Fu	Xia	Zhan	Biao	Sa	Ba	Tai	Lie	Gua	Xuan	Shao	Ju	Biao	Si	Wei	Yang	Yao	Sou	Kai	Sou	Fan	Liu	Xi	Liu	Piao	Piao	Liu	Biao	Biao	Biao	Liao	Biao	Se	Feng	Xiu	Feng	Yang	Zhan	Biao	Sa	Ju	Si	Sou	Yao	Liu	Piao	Biao	Biao	Fei	Fan	Fei	Fei	Shi	Shi	Can	Ji	Ding	Si	Tuo	Zhan	Sun	Xiang	Tun	Ren	Yu	Juan	Chi	Yin	Fan	Fan	Sun	Yin	Tou	Yi	Zuo	Bi	Jie	Tao	Bao	Ci	Tie	Si	Bao	Shi	Duo";
    case 153:
      return "Hai	Ren	Tian	Jiao	Jia	Bing	Yao	Tong	Ci	Xiang	Yang	Juan	Er	Yan	Le	Xi	Can	Bo	Nei	E	Bu	Jun	Dou	Su	Yu	Shi	Yao	Hun	Guo	Shi	Jian	Zhui	Bing	Xian	Bu	Ye	Tan	Fei	Zhang	Wei	Guan	E	Nuan	Yun	Hu	Huang	Tie	Hui	Jian	Hou	Ai	Tang	Fen	Wei	Gu	Cha	Song	Tang	Bo	Gao	Xi	Kui	Liu	Sou	Tao	Ye	Wen	Mo	Tang	Man	Bi	Yu	Xiu	Jin	San	Kui	Zhuan	Shan	Chi	Dan	Yi	Ji	Rao	Cheng	Yong	Tao	Wei	Xiang	Zhan	Fen	Hai	Meng	Yan	Mo	Chan	Xiang	Luo	Zan	Nang	Shi	Ding	Ji	Tuo	Xing	Tun	Xi	Ren	Yu	Chi	Fan	Yin	Jian	Shi	Bao	Si	Duo	Yi	Er	Rao	Xiang	He	Le	Jiao	Xi	Bing	Bo	Dou	E	Yu	Nei	Jun	Guo	Hun	Xian	Guan	Cha	Kui	Gu	Sou	Chan	Ye	Mo	Bo	Liu	Xiu	Jin	Man	San	Zhuan	Nang	Shou	Kui	Guo	Xiang	Fen	Bo	Ni	Bi	Bo	Tu	Han	Fei	Jian	An	Ai	Fu	Xian	Yun	Xin	Fen	Pin	Xin	Ma	Yu	Feng	Han	Di	Tuo	Zhe	Chi	Xun	Zhu	Zhi	Pei	Xin	Ri	Sa	Yun	Wen	Zhi	Dan	Lu	You	Bo	Bao	Jue	Tuo	Yi	Qu	Wen	Qu	Jiong	Po	Zhao	Yuan	Pei	Zhou	Ju	Zhu	Nu	Ju	Pi	Zang	Jia	Ling	Zhen	Tai	Fu	Yang	Shi	Bi	Tuo	Tuo	Si	Liu	Ma	Pian	Tao	Zhi	Rong	Teng	Dong	Xun	Quan	Shen	Jiong	Er	Hai	Bo	Zhu	Yin	Luo	Zhou	Dan	Hai	Liu	Ju	Song	Qin	Mang	Lang	Han	Tu	Xuan	Tui	Jun";
    case 154:
      return "E	Cheng	Xing	Ai	Lu	Zhui	Zhou	She	Pian	Kun	Tao	Lai	Zong	Ke	Qi	Qi	Yan	Fei	Sao	Yan	Ge	Yao	Wu	Pian	Cong	Pian	Qian	Fei	Huang	Qian	Huo	Yu	Ti	Quan	Xia	Zong	Kui	Rou	Si	Gua	Tuo	Gui	Sou	Qian	Cheng	Zhi	Liu	Peng	Teng	Xi	Cao	Du	Yan	Yuan	Zou	Sao	Shan	Qi	Zhi	Shuang	Lu	Xi	Luo	Zhang	Mo	Ao	Can	Biao	Cong	Qu	Bi	Zhi	Yu	Xu	Hua	Bo	Su	Xiao	Lin	Zhan	Dun	Liu	Tuo	Ceng	Dian	Jiao	Tie	Yan	Luo	Zhan	Jing	Yi	Ye	Tuo	Pin	Zhou	Yan	Long	Lu	Teng	Xiang	Ji	Shuang	Ju	Xi	Huan	Li	Biao	Ma	Yu	Tuo	Xun	Chi	Qu	Ri	Bo	Lu	Zang	Shi	Si	Fu	Ju	Zou	Zhu	Tuo	Nu	Jia	Yi	Dai	Xiao	Ma	Yin	Jiao	Hua	Luo	Hai	Pian	Biao	Li	Cheng	Yan	Xing	Qin	Jun	Qi	Qi	Ke	Zhui	Zong	Su	Can	Pian	Zhi	Kui	Sao	Wu	Ao	Liu	Qian	Shan	Biao	Luo	Cong	Chan	Zhou	Ji	Shuang	Xiang	Gu	Wei	Wei	Wei	Yu	Gan	Yi	Ang	Tou	Jie	Bao	Bei	Ci	Ti	Di	Ku	Hai	Qiao	Hou	Kua	Ge	Tui	Geng	Pian	Bi	Ke	Qia	Yu	Sui	Lou	Bo	Xiao	Bang	Bo	Ci	Kuan	Bin	Mo	Liao	Lou	Xiao	Du	Zang	Sui	Ti	Bin	Kuan	Lu	Gao	Gao	Qiao	Kao	Qiao	Lao	Sao	Biao	Kun	Kun	Di	Fang	Xiu	Ran	Mao	Dan	Kun	Bin	Fa	Tiao	Pi	Zi	Fa	Ran	Ti	Bao	Bi	Mao	Fu	Er	Rong	Qu	Gong	Xiu	Kuo	Ji	Peng	Zhua	Shao	Suo";
    case 155:
      return "Ti	Li	Bin	Zong	Di	Peng	Song	Zheng	Quan	Zong	Shun	Jian	Tuo	Hu	La	Jiu	Qi	Lian	Zhen	Bin	Peng	Ma	San	Man	Man	Seng	Xu	Lie	Qian	Qian	Nang	Huan	Kuo	Ning	Bin	Lie	Rang	Dou	Dou	Nao	Hong	Xi	Dou	Han	Dou	Dou	Jiu	Chang	Yu	Yu	Ge	Yan	Fu	Qin	Gui	Zong	Liu	Gui	Shang	Yu	Gui	Mei	Ji	Qi	Ga	Kui	Hun	Ba	Po	Mei	Xu	Yan	Xiao	Liang	Yu	Tui	Qi	Wang	Liang	Wei	Gan	Chi	Piao	Bi	Mo	Ji	Xu	Chou	Yan	Zhan	Yu	Dao	Ren	Jie	Ba	Hong	Tuo	Diao	Ji	Xu	E	E	Sha	Hang	Tun	Mo	Jie	Shen	Ban	Yuan	Pi	Lu	Wen	Hu	Lu	Za	Fang	Fen	Na	You	Pian	Mo	He	Xia	Qu	Han	Pi	Ling	Tuo	Bo	Qiu	Ping	Fu	Bi	Ci	Wei	Ju	Diao	Ba	You	Gun	Pi	Nian	Xing	Tai	Bao	Fu	Zha	Ju	Gu	Shi	Dong	Dai	Ta	Jie	Shu	Hou	Xiang	Er	An	Wei	Zhao	Zhu	Yin	Lie	Luo	Tong	Ti	Yi	Bing	Wei	Jiao	Ku	Gui	Xian	Ge	Hui	Lao	Fu	Kao	Xiu	Duo	Jun	Ti	Mian	Shao	Zha	Suo	Qin	Yu	Nei	Zhe	Gun	Geng	Su	Wu	Qiu	Shan	Pu	Huan	Tiao	Li	Sha	Sha	Kao	Meng	Cheng	Li	Zou	Xi	Yong	Shen	Zi	Qi	Zheng	Xiang	Nei	Chun	Ji	Diao	Qie	Gu	Zhou	Dong	Lai	Fei	Ni	Yi	Kun	Lu	Jiu	Chang	Jing	Lun	Ling	Zou	Li	Meng	Zong	Zhi	Nian	Hu	Yu	Di	Shi	Shen	Huan	Ti	Hou	Xing	Zhu	La	Zong	Zei	Bian	Bian";
    case 156:
      return "Huan	Quan	Zei	Wei	Wei	Yu	Chun	Rou	Die	Huang	Lian	Yan	Qiu	Qiu	Jian	Bi	E	Yang	Fu	Sai	Gan	Xia	Tuo	Hu	Shi	Ruo	Xuan	Wen	Qian	Hao	Wu	Fang	Sao	Liu	Ma	Shi	Shi	Guan	Zi	Teng	Ta	Yao	E	Yong	Qian	Qi	Wen	Ruo	Shen	Lian	Ao	Le	Hui	Min	Ji	Tiao	Qu	Jian	Shen	Man	Xi	Qiu	Biao	Ji	Ji	Zhu	Jiang	Xiu	Zhuan	Yong	Zhang	Kang	Xue	Bie	Yu	Qu	Xiang	Bo	Jiao	Xun	Su	Huang	Zun	Shan	Shan	Fan	Gui	Lin	Xun	Miao	Xi	Zeng	Xiang	Fen	Guan	Hou	Kuai	Zei	Sao	Zhan	Gan	Gui	Ying	Li	Chang	Lei	Shu	Ai	Ru	Ji	Xu	Hu	Shu	Li	Lie	Li	Mie	Zhen	Xiang	E	Lu	Guan	Li	Xian	Yu	Dao	Ji	You	Tun	Lu	Fang	Ba	He	Ba	Ping	Nian	Lu	You	Zha	Fu	Bo	Bao	Hou	Pi	Tai	Gui	Jie	Kao	Wei	Er	Tong	Zei	Hou	Kuai	Ji	Jiao	Xian	Zha	Xiang	Xun	Geng	Li	Lian	Jian	Li	Shi	Tiao	Gun	Sha	Huan	Jun	Ji	Yong	Qing	Ling	Qi	Zou	Fei	Kun	Chang	Gu	Ni	Nian	Diao	Jing	Shen	Shi	Zi	Fen	Die	Bi	Chang	Ti	Wen	Wei	Sai	E	Qiu	Fu	Huang	Quan	Jiang	Bian	Sao	Ao	Qi	Ta	Guan	Yao	Pang	Jian	Le	Biao	Xue	Bie	Man	Min	Yong	Wei	Xi	Gui	Shan	Lin	Zun	Hu	Gan	Li	Zhan	Guan	Niao	Yi	Fu	Li	Jiu	Bu	Yan	Fu	Diao	Ji	Feng	Ru	Gan	Shi	Feng	Ming	Bao	Yuan	Zhi	Hu	Qin	Fu	Ban	Wen	Jian	Shi	Yu";
    case 157:
      return "Fou	Yao	Jue	Jue	Pi	Huan	Zhen	Bao	Yan	Ya	Zheng	Fang	Feng	Wen	Ou	Dai	Ge	Ru	Ling	Mie	Fu	Tuo	Min	Li	Bian	Zhi	Ge	Yuan	Ci	Qu	Xiao	Chi	Dan	Ju	Yao	Gu	Zhong	Yu	Yang	Yu	Ya	Tie	Yu	Tian	Ying	Dui	Wu	Er	Gua	Ai	Zhi	Yan	Heng	Xiao	Jia	Lie	Zhu	Yang	Ti	Hong	Luo	Ru	Mou	Ge	Ren	Jiao	Xiu	Zhou	Chi	Luo	Heng	Nian	E	Luan	Jia	Ji	Tu	Huan	Tuo	Bu	Wu	Juan	Yu	Bo	Jun	Jun	Bi	Xi	Jun	Ju	Tu	Jing	Ti	E	E	Kuang	Hu	Wu	Shen	Lai	Jiao	Pan	Lu	Pi	Shu	Fu	An	Zhuo	Peng	Qin	Qian	Bei	Diao	Lu	Que	Jian	Ju	Tu	Ya	Yuan	Qi	Li	Ye	Zhui	Kong	Duo	Kun	Sheng	Qi	Jing	Yi	Yi	Jing	Zi	Lai	Dong	Qi	Chun	Geng	Ju	Jue	Yi	Zun	Ji	Shu	Ying	Chi	Miao	Rou	An	Qiu	Ti	Hu	Ti	E	Jie	Mao	Fu	Chun	Tu	Yan	He	Yuan	Pian	Kun	Mei	Hu	Ying	Chuan	Wu	Ju	Dong	Cang	Fang	He	Ying	Yuan	Xian	Weng	Shi	He	Chu	Tang	Xia	Ruo	Liu	Ji	Gu	Jian	Sun	Han	Ci	Ci	Yi	Yao	Yan	Ji	Li	Tian	Kou	Ti	Ti	Yi	Tu	Ma	Xiao	Gao	Tian	Chen	Ji	Tuan	Zhe	Ao	Yao	Yi	Ou	Chi	Zhi	Liu	Yong	Lu	Bi	Shuang	Zhuo	Yu	Wu	Jue	Yin	Ti	Si	Jiao	Yi	Hua	Bi	Ying	Su	Huang	Fan	Jiao	Liao	Yan	Gao	Jiu	Xian	Xian	Tu	Mai	Zun	Yu	Ying	Lu	Tuan	Xian	Xue	Yi	Pi";
    case 158:
      return "Shu	Luo	Xi	Yi	Ji	Ze	Yu	Zhan	Ye	Yang	Pi	Ning	Hu	Mi	Ying	Meng	Di	Yue	Yu	Lei	Bu	Lu	He	Long	Shuang	Yue	Ying	Guan	Qu	Li	Luan	Niao	Jiu	Ji	Yuan	Ming	Shi	Ou	Ya	Cang	Bao	Zhen	Gu	Dong	Lu	Ya	Xiao	Yang	Ling	Chi	Qu	Yuan	Xue	Tuo	Si	Zhi	Er	Gua	Xiu	Heng	Zhou	Ge	Luan	Hong	Wu	Bo	Li	Juan	Gu	E	Yu	Xian	Ti	Wu	Que	Miao	An	Kun	Bei	Peng	Qian	Chun	Geng	Yuan	Su	Hu	He	E	Gu	Qiu	Ci	Mei	Wu	Yi	Yao	Weng	Liu	Ji	Yi	Jian	He	Yi	Ying	Zhe	Liu	Liao	Jiao	Jiu	Yu	Lu	Huan	Zhan	Ying	Hu	Meng	Guan	Shuang	Lu	Jin	Ling	Jian	Xian	Cuo	Jian	Jian	Yan	Cuo	Lu	You	Cu	Ji	Pao	Cu	Pao	Zhu	Jun	Zhu	Jian	Mi	Mi	Yu	Liu	Chen	Jun	Lin	Ni	Qi	Lu	Jiu	Jun	Jing	Li	Xiang	Xian	Jia	Mi	Li	She	Zhang	Lin	Jing	Qi	Ling	Yan	Cu	Mai	Mai	He	Chao	Fu	Mian	Mian	Fu	Pao	Qu	Qu	Mou	Fu	Xian	Lai	Qu	Mian	Chi	Feng	Fu	Qu	Mian	Ma	Me	Mo	Hui	Mo	Zou	Nun	Fen	Huang	Huang	Jin	Guang	Tian	Tou	Hong	Hua	Kuang	Hong	Shu	Li	Nian	Chi	Hei	Hei	Yi	Qian	Dan	Xi	Tun	Mo	Mo	Qian	Dai	Chu	You	Dian	Yi	Xia	Yan	Qu	Mei	Yan	Qing	Yue	Li	Dang	Du	Can	Yan	Yan	Yan	Dan	An	Zhen	Dai	Can	Yi	Mei	Zhan	Yan	Du	Lu	Zhi	Fen	Fu	Fu	Mian	Min	Yuan";
    case 159:
      return "Cu	Qu	Chao	Wa	Zhu	Zhi	Meng	Ao	Bie	Tuo	Bi	Yuan	Chao	Tuo	Ding	Mi	Nai	Ding	Zi	Gu	Gu	Dong	Fen	Tao	Yuan	Pi	Chang	Gao	Qi	Yuan	Tang	Teng	Shu	Shu	Fen	Fei	Wen	Ba	Diao	Tuo	Zhong	Qu	Sheng	Shi	You	Shi	Ting	Wu	Ju	Jing	Hun	Ju	Yan	Tu	Si	Xi	Xian	Yan	Lei	Bi	Yao	Qiu	Han	Wu	Wu	Hou	Xie	E	Zha	Xiu	Weng	Zha	Nong	Nang	Qi	Zhai	Ji	Zi	Ji	Ji	Qi	Ji	Chi	Chen	Chen	He	Ya	Yin	Xie	Bao	Ze	Xie	Chai	Chi	Yan	Ju	Tiao	Ling	Ling	Chu	Quan	Xie	Ken	Nie	Jiu	Yao	Chuo	Yun	Yu	Chu	Yi	Ni	Ze	Zou	Qu	Yun	Yan	Ou	E	Wo	Yi	Ci	Zou	Dian	Chu	Jin	Ya	Chi	Chen	He	Yin	Ju	Ling	Bao	Tiao	Zi	Yin	Yu	Chuo	Qu	Wo	Long	Pang	Gong	Pang	Yan	Long	Long	Gong	Kan	Da	Ling	Da	Long	Gong	Kan	Gui	Qiu	Bie	Gui	Yue	Chui	He	Jue	Xie	Yu	Soeng	Syu	Zeoi	Gan	Zhan	Gon	Wang	Ji	Jik	Mou	Zou	Ju	Fu			Shou						Luan	Sen					Hung	Kashidori	Shan	Liang		Futsu	Zheng	Ce	Wu	Zi	Hei	Liang	Gang	Ta	Mai	Zau				Ge	Dan																						Ao	Tian	Ni	Seki		Han	Ba	Lao	Tuo	Dong	Zhi	Lang	An	Tuo	Mi	Mai	Bu	Jia		Lang	Xing";
    case 160:
      return "it	ix	i	ip	iet	iex	ie	iep	at	ax	a	ap	uox	uo	uop	ot	ox	o	op	ex	e	w	bit	bix	bi	bip	biet	biex	bie	biep	bat	bax	ba	bap	buox	buo	buop	bot	box	bo	bop	bex	be	bep	but	bux	bu	bup	burx	bur	byt	byx	by	byp	byrx	byr	pit	pix	pi	pip	piex	pie	piep	pat	pax	pa	pap	puox	puo	puop	pot	pox	po	pop	put	pux	pu	pup	purx	pur	pyt	pyx	py	pyp	pyrx	pyr	bbit	bbix	bbi	bbip	bbiet	bbiex	bbie	bbiep	bbat	bbax	bba	bbap	bbuox	bbuo	bbuop	bbot	bbox	bbo	bbop	bbex	bbe	bbep	bbut	bbux	bbu	bbup	bburx	bbur	bbyt	bbyx	bby	bbyp	nbit	nbix	nbi	nbip	nbiex	nbie	nbiep	nbat	nbax	nba	nbap	nbot	nbox	nbo	nbop	nbut	nbux	nbu	nbup	nburx	nbur	nbyt	nbyx	nby	nbyp	nbyrx	nbyr	hmit	hmix	hmi	hmip	hmiex	hmie	hmiep	hmat	hmax	hma	hmap	hmuox	hmuo	hmuop	hmot	hmox	hmo	hmop	hmut	hmux	hmu	hmup	hmurx	hmur	hmyx	hmy	hmyp	hmyrx	hmyr	mit	mix	mi	mip	miex	mie	miep	mat	max	ma	map	muot	muox	muo	muop	mot	mox	mo	mop	mex	me	mut	mux	mu	mup	murx	mur	myt	myx	my	myp	fit	fix	fi	fip	fat	fax	fa	fap	fox	fo	fop	fut	fux	fu	fup	furx	fur	fyt	fyx	fy	fyp	vit	vix	vi	vip	viet	viex	vie	viep	vat	vax	va	vap	vot	vox	vo	vop	vex	vep	vut	vux	vu	vup	vurx	vur	vyt	vyx	vy	vyp	vyrx	vyr";
    case 161:
      return "dit	dix	di	dip	diex	die	diep	dat	dax	da	dap	duox	duo	dot	dox	do	dop	dex	de	dep	dut	dux	du	dup	durx	dur	tit	tix	ti	tip	tiex	tie	tiep	tat	tax	ta	tap	tuot	tuox	tuo	tuop	tot	tox	to	top	tex	te	tep	tut	tux	tu	tup	turx	tur	ddit	ddix	ddi	ddip	ddiex	ddie	ddiep	ddat	ddax	dda	ddap	dduox	dduo	dduop	ddot	ddox	ddo	ddop	ddex	dde	ddep	ddut	ddux	ddu	ddup	ddurx	ddur	ndit	ndix	ndi	ndip	ndiex	ndie	ndat	ndax	nda	ndap	ndot	ndox	ndo	ndop	ndex	nde	ndep	ndut	ndux	ndu	ndup	ndurx	ndur	hnit	hnix	hni	hnip	hniet	hniex	hnie	hniep	hnat	hnax	hna	hnap	hnuox	hnuo	hnot	hnox	hnop	hnex	hne	hnep	hnut	nit	nix	ni	nip	niex	nie	niep	nax	na	nap	nuox	nuo	nuop	not	nox	no	nop	nex	ne	nep	nut	nux	nu	nup	nurx	nur	hlit	hlix	hli	hlip	hliex	hlie	hliep	hlat	hlax	hla	hlap	hluox	hluo	hluop	hlox	hlo	hlop	hlex	hle	hlep	hlut	hlux	hlu	hlup	hlurx	hlur	hlyt	hlyx	hly	hlyp	hlyrx	hlyr	lit	lix	li	lip	liet	liex	lie	liep	lat	lax	la	lap	luot	luox	luo	luop	lot	lox	lo	lop	lex	le	lep	lut	lux	lu	lup	lurx	lur	lyt	lyx	ly	lyp	lyrx	lyr	git	gix	gi	gip	giet	giex	gie	giep	gat	gax	ga	gap	guot	guox	guo	guop	got	gox	go	gop	get	gex	ge	gep	gut	gux	gu	gup	gurx	gur	kit	kix	ki	kip	kiex	kie	kiep	kat";
    case 162:
      return "kax	ka	kap	kuox	kuo	kuop	kot	kox	ko	kop	ket	kex	ke	kep	kut	kux	ku	kup	kurx	kur	ggit	ggix	ggi	ggiex	ggie	ggiep	ggat	ggax	gga	ggap	gguot	gguox	gguo	gguop	ggot	ggox	ggo	ggop	gget	ggex	gge	ggep	ggut	ggux	ggu	ggup	ggurx	ggur	mgiex	mgie	mgat	mgax	mga	mgap	mguox	mguo	mguop	mgot	mgox	mgo	mgop	mgex	mge	mgep	mgut	mgux	mgu	mgup	mgurx	mgur	hxit	hxix	hxi	hxip	hxiet	hxiex	hxie	hxiep	hxat	hxax	hxa	hxap	hxuot	hxuox	hxuo	hxuop	hxot	hxox	hxo	hxop	hxex	hxe	hxep	ngiex	ngie	ngiep	ngat	ngax	nga	ngap	nguot	nguox	nguo	ngot	ngox	ngo	ngop	ngex	nge	ngep	hit	hiex	hie	hat	hax	ha	hap	huot	huox	huo	huop	hot	hox	ho	hop	hex	he	hep	wat	wax	wa	wap	wuox	wuo	wuop	wox	wo	wop	wex	we	wep	zit	zix	zi	zip	ziex	zie	ziep	zat	zax	za	zap	zuox	zuo	zuop	zot	zox	zo	zop	zex	ze	zep	zut	zux	zu	zup	zurx	zur	zyt	zyx	zy	zyp	zyrx	zyr	cit	cix	ci	cip	ciet	ciex	cie	ciep	cat	cax	ca	cap	cuox	cuo	cuop	cot	cox	co	cop	cex	ce	cep	cut	cux	cu	cup	curx	cur	cyt	cyx	cy	cyp	cyrx	cyr	zzit	zzix	zzi	zzip	zziet	zziex	zzie	zziep	zzat	zzax	zza	zzap	zzox	zzo	zzop	zzex	zze	zzep	zzux	zzu	zzup	zzurx	zzur	zzyt	zzyx	zzy	zzyp	zzyrx	zzyr	nzit	nzix	nzi	nzip	nziex	nzie	nziep	nzat	nzax	nza	nzap	nzuox	nzuo	nzox	nzop	nzex	nze	nzux	nzu";
    case 163:
      return "nzup	nzurx	nzur	nzyt	nzyx	nzy	nzyp	nzyrx	nzyr	sit	six	si	sip	siex	sie	siep	sat	sax	sa	sap	suox	suo	suop	sot	sox	so	sop	sex	se	sep	sut	sux	su	sup	surx	sur	syt	syx	sy	syp	syrx	syr	ssit	ssix	ssi	ssip	ssiex	ssie	ssiep	ssat	ssax	ssa	ssap	ssot	ssox	sso	ssop	ssex	sse	ssep	ssut	ssux	ssu	ssup	ssyt	ssyx	ssy	ssyp	ssyrx	ssyr	zhat	zhax	zha	zhap	zhuox	zhuo	zhuop	zhot	zhox	zho	zhop	zhet	zhex	zhe	zhep	zhut	zhux	zhu	zhup	zhurx	zhur	zhyt	zhyx	zhy	zhyp	zhyrx	zhyr	chat	chax	cha	chap	chuot	chuox	chuo	chuop	chot	chox	cho	chop	chet	chex	che	chep	chux	chu	chup	churx	chur	chyt	chyx	chy	chyp	chyrx	chyr	rrax	rra	rruox	rruo	rrot	rrox	rro	rrop	rret	rrex	rre	rrep	rrut	rrux	rru	rrup	rrurx	rrur	rryt	rryx	rry	rryp	rryrx	rryr	nrat	nrax	nra	nrap	nrox	nro	nrop	nret	nrex	nre	nrep	nrut	nrux	nru	nrup	nrurx	nrur	nryt	nryx	nry	nryp	nryrx	nryr	shat	shax	sha	shap	shuox	shuo	shuop	shot	shox	sho	shop	shet	shex	she	shep	shut	shux	shu	shup	shurx	shur	shyt	shyx	shy	shyp	shyrx	shyr	rat	rax	ra	rap	ruox	ruo	ruop	rot	rox	ro	rop	rex	re	rep	rut	rux	ru	rup	rurx	rur	ryt	ryx	ry	ryp	ryrx	ryr	jit	jix	ji	jip	jiet	jiex	jie	jiep	juot	juox	juo	juop	jot	jox	jo	jop	jut	jux	ju	jup	jurx	jur	jyt	jyx	jy	jyp	jyrx	jyr	qit	qix	qi	qip";
    case 164:
      return "qiet	qiex	qie	qiep	quot	quox	quo	quop	qot	qox	qo	qop	qut	qux	qu	qup	qurx	qur	qyt	qyx	qy	qyp	qyrx	qyr	jjit	jjix	jji	jjip	jjiet	jjiex	jjie	jjiep	jjuox	jjuo	jjuop	jjot	jjox	jjo	jjop	jjut	jjux	jju	jjup	jjurx	jjur	jjyt	jjyx	jjy	jjyp	njit	njix	nji	njip	njiet	njiex	njie	njiep	njuox	njuo	njot	njox	njo	njop	njux	nju	njup	njurx	njur	njyt	njyx	njy	njyp	njyrx	njyr	nyit	nyix	nyi	nyip	nyiet	nyiex	nyie	nyiep	nyuox	nyuo	nyuop	nyot	nyox	nyo	nyop	nyut	nyux	nyu	nyup	xit	xix	xi	xip	xiet	xiex	xie	xiep	xuox	xuo	xot	xox	xo	xop	xyt	xyx	xy	xyp	xyrx	xyr	yit	yix	yi	yip	yiet	yiex	yie	yiep	yuot	yuox	yuo	yuop	yot	yox	yo	yop	yut	yux	yu	yup	yurx	yur	yyt	yyx	yy	yyp	yyrx	yyr				QOT	LI	KIT	NYIP	CYP	SSI	GGOP	GEP	MI	HXIT	LYR	BBUT	MOP	YO	PUT	HXUO	TAT	GA	ZUP	CYT	DDUR	BUR	GGUO	NYOP	TU	OP	JJUT	ZOT	PYT	HMO	YIT	VUR	SHY	VEP	ZA	JO	NZUP	JJY	GOT	JJIE	WO	DU	SHUR	LIE	CY	CUOP	CIP	HXOP	SHAT	ZUR	SHOP	CHE	ZZIET	NBIE	KE										bb	b	p	dd	d	t	gg	g	k	rr	zh	ch	zz	z	c	m	n	l	s	r	ss	ng	h	h	h	f	w	sh	y	e	a	ai	ei	ei	i	o	u	u	e	e	l	q		x	r	t	,	.";
    case 165:
      return "e	e	he	we	we	pe	be	be	mbe	kpe	mgbe	gbe	fe	ve	te	the	de	dhe	le	re	de	nde	se	she	ze	zhe	che	je	nje	ye	ke	ngge	ge	me	ne	nye	i	i	hi	hi	wi	wi	pi	bi	bi	mbi	kpi	mgbi	gbi	fi	vi	ti	thi	di	dhi	li	ri	di	ndi	si	shi	zi	zhi	chi	ji	nji	yi	ki	nggi	gi	mi	ni	nyi	a	a	nga	ha	ha	wa	wa	pa	ba	ba	mba	kpa	kpa	mgba	gba	fa	va	ta	tha	da	dha	la	ra	da	nda	sa	sha	za	zha	cha	ja	nja	ya	ka	ka	ngga	ga	ma	na	nya	o	o	ho	wo	wo	po	bo	bo	mbo	kpo	mgbo	gbo	fo	vo	to	tho	do	dho	lo	ro	do	ndo	so	sho	zo	zho	cho	jo	njo	yo	ko	nggo	go	mo	no	nyo	u	u	hu	hu	wu	wu	pu	bu	bu	mbu	kpu	mgbu	gbu	fu	vu	tu	thu	du	dhu	lu	ru	du	ndu	su	shu	zu	zhu	chu	ju	nju	yu	ku	nggu	gu	mu	nu	nyu	o	o	ngo	ho	ho	wo	wo	po	bo	bo	mbo	kpo	mgbo	gbo	gbo	fo	vo	to	tho	do	dho	lo	ro	do	ndo	so	sho	zo	zho	cho	jo	njo	yo	ko	nggo	go	mo	no	nyo	e	e	nge	he	he	we	we	pe	be	be	mbe	kpe	kpe	mgbe	gbe	gbe	fe	ve	te	the	de	dhe	le	re	de	nde	se	she	ze	zhe	che";
    case 166:
      return "je	nje	ye	ke	ngge	ngge	ge	ge	me	ne	nye	ng	h	,	.	?	fa	ka	so	Feng	Keng	Ting	Nii	Bang	Faa	Taa	Dang	Dong	Kung	Tong	Doo	Jong	0	1	2	3	4	5	6	7	8	9	ma	do																					Z	z	Dz	dz	Dz	dz	I	i	Dj	dj	U	u	O	o	'	'	Y	y	Ie	ie	Oi	oi	Ia	ia	E	e	O	o	Ie	ie	In	in	Ts	ts	Dg	dg	Lg	lg	Mg	mg	O	o	Oo	oo	Oo	oo	O	.	10000000	100000000	1000000000	*	ie	i	i	u	'	y	'	o	'	'	'	'	Dw	dw	Dzw	dzw	Zhw	zhw	Cch	cch	Dz	dz	T	t	Tw	tw	Tsw	tsw	Ts	ts	Tch	tch	Hw	hw	Shw	shw	Oo	oo	O	o	'	'	f	ie	a	ka	u	ku	e	re	te	o	nyi	i	la	pa	rii	rie	lee	mee	taa	ndaa	njem	m	suu	mu	shii	si	shux	sux	kye	ket	nue	nu	njue	yo'	shu	yu'	ya	nsha	kux	pux	nje	nte	pu	wu	pe	fe	ru	lu	mi	ni	rux	re	ken	ngkwen	ngga	nga	sho	pue	fu	fom	wa	na	li	pi	lo'	ko	mben	ren	men	ma	ti	ki	1	2	3	4	5	6	7	8	9	0	'	`	*	.	:	,	;	?";
    case 167:
      return "1	2	3	4	5	6	7	8	5	4	3	2	1	5	4	3	2	1	5	4	3	2	1	'	'	-	~	^	!	!	^	^	-	_	'	'	`	`	H	h	Tz	tz	3	3	4	4	4,	4,	f	s	Aa	aa	Ao	ao	Au	au	Av	av	Av	av	Ay	ay	C.	c.	K.	k.	K.	k.	K.	k.	L	l	L.	l.	O.	o.	O	o	Oo	oo	P.	p.	P.	p.	P.	p.	Q.	q.	Q.	q.	R	r	R.	r.	V.	v.	Vy	vy	Z	z	Th.	th.	Th.	th.	V	v	&	&	S.	s.	'	'	'	d.	l.	m.	n.	r.	r.	t.	s.	D	d	F	f	G	Ng	ng	Ll	ll	R	r	S	s	T	t	^	:	=	'	'	Y	l	-	N	n	C	c	c	h	B	b	F	f	Ae	ae	Oe	oe	Ue	ue	G	g	K	k	N	n	R	r	S	s	H	E	G	L	I	q	K	T	J	X	B	b	O	o	U	u	A	a	I	i	U	u	O	o	W	w	C	S	Z	D	d	S	s	U	S	s			G	g		thth		ww	S	s	S	s	L	l	L																						C	F	Q	H	h	I	H	oe	w	F	P	M	I	M'";
    case 168:
      return "a	i	i	u	e	o		k	kh	g	gh	ng	c	ch	j	jh	t	th	d	dh	t	th	d	dh	n	p	ph	b	bh	m	r	l	r	s	h	a	i	u	e	o	1	2	3	4					1	2	3	1	2	3	/	-	Rs	'							k	kh	g	ng	c	ch	j	ny	t	th	d	n	p	ph	b	m	ts	tsh	dz	w	zh	z	-	y	r	l	sh	s	h	'	i	u	e	o	q	x	f	gg	ee	w	y	tt	tth	dd	nn	y''	sh'	h'	f''	r	r	^	@	@@	/	//									m	h	a	a	i	i	u	u	r	r	l	l	e	e	ai	o	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	l	h	a	i	i	u	u	r	r	l	l	e	e	ai	o	o	au		m									,	.	0	1	2	3	4	5	6	7	8	9							0	1	2	3	4	5	6	7	8	9	a	u	k	n	p	r	v	'	m	m	mm	m2	m3	m'	-	-	^	~	*	Om	a	a";
    case 169:
      return "0	1	2	3	4	5	6	7	8	9	k	hk	g	ng	s	hs	z	ny	t	ht	n	p	hp	m	d	b	r	y	l	w	th	h	v	j	a	oe	i	o	ue	ae	u	e	aw				'	,	k	g	ng	t	d	n	p	b	m	c	j	ny	s	r	l	y	w	h	mb	ngg	nd	nyj	'	i	u	e	ai	o	au	eu	ea	ng	n	r	h													*	dm	db	ds	dj	lg	lkk	ld	ltt	lm	lb	lpp	lv	ls	lj	lk	mg	md	ms	bst	bk	bh	ssb	l	h	jjh	tt	ph	hs	qq				m	ng	r	h	a	i	i	i	u	re	le	lo	e	ai	o	k	q	kh	g	gh	ng	c	ch	j	jny	jh	ny	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	r	l	w	s	s	s	h	'	a	o	i	i	u	u	e	ai	e	re	y	r		<	>	@	@@	@@@	*	:	,	.	|	||	{	}		-	0	1	2	3	4	5	6	7	8	9					^	~	gh	ch	jh	n	bh		-	n	f	g	gh	j	jh	d	dh	n	0	1	2	3	4	5	6	7	8	9	l	d	dh	b	bh";
    case 170:
      return "a	i	u	e	ai	o	k	kh	g	gh	ng	ng	c	ch	j	jh	ny	ny	nj	t	th	d	dh	n	n	nd	p	pp	ph	b	bh	m	m	mb	y	r	l	w	x	s	h	a	i	i	ei	u	e	o	ai	au	u	y	r	l	w										k	g	ng	ng	c	t	n	p	y	r	l	x	m	h			0	1	2	3	4	5	6	7	8	9			*	,	;	.	g	c	ch	j	jh	n	t	th	d	dh	dh	n	s	h	l	f	-	x	z	r	oay	'n	hm	!	1	2	r				ch	sh	k	k	kh	kh	x	x	g	g	ng	ng	ch	ch	chh	chh	s	s	ny	ny	d	d	t	t	th	th	n	n	b	b	p	p	ph	ph	f	f	m	m	y	y	r	r	l	l	v	v	h	h			a	aa	i	ue	u	ae	o	oa	ia	uea	ua	aue	ai	an	am																													Kon	Nueng	-	<	>	e	o	ch	n	t	th	d	dh	n	s	s	i	u	ai	au	au	,	?	*	-	-	h";
    case 171:
      return "	thu	thi	tha	the	th	tho			dhu	dhi	dha	dhe	dh	dho			dzu	dzi	dza	dze	dz	dzo										ch'e	ch'u	ch'i	ch'a	ch'e	ch'	ch'o		b'e	b'u	b'i	b'a	b'e	b'	b'o		a	ae	e	e	e	f	g	l	l	l	m	n	ng	o	o	o	oe	oe	oe	oo	oo	r	r	r	rr	r	rr	r	r	sh	u	u	ui	ui	u	x	x	x	x	x	x	x	y	*	h	l	l	u	ia	ie	oe	uo	a	o	dz	ts	r	w	<	>					a	e	i	o	u	v	ga	ka	ge	gi	go	gu	gv	ha	he	hi	ho	hu	hv	la	le	li	lo	lu	lv	ma	me	mi	mo	mu	na	hna	nah	ne	ni	no	nu	nv	qua	que	qui	quo	quu	quv	sa	s	se	si	so	su	sv	da	ta	de	te	di	ti	do	du	dv	dla	tla	tle	tli	tlo	tlu	tlv	tsa	tse	tsi	tso	tsu	tsv	wa	we	wi	wo	wu	wv	ya	k	s	l	m	p	n	c	t	kh	n	th	w	y	h	u	i	ph	a	g	jh	r	b	j	d	gh	dh	bh	k	l	m	p	n	t	n	i	o	i	a	e	ou	u	ei	m	.					0	1	2	3	4	5	6	7	8	9";
    case 172:
      return "Ga	Gag	Gakk	Gags	Gan	Ganj	Ganh	Gad	Gal	Galg	Galm	Galb	Gals	Galt	Galp	Galh	Gam	Gab	Gabs	Gas	Gass	Gang	Gaj	Gach	Gak	Gat	Gap	Gah	Gae	Gaeg	Gaekk	Gaegs	Gaen	Gaenj	Gaenh	Gaed	Gael	Gaelg	Gaelm	Gaelb	Gaels	Gaelt	Gaelp	Gaelh	Gaem	Gaeb	Gaebs	Gaes	Gaess	Gaeng	Gaej	Gaech	Gaek	Gaet	Gaep	Gaeh	Gya	Gyag	Gyakk	Gyags	Gyan	Gyanj	Gyanh	Gyad	Gyal	Gyalg	Gyalm	Gyalb	Gyals	Gyalt	Gyalp	Gyalh	Gyam	Gyab	Gyabs	Gyas	Gyass	Gyang	Gyaj	Gyach	Gyak	Gyat	Gyap	Gyah	Gyae	Gyaeg	Gyaekk	Gyaegs	Gyaen	Gyaenj	Gyaenh	Gyaed	Gyael	Gyaelg	Gyaelm	Gyaelb	Gyaels	Gyaelt	Gyaelp	Gyaelh	Gyaem	Gyaeb	Gyaebs	Gyaes	Gyaess	Gyaeng	Gyaej	Gyaech	Gyaek	Gyaet	Gyaep	Gyaeh	Geo	Geog	Geokk	Geogs	Geon	Geonj	Geonh	Geod	Geol	Geolg	Geolm	Geolb	Geols	Geolt	Geolp	Geolh	Geom	Geob	Geobs	Geos	Geoss	Geong	Geoj	Geoch	Geok	Geot	Geop	Geoh	Ge	Geg	Gekk	Gegs	Gen	Genj	Genh	Ged	Gel	Gelg	Gelm	Gelb	Gels	Gelt	Gelp	Gelh	Gem	Geb	Gebs	Ges	Gess	Geng	Gej	Gech	Gek	Get	Gep	Geh	Gyeo	Gyeog	Gyeokk	Gyeogs	Gyeon	Gyeonj	Gyeonh	Gyeod	Gyeol	Gyeolg	Gyeolm	Gyeolb	Gyeols	Gyeolt	Gyeolp	Gyeolh	Gyeom	Gyeob	Gyeobs	Gyeos	Gyeoss	Gyeong	Gyeoj	Gyeoch	Gyeok	Gyeot	Gyeop	Gyeoh	Gye	Gyeg	Gyekk	Gyegs	Gyen	Gyenj	Gyenh	Gyed	Gyel	Gyelg	Gyelm	Gyelb	Gyels	Gyelt	Gyelp	Gyelh	Gyem	Gyeb	Gyebs	Gyes	Gyess	Gyeng	Gyej	Gyech	Gyek	Gyet	Gyep	Gyeh	Go	Gog	Gokk	Gogs	Gon	Gonj	Gonh	God	Gol	Golg	Golm	Golb	Gols	Golt	Golp	Golh	Gom	Gob	Gobs	Gos	Goss	Gong	Goj	Goch	Gok	Got	Gop	Goh	Gwa	Gwag	Gwakk	Gwags";
    case 173:
      return "Gwan	Gwanj	Gwanh	Gwad	Gwal	Gwalg	Gwalm	Gwalb	Gwals	Gwalt	Gwalp	Gwalh	Gwam	Gwab	Gwabs	Gwas	Gwass	Gwang	Gwaj	Gwach	Gwak	Gwat	Gwap	Gwah	Gwae	Gwaeg	Gwaekk	Gwaegs	Gwaen	Gwaenj	Gwaenh	Gwaed	Gwael	Gwaelg	Gwaelm	Gwaelb	Gwaels	Gwaelt	Gwaelp	Gwaelh	Gwaem	Gwaeb	Gwaebs	Gwaes	Gwaess	Gwaeng	Gwaej	Gwaech	Gwaek	Gwaet	Gwaep	Gwaeh	Goe	Goeg	Goekk	Goegs	Goen	Goenj	Goenh	Goed	Goel	Goelg	Goelm	Goelb	Goels	Goelt	Goelp	Goelh	Goem	Goeb	Goebs	Goes	Goess	Goeng	Goej	Goech	Goek	Goet	Goep	Goeh	Gyo	Gyog	Gyokk	Gyogs	Gyon	Gyonj	Gyonh	Gyod	Gyol	Gyolg	Gyolm	Gyolb	Gyols	Gyolt	Gyolp	Gyolh	Gyom	Gyob	Gyobs	Gyos	Gyoss	Gyong	Gyoj	Gyoch	Gyok	Gyot	Gyop	Gyoh	Gu	Gug	Gukk	Gugs	Gun	Gunj	Gunh	Gud	Gul	Gulg	Gulm	Gulb	Guls	Gult	Gulp	Gulh	Gum	Gub	Gubs	Gus	Guss	Gung	Guj	Guch	Guk	Gut	Gup	Guh	Gwo	Gwog	Gwokk	Gwogs	Gwon	Gwonj	Gwonh	Gwod	Gwol	Gwolg	Gwolm	Gwolb	Gwols	Gwolt	Gwolp	Gwolh	Gwom	Gwob	Gwobs	Gwos	Gwoss	Gwong	Gwoj	Gwoch	Gwok	Gwot	Gwop	Gwoh	Gwe	Gweg	Gwekk	Gwegs	Gwen	Gwenj	Gwenh	Gwed	Gwel	Gwelg	Gwelm	Gwelb	Gwels	Gwelt	Gwelp	Gwelh	Gwem	Gweb	Gwebs	Gwes	Gwess	Gweng	Gwej	Gwech	Gwek	Gwet	Gwep	Gweh	Gwi	Gwig	Gwikk	Gwigs	Gwin	Gwinj	Gwinh	Gwid	Gwil	Gwilg	Gwilm	Gwilb	Gwils	Gwilt	Gwilp	Gwilh	Gwim	Gwib	Gwibs	Gwis	Gwiss	Gwing	Gwij	Gwich	Gwik	Gwit	Gwip	Gwih	Gyu	Gyug	Gyukk	Gyugs	Gyun	Gyunj	Gyunh	Gyud	Gyul	Gyulg	Gyulm	Gyulb	Gyuls	Gyult	Gyulp	Gyulh	Gyum	Gyub	Gyubs	Gyus	Gyuss	Gyung	Gyuj	Gyuch	Gyuk	Gyut	Gyup	Gyuh	Geu	Geug	Geukk	Geugs	Geun	Geunj	Geunh	Geud";
    case 174:
      return "Geul	Geulg	Geulm	Geulb	Geuls	Geult	Geulp	Geulh	Geum	Geub	Geubs	Geus	Geuss	Geung	Geuj	Geuch	Geuk	Geut	Geup	Geuh	Gui	Guig	Guikk	Guigs	Guin	Guinj	Guinh	Guid	Guil	Guilg	Guilm	Guilb	Guils	Guilt	Guilp	Guilh	Guim	Guib	Guibs	Guis	Guiss	Guing	Guij	Guich	Guik	Guit	Guip	Guih	Gi	Gig	Gikk	Gigs	Gin	Ginj	Ginh	Gid	Gil	Gilg	Gilm	Gilb	Gils	Gilt	Gilp	Gilh	Gim	Gib	Gibs	Gis	Giss	Ging	Gij	Gich	Gik	Git	Gip	Gih	Kka	Kkag	Kkakk	Kkags	Kkan	Kkanj	Kkanh	Kkad	Kkal	Kkalg	Kkalm	Kkalb	Kkals	Kkalt	Kkalp	Kkalh	Kkam	Kkab	Kkabs	Kkas	Kkass	Kkang	Kkaj	Kkach	Kkak	Kkat	Kkap	Kkah	Kkae	Kkaeg	Kkaekk	Kkaegs	Kkaen	Kkaenj	Kkaenh	Kkaed	Kkael	Kkaelg	Kkaelm	Kkaelb	Kkaels	Kkaelt	Kkaelp	Kkaelh	Kkaem	Kkaeb	Kkaebs	Kkaes	Kkaess	Kkaeng	Kkaej	Kkaech	Kkaek	Kkaet	Kkaep	Kkaeh	Kkya	Kkyag	Kkyakk	Kkyags	Kkyan	Kkyanj	Kkyanh	Kkyad	Kkyal	Kkyalg	Kkyalm	Kkyalb	Kkyals	Kkyalt	Kkyalp	Kkyalh	Kkyam	Kkyab	Kkyabs	Kkyas	Kkyass	Kkyang	Kkyaj	Kkyach	Kkyak	Kkyat	Kkyap	Kkyah	Kkyae	Kkyaeg	Kkyaekk	Kkyaegs	Kkyaen	Kkyaenj	Kkyaenh	Kkyaed	Kkyael	Kkyaelg	Kkyaelm	Kkyaelb	Kkyaels	Kkyaelt	Kkyaelp	Kkyaelh	Kkyaem	Kkyaeb	Kkyaebs	Kkyaes	Kkyaess	Kkyaeng	Kkyaej	Kkyaech	Kkyaek	Kkyaet	Kkyaep	Kkyaeh	Kkeo	Kkeog	Kkeokk	Kkeogs	Kkeon	Kkeonj	Kkeonh	Kkeod	Kkeol	Kkeolg	Kkeolm	Kkeolb	Kkeols	Kkeolt	Kkeolp	Kkeolh	Kkeom	Kkeob	Kkeobs	Kkeos	Kkeoss	Kkeong	Kkeoj	Kkeoch	Kkeok	Kkeot	Kkeop	Kkeoh	Kke	Kkeg	Kkekk	Kkegs	Kken	Kkenj	Kkenh	Kked	Kkel	Kkelg	Kkelm	Kkelb	Kkels	Kkelt	Kkelp	Kkelh	Kkem	Kkeb	Kkebs	Kkes	Kkess	Kkeng	Kkej	Kkech	Kkek	Kket	Kkep	Kkeh	Kkyeo	Kkyeog	Kkyeokk	Kkyeogs	Kkyeon	Kkyeonj	Kkyeonh	Kkyeod	Kkyeol	Kkyeolg	Kkyeolm	Kkyeolb";
    case 175:
      return "Kkyeols	Kkyeolt	Kkyeolp	Kkyeolh	Kkyeom	Kkyeob	Kkyeobs	Kkyeos	Kkyeoss	Kkyeong	Kkyeoj	Kkyeoch	Kkyeok	Kkyeot	Kkyeop	Kkyeoh	Kkye	Kkyeg	Kkyekk	Kkyegs	Kkyen	Kkyenj	Kkyenh	Kkyed	Kkyel	Kkyelg	Kkyelm	Kkyelb	Kkyels	Kkyelt	Kkyelp	Kkyelh	Kkyem	Kkyeb	Kkyebs	Kkyes	Kkyess	Kkyeng	Kkyej	Kkyech	Kkyek	Kkyet	Kkyep	Kkyeh	Kko	Kkog	Kkokk	Kkogs	Kkon	Kkonj	Kkonh	Kkod	Kkol	Kkolg	Kkolm	Kkolb	Kkols	Kkolt	Kkolp	Kkolh	Kkom	Kkob	Kkobs	Kkos	Kkoss	Kkong	Kkoj	Kkoch	Kkok	Kkot	Kkop	Kkoh	Kkwa	Kkwag	Kkwakk	Kkwags	Kkwan	Kkwanj	Kkwanh	Kkwad	Kkwal	Kkwalg	Kkwalm	Kkwalb	Kkwals	Kkwalt	Kkwalp	Kkwalh	Kkwam	Kkwab	Kkwabs	Kkwas	Kkwass	Kkwang	Kkwaj	Kkwach	Kkwak	Kkwat	Kkwap	Kkwah	Kkwae	Kkwaeg	Kkwaekk	Kkwaegs	Kkwaen	Kkwaenj	Kkwaenh	Kkwaed	Kkwael	Kkwaelg	Kkwaelm	Kkwaelb	Kkwaels	Kkwaelt	Kkwaelp	Kkwaelh	Kkwaem	Kkwaeb	Kkwaebs	Kkwaes	Kkwaess	Kkwaeng	Kkwaej	Kkwaech	Kkwaek	Kkwaet	Kkwaep	Kkwaeh	Kkoe	Kkoeg	Kkoekk	Kkoegs	Kkoen	Kkoenj	Kkoenh	Kkoed	Kkoel	Kkoelg	Kkoelm	Kkoelb	Kkoels	Kkoelt	Kkoelp	Kkoelh	Kkoem	Kkoeb	Kkoebs	Kkoes	Kkoess	Kkoeng	Kkoej	Kkoech	Kkoek	Kkoet	Kkoep	Kkoeh	Kkyo	Kkyog	Kkyokk	Kkyogs	Kkyon	Kkyonj	Kkyonh	Kkyod	Kkyol	Kkyolg	Kkyolm	Kkyolb	Kkyols	Kkyolt	Kkyolp	Kkyolh	Kkyom	Kkyob	Kkyobs	Kkyos	Kkyoss	Kkyong	Kkyoj	Kkyoch	Kkyok	Kkyot	Kkyop	Kkyoh	Kku	Kkug	Kkukk	Kkugs	Kkun	Kkunj	Kkunh	Kkud	Kkul	Kkulg	Kkulm	Kkulb	Kkuls	Kkult	Kkulp	Kkulh	Kkum	Kkub	Kkubs	Kkus	Kkuss	Kkung	Kkuj	Kkuch	Kkuk	Kkut	Kkup	Kkuh	Kkwo	Kkwog	Kkwokk	Kkwogs	Kkwon	Kkwonj	Kkwonh	Kkwod	Kkwol	Kkwolg	Kkwolm	Kkwolb	Kkwols	Kkwolt	Kkwolp	Kkwolh	Kkwom	Kkwob	Kkwobs	Kkwos	Kkwoss	Kkwong	Kkwoj	Kkwoch	Kkwok	Kkwot	Kkwop	Kkwoh	Kkwe	Kkweg	Kkwekk	Kkwegs	Kkwen	Kkwenj	Kkwenh	Kkwed	Kkwel	Kkwelg	Kkwelm	Kkwelb	Kkwels	Kkwelt	Kkwelp	Kkwelh";
    case 176:
      return "Kkwem	Kkweb	Kkwebs	Kkwes	Kkwess	Kkweng	Kkwej	Kkwech	Kkwek	Kkwet	Kkwep	Kkweh	Kkwi	Kkwig	Kkwikk	Kkwigs	Kkwin	Kkwinj	Kkwinh	Kkwid	Kkwil	Kkwilg	Kkwilm	Kkwilb	Kkwils	Kkwilt	Kkwilp	Kkwilh	Kkwim	Kkwib	Kkwibs	Kkwis	Kkwiss	Kkwing	Kkwij	Kkwich	Kkwik	Kkwit	Kkwip	Kkwih	Kkyu	Kkyug	Kkyukk	Kkyugs	Kkyun	Kkyunj	Kkyunh	Kkyud	Kkyul	Kkyulg	Kkyulm	Kkyulb	Kkyuls	Kkyult	Kkyulp	Kkyulh	Kkyum	Kkyub	Kkyubs	Kkyus	Kkyuss	Kkyung	Kkyuj	Kkyuch	Kkyuk	Kkyut	Kkyup	Kkyuh	Kkeu	Kkeug	Kkeukk	Kkeugs	Kkeun	Kkeunj	Kkeunh	Kkeud	Kkeul	Kkeulg	Kkeulm	Kkeulb	Kkeuls	Kkeult	Kkeulp	Kkeulh	Kkeum	Kkeub	Kkeubs	Kkeus	Kkeuss	Kkeung	Kkeuj	Kkeuch	Kkeuk	Kkeut	Kkeup	Kkeuh	Kkui	Kkuig	Kkuikk	Kkuigs	Kkuin	Kkuinj	Kkuinh	Kkuid	Kkuil	Kkuilg	Kkuilm	Kkuilb	Kkuils	Kkuilt	Kkuilp	Kkuilh	Kkuim	Kkuib	Kkuibs	Kkuis	Kkuiss	Kkuing	Kkuij	Kkuich	Kkuik	Kkuit	Kkuip	Kkuih	Kki	Kkig	Kkikk	Kkigs	Kkin	Kkinj	Kkinh	Kkid	Kkil	Kkilg	Kkilm	Kkilb	Kkils	Kkilt	Kkilp	Kkilh	Kkim	Kkib	Kkibs	Kkis	Kkiss	Kking	Kkij	Kkich	Kkik	Kkit	Kkip	Kkih	Na	Nag	Nakk	Nags	Nan	Nanj	Nanh	Nad	Nal	Nalg	Nalm	Nalb	Nals	Nalt	Nalp	Nalh	Nam	Nab	Nabs	Nas	Nass	Nang	Naj	Nach	Nak	Nat	Nap	Nah	Nae	Naeg	Naekk	Naegs	Naen	Naenj	Naenh	Naed	Nael	Naelg	Naelm	Naelb	Naels	Naelt	Naelp	Naelh	Naem	Naeb	Naebs	Naes	Naess	Naeng	Naej	Naech	Naek	Naet	Naep	Naeh	Nya	Nyag	Nyakk	Nyags	Nyan	Nyanj	Nyanh	Nyad	Nyal	Nyalg	Nyalm	Nyalb	Nyals	Nyalt	Nyalp	Nyalh	Nyam	Nyab	Nyabs	Nyas	Nyass	Nyang	Nyaj	Nyach	Nyak	Nyat	Nyap	Nyah	Nyae	Nyaeg	Nyaekk	Nyaegs	Nyaen	Nyaenj	Nyaenh	Nyaed	Nyael	Nyaelg	Nyaelm	Nyaelb	Nyaels	Nyaelt	Nyaelp	Nyaelh	Nyaem	Nyaeb	Nyaebs	Nyaes";
    case 177:
      return "Nyaess	Nyaeng	Nyaej	Nyaech	Nyaek	Nyaet	Nyaep	Nyaeh	Neo	Neog	Neokk	Neogs	Neon	Neonj	Neonh	Neod	Neol	Neolg	Neolm	Neolb	Neols	Neolt	Neolp	Neolh	Neom	Neob	Neobs	Neos	Neoss	Neong	Neoj	Neoch	Neok	Neot	Neop	Neoh	Ne	Neg	Nekk	Negs	Nen	Nenj	Nenh	Ned	Nel	Nelg	Nelm	Nelb	Nels	Nelt	Nelp	Nelh	Nem	Neb	Nebs	Nes	Ness	Neng	Nej	Nech	Nek	Net	Nep	Neh	Nyeo	Nyeog	Nyeokk	Nyeogs	Nyeon	Nyeonj	Nyeonh	Nyeod	Nyeol	Nyeolg	Nyeolm	Nyeolb	Nyeols	Nyeolt	Nyeolp	Nyeolh	Nyeom	Nyeob	Nyeobs	Nyeos	Nyeoss	Nyeong	Nyeoj	Nyeoch	Nyeok	Nyeot	Nyeop	Nyeoh	Nye	Nyeg	Nyekk	Nyegs	Nyen	Nyenj	Nyenh	Nyed	Nyel	Nyelg	Nyelm	Nyelb	Nyels	Nyelt	Nyelp	Nyelh	Nyem	Nyeb	Nyebs	Nyes	Nyess	Nyeng	Nyej	Nyech	Nyek	Nyet	Nyep	Nyeh	No	Nog	Nokk	Nogs	Non	Nonj	Nonh	Nod	Nol	Nolg	Nolm	Nolb	Nols	Nolt	Nolp	Nolh	Nom	Nob	Nobs	Nos	Noss	Nong	Noj	Noch	Nok	Not	Nop	Noh	Nwa	Nwag	Nwakk	Nwags	Nwan	Nwanj	Nwanh	Nwad	Nwal	Nwalg	Nwalm	Nwalb	Nwals	Nwalt	Nwalp	Nwalh	Nwam	Nwab	Nwabs	Nwas	Nwass	Nwang	Nwaj	Nwach	Nwak	Nwat	Nwap	Nwah	Nwae	Nwaeg	Nwaekk	Nwaegs	Nwaen	Nwaenj	Nwaenh	Nwaed	Nwael	Nwaelg	Nwaelm	Nwaelb	Nwaels	Nwaelt	Nwaelp	Nwaelh	Nwaem	Nwaeb	Nwaebs	Nwaes	Nwaess	Nwaeng	Nwaej	Nwaech	Nwaek	Nwaet	Nwaep	Nwaeh	Noe	Noeg	Noekk	Noegs	Noen	Noenj	Noenh	Noed	Noel	Noelg	Noelm	Noelb	Noels	Noelt	Noelp	Noelh	Noem	Noeb	Noebs	Noes	Noess	Noeng	Noej	Noech	Noek	Noet	Noep	Noeh	Nyo	Nyog	Nyokk	Nyogs	Nyon	Nyonj	Nyonh	Nyod	Nyol	Nyolg	Nyolm	Nyolb	Nyols	Nyolt	Nyolp	Nyolh	Nyom	Nyob	Nyobs	Nyos	Nyoss	Nyong	Nyoj	Nyoch";
    case 178:
      return "Nyok	Nyot	Nyop	Nyoh	Nu	Nug	Nukk	Nugs	Nun	Nunj	Nunh	Nud	Nul	Nulg	Nulm	Nulb	Nuls	Nult	Nulp	Nulh	Num	Nub	Nubs	Nus	Nuss	Nung	Nuj	Nuch	Nuk	Nut	Nup	Nuh	Nwo	Nwog	Nwokk	Nwogs	Nwon	Nwonj	Nwonh	Nwod	Nwol	Nwolg	Nwolm	Nwolb	Nwols	Nwolt	Nwolp	Nwolh	Nwom	Nwob	Nwobs	Nwos	Nwoss	Nwong	Nwoj	Nwoch	Nwok	Nwot	Nwop	Nwoh	Nwe	Nweg	Nwekk	Nwegs	Nwen	Nwenj	Nwenh	Nwed	Nwel	Nwelg	Nwelm	Nwelb	Nwels	Nwelt	Nwelp	Nwelh	Nwem	Nweb	Nwebs	Nwes	Nwess	Nweng	Nwej	Nwech	Nwek	Nwet	Nwep	Nweh	Nwi	Nwig	Nwikk	Nwigs	Nwin	Nwinj	Nwinh	Nwid	Nwil	Nwilg	Nwilm	Nwilb	Nwils	Nwilt	Nwilp	Nwilh	Nwim	Nwib	Nwibs	Nwis	Nwiss	Nwing	Nwij	Nwich	Nwik	Nwit	Nwip	Nwih	Nyu	Nyug	Nyukk	Nyugs	Nyun	Nyunj	Nyunh	Nyud	Nyul	Nyulg	Nyulm	Nyulb	Nyuls	Nyult	Nyulp	Nyulh	Nyum	Nyub	Nyubs	Nyus	Nyuss	Nyung	Nyuj	Nyuch	Nyuk	Nyut	Nyup	Nyuh	Neu	Neug	Neukk	Neugs	Neun	Neunj	Neunh	Neud	Neul	Neulg	Neulm	Neulb	Neuls	Neult	Neulp	Neulh	Neum	Neub	Neubs	Neus	Neuss	Neung	Neuj	Neuch	Neuk	Neut	Neup	Neuh	Nui	Nuig	Nuikk	Nuigs	Nuin	Nuinj	Nuinh	Nuid	Nuil	Nuilg	Nuilm	Nuilb	Nuils	Nuilt	Nuilp	Nuilh	Nuim	Nuib	Nuibs	Nuis	Nuiss	Nuing	Nuij	Nuich	Nuik	Nuit	Nuip	Nuih	Ni	Nig	Nikk	Nigs	Nin	Ninj	Ninh	Nid	Nil	Nilg	Nilm	Nilb	Nils	Nilt	Nilp	Nilh	Nim	Nib	Nibs	Nis	Niss	Ning	Nij	Nich	Nik	Nit	Nip	Nih	Da	Dag	Dakk	Dags	Dan	Danj	Danh	Dad	Dal	Dalg	Dalm	Dalb	Dals	Dalt	Dalp	Dalh	Dam	Dab	Dabs	Das	Dass	Dang	Daj	Dach	Dak	Dat	Dap	Dah";
    case 179:
      return "Dae	Daeg	Daekk	Daegs	Daen	Daenj	Daenh	Daed	Dael	Daelg	Daelm	Daelb	Daels	Daelt	Daelp	Daelh	Daem	Daeb	Daebs	Daes	Daess	Daeng	Daej	Daech	Daek	Daet	Daep	Daeh	Dya	Dyag	Dyakk	Dyags	Dyan	Dyanj	Dyanh	Dyad	Dyal	Dyalg	Dyalm	Dyalb	Dyals	Dyalt	Dyalp	Dyalh	Dyam	Dyab	Dyabs	Dyas	Dyass	Dyang	Dyaj	Dyach	Dyak	Dyat	Dyap	Dyah	Dyae	Dyaeg	Dyaekk	Dyaegs	Dyaen	Dyaenj	Dyaenh	Dyaed	Dyael	Dyaelg	Dyaelm	Dyaelb	Dyaels	Dyaelt	Dyaelp	Dyaelh	Dyaem	Dyaeb	Dyaebs	Dyaes	Dyaess	Dyaeng	Dyaej	Dyaech	Dyaek	Dyaet	Dyaep	Dyaeh	Deo	Deog	Deokk	Deogs	Deon	Deonj	Deonh	Deod	Deol	Deolg	Deolm	Deolb	Deols	Deolt	Deolp	Deolh	Deom	Deob	Deobs	Deos	Deoss	Deong	Deoj	Deoch	Deok	Deot	Deop	Deoh	De	Deg	Dekk	Degs	Den	Denj	Denh	Ded	Del	Delg	Delm	Delb	Dels	Delt	Delp	Delh	Dem	Deb	Debs	Des	Dess	Deng	Dej	Dech	Dek	Det	Dep	Deh	Dyeo	Dyeog	Dyeokk	Dyeogs	Dyeon	Dyeonj	Dyeonh	Dyeod	Dyeol	Dyeolg	Dyeolm	Dyeolb	Dyeols	Dyeolt	Dyeolp	Dyeolh	Dyeom	Dyeob	Dyeobs	Dyeos	Dyeoss	Dyeong	Dyeoj	Dyeoch	Dyeok	Dyeot	Dyeop	Dyeoh	Dye	Dyeg	Dyekk	Dyegs	Dyen	Dyenj	Dyenh	Dyed	Dyel	Dyelg	Dyelm	Dyelb	Dyels	Dyelt	Dyelp	Dyelh	Dyem	Dyeb	Dyebs	Dyes	Dyess	Dyeng	Dyej	Dyech	Dyek	Dyet	Dyep	Dyeh	Do	Dog	Dokk	Dogs	Don	Donj	Donh	Dod	Dol	Dolg	Dolm	Dolb	Dols	Dolt	Dolp	Dolh	Dom	Dob	Dobs	Dos	Doss	Dong	Doj	Doch	Dok	Dot	Dop	Doh	Dwa	Dwag	Dwakk	Dwags	Dwan	Dwanj	Dwanh	Dwad	Dwal	Dwalg	Dwalm	Dwalb	Dwals	Dwalt	Dwalp	Dwalh	Dwam	Dwab	Dwabs	Dwas	Dwass	Dwang	Dwaj	Dwach	Dwak	Dwat	Dwap	Dwah	Dwae	Dwaeg	Dwaekk	Dwaegs";
    case 180:
      return "Dwaen	Dwaenj	Dwaenh	Dwaed	Dwael	Dwaelg	Dwaelm	Dwaelb	Dwaels	Dwaelt	Dwaelp	Dwaelh	Dwaem	Dwaeb	Dwaebs	Dwaes	Dwaess	Dwaeng	Dwaej	Dwaech	Dwaek	Dwaet	Dwaep	Dwaeh	Doe	Doeg	Doekk	Doegs	Doen	Doenj	Doenh	Doed	Doel	Doelg	Doelm	Doelb	Doels	Doelt	Doelp	Doelh	Doem	Doeb	Doebs	Does	Doess	Doeng	Doej	Doech	Doek	Doet	Doep	Doeh	Dyo	Dyog	Dyokk	Dyogs	Dyon	Dyonj	Dyonh	Dyod	Dyol	Dyolg	Dyolm	Dyolb	Dyols	Dyolt	Dyolp	Dyolh	Dyom	Dyob	Dyobs	Dyos	Dyoss	Dyong	Dyoj	Dyoch	Dyok	Dyot	Dyop	Dyoh	Du	Dug	Dukk	Dugs	Dun	Dunj	Dunh	Dud	Dul	Dulg	Dulm	Dulb	Duls	Dult	Dulp	Dulh	Dum	Dub	Dubs	Dus	Duss	Dung	Duj	Duch	Duk	Dut	Dup	Duh	Dwo	Dwog	Dwokk	Dwogs	Dwon	Dwonj	Dwonh	Dwod	Dwol	Dwolg	Dwolm	Dwolb	Dwols	Dwolt	Dwolp	Dwolh	Dwom	Dwob	Dwobs	Dwos	Dwoss	Dwong	Dwoj	Dwoch	Dwok	Dwot	Dwop	Dwoh	Dwe	Dweg	Dwekk	Dwegs	Dwen	Dwenj	Dwenh	Dwed	Dwel	Dwelg	Dwelm	Dwelb	Dwels	Dwelt	Dwelp	Dwelh	Dwem	Dweb	Dwebs	Dwes	Dwess	Dweng	Dwej	Dwech	Dwek	Dwet	Dwep	Dweh	Dwi	Dwig	Dwikk	Dwigs	Dwin	Dwinj	Dwinh	Dwid	Dwil	Dwilg	Dwilm	Dwilb	Dwils	Dwilt	Dwilp	Dwilh	Dwim	Dwib	Dwibs	Dwis	Dwiss	Dwing	Dwij	Dwich	Dwik	Dwit	Dwip	Dwih	Dyu	Dyug	Dyukk	Dyugs	Dyun	Dyunj	Dyunh	Dyud	Dyul	Dyulg	Dyulm	Dyulb	Dyuls	Dyult	Dyulp	Dyulh	Dyum	Dyub	Dyubs	Dyus	Dyuss	Dyung	Dyuj	Dyuch	Dyuk	Dyut	Dyup	Dyuh	Deu	Deug	Deukk	Deugs	Deun	Deunj	Deunh	Deud	Deul	Deulg	Deulm	Deulb	Deuls	Deult	Deulp	Deulh	Deum	Deub	Deubs	Deus	Deuss	Deung	Deuj	Deuch	Deuk	Deut	Deup	Deuh	Dui	Duig	Duikk	Duigs	Duin	Duinj	Duinh	Duid";
    case 181:
      return "Duil	Duilg	Duilm	Duilb	Duils	Duilt	Duilp	Duilh	Duim	Duib	Duibs	Duis	Duiss	Duing	Duij	Duich	Duik	Duit	Duip	Duih	Di	Dig	Dikk	Digs	Din	Dinj	Dinh	Did	Dil	Dilg	Dilm	Dilb	Dils	Dilt	Dilp	Dilh	Dim	Dib	Dibs	Dis	Diss	Ding	Dij	Dich	Dik	Dit	Dip	Dih	Tta	Ttag	Ttakk	Ttags	Ttan	Ttanj	Ttanh	Ttad	Ttal	Ttalg	Ttalm	Ttalb	Ttals	Ttalt	Ttalp	Ttalh	Ttam	Ttab	Ttabs	Ttas	Ttass	Ttang	Ttaj	Ttach	Ttak	Ttat	Ttap	Ttah	Ttae	Ttaeg	Ttaekk	Ttaegs	Ttaen	Ttaenj	Ttaenh	Ttaed	Ttael	Ttaelg	Ttaelm	Ttaelb	Ttaels	Ttaelt	Ttaelp	Ttaelh	Ttaem	Ttaeb	Ttaebs	Ttaes	Ttaess	Ttaeng	Ttaej	Ttaech	Ttaek	Ttaet	Ttaep	Ttaeh	Ttya	Ttyag	Ttyakk	Ttyags	Ttyan	Ttyanj	Ttyanh	Ttyad	Ttyal	Ttyalg	Ttyalm	Ttyalb	Ttyals	Ttyalt	Ttyalp	Ttyalh	Ttyam	Ttyab	Ttyabs	Ttyas	Ttyass	Ttyang	Ttyaj	Ttyach	Ttyak	Ttyat	Ttyap	Ttyah	Ttyae	Ttyaeg	Ttyaekk	Ttyaegs	Ttyaen	Ttyaenj	Ttyaenh	Ttyaed	Ttyael	Ttyaelg	Ttyaelm	Ttyaelb	Ttyaels	Ttyaelt	Ttyaelp	Ttyaelh	Ttyaem	Ttyaeb	Ttyaebs	Ttyaes	Ttyaess	Ttyaeng	Ttyaej	Ttyaech	Ttyaek	Ttyaet	Ttyaep	Ttyaeh	Tteo	Tteog	Tteokk	Tteogs	Tteon	Tteonj	Tteonh	Tteod	Tteol	Tteolg	Tteolm	Tteolb	Tteols	Tteolt	Tteolp	Tteolh	Tteom	Tteob	Tteobs	Tteos	Tteoss	Tteong	Tteoj	Tteoch	Tteok	Tteot	Tteop	Tteoh	Tte	Tteg	Ttekk	Ttegs	Tten	Ttenj	Ttenh	Tted	Ttel	Ttelg	Ttelm	Ttelb	Ttels	Ttelt	Ttelp	Ttelh	Ttem	Tteb	Ttebs	Ttes	Ttess	Tteng	Ttej	Ttech	Ttek	Ttet	Ttep	Tteh	Ttyeo	Ttyeog	Ttyeokk	Ttyeogs	Ttyeon	Ttyeonj	Ttyeonh	Ttyeod	Ttyeol	Ttyeolg	Ttyeolm	Ttyeolb	Ttyeols	Ttyeolt	Ttyeolp	Ttyeolh	Ttyeom	Ttyeob	Ttyeobs	Ttyeos	Ttyeoss	Ttyeong	Ttyeoj	Ttyeoch	Ttyeok	Ttyeot	Ttyeop	Ttyeoh	Ttye	Ttyeg	Ttyekk	Ttyegs	Ttyen	Ttyenj	Ttyenh	Ttyed	Ttyel	Ttyelg	Ttyelm	Ttyelb";
    case 182:
      return "Ttyels	Ttyelt	Ttyelp	Ttyelh	Ttyem	Ttyeb	Ttyebs	Ttyes	Ttyess	Ttyeng	Ttyej	Ttyech	Ttyek	Ttyet	Ttyep	Ttyeh	Tto	Ttog	Ttokk	Ttogs	Tton	Ttonj	Ttonh	Ttod	Ttol	Ttolg	Ttolm	Ttolb	Ttols	Ttolt	Ttolp	Ttolh	Ttom	Ttob	Ttobs	Ttos	Ttoss	Ttong	Ttoj	Ttoch	Ttok	Ttot	Ttop	Ttoh	Ttwa	Ttwag	Ttwakk	Ttwags	Ttwan	Ttwanj	Ttwanh	Ttwad	Ttwal	Ttwalg	Ttwalm	Ttwalb	Ttwals	Ttwalt	Ttwalp	Ttwalh	Ttwam	Ttwab	Ttwabs	Ttwas	Ttwass	Ttwang	Ttwaj	Ttwach	Ttwak	Ttwat	Ttwap	Ttwah	Ttwae	Ttwaeg	Ttwaekk	Ttwaegs	Ttwaen	Ttwaenj	Ttwaenh	Ttwaed	Ttwael	Ttwaelg	Ttwaelm	Ttwaelb	Ttwaels	Ttwaelt	Ttwaelp	Ttwaelh	Ttwaem	Ttwaeb	Ttwaebs	Ttwaes	Ttwaess	Ttwaeng	Ttwaej	Ttwaech	Ttwaek	Ttwaet	Ttwaep	Ttwaeh	Ttoe	Ttoeg	Ttoekk	Ttoegs	Ttoen	Ttoenj	Ttoenh	Ttoed	Ttoel	Ttoelg	Ttoelm	Ttoelb	Ttoels	Ttoelt	Ttoelp	Ttoelh	Ttoem	Ttoeb	Ttoebs	Ttoes	Ttoess	Ttoeng	Ttoej	Ttoech	Ttoek	Ttoet	Ttoep	Ttoeh	Ttyo	Ttyog	Ttyokk	Ttyogs	Ttyon	Ttyonj	Ttyonh	Ttyod	Ttyol	Ttyolg	Ttyolm	Ttyolb	Ttyols	Ttyolt	Ttyolp	Ttyolh	Ttyom	Ttyob	Ttyobs	Ttyos	Ttyoss	Ttyong	Ttyoj	Ttyoch	Ttyok	Ttyot	Ttyop	Ttyoh	Ttu	Ttug	Ttukk	Ttugs	Ttun	Ttunj	Ttunh	Ttud	Ttul	Ttulg	Ttulm	Ttulb	Ttuls	Ttult	Ttulp	Ttulh	Ttum	Ttub	Ttubs	Ttus	Ttuss	Ttung	Ttuj	Ttuch	Ttuk	Ttut	Ttup	Ttuh	Ttwo	Ttwog	Ttwokk	Ttwogs	Ttwon	Ttwonj	Ttwonh	Ttwod	Ttwol	Ttwolg	Ttwolm	Ttwolb	Ttwols	Ttwolt	Ttwolp	Ttwolh	Ttwom	Ttwob	Ttwobs	Ttwos	Ttwoss	Ttwong	Ttwoj	Ttwoch	Ttwok	Ttwot	Ttwop	Ttwoh	Ttwe	Ttweg	Ttwekk	Ttwegs	Ttwen	Ttwenj	Ttwenh	Ttwed	Ttwel	Ttwelg	Ttwelm	Ttwelb	Ttwels	Ttwelt	Ttwelp	Ttwelh	Ttwem	Ttweb	Ttwebs	Ttwes	Ttwess	Ttweng	Ttwej	Ttwech	Ttwek	Ttwet	Ttwep	Ttweh	Ttwi	Ttwig	Ttwikk	Ttwigs	Ttwin	Ttwinj	Ttwinh	Ttwid	Ttwil	Ttwilg	Ttwilm	Ttwilb	Ttwils	Ttwilt	Ttwilp	Ttwilh";
    case 183:
      return "Ttwim	Ttwib	Ttwibs	Ttwis	Ttwiss	Ttwing	Ttwij	Ttwich	Ttwik	Ttwit	Ttwip	Ttwih	Ttyu	Ttyug	Ttyukk	Ttyugs	Ttyun	Ttyunj	Ttyunh	Ttyud	Ttyul	Ttyulg	Ttyulm	Ttyulb	Ttyuls	Ttyult	Ttyulp	Ttyulh	Ttyum	Ttyub	Ttyubs	Ttyus	Ttyuss	Ttyung	Ttyuj	Ttyuch	Ttyuk	Ttyut	Ttyup	Ttyuh	Tteu	Tteug	Tteukk	Tteugs	Tteun	Tteunj	Tteunh	Tteud	Tteul	Tteulg	Tteulm	Tteulb	Tteuls	Tteult	Tteulp	Tteulh	Tteum	Tteub	Tteubs	Tteus	Tteuss	Tteung	Tteuj	Tteuch	Tteuk	Tteut	Tteup	Tteuh	Ttui	Ttuig	Ttuikk	Ttuigs	Ttuin	Ttuinj	Ttuinh	Ttuid	Ttuil	Ttuilg	Ttuilm	Ttuilb	Ttuils	Ttuilt	Ttuilp	Ttuilh	Ttuim	Ttuib	Ttuibs	Ttuis	Ttuiss	Ttuing	Ttuij	Ttuich	Ttuik	Ttuit	Ttuip	Ttuih	Tti	Ttig	Ttikk	Ttigs	Ttin	Ttinj	Ttinh	Ttid	Ttil	Ttilg	Ttilm	Ttilb	Ttils	Ttilt	Ttilp	Ttilh	Ttim	Ttib	Ttibs	Ttis	Ttiss	Tting	Ttij	Ttich	Ttik	Ttit	Ttip	Ttih	La	Lag	Lakk	Lags	Lan	Lanj	Lanh	Lad	Lal	Lalg	Lalm	Lalb	Lals	Lalt	Lalp	Lalh	Lam	Lab	Labs	Las	Lass	Lang	Laj	Lach	Lak	Lat	Lap	Lah	Lae	Laeg	Laekk	Laegs	Laen	Laenj	Laenh	Laed	Lael	Laelg	Laelm	Laelb	Laels	Laelt	Laelp	Laelh	Laem	Laeb	Laebs	Laes	Laess	Laeng	Laej	Laech	Laek	Laet	Laep	Laeh	Lya	Lyag	Lyakk	Lyags	Lyan	Lyanj	Lyanh	Lyad	Lyal	Lyalg	Lyalm	Lyalb	Lyals	Lyalt	Lyalp	Lyalh	Lyam	Lyab	Lyabs	Lyas	Lyass	Lyang	Lyaj	Lyach	Lyak	Lyat	Lyap	Lyah	Lyae	Lyaeg	Lyaekk	Lyaegs	Lyaen	Lyaenj	Lyaenh	Lyaed	Lyael	Lyaelg	Lyaelm	Lyaelb	Lyaels	Lyaelt	Lyaelp	Lyaelh	Lyaem	Lyaeb	Lyaebs	Lyaes	Lyaess	Lyaeng	Lyaej	Lyaech	Lyaek	Lyaet	Lyaep	Lyaeh	Leo	Leog	Leokk	Leogs	Leon	Leonj	Leonh	Leod	Leol	Leolg	Leolm	Leolb	Leols	Leolt	Leolp	Leolh	Leom	Leob	Leobs	Leos";
    case 184:
      return "Leoss	Leong	Leoj	Leoch	Leok	Leot	Leop	Leoh	Le	Leg	Lekk	Legs	Len	Lenj	Lenh	Led	Lel	Lelg	Lelm	Lelb	Lels	Lelt	Lelp	Lelh	Lem	Leb	Lebs	Les	Less	Leng	Lej	Lech	Lek	Let	Lep	Leh	Lyeo	Lyeog	Lyeokk	Lyeogs	Lyeon	Lyeonj	Lyeonh	Lyeod	Lyeol	Lyeolg	Lyeolm	Lyeolb	Lyeols	Lyeolt	Lyeolp	Lyeolh	Lyeom	Lyeob	Lyeobs	Lyeos	Lyeoss	Lyeong	Lyeoj	Lyeoch	Lyeok	Lyeot	Lyeop	Lyeoh	Lye	Lyeg	Lyekk	Lyegs	Lyen	Lyenj	Lyenh	Lyed	Lyel	Lyelg	Lyelm	Lyelb	Lyels	Lyelt	Lyelp	Lyelh	Lyem	Lyeb	Lyebs	Lyes	Lyess	Lyeng	Lyej	Lyech	Lyek	Lyet	Lyep	Lyeh	Lo	Log	Lokk	Logs	Lon	Lonj	Lonh	Lod	Lol	Lolg	Lolm	Lolb	Lols	Lolt	Lolp	Lolh	Lom	Lob	Lobs	Los	Loss	Long	Loj	Loch	Lok	Lot	Lop	Loh	Lwa	Lwag	Lwakk	Lwags	Lwan	Lwanj	Lwanh	Lwad	Lwal	Lwalg	Lwalm	Lwalb	Lwals	Lwalt	Lwalp	Lwalh	Lwam	Lwab	Lwabs	Lwas	Lwass	Lwang	Lwaj	Lwach	Lwak	Lwat	Lwap	Lwah	Lwae	Lwaeg	Lwaekk	Lwaegs	Lwaen	Lwaenj	Lwaenh	Lwaed	Lwael	Lwaelg	Lwaelm	Lwaelb	Lwaels	Lwaelt	Lwaelp	Lwaelh	Lwaem	Lwaeb	Lwaebs	Lwaes	Lwaess	Lwaeng	Lwaej	Lwaech	Lwaek	Lwaet	Lwaep	Lwaeh	Loe	Loeg	Loekk	Loegs	Loen	Loenj	Loenh	Loed	Loel	Loelg	Loelm	Loelb	Loels	Loelt	Loelp	Loelh	Loem	Loeb	Loebs	Loes	Loess	Loeng	Loej	Loech	Loek	Loet	Loep	Loeh	Lyo	Lyog	Lyokk	Lyogs	Lyon	Lyonj	Lyonh	Lyod	Lyol	Lyolg	Lyolm	Lyolb	Lyols	Lyolt	Lyolp	Lyolh	Lyom	Lyob	Lyobs	Lyos	Lyoss	Lyong	Lyoj	Lyoch	Lyok	Lyot	Lyop	Lyoh	Lu	Lug	Lukk	Lugs	Lun	Lunj	Lunh	Lud	Lul	Lulg	Lulm	Lulb	Luls	Lult	Lulp	Lulh	Lum	Lub	Lubs	Lus	Luss	Lung	Luj	Luch";
    case 185:
      return "Luk	Lut	Lup	Luh	Lwo	Lwog	Lwokk	Lwogs	Lwon	Lwonj	Lwonh	Lwod	Lwol	Lwolg	Lwolm	Lwolb	Lwols	Lwolt	Lwolp	Lwolh	Lwom	Lwob	Lwobs	Lwos	Lwoss	Lwong	Lwoj	Lwoch	Lwok	Lwot	Lwop	Lwoh	Lwe	Lweg	Lwekk	Lwegs	Lwen	Lwenj	Lwenh	Lwed	Lwel	Lwelg	Lwelm	Lwelb	Lwels	Lwelt	Lwelp	Lwelh	Lwem	Lweb	Lwebs	Lwes	Lwess	Lweng	Lwej	Lwech	Lwek	Lwet	Lwep	Lweh	Lwi	Lwig	Lwikk	Lwigs	Lwin	Lwinj	Lwinh	Lwid	Lwil	Lwilg	Lwilm	Lwilb	Lwils	Lwilt	Lwilp	Lwilh	Lwim	Lwib	Lwibs	Lwis	Lwiss	Lwing	Lwij	Lwich	Lwik	Lwit	Lwip	Lwih	Lyu	Lyug	Lyukk	Lyugs	Lyun	Lyunj	Lyunh	Lyud	Lyul	Lyulg	Lyulm	Lyulb	Lyuls	Lyult	Lyulp	Lyulh	Lyum	Lyub	Lyubs	Lyus	Lyuss	Lyung	Lyuj	Lyuch	Lyuk	Lyut	Lyup	Lyuh	Leu	Leug	Leukk	Leugs	Leun	Leunj	Leunh	Leud	Leul	Leulg	Leulm	Leulb	Leuls	Leult	Leulp	Leulh	Leum	Leub	Leubs	Leus	Leuss	Leung	Leuj	Leuch	Leuk	Leut	Leup	Leuh	Lui	Luig	Luikk	Luigs	Luin	Luinj	Luinh	Luid	Luil	Luilg	Luilm	Luilb	Luils	Luilt	Luilp	Luilh	Luim	Luib	Luibs	Luis	Luiss	Luing	Luij	Luich	Luik	Luit	Luip	Luih	Li	Lig	Likk	Ligs	Lin	Linj	Linh	Lid	Lil	Lilg	Lilm	Lilb	Lils	Lilt	Lilp	Lilh	Lim	Lib	Libs	Lis	Liss	Ling	Lij	Lich	Lik	Lit	Lip	Lih	Ma	Mag	Makk	Mags	Man	Manj	Manh	Mad	Mal	Malg	Malm	Malb	Mals	Malt	Malp	Malh	Mam	Mab	Mabs	Mas	Mass	Mang	Maj	Mach	Mak	Mat	Map	Mah	Mae	Maeg	Maekk	Maegs	Maen	Maenj	Maenh	Maed	Mael	Maelg	Maelm	Maelb	Maels	Maelt	Maelp	Maelh	Maem	Maeb	Maebs	Maes	Maess	Maeng	Maej	Maech	Maek	Maet	Maep	Maeh";
    case 186:
      return "Mya	Myag	Myakk	Myags	Myan	Myanj	Myanh	Myad	Myal	Myalg	Myalm	Myalb	Myals	Myalt	Myalp	Myalh	Myam	Myab	Myabs	Myas	Myass	Myang	Myaj	Myach	Myak	Myat	Myap	Myah	Myae	Myaeg	Myaekk	Myaegs	Myaen	Myaenj	Myaenh	Myaed	Myael	Myaelg	Myaelm	Myaelb	Myaels	Myaelt	Myaelp	Myaelh	Myaem	Myaeb	Myaebs	Myaes	Myaess	Myaeng	Myaej	Myaech	Myaek	Myaet	Myaep	Myaeh	Meo	Meog	Meokk	Meogs	Meon	Meonj	Meonh	Meod	Meol	Meolg	Meolm	Meolb	Meols	Meolt	Meolp	Meolh	Meom	Meob	Meobs	Meos	Meoss	Meong	Meoj	Meoch	Meok	Meot	Meop	Meoh	Me	Meg	Mekk	Megs	Men	Menj	Menh	Med	Mel	Melg	Melm	Melb	Mels	Melt	Melp	Melh	Mem	Meb	Mebs	Mes	Mess	Meng	Mej	Mech	Mek	Met	Mep	Meh	Myeo	Myeog	Myeokk	Myeogs	Myeon	Myeonj	Myeonh	Myeod	Myeol	Myeolg	Myeolm	Myeolb	Myeols	Myeolt	Myeolp	Myeolh	Myeom	Myeob	Myeobs	Myeos	Myeoss	Myeong	Myeoj	Myeoch	Myeok	Myeot	Myeop	Myeoh	Mye	Myeg	Myekk	Myegs	Myen	Myenj	Myenh	Myed	Myel	Myelg	Myelm	Myelb	Myels	Myelt	Myelp	Myelh	Myem	Myeb	Myebs	Myes	Myess	Myeng	Myej	Myech	Myek	Myet	Myep	Myeh	Mo	Mog	Mokk	Mogs	Mon	Monj	Monh	Mod	Mol	Molg	Molm	Molb	Mols	Molt	Molp	Molh	Mom	Mob	Mobs	Mos	Moss	Mong	Moj	Moch	Mok	Mot	Mop	Moh	Mwa	Mwag	Mwakk	Mwags	Mwan	Mwanj	Mwanh	Mwad	Mwal	Mwalg	Mwalm	Mwalb	Mwals	Mwalt	Mwalp	Mwalh	Mwam	Mwab	Mwabs	Mwas	Mwass	Mwang	Mwaj	Mwach	Mwak	Mwat	Mwap	Mwah	Mwae	Mwaeg	Mwaekk	Mwaegs	Mwaen	Mwaenj	Mwaenh	Mwaed	Mwael	Mwaelg	Mwaelm	Mwaelb	Mwaels	Mwaelt	Mwaelp	Mwaelh	Mwaem	Mwaeb	Mwaebs	Mwaes	Mwaess	Mwaeng	Mwaej	Mwaech	Mwaek	Mwaet	Mwaep	Mwaeh	Moe	Moeg	Moekk	Moegs";
    case 187:
      return "Moen	Moenj	Moenh	Moed	Moel	Moelg	Moelm	Moelb	Moels	Moelt	Moelp	Moelh	Moem	Moeb	Moebs	Moes	Moess	Moeng	Moej	Moech	Moek	Moet	Moep	Moeh	Myo	Myog	Myokk	Myogs	Myon	Myonj	Myonh	Myod	Myol	Myolg	Myolm	Myolb	Myols	Myolt	Myolp	Myolh	Myom	Myob	Myobs	Myos	Myoss	Myong	Myoj	Myoch	Myok	Myot	Myop	Myoh	Mu	Mug	Mukk	Mugs	Mun	Munj	Munh	Mud	Mul	Mulg	Mulm	Mulb	Muls	Mult	Mulp	Mulh	Mum	Mub	Mubs	Mus	Muss	Mung	Muj	Much	Muk	Mut	Mup	Muh	Mwo	Mwog	Mwokk	Mwogs	Mwon	Mwonj	Mwonh	Mwod	Mwol	Mwolg	Mwolm	Mwolb	Mwols	Mwolt	Mwolp	Mwolh	Mwom	Mwob	Mwobs	Mwos	Mwoss	Mwong	Mwoj	Mwoch	Mwok	Mwot	Mwop	Mwoh	Mwe	Mweg	Mwekk	Mwegs	Mwen	Mwenj	Mwenh	Mwed	Mwel	Mwelg	Mwelm	Mwelb	Mwels	Mwelt	Mwelp	Mwelh	Mwem	Mweb	Mwebs	Mwes	Mwess	Mweng	Mwej	Mwech	Mwek	Mwet	Mwep	Mweh	Mwi	Mwig	Mwikk	Mwigs	Mwin	Mwinj	Mwinh	Mwid	Mwil	Mwilg	Mwilm	Mwilb	Mwils	Mwilt	Mwilp	Mwilh	Mwim	Mwib	Mwibs	Mwis	Mwiss	Mwing	Mwij	Mwich	Mwik	Mwit	Mwip	Mwih	Myu	Myug	Myukk	Myugs	Myun	Myunj	Myunh	Myud	Myul	Myulg	Myulm	Myulb	Myuls	Myult	Myulp	Myulh	Myum	Myub	Myubs	Myus	Myuss	Myung	Myuj	Myuch	Myuk	Myut	Myup	Myuh	Meu	Meug	Meukk	Meugs	Meun	Meunj	Meunh	Meud	Meul	Meulg	Meulm	Meulb	Meuls	Meult	Meulp	Meulh	Meum	Meub	Meubs	Meus	Meuss	Meung	Meuj	Meuch	Meuk	Meut	Meup	Meuh	Mui	Muig	Muikk	Muigs	Muin	Muinj	Muinh	Muid	Muil	Muilg	Muilm	Muilb	Muils	Muilt	Muilp	Muilh	Muim	Muib	Muibs	Muis	Muiss	Muing	Muij	Muich	Muik	Muit	Muip	Muih	Mi	Mig	Mikk	Migs	Min	Minj	Minh	Mid";
    case 188:
      return "Mil	Milg	Milm	Milb	Mils	Milt	Milp	Milh	Mim	Mib	Mibs	Mis	Miss	Ming	Mij	Mich	Mik	Mit	Mip	Mih	Ba	Bag	Bakk	Bags	Ban	Banj	Banh	Bad	Bal	Balg	Balm	Balb	Bals	Balt	Balp	Balh	Bam	Bab	Babs	Bas	Bass	Bang	Baj	Bach	Bak	Bat	Bap	Bah	Bae	Baeg	Baekk	Baegs	Baen	Baenj	Baenh	Baed	Bael	Baelg	Baelm	Baelb	Baels	Baelt	Baelp	Baelh	Baem	Baeb	Baebs	Baes	Baess	Baeng	Baej	Baech	Baek	Baet	Baep	Baeh	Bya	Byag	Byakk	Byags	Byan	Byanj	Byanh	Byad	Byal	Byalg	Byalm	Byalb	Byals	Byalt	Byalp	Byalh	Byam	Byab	Byabs	Byas	Byass	Byang	Byaj	Byach	Byak	Byat	Byap	Byah	Byae	Byaeg	Byaekk	Byaegs	Byaen	Byaenj	Byaenh	Byaed	Byael	Byaelg	Byaelm	Byaelb	Byaels	Byaelt	Byaelp	Byaelh	Byaem	Byaeb	Byaebs	Byaes	Byaess	Byaeng	Byaej	Byaech	Byaek	Byaet	Byaep	Byaeh	Beo	Beog	Beokk	Beogs	Beon	Beonj	Beonh	Beod	Beol	Beolg	Beolm	Beolb	Beols	Beolt	Beolp	Beolh	Beom	Beob	Beobs	Beos	Beoss	Beong	Beoj	Beoch	Beok	Beot	Beop	Beoh	Be	Beg	Bekk	Begs	Ben	Benj	Benh	Bed	Bel	Belg	Belm	Belb	Bels	Belt	Belp	Belh	Bem	Beb	Bebs	Bes	Bess	Beng	Bej	Bech	Bek	Bet	Bep	Beh	Byeo	Byeog	Byeokk	Byeogs	Byeon	Byeonj	Byeonh	Byeod	Byeol	Byeolg	Byeolm	Byeolb	Byeols	Byeolt	Byeolp	Byeolh	Byeom	Byeob	Byeobs	Byeos	Byeoss	Byeong	Byeoj	Byeoch	Byeok	Byeot	Byeop	Byeoh	Bye	Byeg	Byekk	Byegs	Byen	Byenj	Byenh	Byed	Byel	Byelg	Byelm	Byelb	Byels	Byelt	Byelp	Byelh	Byem	Byeb	Byebs	Byes	Byess	Byeng	Byej	Byech	Byek	Byet	Byep	Byeh	Bo	Bog	Bokk	Bogs	Bon	Bonj	Bonh	Bod	Bol	Bolg	Bolm	Bolb";
    case 189:
      return "Bols	Bolt	Bolp	Bolh	Bom	Bob	Bobs	Bos	Boss	Bong	Boj	Boch	Bok	Bot	Bop	Boh	Bwa	Bwag	Bwakk	Bwags	Bwan	Bwanj	Bwanh	Bwad	Bwal	Bwalg	Bwalm	Bwalb	Bwals	Bwalt	Bwalp	Bwalh	Bwam	Bwab	Bwabs	Bwas	Bwass	Bwang	Bwaj	Bwach	Bwak	Bwat	Bwap	Bwah	Bwae	Bwaeg	Bwaekk	Bwaegs	Bwaen	Bwaenj	Bwaenh	Bwaed	Bwael	Bwaelg	Bwaelm	Bwaelb	Bwaels	Bwaelt	Bwaelp	Bwaelh	Bwaem	Bwaeb	Bwaebs	Bwaes	Bwaess	Bwaeng	Bwaej	Bwaech	Bwaek	Bwaet	Bwaep	Bwaeh	Boe	Boeg	Boekk	Boegs	Boen	Boenj	Boenh	Boed	Boel	Boelg	Boelm	Boelb	Boels	Boelt	Boelp	Boelh	Boem	Boeb	Boebs	Boes	Boess	Boeng	Boej	Boech	Boek	Boet	Boep	Boeh	Byo	Byog	Byokk	Byogs	Byon	Byonj	Byonh	Byod	Byol	Byolg	Byolm	Byolb	Byols	Byolt	Byolp	Byolh	Byom	Byob	Byobs	Byos	Byoss	Byong	Byoj	Byoch	Byok	Byot	Byop	Byoh	Bu	Bug	Bukk	Bugs	Bun	Bunj	Bunh	Bud	Bul	Bulg	Bulm	Bulb	Buls	Bult	Bulp	Bulh	Bum	Bub	Bubs	Bus	Buss	Bung	Buj	Buch	Buk	But	Bup	Buh	Bwo	Bwog	Bwokk	Bwogs	Bwon	Bwonj	Bwonh	Bwod	Bwol	Bwolg	Bwolm	Bwolb	Bwols	Bwolt	Bwolp	Bwolh	Bwom	Bwob	Bwobs	Bwos	Bwoss	Bwong	Bwoj	Bwoch	Bwok	Bwot	Bwop	Bwoh	Bwe	Bweg	Bwekk	Bwegs	Bwen	Bwenj	Bwenh	Bwed	Bwel	Bwelg	Bwelm	Bwelb	Bwels	Bwelt	Bwelp	Bwelh	Bwem	Bweb	Bwebs	Bwes	Bwess	Bweng	Bwej	Bwech	Bwek	Bwet	Bwep	Bweh	Bwi	Bwig	Bwikk	Bwigs	Bwin	Bwinj	Bwinh	Bwid	Bwil	Bwilg	Bwilm	Bwilb	Bwils	Bwilt	Bwilp	Bwilh	Bwim	Bwib	Bwibs	Bwis	Bwiss	Bwing	Bwij	Bwich	Bwik	Bwit	Bwip	Bwih	Byu	Byug	Byukk	Byugs	Byun	Byunj	Byunh	Byud	Byul	Byulg	Byulm	Byulb	Byuls	Byult	Byulp	Byulh";
    case 190:
      return "Byum	Byub	Byubs	Byus	Byuss	Byung	Byuj	Byuch	Byuk	Byut	Byup	Byuh	Beu	Beug	Beukk	Beugs	Beun	Beunj	Beunh	Beud	Beul	Beulg	Beulm	Beulb	Beuls	Beult	Beulp	Beulh	Beum	Beub	Beubs	Beus	Beuss	Beung	Beuj	Beuch	Beuk	Beut	Beup	Beuh	Bui	Buig	Buikk	Buigs	Buin	Buinj	Buinh	Buid	Buil	Builg	Builm	Builb	Buils	Built	Builp	Builh	Buim	Buib	Buibs	Buis	Buiss	Buing	Buij	Buich	Buik	Buit	Buip	Buih	Bi	Big	Bikk	Bigs	Bin	Binj	Binh	Bid	Bil	Bilg	Bilm	Bilb	Bils	Bilt	Bilp	Bilh	Bim	Bib	Bibs	Bis	Biss	Bing	Bij	Bich	Bik	Bit	Bip	Bih	Ppa	Ppag	Ppakk	Ppags	Ppan	Ppanj	Ppanh	Ppad	Ppal	Ppalg	Ppalm	Ppalb	Ppals	Ppalt	Ppalp	Ppalh	Ppam	Ppab	Ppabs	Ppas	Ppass	Ppang	Ppaj	Ppach	Ppak	Ppat	Ppap	Ppah	Ppae	Ppaeg	Ppaekk	Ppaegs	Ppaen	Ppaenj	Ppaenh	Ppaed	Ppael	Ppaelg	Ppaelm	Ppaelb	Ppaels	Ppaelt	Ppaelp	Ppaelh	Ppaem	Ppaeb	Ppaebs	Ppaes	Ppaess	Ppaeng	Ppaej	Ppaech	Ppaek	Ppaet	Ppaep	Ppaeh	Ppya	Ppyag	Ppyakk	Ppyags	Ppyan	Ppyanj	Ppyanh	Ppyad	Ppyal	Ppyalg	Ppyalm	Ppyalb	Ppyals	Ppyalt	Ppyalp	Ppyalh	Ppyam	Ppyab	Ppyabs	Ppyas	Ppyass	Ppyang	Ppyaj	Ppyach	Ppyak	Ppyat	Ppyap	Ppyah	Ppyae	Ppyaeg	Ppyaekk	Ppyaegs	Ppyaen	Ppyaenj	Ppyaenh	Ppyaed	Ppyael	Ppyaelg	Ppyaelm	Ppyaelb	Ppyaels	Ppyaelt	Ppyaelp	Ppyaelh	Ppyaem	Ppyaeb	Ppyaebs	Ppyaes	Ppyaess	Ppyaeng	Ppyaej	Ppyaech	Ppyaek	Ppyaet	Ppyaep	Ppyaeh	Ppeo	Ppeog	Ppeokk	Ppeogs	Ppeon	Ppeonj	Ppeonh	Ppeod	Ppeol	Ppeolg	Ppeolm	Ppeolb	Ppeols	Ppeolt	Ppeolp	Ppeolh	Ppeom	Ppeob	Ppeobs	Ppeos	Ppeoss	Ppeong	Ppeoj	Ppeoch	Ppeok	Ppeot	Ppeop	Ppeoh	Ppe	Ppeg	Ppekk	Ppegs	Ppen	Ppenj	Ppenh	Pped	Ppel	Ppelg	Ppelm	Ppelb	Ppels	Ppelt	Ppelp	Ppelh	Ppem	Ppeb	Ppebs	Ppes";
    case 191:
      return "Ppess	Ppeng	Ppej	Ppech	Ppek	Ppet	Ppep	Ppeh	Ppyeo	Ppyeog	Ppyeokk	Ppyeogs	Ppyeon	Ppyeonj	Ppyeonh	Ppyeod	Ppyeol	Ppyeolg	Ppyeolm	Ppyeolb	Ppyeols	Ppyeolt	Ppyeolp	Ppyeolh	Ppyeom	Ppyeob	Ppyeobs	Ppyeos	Ppyeoss	Ppyeong	Ppyeoj	Ppyeoch	Ppyeok	Ppyeot	Ppyeop	Ppyeoh	Ppye	Ppyeg	Ppyekk	Ppyegs	Ppyen	Ppyenj	Ppyenh	Ppyed	Ppyel	Ppyelg	Ppyelm	Ppyelb	Ppyels	Ppyelt	Ppyelp	Ppyelh	Ppyem	Ppyeb	Ppyebs	Ppyes	Ppyess	Ppyeng	Ppyej	Ppyech	Ppyek	Ppyet	Ppyep	Ppyeh	Ppo	Ppog	Ppokk	Ppogs	Ppon	Pponj	Pponh	Ppod	Ppol	Ppolg	Ppolm	Ppolb	Ppols	Ppolt	Ppolp	Ppolh	Ppom	Ppob	Ppobs	Ppos	Pposs	Ppong	Ppoj	Ppoch	Ppok	Ppot	Ppop	Ppoh	Ppwa	Ppwag	Ppwakk	Ppwags	Ppwan	Ppwanj	Ppwanh	Ppwad	Ppwal	Ppwalg	Ppwalm	Ppwalb	Ppwals	Ppwalt	Ppwalp	Ppwalh	Ppwam	Ppwab	Ppwabs	Ppwas	Ppwass	Ppwang	Ppwaj	Ppwach	Ppwak	Ppwat	Ppwap	Ppwah	Ppwae	Ppwaeg	Ppwaekk	Ppwaegs	Ppwaen	Ppwaenj	Ppwaenh	Ppwaed	Ppwael	Ppwaelg	Ppwaelm	Ppwaelb	Ppwaels	Ppwaelt	Ppwaelp	Ppwaelh	Ppwaem	Ppwaeb	Ppwaebs	Ppwaes	Ppwaess	Ppwaeng	Ppwaej	Ppwaech	Ppwaek	Ppwaet	Ppwaep	Ppwaeh	Ppoe	Ppoeg	Ppoekk	Ppoegs	Ppoen	Ppoenj	Ppoenh	Ppoed	Ppoel	Ppoelg	Ppoelm	Ppoelb	Ppoels	Ppoelt	Ppoelp	Ppoelh	Ppoem	Ppoeb	Ppoebs	Ppoes	Ppoess	Ppoeng	Ppoej	Ppoech	Ppoek	Ppoet	Ppoep	Ppoeh	Ppyo	Ppyog	Ppyokk	Ppyogs	Ppyon	Ppyonj	Ppyonh	Ppyod	Ppyol	Ppyolg	Ppyolm	Ppyolb	Ppyols	Ppyolt	Ppyolp	Ppyolh	Ppyom	Ppyob	Ppyobs	Ppyos	Ppyoss	Ppyong	Ppyoj	Ppyoch	Ppyok	Ppyot	Ppyop	Ppyoh	Ppu	Ppug	Ppukk	Ppugs	Ppun	Ppunj	Ppunh	Ppud	Ppul	Ppulg	Ppulm	Ppulb	Ppuls	Ppult	Ppulp	Ppulh	Ppum	Ppub	Ppubs	Ppus	Ppuss	Ppung	Ppuj	Ppuch	Ppuk	Pput	Ppup	Ppuh	Ppwo	Ppwog	Ppwokk	Ppwogs	Ppwon	Ppwonj	Ppwonh	Ppwod	Ppwol	Ppwolg	Ppwolm	Ppwolb	Ppwols	Ppwolt	Ppwolp	Ppwolh	Ppwom	Ppwob	Ppwobs	Ppwos	Ppwoss	Ppwong	Ppwoj	Ppwoch";
    case 192:
      return "Ppwok	Ppwot	Ppwop	Ppwoh	Ppwe	Ppweg	Ppwekk	Ppwegs	Ppwen	Ppwenj	Ppwenh	Ppwed	Ppwel	Ppwelg	Ppwelm	Ppwelb	Ppwels	Ppwelt	Ppwelp	Ppwelh	Ppwem	Ppweb	Ppwebs	Ppwes	Ppwess	Ppweng	Ppwej	Ppwech	Ppwek	Ppwet	Ppwep	Ppweh	Ppwi	Ppwig	Ppwikk	Ppwigs	Ppwin	Ppwinj	Ppwinh	Ppwid	Ppwil	Ppwilg	Ppwilm	Ppwilb	Ppwils	Ppwilt	Ppwilp	Ppwilh	Ppwim	Ppwib	Ppwibs	Ppwis	Ppwiss	Ppwing	Ppwij	Ppwich	Ppwik	Ppwit	Ppwip	Ppwih	Ppyu	Ppyug	Ppyukk	Ppyugs	Ppyun	Ppyunj	Ppyunh	Ppyud	Ppyul	Ppyulg	Ppyulm	Ppyulb	Ppyuls	Ppyult	Ppyulp	Ppyulh	Ppyum	Ppyub	Ppyubs	Ppyus	Ppyuss	Ppyung	Ppyuj	Ppyuch	Ppyuk	Ppyut	Ppyup	Ppyuh	Ppeu	Ppeug	Ppeukk	Ppeugs	Ppeun	Ppeunj	Ppeunh	Ppeud	Ppeul	Ppeulg	Ppeulm	Ppeulb	Ppeuls	Ppeult	Ppeulp	Ppeulh	Ppeum	Ppeub	Ppeubs	Ppeus	Ppeuss	Ppeung	Ppeuj	Ppeuch	Ppeuk	Ppeut	Ppeup	Ppeuh	Ppui	Ppuig	Ppuikk	Ppuigs	Ppuin	Ppuinj	Ppuinh	Ppuid	Ppuil	Ppuilg	Ppuilm	Ppuilb	Ppuils	Ppuilt	Ppuilp	Ppuilh	Ppuim	Ppuib	Ppuibs	Ppuis	Ppuiss	Ppuing	Ppuij	Ppuich	Ppuik	Ppuit	Ppuip	Ppuih	Ppi	Ppig	Ppikk	Ppigs	Ppin	Ppinj	Ppinh	Ppid	Ppil	Ppilg	Ppilm	Ppilb	Ppils	Ppilt	Ppilp	Ppilh	Ppim	Ppib	Ppibs	Ppis	Ppiss	Pping	Ppij	Ppich	Ppik	Ppit	Ppip	Ppih	Sa	Sag	Sakk	Sags	San	Sanj	Sanh	Sad	Sal	Salg	Salm	Salb	Sals	Salt	Salp	Salh	Sam	Sab	Sabs	Sas	Sass	Sang	Saj	Sach	Sak	Sat	Sap	Sah	Sae	Saeg	Saekk	Saegs	Saen	Saenj	Saenh	Saed	Sael	Saelg	Saelm	Saelb	Saels	Saelt	Saelp	Saelh	Saem	Saeb	Saebs	Saes	Saess	Saeng	Saej	Saech	Saek	Saet	Saep	Saeh	Sya	Syag	Syakk	Syags	Syan	Syanj	Syanh	Syad	Syal	Syalg	Syalm	Syalb	Syals	Syalt	Syalp	Syalh	Syam	Syab	Syabs	Syas	Syass	Syang	Syaj	Syach	Syak	Syat	Syap	Syah";
    case 193:
      return "Syae	Syaeg	Syaekk	Syaegs	Syaen	Syaenj	Syaenh	Syaed	Syael	Syaelg	Syaelm	Syaelb	Syaels	Syaelt	Syaelp	Syaelh	Syaem	Syaeb	Syaebs	Syaes	Syaess	Syaeng	Syaej	Syaech	Syaek	Syaet	Syaep	Syaeh	Seo	Seog	Seokk	Seogs	Seon	Seonj	Seonh	Seod	Seol	Seolg	Seolm	Seolb	Seols	Seolt	Seolp	Seolh	Seom	Seob	Seobs	Seos	Seoss	Seong	Seoj	Seoch	Seok	Seot	Seop	Seoh	Se	Seg	Sekk	Segs	Sen	Senj	Senh	Sed	Sel	Selg	Selm	Selb	Sels	Selt	Selp	Selh	Sem	Seb	Sebs	Ses	Sess	Seng	Sej	Sech	Sek	Set	Sep	Seh	Syeo	Syeog	Syeokk	Syeogs	Syeon	Syeonj	Syeonh	Syeod	Syeol	Syeolg	Syeolm	Syeolb	Syeols	Syeolt	Syeolp	Syeolh	Syeom	Syeob	Syeobs	Syeos	Syeoss	Syeong	Syeoj	Syeoch	Syeok	Syeot	Syeop	Syeoh	Sye	Syeg	Syekk	Syegs	Syen	Syenj	Syenh	Syed	Syel	Syelg	Syelm	Syelb	Syels	Syelt	Syelp	Syelh	Syem	Syeb	Syebs	Syes	Syess	Syeng	Syej	Syech	Syek	Syet	Syep	Syeh	So	Sog	Sokk	Sogs	Son	Sonj	Sonh	Sod	Sol	Solg	Solm	Solb	Sols	Solt	Solp	Solh	Som	Sob	Sobs	Sos	Soss	Song	Soj	Soch	Sok	Sot	Sop	Soh	Swa	Swag	Swakk	Swags	Swan	Swanj	Swanh	Swad	Swal	Swalg	Swalm	Swalb	Swals	Swalt	Swalp	Swalh	Swam	Swab	Swabs	Swas	Swass	Swang	Swaj	Swach	Swak	Swat	Swap	Swah	Swae	Swaeg	Swaekk	Swaegs	Swaen	Swaenj	Swaenh	Swaed	Swael	Swaelg	Swaelm	Swaelb	Swaels	Swaelt	Swaelp	Swaelh	Swaem	Swaeb	Swaebs	Swaes	Swaess	Swaeng	Swaej	Swaech	Swaek	Swaet	Swaep	Swaeh	Soe	Soeg	Soekk	Soegs	Soen	Soenj	Soenh	Soed	Soel	Soelg	Soelm	Soelb	Soels	Soelt	Soelp	Soelh	Soem	Soeb	Soebs	Soes	Soess	Soeng	Soej	Soech	Soek	Soet	Soep	Soeh	Syo	Syog	Syokk	Syogs";
    case 194:
      return "Syon	Syonj	Syonh	Syod	Syol	Syolg	Syolm	Syolb	Syols	Syolt	Syolp	Syolh	Syom	Syob	Syobs	Syos	Syoss	Syong	Syoj	Syoch	Syok	Syot	Syop	Syoh	Su	Sug	Sukk	Sugs	Sun	Sunj	Sunh	Sud	Sul	Sulg	Sulm	Sulb	Suls	Sult	Sulp	Sulh	Sum	Sub	Subs	Sus	Suss	Sung	Suj	Such	Suk	Sut	Sup	Suh	Swo	Swog	Swokk	Swogs	Swon	Swonj	Swonh	Swod	Swol	Swolg	Swolm	Swolb	Swols	Swolt	Swolp	Swolh	Swom	Swob	Swobs	Swos	Swoss	Swong	Swoj	Swoch	Swok	Swot	Swop	Swoh	Swe	Sweg	Swekk	Swegs	Swen	Swenj	Swenh	Swed	Swel	Swelg	Swelm	Swelb	Swels	Swelt	Swelp	Swelh	Swem	Sweb	Swebs	Swes	Swess	Sweng	Swej	Swech	Swek	Swet	Swep	Sweh	Swi	Swig	Swikk	Swigs	Swin	Swinj	Swinh	Swid	Swil	Swilg	Swilm	Swilb	Swils	Swilt	Swilp	Swilh	Swim	Swib	Swibs	Swis	Swiss	Swing	Swij	Swich	Swik	Swit	Swip	Swih	Syu	Syug	Syukk	Syugs	Syun	Syunj	Syunh	Syud	Syul	Syulg	Syulm	Syulb	Syuls	Syult	Syulp	Syulh	Syum	Syub	Syubs	Syus	Syuss	Syung	Syuj	Syuch	Syuk	Syut	Syup	Syuh	Seu	Seug	Seukk	Seugs	Seun	Seunj	Seunh	Seud	Seul	Seulg	Seulm	Seulb	Seuls	Seult	Seulp	Seulh	Seum	Seub	Seubs	Seus	Seuss	Seung	Seuj	Seuch	Seuk	Seut	Seup	Seuh	Sui	Suig	Suikk	Suigs	Suin	Suinj	Suinh	Suid	Suil	Suilg	Suilm	Suilb	Suils	Suilt	Suilp	Suilh	Suim	Suib	Suibs	Suis	Suiss	Suing	Suij	Suich	Suik	Suit	Suip	Suih	Si	Sig	Sikk	Sigs	Sin	Sinj	Sinh	Sid	Sil	Silg	Silm	Silb	Sils	Silt	Silp	Silh	Sim	Sib	Sibs	Sis	Siss	Sing	Sij	Sich	Sik	Sit	Sip	Sih	Ssa	Ssag	Ssakk	Ssags	Ssan	Ssanj	Ssanh	Ssad";
    case 195:
      return "Ssal	Ssalg	Ssalm	Ssalb	Ssals	Ssalt	Ssalp	Ssalh	Ssam	Ssab	Ssabs	Ssas	Ssass	Ssang	Ssaj	Ssach	Ssak	Ssat	Ssap	Ssah	Ssae	Ssaeg	Ssaekk	Ssaegs	Ssaen	Ssaenj	Ssaenh	Ssaed	Ssael	Ssaelg	Ssaelm	Ssaelb	Ssaels	Ssaelt	Ssaelp	Ssaelh	Ssaem	Ssaeb	Ssaebs	Ssaes	Ssaess	Ssaeng	Ssaej	Ssaech	Ssaek	Ssaet	Ssaep	Ssaeh	Ssya	Ssyag	Ssyakk	Ssyags	Ssyan	Ssyanj	Ssyanh	Ssyad	Ssyal	Ssyalg	Ssyalm	Ssyalb	Ssyals	Ssyalt	Ssyalp	Ssyalh	Ssyam	Ssyab	Ssyabs	Ssyas	Ssyass	Ssyang	Ssyaj	Ssyach	Ssyak	Ssyat	Ssyap	Ssyah	Ssyae	Ssyaeg	Ssyaekk	Ssyaegs	Ssyaen	Ssyaenj	Ssyaenh	Ssyaed	Ssyael	Ssyaelg	Ssyaelm	Ssyaelb	Ssyaels	Ssyaelt	Ssyaelp	Ssyaelh	Ssyaem	Ssyaeb	Ssyaebs	Ssyaes	Ssyaess	Ssyaeng	Ssyaej	Ssyaech	Ssyaek	Ssyaet	Ssyaep	Ssyaeh	Sseo	Sseog	Sseokk	Sseogs	Sseon	Sseonj	Sseonh	Sseod	Sseol	Sseolg	Sseolm	Sseolb	Sseols	Sseolt	Sseolp	Sseolh	Sseom	Sseob	Sseobs	Sseos	Sseoss	Sseong	Sseoj	Sseoch	Sseok	Sseot	Sseop	Sseoh	Sse	Sseg	Ssekk	Ssegs	Ssen	Ssenj	Ssenh	Ssed	Ssel	Sselg	Sselm	Sselb	Ssels	Sselt	Sselp	Sselh	Ssem	Sseb	Ssebs	Sses	Ssess	Sseng	Ssej	Ssech	Ssek	Sset	Ssep	Sseh	Ssyeo	Ssyeog	Ssyeokk	Ssyeogs	Ssyeon	Ssyeonj	Ssyeonh	Ssyeod	Ssyeol	Ssyeolg	Ssyeolm	Ssyeolb	Ssyeols	Ssyeolt	Ssyeolp	Ssyeolh	Ssyeom	Ssyeob	Ssyeobs	Ssyeos	Ssyeoss	Ssyeong	Ssyeoj	Ssyeoch	Ssyeok	Ssyeot	Ssyeop	Ssyeoh	Ssye	Ssyeg	Ssyekk	Ssyegs	Ssyen	Ssyenj	Ssyenh	Ssyed	Ssyel	Ssyelg	Ssyelm	Ssyelb	Ssyels	Ssyelt	Ssyelp	Ssyelh	Ssyem	Ssyeb	Ssyebs	Ssyes	Ssyess	Ssyeng	Ssyej	Ssyech	Ssyek	Ssyet	Ssyep	Ssyeh	Sso	Ssog	Ssokk	Ssogs	Sson	Ssonj	Ssonh	Ssod	Ssol	Ssolg	Ssolm	Ssolb	Ssols	Ssolt	Ssolp	Ssolh	Ssom	Ssob	Ssobs	Ssos	Ssoss	Ssong	Ssoj	Ssoch	Ssok	Ssot	Ssop	Ssoh	Sswa	Sswag	Sswakk	Sswags	Sswan	Sswanj	Sswanh	Sswad	Sswal	Sswalg	Sswalm	Sswalb";
    case 196:
      return "Sswals	Sswalt	Sswalp	Sswalh	Sswam	Sswab	Sswabs	Sswas	Sswass	Sswang	Sswaj	Sswach	Sswak	Sswat	Sswap	Sswah	Sswae	Sswaeg	Sswaekk	Sswaegs	Sswaen	Sswaenj	Sswaenh	Sswaed	Sswael	Sswaelg	Sswaelm	Sswaelb	Sswaels	Sswaelt	Sswaelp	Sswaelh	Sswaem	Sswaeb	Sswaebs	Sswaes	Sswaess	Sswaeng	Sswaej	Sswaech	Sswaek	Sswaet	Sswaep	Sswaeh	Ssoe	Ssoeg	Ssoekk	Ssoegs	Ssoen	Ssoenj	Ssoenh	Ssoed	Ssoel	Ssoelg	Ssoelm	Ssoelb	Ssoels	Ssoelt	Ssoelp	Ssoelh	Ssoem	Ssoeb	Ssoebs	Ssoes	Ssoess	Ssoeng	Ssoej	Ssoech	Ssoek	Ssoet	Ssoep	Ssoeh	Ssyo	Ssyog	Ssyokk	Ssyogs	Ssyon	Ssyonj	Ssyonh	Ssyod	Ssyol	Ssyolg	Ssyolm	Ssyolb	Ssyols	Ssyolt	Ssyolp	Ssyolh	Ssyom	Ssyob	Ssyobs	Ssyos	Ssyoss	Ssyong	Ssyoj	Ssyoch	Ssyok	Ssyot	Ssyop	Ssyoh	Ssu	Ssug	Ssukk	Ssugs	Ssun	Ssunj	Ssunh	Ssud	Ssul	Ssulg	Ssulm	Ssulb	Ssuls	Ssult	Ssulp	Ssulh	Ssum	Ssub	Ssubs	Ssus	Ssuss	Ssung	Ssuj	Ssuch	Ssuk	Ssut	Ssup	Ssuh	Sswo	Sswog	Sswokk	Sswogs	Sswon	Sswonj	Sswonh	Sswod	Sswol	Sswolg	Sswolm	Sswolb	Sswols	Sswolt	Sswolp	Sswolh	Sswom	Sswob	Sswobs	Sswos	Sswoss	Sswong	Sswoj	Sswoch	Sswok	Sswot	Sswop	Sswoh	Sswe	Ssweg	Sswekk	Sswegs	Sswen	Sswenj	Sswenh	Sswed	Sswel	Sswelg	Sswelm	Sswelb	Sswels	Sswelt	Sswelp	Sswelh	Sswem	Ssweb	Sswebs	Sswes	Sswess	Ssweng	Sswej	Sswech	Sswek	Sswet	Sswep	Ssweh	Sswi	Sswig	Sswikk	Sswigs	Sswin	Sswinj	Sswinh	Sswid	Sswil	Sswilg	Sswilm	Sswilb	Sswils	Sswilt	Sswilp	Sswilh	Sswim	Sswib	Sswibs	Sswis	Sswiss	Sswing	Sswij	Sswich	Sswik	Sswit	Sswip	Sswih	Ssyu	Ssyug	Ssyukk	Ssyugs	Ssyun	Ssyunj	Ssyunh	Ssyud	Ssyul	Ssyulg	Ssyulm	Ssyulb	Ssyuls	Ssyult	Ssyulp	Ssyulh	Ssyum	Ssyub	Ssyubs	Ssyus	Ssyuss	Ssyung	Ssyuj	Ssyuch	Ssyuk	Ssyut	Ssyup	Ssyuh	Sseu	Sseug	Sseukk	Sseugs	Sseun	Sseunj	Sseunh	Sseud	Sseul	Sseulg	Sseulm	Sseulb	Sseuls	Sseult	Sseulp	Sseulh";
    case 197:
      return "Sseum	Sseub	Sseubs	Sseus	Sseuss	Sseung	Sseuj	Sseuch	Sseuk	Sseut	Sseup	Sseuh	Ssui	Ssuig	Ssuikk	Ssuigs	Ssuin	Ssuinj	Ssuinh	Ssuid	Ssuil	Ssuilg	Ssuilm	Ssuilb	Ssuils	Ssuilt	Ssuilp	Ssuilh	Ssuim	Ssuib	Ssuibs	Ssuis	Ssuiss	Ssuing	Ssuij	Ssuich	Ssuik	Ssuit	Ssuip	Ssuih	Ssi	Ssig	Ssikk	Ssigs	Ssin	Ssinj	Ssinh	Ssid	Ssil	Ssilg	Ssilm	Ssilb	Ssils	Ssilt	Ssilp	Ssilh	Ssim	Ssib	Ssibs	Ssis	Ssiss	Ssing	Ssij	Ssich	Ssik	Ssit	Ssip	Ssih	A	Ag	Akk	Ags	An	Anj	Anh	Ad	Al	Alg	Alm	Alb	Als	Alt	Alp	Alh	Am	Ab	Abs	As	Ass	Ang	Aj	Ach	Ak	At	Ap	Ah	Ae	Aeg	Aekk	Aegs	Aen	Aenj	Aenh	Aed	Ael	Aelg	Aelm	Aelb	Aels	Aelt	Aelp	Aelh	Aem	Aeb	Aebs	Aes	Aess	Aeng	Aej	Aech	Aek	Aet	Aep	Aeh	Ya	Yag	Yakk	Yags	Yan	Yanj	Yanh	Yad	Yal	Yalg	Yalm	Yalb	Yals	Yalt	Yalp	Yalh	Yam	Yab	Yabs	Yas	Yass	Yang	Yaj	Yach	Yak	Yat	Yap	Yah	Yae	Yaeg	Yaekk	Yaegs	Yaen	Yaenj	Yaenh	Yaed	Yael	Yaelg	Yaelm	Yaelb	Yaels	Yaelt	Yaelp	Yaelh	Yaem	Yaeb	Yaebs	Yaes	Yaess	Yaeng	Yaej	Yaech	Yaek	Yaet	Yaep	Yaeh	Eo	Eog	Eokk	Eogs	Eon	Eonj	Eonh	Eod	Eol	Eolg	Eolm	Eolb	Eols	Eolt	Eolp	Eolh	Eom	Eob	Eobs	Eos	Eoss	Eong	Eoj	Eoch	Eok	Eot	Eop	Eoh	E	Eg	Ekk	Egs	En	Enj	Enh	Ed	El	Elg	Elm	Elb	Els	Elt	Elp	Elh	Em	Eb	Ebs	Es	Ess	Eng	Ej	Ech	Ek	Et	Ep	Eh	Yeo	Yeog	Yeokk	Yeogs	Yeon	Yeonj	Yeonh	Yeod	Yeol	Yeolg	Yeolm	Yeolb	Yeols	Yeolt	Yeolp	Yeolh	Yeom	Yeob	Yeobs	Yeos";
    case 198:
      return "Yeoss	Yeong	Yeoj	Yeoch	Yeok	Yeot	Yeop	Yeoh	Ye	Yeg	Yekk	Yegs	Yen	Yenj	Yenh	Yed	Yel	Yelg	Yelm	Yelb	Yels	Yelt	Yelp	Yelh	Yem	Yeb	Yebs	Yes	Yess	Yeng	Yej	Yech	Yek	Yet	Yep	Yeh	O	Og	Okk	Ogs	On	Onj	Onh	Od	Ol	Olg	Olm	Olb	Ols	Olt	Olp	Olh	Om	Ob	Obs	Os	Oss	Ong	Oj	Och	Ok	Ot	Op	Oh	Wa	Wag	Wakk	Wags	Wan	Wanj	Wanh	Wad	Wal	Walg	Walm	Walb	Wals	Walt	Walp	Walh	Wam	Wab	Wabs	Was	Wass	Wang	Waj	Wach	Wak	Wat	Wap	Wah	Wae	Waeg	Waekk	Waegs	Waen	Waenj	Waenh	Waed	Wael	Waelg	Waelm	Waelb	Waels	Waelt	Waelp	Waelh	Waem	Waeb	Waebs	Waes	Waess	Waeng	Waej	Waech	Waek	Waet	Waep	Waeh	Oe	Oeg	Oekk	Oegs	Oen	Oenj	Oenh	Oed	Oel	Oelg	Oelm	Oelb	Oels	Oelt	Oelp	Oelh	Oem	Oeb	Oebs	Oes	Oess	Oeng	Oej	Oech	Oek	Oet	Oep	Oeh	Yo	Yog	Yokk	Yogs	Yon	Yonj	Yonh	Yod	Yol	Yolg	Yolm	Yolb	Yols	Yolt	Yolp	Yolh	Yom	Yob	Yobs	Yos	Yoss	Yong	Yoj	Yoch	Yok	Yot	Yop	Yoh	U	Ug	Ukk	Ugs	Un	Unj	Unh	Ud	Ul	Ulg	Ulm	Ulb	Uls	Ult	Ulp	Ulh	Um	Ub	Ubs	Us	Uss	Ung	Uj	Uch	Uk	Ut	Up	Uh	Wo	Wog	Wokk	Wogs	Won	Wonj	Wonh	Wod	Wol	Wolg	Wolm	Wolb	Wols	Wolt	Wolp	Wolh	Wom	Wob	Wobs	Wos	Woss	Wong	Woj	Woch	Wok	Wot	Wop	Woh	We	Weg	Wekk	Wegs	Wen	Wenj	Wenh	Wed	Wel	Welg	Welm	Welb	Wels	Welt	Welp	Welh	Wem	Web	Webs	Wes	Wess	Weng	Wej	Wech";
    case 199:
      return "Wek	Wet	Wep	Weh	Wi	Wig	Wikk	Wigs	Win	Winj	Winh	Wid	Wil	Wilg	Wilm	Wilb	Wils	Wilt	Wilp	Wilh	Wim	Wib	Wibs	Wis	Wiss	Wing	Wij	Wich	Wik	Wit	Wip	Wih	Yu	Yug	Yukk	Yugs	Yun	Yunj	Yunh	Yud	Yul	Yulg	Yulm	Yulb	Yuls	Yult	Yulp	Yulh	Yum	Yub	Yubs	Yus	Yuss	Yung	Yuj	Yuch	Yuk	Yut	Yup	Yuh	Eu	Eug	Eukk	Eugs	Eun	Eunj	Eunh	Eud	Eul	Eulg	Eulm	Eulb	Euls	Eult	Eulp	Eulh	Eum	Eub	Eubs	Eus	Euss	Eung	Euj	Euch	Euk	Eut	Eup	Euh	Ui	Uig	Uikk	Uigs	Uin	Uinj	Uinh	Uid	Uil	Uilg	Uilm	Uilb	Uils	Uilt	Uilp	Uilh	Uim	Uib	Uibs	Uis	Uiss	Uing	Uij	Uich	Uik	Uit	Uip	Uih	I	Ig	Ikk	Igs	In	Inj	Inh	Id	Il	Ilg	Ilm	Ilb	Ils	Ilt	Ilp	Ilh	Im	Ib	Ibs	Is	Iss	Ing	Ij	Ich	Ik	It	Ip	Ih	Ja	Jag	Jakk	Jags	Jan	Janj	Janh	Jad	Jal	Jalg	Jalm	Jalb	Jals	Jalt	Jalp	Jalh	Jam	Jab	Jabs	Jas	Jass	Jang	Jaj	Jach	Jak	Jat	Jap	Jah	Jae	Jaeg	Jaekk	Jaegs	Jaen	Jaenj	Jaenh	Jaed	Jael	Jaelg	Jaelm	Jaelb	Jaels	Jaelt	Jaelp	Jaelh	Jaem	Jaeb	Jaebs	Jaes	Jaess	Jaeng	Jaej	Jaech	Jaek	Jaet	Jaep	Jaeh	Jya	Jyag	Jyakk	Jyags	Jyan	Jyanj	Jyanh	Jyad	Jyal	Jyalg	Jyalm	Jyalb	Jyals	Jyalt	Jyalp	Jyalh	Jyam	Jyab	Jyabs	Jyas	Jyass	Jyang	Jyaj	Jyach	Jyak	Jyat	Jyap	Jyah	Jyae	Jyaeg	Jyaekk	Jyaegs	Jyaen	Jyaenj	Jyaenh	Jyaed	Jyael	Jyaelg	Jyaelm	Jyaelb	Jyaels	Jyaelt	Jyaelp	Jyaelh	Jyaem	Jyaeb	Jyaebs	Jyaes	Jyaess	Jyaeng	Jyaej	Jyaech	Jyaek	Jyaet	Jyaep	Jyaeh";
    case 200:
      return "Jeo	Jeog	Jeokk	Jeogs	Jeon	Jeonj	Jeonh	Jeod	Jeol	Jeolg	Jeolm	Jeolb	Jeols	Jeolt	Jeolp	Jeolh	Jeom	Jeob	Jeobs	Jeos	Jeoss	Jeong	Jeoj	Jeoch	Jeok	Jeot	Jeop	Jeoh	Je	Jeg	Jekk	Jegs	Jen	Jenj	Jenh	Jed	Jel	Jelg	Jelm	Jelb	Jels	Jelt	Jelp	Jelh	Jem	Jeb	Jebs	Jes	Jess	Jeng	Jej	Jech	Jek	Jet	Jep	Jeh	Jyeo	Jyeog	Jyeokk	Jyeogs	Jyeon	Jyeonj	Jyeonh	Jyeod	Jyeol	Jyeolg	Jyeolm	Jyeolb	Jyeols	Jyeolt	Jyeolp	Jyeolh	Jyeom	Jyeob	Jyeobs	Jyeos	Jyeoss	Jyeong	Jyeoj	Jyeoch	Jyeok	Jyeot	Jyeop	Jyeoh	Jye	Jyeg	Jyekk	Jyegs	Jyen	Jyenj	Jyenh	Jyed	Jyel	Jyelg	Jyelm	Jyelb	Jyels	Jyelt	Jyelp	Jyelh	Jyem	Jyeb	Jyebs	Jyes	Jyess	Jyeng	Jyej	Jyech	Jyek	Jyet	Jyep	Jyeh	Jo	Jog	Jokk	Jogs	Jon	Jonj	Jonh	Jod	Jol	Jolg	Jolm	Jolb	Jols	Jolt	Jolp	Jolh	Jom	Job	Jobs	Jos	Joss	Jong	Joj	Joch	Jok	Jot	Jop	Joh	Jwa	Jwag	Jwakk	Jwags	Jwan	Jwanj	Jwanh	Jwad	Jwal	Jwalg	Jwalm	Jwalb	Jwals	Jwalt	Jwalp	Jwalh	Jwam	Jwab	Jwabs	Jwas	Jwass	Jwang	Jwaj	Jwach	Jwak	Jwat	Jwap	Jwah	Jwae	Jwaeg	Jwaekk	Jwaegs	Jwaen	Jwaenj	Jwaenh	Jwaed	Jwael	Jwaelg	Jwaelm	Jwaelb	Jwaels	Jwaelt	Jwaelp	Jwaelh	Jwaem	Jwaeb	Jwaebs	Jwaes	Jwaess	Jwaeng	Jwaej	Jwaech	Jwaek	Jwaet	Jwaep	Jwaeh	Joe	Joeg	Joekk	Joegs	Joen	Joenj	Joenh	Joed	Joel	Joelg	Joelm	Joelb	Joels	Joelt	Joelp	Joelh	Joem	Joeb	Joebs	Joes	Joess	Joeng	Joej	Joech	Joek	Joet	Joep	Joeh	Jyo	Jyog	Jyokk	Jyogs	Jyon	Jyonj	Jyonh	Jyod	Jyol	Jyolg	Jyolm	Jyolb	Jyols	Jyolt	Jyolp	Jyolh	Jyom	Jyob	Jyobs	Jyos	Jyoss	Jyong	Jyoj	Jyoch	Jyok	Jyot	Jyop	Jyoh	Ju	Jug	Jukk	Jugs";
    case 201:
      return "Jun	Junj	Junh	Jud	Jul	Julg	Julm	Julb	Juls	Jult	Julp	Julh	Jum	Jub	Jubs	Jus	Juss	Jung	Juj	Juch	Juk	Jut	Jup	Juh	Jwo	Jwog	Jwokk	Jwogs	Jwon	Jwonj	Jwonh	Jwod	Jwol	Jwolg	Jwolm	Jwolb	Jwols	Jwolt	Jwolp	Jwolh	Jwom	Jwob	Jwobs	Jwos	Jwoss	Jwong	Jwoj	Jwoch	Jwok	Jwot	Jwop	Jwoh	Jwe	Jweg	Jwekk	Jwegs	Jwen	Jwenj	Jwenh	Jwed	Jwel	Jwelg	Jwelm	Jwelb	Jwels	Jwelt	Jwelp	Jwelh	Jwem	Jweb	Jwebs	Jwes	Jwess	Jweng	Jwej	Jwech	Jwek	Jwet	Jwep	Jweh	Jwi	Jwig	Jwikk	Jwigs	Jwin	Jwinj	Jwinh	Jwid	Jwil	Jwilg	Jwilm	Jwilb	Jwils	Jwilt	Jwilp	Jwilh	Jwim	Jwib	Jwibs	Jwis	Jwiss	Jwing	Jwij	Jwich	Jwik	Jwit	Jwip	Jwih	Jyu	Jyug	Jyukk	Jyugs	Jyun	Jyunj	Jyunh	Jyud	Jyul	Jyulg	Jyulm	Jyulb	Jyuls	Jyult	Jyulp	Jyulh	Jyum	Jyub	Jyubs	Jyus	Jyuss	Jyung	Jyuj	Jyuch	Jyuk	Jyut	Jyup	Jyuh	Jeu	Jeug	Jeukk	Jeugs	Jeun	Jeunj	Jeunh	Jeud	Jeul	Jeulg	Jeulm	Jeulb	Jeuls	Jeult	Jeulp	Jeulh	Jeum	Jeub	Jeubs	Jeus	Jeuss	Jeung	Jeuj	Jeuch	Jeuk	Jeut	Jeup	Jeuh	Jui	Juig	Juikk	Juigs	Juin	Juinj	Juinh	Juid	Juil	Juilg	Juilm	Juilb	Juils	Juilt	Juilp	Juilh	Juim	Juib	Juibs	Juis	Juiss	Juing	Juij	Juich	Juik	Juit	Juip	Juih	Ji	Jig	Jikk	Jigs	Jin	Jinj	Jinh	Jid	Jil	Jilg	Jilm	Jilb	Jils	Jilt	Jilp	Jilh	Jim	Jib	Jibs	Jis	Jiss	Jing	Jij	Jich	Jik	Jit	Jip	Jih	Jja	Jjag	Jjakk	Jjags	Jjan	Jjanj	Jjanh	Jjad	Jjal	Jjalg	Jjalm	Jjalb	Jjals	Jjalt	Jjalp	Jjalh	Jjam	Jjab	Jjabs	Jjas	Jjass	Jjang	Jjaj	Jjach	Jjak	Jjat	Jjap	Jjah	Jjae	Jjaeg	Jjaekk	Jjaegs	Jjaen	Jjaenj	Jjaenh	Jjaed";
    case 202:
      return "Jjael	Jjaelg	Jjaelm	Jjaelb	Jjaels	Jjaelt	Jjaelp	Jjaelh	Jjaem	Jjaeb	Jjaebs	Jjaes	Jjaess	Jjaeng	Jjaej	Jjaech	Jjaek	Jjaet	Jjaep	Jjaeh	Jjya	Jjyag	Jjyakk	Jjyags	Jjyan	Jjyanj	Jjyanh	Jjyad	Jjyal	Jjyalg	Jjyalm	Jjyalb	Jjyals	Jjyalt	Jjyalp	Jjyalh	Jjyam	Jjyab	Jjyabs	Jjyas	Jjyass	Jjyang	Jjyaj	Jjyach	Jjyak	Jjyat	Jjyap	Jjyah	Jjyae	Jjyaeg	Jjyaekk	Jjyaegs	Jjyaen	Jjyaenj	Jjyaenh	Jjyaed	Jjyael	Jjyaelg	Jjyaelm	Jjyaelb	Jjyaels	Jjyaelt	Jjyaelp	Jjyaelh	Jjyaem	Jjyaeb	Jjyaebs	Jjyaes	Jjyaess	Jjyaeng	Jjyaej	Jjyaech	Jjyaek	Jjyaet	Jjyaep	Jjyaeh	Jjeo	Jjeog	Jjeokk	Jjeogs	Jjeon	Jjeonj	Jjeonh	Jjeod	Jjeol	Jjeolg	Jjeolm	Jjeolb	Jjeols	Jjeolt	Jjeolp	Jjeolh	Jjeom	Jjeob	Jjeobs	Jjeos	Jjeoss	Jjeong	Jjeoj	Jjeoch	Jjeok	Jjeot	Jjeop	Jjeoh	Jje	Jjeg	Jjekk	Jjegs	Jjen	Jjenj	Jjenh	Jjed	Jjel	Jjelg	Jjelm	Jjelb	Jjels	Jjelt	Jjelp	Jjelh	Jjem	Jjeb	Jjebs	Jjes	Jjess	Jjeng	Jjej	Jjech	Jjek	Jjet	Jjep	Jjeh	Jjyeo	Jjyeog	Jjyeokk	Jjyeogs	Jjyeon	Jjyeonj	Jjyeonh	Jjyeod	Jjyeol	Jjyeolg	Jjyeolm	Jjyeolb	Jjyeols	Jjyeolt	Jjyeolp	Jjyeolh	Jjyeom	Jjyeob	Jjyeobs	Jjyeos	Jjyeoss	Jjyeong	Jjyeoj	Jjyeoch	Jjyeok	Jjyeot	Jjyeop	Jjyeoh	Jjye	Jjyeg	Jjyekk	Jjyegs	Jjyen	Jjyenj	Jjyenh	Jjyed	Jjyel	Jjyelg	Jjyelm	Jjyelb	Jjyels	Jjyelt	Jjyelp	Jjyelh	Jjyem	Jjyeb	Jjyebs	Jjyes	Jjyess	Jjyeng	Jjyej	Jjyech	Jjyek	Jjyet	Jjyep	Jjyeh	Jjo	Jjog	Jjokk	Jjogs	Jjon	Jjonj	Jjonh	Jjod	Jjol	Jjolg	Jjolm	Jjolb	Jjols	Jjolt	Jjolp	Jjolh	Jjom	Jjob	Jjobs	Jjos	Jjoss	Jjong	Jjoj	Jjoch	Jjok	Jjot	Jjop	Jjoh	Jjwa	Jjwag	Jjwakk	Jjwags	Jjwan	Jjwanj	Jjwanh	Jjwad	Jjwal	Jjwalg	Jjwalm	Jjwalb	Jjwals	Jjwalt	Jjwalp	Jjwalh	Jjwam	Jjwab	Jjwabs	Jjwas	Jjwass	Jjwang	Jjwaj	Jjwach	Jjwak	Jjwat	Jjwap	Jjwah	Jjwae	Jjwaeg	Jjwaekk	Jjwaegs	Jjwaen	Jjwaenj	Jjwaenh	Jjwaed	Jjwael	Jjwaelg	Jjwaelm	Jjwaelb";
    case 203:
      return "Jjwaels	Jjwaelt	Jjwaelp	Jjwaelh	Jjwaem	Jjwaeb	Jjwaebs	Jjwaes	Jjwaess	Jjwaeng	Jjwaej	Jjwaech	Jjwaek	Jjwaet	Jjwaep	Jjwaeh	Jjoe	Jjoeg	Jjoekk	Jjoegs	Jjoen	Jjoenj	Jjoenh	Jjoed	Jjoel	Jjoelg	Jjoelm	Jjoelb	Jjoels	Jjoelt	Jjoelp	Jjoelh	Jjoem	Jjoeb	Jjoebs	Jjoes	Jjoess	Jjoeng	Jjoej	Jjoech	Jjoek	Jjoet	Jjoep	Jjoeh	Jjyo	Jjyog	Jjyokk	Jjyogs	Jjyon	Jjyonj	Jjyonh	Jjyod	Jjyol	Jjyolg	Jjyolm	Jjyolb	Jjyols	Jjyolt	Jjyolp	Jjyolh	Jjyom	Jjyob	Jjyobs	Jjyos	Jjyoss	Jjyong	Jjyoj	Jjyoch	Jjyok	Jjyot	Jjyop	Jjyoh	Jju	Jjug	Jjukk	Jjugs	Jjun	Jjunj	Jjunh	Jjud	Jjul	Jjulg	Jjulm	Jjulb	Jjuls	Jjult	Jjulp	Jjulh	Jjum	Jjub	Jjubs	Jjus	Jjuss	Jjung	Jjuj	Jjuch	Jjuk	Jjut	Jjup	Jjuh	Jjwo	Jjwog	Jjwokk	Jjwogs	Jjwon	Jjwonj	Jjwonh	Jjwod	Jjwol	Jjwolg	Jjwolm	Jjwolb	Jjwols	Jjwolt	Jjwolp	Jjwolh	Jjwom	Jjwob	Jjwobs	Jjwos	Jjwoss	Jjwong	Jjwoj	Jjwoch	Jjwok	Jjwot	Jjwop	Jjwoh	Jjwe	Jjweg	Jjwekk	Jjwegs	Jjwen	Jjwenj	Jjwenh	Jjwed	Jjwel	Jjwelg	Jjwelm	Jjwelb	Jjwels	Jjwelt	Jjwelp	Jjwelh	Jjwem	Jjweb	Jjwebs	Jjwes	Jjwess	Jjweng	Jjwej	Jjwech	Jjwek	Jjwet	Jjwep	Jjweh	Jjwi	Jjwig	Jjwikk	Jjwigs	Jjwin	Jjwinj	Jjwinh	Jjwid	Jjwil	Jjwilg	Jjwilm	Jjwilb	Jjwils	Jjwilt	Jjwilp	Jjwilh	Jjwim	Jjwib	Jjwibs	Jjwis	Jjwiss	Jjwing	Jjwij	Jjwich	Jjwik	Jjwit	Jjwip	Jjwih	Jjyu	Jjyug	Jjyukk	Jjyugs	Jjyun	Jjyunj	Jjyunh	Jjyud	Jjyul	Jjyulg	Jjyulm	Jjyulb	Jjyuls	Jjyult	Jjyulp	Jjyulh	Jjyum	Jjyub	Jjyubs	Jjyus	Jjyuss	Jjyung	Jjyuj	Jjyuch	Jjyuk	Jjyut	Jjyup	Jjyuh	Jjeu	Jjeug	Jjeukk	Jjeugs	Jjeun	Jjeunj	Jjeunh	Jjeud	Jjeul	Jjeulg	Jjeulm	Jjeulb	Jjeuls	Jjeult	Jjeulp	Jjeulh	Jjeum	Jjeub	Jjeubs	Jjeus	Jjeuss	Jjeung	Jjeuj	Jjeuch	Jjeuk	Jjeut	Jjeup	Jjeuh	Jjui	Jjuig	Jjuikk	Jjuigs	Jjuin	Jjuinj	Jjuinh	Jjuid	Jjuil	Jjuilg	Jjuilm	Jjuilb	Jjuils	Jjuilt	Jjuilp	Jjuilh";
    case 204:
      return "Jjuim	Jjuib	Jjuibs	Jjuis	Jjuiss	Jjuing	Jjuij	Jjuich	Jjuik	Jjuit	Jjuip	Jjuih	Jji	Jjig	Jjikk	Jjigs	Jjin	Jjinj	Jjinh	Jjid	Jjil	Jjilg	Jjilm	Jjilb	Jjils	Jjilt	Jjilp	Jjilh	Jjim	Jjib	Jjibs	Jjis	Jjiss	Jjing	Jjij	Jjich	Jjik	Jjit	Jjip	Jjih	Cha	Chag	Chakk	Chags	Chan	Chanj	Chanh	Chad	Chal	Chalg	Chalm	Chalb	Chals	Chalt	Chalp	Chalh	Cham	Chab	Chabs	Chas	Chass	Chang	Chaj	Chach	Chak	Chat	Chap	Chah	Chae	Chaeg	Chaekk	Chaegs	Chaen	Chaenj	Chaenh	Chaed	Chael	Chaelg	Chaelm	Chaelb	Chaels	Chaelt	Chaelp	Chaelh	Chaem	Chaeb	Chaebs	Chaes	Chaess	Chaeng	Chaej	Chaech	Chaek	Chaet	Chaep	Chaeh	Chya	Chyag	Chyakk	Chyags	Chyan	Chyanj	Chyanh	Chyad	Chyal	Chyalg	Chyalm	Chyalb	Chyals	Chyalt	Chyalp	Chyalh	Chyam	Chyab	Chyabs	Chyas	Chyass	Chyang	Chyaj	Chyach	Chyak	Chyat	Chyap	Chyah	Chyae	Chyaeg	Chyaekk	Chyaegs	Chyaen	Chyaenj	Chyaenh	Chyaed	Chyael	Chyaelg	Chyaelm	Chyaelb	Chyaels	Chyaelt	Chyaelp	Chyaelh	Chyaem	Chyaeb	Chyaebs	Chyaes	Chyaess	Chyaeng	Chyaej	Chyaech	Chyaek	Chyaet	Chyaep	Chyaeh	Cheo	Cheog	Cheokk	Cheogs	Cheon	Cheonj	Cheonh	Cheod	Cheol	Cheolg	Cheolm	Cheolb	Cheols	Cheolt	Cheolp	Cheolh	Cheom	Cheob	Cheobs	Cheos	Cheoss	Cheong	Cheoj	Cheoch	Cheok	Cheot	Cheop	Cheoh	Che	Cheg	Chekk	Chegs	Chen	Chenj	Chenh	Ched	Chel	Chelg	Chelm	Chelb	Chels	Chelt	Chelp	Chelh	Chem	Cheb	Chebs	Ches	Chess	Cheng	Chej	Chech	Chek	Chet	Chep	Cheh	Chyeo	Chyeog	Chyeokk	Chyeogs	Chyeon	Chyeonj	Chyeonh	Chyeod	Chyeol	Chyeolg	Chyeolm	Chyeolb	Chyeols	Chyeolt	Chyeolp	Chyeolh	Chyeom	Chyeob	Chyeobs	Chyeos	Chyeoss	Chyeong	Chyeoj	Chyeoch	Chyeok	Chyeot	Chyeop	Chyeoh	Chye	Chyeg	Chyekk	Chyegs	Chyen	Chyenj	Chyenh	Chyed	Chyel	Chyelg	Chyelm	Chyelb	Chyels	Chyelt	Chyelp	Chyelh	Chyem	Chyeb	Chyebs	Chyes";
    case 205:
      return "Chyess	Chyeng	Chyej	Chyech	Chyek	Chyet	Chyep	Chyeh	Cho	Chog	Chokk	Chogs	Chon	Chonj	Chonh	Chod	Chol	Cholg	Cholm	Cholb	Chols	Cholt	Cholp	Cholh	Chom	Chob	Chobs	Chos	Choss	Chong	Choj	Choch	Chok	Chot	Chop	Choh	Chwa	Chwag	Chwakk	Chwags	Chwan	Chwanj	Chwanh	Chwad	Chwal	Chwalg	Chwalm	Chwalb	Chwals	Chwalt	Chwalp	Chwalh	Chwam	Chwab	Chwabs	Chwas	Chwass	Chwang	Chwaj	Chwach	Chwak	Chwat	Chwap	Chwah	Chwae	Chwaeg	Chwaekk	Chwaegs	Chwaen	Chwaenj	Chwaenh	Chwaed	Chwael	Chwaelg	Chwaelm	Chwaelb	Chwaels	Chwaelt	Chwaelp	Chwaelh	Chwaem	Chwaeb	Chwaebs	Chwaes	Chwaess	Chwaeng	Chwaej	Chwaech	Chwaek	Chwaet	Chwaep	Chwaeh	Choe	Choeg	Choekk	Choegs	Choen	Choenj	Choenh	Choed	Choel	Choelg	Choelm	Choelb	Choels	Choelt	Choelp	Choelh	Choem	Choeb	Choebs	Choes	Choess	Choeng	Choej	Choech	Choek	Choet	Choep	Choeh	Chyo	Chyog	Chyokk	Chyogs	Chyon	Chyonj	Chyonh	Chyod	Chyol	Chyolg	Chyolm	Chyolb	Chyols	Chyolt	Chyolp	Chyolh	Chyom	Chyob	Chyobs	Chyos	Chyoss	Chyong	Chyoj	Chyoch	Chyok	Chyot	Chyop	Chyoh	Chu	Chug	Chukk	Chugs	Chun	Chunj	Chunh	Chud	Chul	Chulg	Chulm	Chulb	Chuls	Chult	Chulp	Chulh	Chum	Chub	Chubs	Chus	Chuss	Chung	Chuj	Chuch	Chuk	Chut	Chup	Chuh	Chwo	Chwog	Chwokk	Chwogs	Chwon	Chwonj	Chwonh	Chwod	Chwol	Chwolg	Chwolm	Chwolb	Chwols	Chwolt	Chwolp	Chwolh	Chwom	Chwob	Chwobs	Chwos	Chwoss	Chwong	Chwoj	Chwoch	Chwok	Chwot	Chwop	Chwoh	Chwe	Chweg	Chwekk	Chwegs	Chwen	Chwenj	Chwenh	Chwed	Chwel	Chwelg	Chwelm	Chwelb	Chwels	Chwelt	Chwelp	Chwelh	Chwem	Chweb	Chwebs	Chwes	Chwess	Chweng	Chwej	Chwech	Chwek	Chwet	Chwep	Chweh	Chwi	Chwig	Chwikk	Chwigs	Chwin	Chwinj	Chwinh	Chwid	Chwil	Chwilg	Chwilm	Chwilb	Chwils	Chwilt	Chwilp	Chwilh	Chwim	Chwib	Chwibs	Chwis	Chwiss	Chwing	Chwij	Chwich";
    case 206:
      return "Chwik	Chwit	Chwip	Chwih	Chyu	Chyug	Chyukk	Chyugs	Chyun	Chyunj	Chyunh	Chyud	Chyul	Chyulg	Chyulm	Chyulb	Chyuls	Chyult	Chyulp	Chyulh	Chyum	Chyub	Chyubs	Chyus	Chyuss	Chyung	Chyuj	Chyuch	Chyuk	Chyut	Chyup	Chyuh	Cheu	Cheug	Cheukk	Cheugs	Cheun	Cheunj	Cheunh	Cheud	Cheul	Cheulg	Cheulm	Cheulb	Cheuls	Cheult	Cheulp	Cheulh	Cheum	Cheub	Cheubs	Cheus	Cheuss	Cheung	Cheuj	Cheuch	Cheuk	Cheut	Cheup	Cheuh	Chui	Chuig	Chuikk	Chuigs	Chuin	Chuinj	Chuinh	Chuid	Chuil	Chuilg	Chuilm	Chuilb	Chuils	Chuilt	Chuilp	Chuilh	Chuim	Chuib	Chuibs	Chuis	Chuiss	Chuing	Chuij	Chuich	Chuik	Chuit	Chuip	Chuih	Chi	Chig	Chikk	Chigs	Chin	Chinj	Chinh	Chid	Chil	Chilg	Chilm	Chilb	Chils	Chilt	Chilp	Chilh	Chim	Chib	Chibs	Chis	Chiss	Ching	Chij	Chich	Chik	Chit	Chip	Chih	Ka	Kag	Kakk	Kags	Kan	Kanj	Kanh	Kad	Kal	Kalg	Kalm	Kalb	Kals	Kalt	Kalp	Kalh	Kam	Kab	Kabs	Kas	Kass	Kang	Kaj	Kach	Kak	Kat	Kap	Kah	Kae	Kaeg	Kaekk	Kaegs	Kaen	Kaenj	Kaenh	Kaed	Kael	Kaelg	Kaelm	Kaelb	Kaels	Kaelt	Kaelp	Kaelh	Kaem	Kaeb	Kaebs	Kaes	Kaess	Kaeng	Kaej	Kaech	Kaek	Kaet	Kaep	Kaeh	Kya	Kyag	Kyakk	Kyags	Kyan	Kyanj	Kyanh	Kyad	Kyal	Kyalg	Kyalm	Kyalb	Kyals	Kyalt	Kyalp	Kyalh	Kyam	Kyab	Kyabs	Kyas	Kyass	Kyang	Kyaj	Kyach	Kyak	Kyat	Kyap	Kyah	Kyae	Kyaeg	Kyaekk	Kyaegs	Kyaen	Kyaenj	Kyaenh	Kyaed	Kyael	Kyaelg	Kyaelm	Kyaelb	Kyaels	Kyaelt	Kyaelp	Kyaelh	Kyaem	Kyaeb	Kyaebs	Kyaes	Kyaess	Kyaeng	Kyaej	Kyaech	Kyaek	Kyaet	Kyaep	Kyaeh	Keo	Keog	Keokk	Keogs	Keon	Keonj	Keonh	Keod	Keol	Keolg	Keolm	Keolb	Keols	Keolt	Keolp	Keolh	Keom	Keob	Keobs	Keos	Keoss	Keong	Keoj	Keoch	Keok	Keot	Keop	Keoh";
    case 207:
      return "Ke	Keg	Kekk	Kegs	Ken	Kenj	Kenh	Ked	Kel	Kelg	Kelm	Kelb	Kels	Kelt	Kelp	Kelh	Kem	Keb	Kebs	Kes	Kess	Keng	Kej	Kech	Kek	Ket	Kep	Keh	Kyeo	Kyeog	Kyeokk	Kyeogs	Kyeon	Kyeonj	Kyeonh	Kyeod	Kyeol	Kyeolg	Kyeolm	Kyeolb	Kyeols	Kyeolt	Kyeolp	Kyeolh	Kyeom	Kyeob	Kyeobs	Kyeos	Kyeoss	Kyeong	Kyeoj	Kyeoch	Kyeok	Kyeot	Kyeop	Kyeoh	Kye	Kyeg	Kyekk	Kyegs	Kyen	Kyenj	Kyenh	Kyed	Kyel	Kyelg	Kyelm	Kyelb	Kyels	Kyelt	Kyelp	Kyelh	Kyem	Kyeb	Kyebs	Kyes	Kyess	Kyeng	Kyej	Kyech	Kyek	Kyet	Kyep	Kyeh	Ko	Kog	Kokk	Kogs	Kon	Konj	Konh	Kod	Kol	Kolg	Kolm	Kolb	Kols	Kolt	Kolp	Kolh	Kom	Kob	Kobs	Kos	Koss	Kong	Koj	Koch	Kok	Kot	Kop	Koh	Kwa	Kwag	Kwakk	Kwags	Kwan	Kwanj	Kwanh	Kwad	Kwal	Kwalg	Kwalm	Kwalb	Kwals	Kwalt	Kwalp	Kwalh	Kwam	Kwab	Kwabs	Kwas	Kwass	Kwang	Kwaj	Kwach	Kwak	Kwat	Kwap	Kwah	Kwae	Kwaeg	Kwaekk	Kwaegs	Kwaen	Kwaenj	Kwaenh	Kwaed	Kwael	Kwaelg	Kwaelm	Kwaelb	Kwaels	Kwaelt	Kwaelp	Kwaelh	Kwaem	Kwaeb	Kwaebs	Kwaes	Kwaess	Kwaeng	Kwaej	Kwaech	Kwaek	Kwaet	Kwaep	Kwaeh	Koe	Koeg	Koekk	Koegs	Koen	Koenj	Koenh	Koed	Koel	Koelg	Koelm	Koelb	Koels	Koelt	Koelp	Koelh	Koem	Koeb	Koebs	Koes	Koess	Koeng	Koej	Koech	Koek	Koet	Koep	Koeh	Kyo	Kyog	Kyokk	Kyogs	Kyon	Kyonj	Kyonh	Kyod	Kyol	Kyolg	Kyolm	Kyolb	Kyols	Kyolt	Kyolp	Kyolh	Kyom	Kyob	Kyobs	Kyos	Kyoss	Kyong	Kyoj	Kyoch	Kyok	Kyot	Kyop	Kyoh	Ku	Kug	Kukk	Kugs	Kun	Kunj	Kunh	Kud	Kul	Kulg	Kulm	Kulb	Kuls	Kult	Kulp	Kulh	Kum	Kub	Kubs	Kus	Kuss	Kung	Kuj	Kuch	Kuk	Kut	Kup	Kuh	Kwo	Kwog	Kwokk	Kwogs";
    case 208:
      return "Kwon	Kwonj	Kwonh	Kwod	Kwol	Kwolg	Kwolm	Kwolb	Kwols	Kwolt	Kwolp	Kwolh	Kwom	Kwob	Kwobs	Kwos	Kwoss	Kwong	Kwoj	Kwoch	Kwok	Kwot	Kwop	Kwoh	Kwe	Kweg	Kwekk	Kwegs	Kwen	Kwenj	Kwenh	Kwed	Kwel	Kwelg	Kwelm	Kwelb	Kwels	Kwelt	Kwelp	Kwelh	Kwem	Kweb	Kwebs	Kwes	Kwess	Kweng	Kwej	Kwech	Kwek	Kwet	Kwep	Kweh	Kwi	Kwig	Kwikk	Kwigs	Kwin	Kwinj	Kwinh	Kwid	Kwil	Kwilg	Kwilm	Kwilb	Kwils	Kwilt	Kwilp	Kwilh	Kwim	Kwib	Kwibs	Kwis	Kwiss	Kwing	Kwij	Kwich	Kwik	Kwit	Kwip	Kwih	Kyu	Kyug	Kyukk	Kyugs	Kyun	Kyunj	Kyunh	Kyud	Kyul	Kyulg	Kyulm	Kyulb	Kyuls	Kyult	Kyulp	Kyulh	Kyum	Kyub	Kyubs	Kyus	Kyuss	Kyung	Kyuj	Kyuch	Kyuk	Kyut	Kyup	Kyuh	Keu	Keug	Keukk	Keugs	Keun	Keunj	Keunh	Keud	Keul	Keulg	Keulm	Keulb	Keuls	Keult	Keulp	Keulh	Keum	Keub	Keubs	Keus	Keuss	Keung	Keuj	Keuch	Keuk	Keut	Keup	Keuh	Kui	Kuig	Kuikk	Kuigs	Kuin	Kuinj	Kuinh	Kuid	Kuil	Kuilg	Kuilm	Kuilb	Kuils	Kuilt	Kuilp	Kuilh	Kuim	Kuib	Kuibs	Kuis	Kuiss	Kuing	Kuij	Kuich	Kuik	Kuit	Kuip	Kuih	Ki	Kig	Kikk	Kigs	Kin	Kinj	Kinh	Kid	Kil	Kilg	Kilm	Kilb	Kils	Kilt	Kilp	Kilh	Kim	Kib	Kibs	Kis	Kiss	King	Kij	Kich	Kik	Kit	Kip	Kih	Ta	Tag	Takk	Tags	Tan	Tanj	Tanh	Tad	Tal	Talg	Talm	Talb	Tals	Talt	Talp	Talh	Tam	Tab	Tabs	Tas	Tass	Tang	Taj	Tach	Tak	Tat	Tap	Tah	Tae	Taeg	Taekk	Taegs	Taen	Taenj	Taenh	Taed	Tael	Taelg	Taelm	Taelb	Taels	Taelt	Taelp	Taelh	Taem	Taeb	Taebs	Taes	Taess	Taeng	Taej	Taech	Taek	Taet	Taep	Taeh	Tya	Tyag	Tyakk	Tyags	Tyan	Tyanj	Tyanh	Tyad";
    case 209:
      return "Tyal	Tyalg	Tyalm	Tyalb	Tyals	Tyalt	Tyalp	Tyalh	Tyam	Tyab	Tyabs	Tyas	Tyass	Tyang	Tyaj	Tyach	Tyak	Tyat	Tyap	Tyah	Tyae	Tyaeg	Tyaekk	Tyaegs	Tyaen	Tyaenj	Tyaenh	Tyaed	Tyael	Tyaelg	Tyaelm	Tyaelb	Tyaels	Tyaelt	Tyaelp	Tyaelh	Tyaem	Tyaeb	Tyaebs	Tyaes	Tyaess	Tyaeng	Tyaej	Tyaech	Tyaek	Tyaet	Tyaep	Tyaeh	Teo	Teog	Teokk	Teogs	Teon	Teonj	Teonh	Teod	Teol	Teolg	Teolm	Teolb	Teols	Teolt	Teolp	Teolh	Teom	Teob	Teobs	Teos	Teoss	Teong	Teoj	Teoch	Teok	Teot	Teop	Teoh	Te	Teg	Tekk	Tegs	Ten	Tenj	Tenh	Ted	Tel	Telg	Telm	Telb	Tels	Telt	Telp	Telh	Tem	Teb	Tebs	Tes	Tess	Teng	Tej	Tech	Tek	Tet	Tep	Teh	Tyeo	Tyeog	Tyeokk	Tyeogs	Tyeon	Tyeonj	Tyeonh	Tyeod	Tyeol	Tyeolg	Tyeolm	Tyeolb	Tyeols	Tyeolt	Tyeolp	Tyeolh	Tyeom	Tyeob	Tyeobs	Tyeos	Tyeoss	Tyeong	Tyeoj	Tyeoch	Tyeok	Tyeot	Tyeop	Tyeoh	Tye	Tyeg	Tyekk	Tyegs	Tyen	Tyenj	Tyenh	Tyed	Tyel	Tyelg	Tyelm	Tyelb	Tyels	Tyelt	Tyelp	Tyelh	Tyem	Tyeb	Tyebs	Tyes	Tyess	Tyeng	Tyej	Tyech	Tyek	Tyet	Tyep	Tyeh	To	Tog	Tokk	Togs	Ton	Tonj	Tonh	Tod	Tol	Tolg	Tolm	Tolb	Tols	Tolt	Tolp	Tolh	Tom	Tob	Tobs	Tos	Toss	Tong	Toj	Toch	Tok	Tot	Top	Toh	Twa	Twag	Twakk	Twags	Twan	Twanj	Twanh	Twad	Twal	Twalg	Twalm	Twalb	Twals	Twalt	Twalp	Twalh	Twam	Twab	Twabs	Twas	Twass	Twang	Twaj	Twach	Twak	Twat	Twap	Twah	Twae	Twaeg	Twaekk	Twaegs	Twaen	Twaenj	Twaenh	Twaed	Twael	Twaelg	Twaelm	Twaelb	Twaels	Twaelt	Twaelp	Twaelh	Twaem	Twaeb	Twaebs	Twaes	Twaess	Twaeng	Twaej	Twaech	Twaek	Twaet	Twaep	Twaeh	Toe	Toeg	Toekk	Toegs	Toen	Toenj	Toenh	Toed	Toel	Toelg	Toelm	Toelb";
    case 210:
      return "Toels	Toelt	Toelp	Toelh	Toem	Toeb	Toebs	Toes	Toess	Toeng	Toej	Toech	Toek	Toet	Toep	Toeh	Tyo	Tyog	Tyokk	Tyogs	Tyon	Tyonj	Tyonh	Tyod	Tyol	Tyolg	Tyolm	Tyolb	Tyols	Tyolt	Tyolp	Tyolh	Tyom	Tyob	Tyobs	Tyos	Tyoss	Tyong	Tyoj	Tyoch	Tyok	Tyot	Tyop	Tyoh	Tu	Tug	Tukk	Tugs	Tun	Tunj	Tunh	Tud	Tul	Tulg	Tulm	Tulb	Tuls	Tult	Tulp	Tulh	Tum	Tub	Tubs	Tus	Tuss	Tung	Tuj	Tuch	Tuk	Tut	Tup	Tuh	Two	Twog	Twokk	Twogs	Twon	Twonj	Twonh	Twod	Twol	Twolg	Twolm	Twolb	Twols	Twolt	Twolp	Twolh	Twom	Twob	Twobs	Twos	Twoss	Twong	Twoj	Twoch	Twok	Twot	Twop	Twoh	Twe	Tweg	Twekk	Twegs	Twen	Twenj	Twenh	Twed	Twel	Twelg	Twelm	Twelb	Twels	Twelt	Twelp	Twelh	Twem	Tweb	Twebs	Twes	Twess	Tweng	Twej	Twech	Twek	Twet	Twep	Tweh	Twi	Twig	Twikk	Twigs	Twin	Twinj	Twinh	Twid	Twil	Twilg	Twilm	Twilb	Twils	Twilt	Twilp	Twilh	Twim	Twib	Twibs	Twis	Twiss	Twing	Twij	Twich	Twik	Twit	Twip	Twih	Tyu	Tyug	Tyukk	Tyugs	Tyun	Tyunj	Tyunh	Tyud	Tyul	Tyulg	Tyulm	Tyulb	Tyuls	Tyult	Tyulp	Tyulh	Tyum	Tyub	Tyubs	Tyus	Tyuss	Tyung	Tyuj	Tyuch	Tyuk	Tyut	Tyup	Tyuh	Teu	Teug	Teukk	Teugs	Teun	Teunj	Teunh	Teud	Teul	Teulg	Teulm	Teulb	Teuls	Teult	Teulp	Teulh	Teum	Teub	Teubs	Teus	Teuss	Teung	Teuj	Teuch	Teuk	Teut	Teup	Teuh	Tui	Tuig	Tuikk	Tuigs	Tuin	Tuinj	Tuinh	Tuid	Tuil	Tuilg	Tuilm	Tuilb	Tuils	Tuilt	Tuilp	Tuilh	Tuim	Tuib	Tuibs	Tuis	Tuiss	Tuing	Tuij	Tuich	Tuik	Tuit	Tuip	Tuih	Ti	Tig	Tikk	Tigs	Tin	Tinj	Tinh	Tid	Til	Tilg	Tilm	Tilb	Tils	Tilt	Tilp	Tilh";
    case 211:
      return "Tim	Tib	Tibs	Tis	Tiss	Ting	Tij	Tich	Tik	Tit	Tip	Tih	Pa	Pag	Pakk	Pags	Pan	Panj	Panh	Pad	Pal	Palg	Palm	Palb	Pals	Palt	Palp	Palh	Pam	Pab	Pabs	Pas	Pass	Pang	Paj	Pach	Pak	Pat	Pap	Pah	Pae	Paeg	Paekk	Paegs	Paen	Paenj	Paenh	Paed	Pael	Paelg	Paelm	Paelb	Paels	Paelt	Paelp	Paelh	Paem	Paeb	Paebs	Paes	Paess	Paeng	Paej	Paech	Paek	Paet	Paep	Paeh	Pya	Pyag	Pyakk	Pyags	Pyan	Pyanj	Pyanh	Pyad	Pyal	Pyalg	Pyalm	Pyalb	Pyals	Pyalt	Pyalp	Pyalh	Pyam	Pyab	Pyabs	Pyas	Pyass	Pyang	Pyaj	Pyach	Pyak	Pyat	Pyap	Pyah	Pyae	Pyaeg	Pyaekk	Pyaegs	Pyaen	Pyaenj	Pyaenh	Pyaed	Pyael	Pyaelg	Pyaelm	Pyaelb	Pyaels	Pyaelt	Pyaelp	Pyaelh	Pyaem	Pyaeb	Pyaebs	Pyaes	Pyaess	Pyaeng	Pyaej	Pyaech	Pyaek	Pyaet	Pyaep	Pyaeh	Peo	Peog	Peokk	Peogs	Peon	Peonj	Peonh	Peod	Peol	Peolg	Peolm	Peolb	Peols	Peolt	Peolp	Peolh	Peom	Peob	Peobs	Peos	Peoss	Peong	Peoj	Peoch	Peok	Peot	Peop	Peoh	Pe	Peg	Pekk	Pegs	Pen	Penj	Penh	Ped	Pel	Pelg	Pelm	Pelb	Pels	Pelt	Pelp	Pelh	Pem	Peb	Pebs	Pes	Pess	Peng	Pej	Pech	Pek	Pet	Pep	Peh	Pyeo	Pyeog	Pyeokk	Pyeogs	Pyeon	Pyeonj	Pyeonh	Pyeod	Pyeol	Pyeolg	Pyeolm	Pyeolb	Pyeols	Pyeolt	Pyeolp	Pyeolh	Pyeom	Pyeob	Pyeobs	Pyeos	Pyeoss	Pyeong	Pyeoj	Pyeoch	Pyeok	Pyeot	Pyeop	Pyeoh	Pye	Pyeg	Pyekk	Pyegs	Pyen	Pyenj	Pyenh	Pyed	Pyel	Pyelg	Pyelm	Pyelb	Pyels	Pyelt	Pyelp	Pyelh	Pyem	Pyeb	Pyebs	Pyes	Pyess	Pyeng	Pyej	Pyech	Pyek	Pyet	Pyep	Pyeh	Po	Pog	Pokk	Pogs	Pon	Ponj	Ponh	Pod	Pol	Polg	Polm	Polb	Pols	Polt	Polp	Polh	Pom	Pob	Pobs	Pos";
    case 212:
      return "Poss	Pong	Poj	Poch	Pok	Pot	Pop	Poh	Pwa	Pwag	Pwakk	Pwags	Pwan	Pwanj	Pwanh	Pwad	Pwal	Pwalg	Pwalm	Pwalb	Pwals	Pwalt	Pwalp	Pwalh	Pwam	Pwab	Pwabs	Pwas	Pwass	Pwang	Pwaj	Pwach	Pwak	Pwat	Pwap	Pwah	Pwae	Pwaeg	Pwaekk	Pwaegs	Pwaen	Pwaenj	Pwaenh	Pwaed	Pwael	Pwaelg	Pwaelm	Pwaelb	Pwaels	Pwaelt	Pwaelp	Pwaelh	Pwaem	Pwaeb	Pwaebs	Pwaes	Pwaess	Pwaeng	Pwaej	Pwaech	Pwaek	Pwaet	Pwaep	Pwaeh	Poe	Poeg	Poekk	Poegs	Poen	Poenj	Poenh	Poed	Poel	Poelg	Poelm	Poelb	Poels	Poelt	Poelp	Poelh	Poem	Poeb	Poebs	Poes	Poess	Poeng	Poej	Poech	Poek	Poet	Poep	Poeh	Pyo	Pyog	Pyokk	Pyogs	Pyon	Pyonj	Pyonh	Pyod	Pyol	Pyolg	Pyolm	Pyolb	Pyols	Pyolt	Pyolp	Pyolh	Pyom	Pyob	Pyobs	Pyos	Pyoss	Pyong	Pyoj	Pyoch	Pyok	Pyot	Pyop	Pyoh	Pu	Pug	Pukk	Pugs	Pun	Punj	Punh	Pud	Pul	Pulg	Pulm	Pulb	Puls	Pult	Pulp	Pulh	Pum	Pub	Pubs	Pus	Puss	Pung	Puj	Puch	Puk	Put	Pup	Puh	Pwo	Pwog	Pwokk	Pwogs	Pwon	Pwonj	Pwonh	Pwod	Pwol	Pwolg	Pwolm	Pwolb	Pwols	Pwolt	Pwolp	Pwolh	Pwom	Pwob	Pwobs	Pwos	Pwoss	Pwong	Pwoj	Pwoch	Pwok	Pwot	Pwop	Pwoh	Pwe	Pweg	Pwekk	Pwegs	Pwen	Pwenj	Pwenh	Pwed	Pwel	Pwelg	Pwelm	Pwelb	Pwels	Pwelt	Pwelp	Pwelh	Pwem	Pweb	Pwebs	Pwes	Pwess	Pweng	Pwej	Pwech	Pwek	Pwet	Pwep	Pweh	Pwi	Pwig	Pwikk	Pwigs	Pwin	Pwinj	Pwinh	Pwid	Pwil	Pwilg	Pwilm	Pwilb	Pwils	Pwilt	Pwilp	Pwilh	Pwim	Pwib	Pwibs	Pwis	Pwiss	Pwing	Pwij	Pwich	Pwik	Pwit	Pwip	Pwih	Pyu	Pyug	Pyukk	Pyugs	Pyun	Pyunj	Pyunh	Pyud	Pyul	Pyulg	Pyulm	Pyulb	Pyuls	Pyult	Pyulp	Pyulh	Pyum	Pyub	Pyubs	Pyus	Pyuss	Pyung	Pyuj	Pyuch";
    case 213:
      return "Pyuk	Pyut	Pyup	Pyuh	Peu	Peug	Peukk	Peugs	Peun	Peunj	Peunh	Peud	Peul	Peulg	Peulm	Peulb	Peuls	Peult	Peulp	Peulh	Peum	Peub	Peubs	Peus	Peuss	Peung	Peuj	Peuch	Peuk	Peut	Peup	Peuh	Pui	Puig	Puikk	Puigs	Puin	Puinj	Puinh	Puid	Puil	Puilg	Puilm	Puilb	Puils	Puilt	Puilp	Puilh	Puim	Puib	Puibs	Puis	Puiss	Puing	Puij	Puich	Puik	Puit	Puip	Puih	Pi	Pig	Pikk	Pigs	Pin	Pinj	Pinh	Pid	Pil	Pilg	Pilm	Pilb	Pils	Pilt	Pilp	Pilh	Pim	Pib	Pibs	Pis	Piss	Ping	Pij	Pich	Pik	Pit	Pip	Pih	Ha	Hag	Hakk	Hags	Han	Hanj	Hanh	Had	Hal	Halg	Halm	Halb	Hals	Halt	Halp	Halh	Ham	Hab	Habs	Has	Hass	Hang	Haj	Hach	Hak	Hat	Hap	Hah	Hae	Haeg	Haekk	Haegs	Haen	Haenj	Haenh	Haed	Hael	Haelg	Haelm	Haelb	Haels	Haelt	Haelp	Haelh	Haem	Haeb	Haebs	Haes	Haess	Haeng	Haej	Haech	Haek	Haet	Haep	Haeh	Hya	Hyag	Hyakk	Hyags	Hyan	Hyanj	Hyanh	Hyad	Hyal	Hyalg	Hyalm	Hyalb	Hyals	Hyalt	Hyalp	Hyalh	Hyam	Hyab	Hyabs	Hyas	Hyass	Hyang	Hyaj	Hyach	Hyak	Hyat	Hyap	Hyah	Hyae	Hyaeg	Hyaekk	Hyaegs	Hyaen	Hyaenj	Hyaenh	Hyaed	Hyael	Hyaelg	Hyaelm	Hyaelb	Hyaels	Hyaelt	Hyaelp	Hyaelh	Hyaem	Hyaeb	Hyaebs	Hyaes	Hyaess	Hyaeng	Hyaej	Hyaech	Hyaek	Hyaet	Hyaep	Hyaeh	Heo	Heog	Heokk	Heogs	Heon	Heonj	Heonh	Heod	Heol	Heolg	Heolm	Heolb	Heols	Heolt	Heolp	Heolh	Heom	Heob	Heobs	Heos	Heoss	Heong	Heoj	Heoch	Heok	Heot	Heop	Heoh	He	Heg	Hekk	Hegs	Hen	Henj	Henh	Hed	Hel	Helg	Helm	Helb	Hels	Helt	Help	Helh	Hem	Heb	Hebs	Hes	Hess	Heng	Hej	Hech	Hek	Het	Hep	Heh";
    case 214:
      return "Hyeo	Hyeog	Hyeokk	Hyeogs	Hyeon	Hyeonj	Hyeonh	Hyeod	Hyeol	Hyeolg	Hyeolm	Hyeolb	Hyeols	Hyeolt	Hyeolp	Hyeolh	Hyeom	Hyeob	Hyeobs	Hyeos	Hyeoss	Hyeong	Hyeoj	Hyeoch	Hyeok	Hyeot	Hyeop	Hyeoh	Hye	Hyeg	Hyekk	Hyegs	Hyen	Hyenj	Hyenh	Hyed	Hyel	Hyelg	Hyelm	Hyelb	Hyels	Hyelt	Hyelp	Hyelh	Hyem	Hyeb	Hyebs	Hyes	Hyess	Hyeng	Hyej	Hyech	Hyek	Hyet	Hyep	Hyeh	Ho	Hog	Hokk	Hogs	Hon	Honj	Honh	Hod	Hol	Holg	Holm	Holb	Hols	Holt	Holp	Holh	Hom	Hob	Hobs	Hos	Hoss	Hong	Hoj	Hoch	Hok	Hot	Hop	Hoh	Hwa	Hwag	Hwakk	Hwags	Hwan	Hwanj	Hwanh	Hwad	Hwal	Hwalg	Hwalm	Hwalb	Hwals	Hwalt	Hwalp	Hwalh	Hwam	Hwab	Hwabs	Hwas	Hwass	Hwang	Hwaj	Hwach	Hwak	Hwat	Hwap	Hwah	Hwae	Hwaeg	Hwaekk	Hwaegs	Hwaen	Hwaenj	Hwaenh	Hwaed	Hwael	Hwaelg	Hwaelm	Hwaelb	Hwaels	Hwaelt	Hwaelp	Hwaelh	Hwaem	Hwaeb	Hwaebs	Hwaes	Hwaess	Hwaeng	Hwaej	Hwaech	Hwaek	Hwaet	Hwaep	Hwaeh	Hoe	Hoeg	Hoekk	Hoegs	Hoen	Hoenj	Hoenh	Hoed	Hoel	Hoelg	Hoelm	Hoelb	Hoels	Hoelt	Hoelp	Hoelh	Hoem	Hoeb	Hoebs	Hoes	Hoess	Hoeng	Hoej	Hoech	Hoek	Hoet	Hoep	Hoeh	Hyo	Hyog	Hyokk	Hyogs	Hyon	Hyonj	Hyonh	Hyod	Hyol	Hyolg	Hyolm	Hyolb	Hyols	Hyolt	Hyolp	Hyolh	Hyom	Hyob	Hyobs	Hyos	Hyoss	Hyong	Hyoj	Hyoch	Hyok	Hyot	Hyop	Hyoh	Hu	Hug	Hukk	Hugs	Hun	Hunj	Hunh	Hud	Hul	Hulg	Hulm	Hulb	Huls	Hult	Hulp	Hulh	Hum	Hub	Hubs	Hus	Huss	Hung	Huj	Huch	Huk	Hut	Hup	Huh	Hwo	Hwog	Hwokk	Hwogs	Hwon	Hwonj	Hwonh	Hwod	Hwol	Hwolg	Hwolm	Hwolb	Hwols	Hwolt	Hwolp	Hwolh	Hwom	Hwob	Hwobs	Hwos	Hwoss	Hwong	Hwoj	Hwoch	Hwok	Hwot	Hwop	Hwoh	Hwe	Hweg	Hwekk	Hwegs";
    case 215:
      return "Hwen	Hwenj	Hwenh	Hwed	Hwel	Hwelg	Hwelm	Hwelb	Hwels	Hwelt	Hwelp	Hwelh	Hwem	Hweb	Hwebs	Hwes	Hwess	Hweng	Hwej	Hwech	Hwek	Hwet	Hwep	Hweh	Hwi	Hwig	Hwikk	Hwigs	Hwin	Hwinj	Hwinh	Hwid	Hwil	Hwilg	Hwilm	Hwilb	Hwils	Hwilt	Hwilp	Hwilh	Hwim	Hwib	Hwibs	Hwis	Hwiss	Hwing	Hwij	Hwich	Hwik	Hwit	Hwip	Hwih	Hyu	Hyug	Hyukk	Hyugs	Hyun	Hyunj	Hyunh	Hyud	Hyul	Hyulg	Hyulm	Hyulb	Hyuls	Hyult	Hyulp	Hyulh	Hyum	Hyub	Hyubs	Hyus	Hyuss	Hyung	Hyuj	Hyuch	Hyuk	Hyut	Hyup	Hyuh	Heu	Heug	Heukk	Heugs	Heun	Heunj	Heunh	Heud	Heul	Heulg	Heulm	Heulb	Heuls	Heult	Heulp	Heulh	Heum	Heub	Heubs	Heus	Heuss	Heung	Heuj	Heuch	Heuk	Heut	Heup	Heuh	Hui	Huig	Huikk	Huigs	Huin	Huinj	Huinh	Huid	Huil	Huilg	Huilm	Huilb	Huils	Huilt	Huilp	Huilh	Huim	Huib	Huibs	Huis	Huiss	Huing	Huij	Huich	Huik	Huit	Huip	Huih	Hi	Hig	Hikk	Higs	Hin	Hinj	Hinh	Hid	Hil	Hilg	Hilm	Hilb	Hils	Hilt	Hilp	Hilh	Him	Hib	Hibs	His	Hiss	Hing	Hij	Hich	Hik	Hit	Hip	Hih													oyeo	ooi	yoa	yoae	yoeo	uyeo	uii	yuae	yuo	eua	eueo	eue	euo	iyao	iyae	iyeo	iye	ioi	iyo	iyu	ii	oa	oe					nl	nch	tt	ttb	db	ds	dsg	dj	dch	dt	lkk	lgh	llk	lmh	lbd	lbp	lng	lqh	r	mn	mnn	mm	mbs	mj	bd	blp	bm	pp	bsd	bj	bch	sm	sv	ssg	ssd	sz	sj	sch	st	sh	zb	zv	ngm	ngh	jb	jpp	jj	ps	pt";
    case 249:
      return "Gae	Gaeng	Geo	Go	Gol	Gwan	Gwi	Gwi	Gyun	Geul	Geum	Na	Na	Na	Na	Na	Na	Na	Na	Na	Nag	Nag	Nag	Nag	Nag	Nag	Nag	Nan	Nan	Nan	Nan	Nan	Nan	Nam	Nam	Nam	Nam	Nab	Nab	Nab	Long	Nang	Nang	Nang	Nang	Nae	Naeng	No	No	No	No	No	No	No	Lou	No	No	No	No	Nog	Nog	Nog	Nog	Nog	Nog	Non	Nong	Nong	Nong	Lung	Noe	Noe	Noe	Noe	Nu	Nu	Nu	Nu	Nu	Nu	Nu	Nu	Neug	Neug	Neum	Neung	Neung	Neung	Neung	Neung	Du	La	Lag	Lag	Lan	Lyeong	Lo	Lyul	Li	Bae	Beon	Byeon	Bu	Bul	Bi	Sag	Sag	Sam	Saeg	Saeng	Seob	Se	Swae	Sin	Sim	Sib	Ya	Yag	Yag	Yang	Yang	Yang	Yang	Yang	Yang	Yang	Yang	Yeo	Yeo	Yeo	Yeo	Yeo	Yeo	Yeo	Yeo	Yeo	Yeo	Yeo	Yeog	Yeog	Yeog	Yeog	Yeon	Yeon	Yeon	Yeon	Yeon	Yeon	Yeon	Yeon	Yeon	Yeon	Yeon	Yeon	Yeon	Yeon	Yeol	Yeol	Yeol	Yeol	Yeol	Yeol	Yeom	Yeom	Yeom	Yeom	Yeom	Yeob	Yeong	Yeong	Yeong	Yeong	Yeong	Yeong	Yeong	Yeong	Yeong	Yeong	Yeong	Yeong	Yeong	Ye	Ye	Ye	Ye	O	Yo	Yo	Yo	Yo	Yo	Yo	Yo	Yo	Yo	Yo	Yong	Un	Won	Yu	Yu	Yu	Yu	Yu	Yu	Yu	Yu	Yu	Yu	Yug	Yug	Yug	Yun	Yun	Yun	Yun	Yul	Yul	Yul	Yul	Yung	I	I	I	I	I	I	I	I	I	I	I	I	I	I	Ig	Ig	In	In	In	In	In	In	In	Im	Im	Im	Ib	Ib	Ib	Jang	Jeog	Ji	Jib	Cha	Cheog";
    case 250:
      return "Che	Tag	Tag	Tang	Taeg	Tong	Po	Pog	Hang	Hang	Hyeon	Hwag	Kotsu	Kaku	So	Sako	Chou	Ki	Sei	Tabu	Kyo	Ki	Cho	Jik	Li	Shin	Shou	Fuku	Sei	Sei	U	Ro	Hagi	Ni	Sho	Kyu	Hen	Itsu	To	Ko	Ko	Shima	Han	Shi	Kan	Kaku	Nang	Ye	Wu	Seng	Mian	Mian	Qin	Bei	He	Tan	Qi	Ping	Mo	Ceng	Che	Hui	Kai	Zeng	Cheng	Min	Ji	Shu	Mei	Hai	Zhu	Han	Zhu	Zhao	Zuo	Bei	She	Zhi	Qi	You	Zu	Zhu	Huo	Zhen	Gu	Tu	Jie	Lian	Jin	Fan	Shu	Zhe	Chou	Cao	Cao	Zhu	He	Shi	Ye	Jin	Bin	Zeng	Chuo	Yi	Nan	Xiang	Pin	Hui	Hei	Guan			Bing	Kuang	Quan	Xing	Chong	Ji	Yong	Shao	He	Tao	Hui	Wa	Zhong	Fen	Yan	Ben	Bi	Ci	Ao	Yi	Cai	Yao	Wang	Shen	Yu	Zeng	Ao	Cheng	Dai	Yu	Sou	Bing	Ao	Qing	Lang	Wang	Zhang	Dai	Sha	Liu	Yin	Zi	Han	Jing	Zhu	Qiao	Jue	Fan	Zhu	Tian	Ci	Hua	Guan	Wen	Yi	Sheng	Zhi	Juan	Zhe	Tian	Tiao	Jie	Lei	Tao	Lian	Ping	Zhe	Huang	Hua	Yun	Qiang	Fu	Shi	Diao	Zhu	Qing	Ye	Nuo	Yu	Jin	Bian	Zeng	Shu	Chi	Sou	Xing	Zhu	Nan	Jing	Bai	Xiang	E	Pin	Zhen	Gui	Ken	San	Hai	He	Xie	Jie	Teki	Qian	Beng	E	Pang";
    case 251:
      return "ff	fi	fl	ffi	ffl	st	st													mn	me	mi	vn	mkh						i		ay	'	'	d	h	kh	l	m	r	t	+	sh	s	sh	ss	a	o	'	b	g	d	h	u	zz		tt	yy	k	k	ll		mm		nn	ss		p	p		ts	kk	rr	ss	t	o	v	kh	f	'l	'	'	b	b	b	b	p	p	p	p	bh	bh	bh	bh	th	th	th	th	th	th	th	th	t	t	t	t	v	v	v	v	ph	ph	ph	ph	j	j	j	j	n	n	n	n	ch	ch	ch	ch	ch	ch	ch	ch	dh	dh	dh	dh	dh	dh	d	d	zh	zh	r	r	k	k	k	k	g	g	g	g	g	g	g	g	n	n	n	n	n	n	n	n	n	n	e	e	h	h	h	h	h	h	h	h	e	e	e'	e'	.	.	.	.	.	.	.	.	.	.	.	.	.	.	t	t	'																	ng	ng	ng	ng	u	u	o	o	u	u	u	v	v	o	o	u	u	e	e	e	e	a	a	i'a	i'a	i'e	i'e	i'w	i'w	i'u	i'u	i'o	i'o	i'u	i'u	i'e	i'e	i'e	i'a	i'a	i'a	y	y	y	y";
    case 252:
      return "i'j	i'h	i'm	i'a	i'y	bj	bh	bkh	bm	ba	by	tj	th	tkh	tm	ta	ty	thj	thm	tha	thy	jh	jm	hj	hm	khj	khh	khm	sj	sh	skh	sm	sh	sm	dj	dh	dkh	dm	th	tm	dhm	`j	`m	ghj	ghm	fj	fh	fkh	fm	fa	fy	qh	qm	qa	qy	ka	kj	kh	kkh	kl	km	ka	ky	lj	lh	lkh	lm	la	ly	mj	mh	mkh	mm	ma	my	nj	nh	nkh	nm	na	ny	hj	hm	ha	hy	yj	yh	ykh	ym	ya	yy	dha	ra	aa	un-	in-	a-	u-	i-	-a	i'r	i'z	i'm	i'n	i'a	i'y	br	bz	bm	bn	ba	by	tr	tz	tm	tn	ta	ty	thr	thz	thm	thn	tha	thy	fa	fy	qa	qy	ka	kl	km	ka	ky	lm	la	ly	ma	mm	nr	nz	nm	nn	na	ny	aa	yr	yz	ym	yn	ya	yy	i'j	i'h	i'kh	i'm	i'h	bj	bh	bkh	bm	bh	tj	th	tkh	tm	th	thm	jh	jm	hj	hm	khj	khm	sj	sh	skh	sm	sh	skh	sm	dj	dh	dkh	dm	th	dhm	`j	`m	ghj	ghm	fj	fh	fkh	fm	qh	qm	kj	kh	kkh	kl	km	lj	lh	lkh	lm	lh	mj	mh	mkh	mm	nj	nh	nkh	nm	nh	hj	hm	ha	yj	yh	ykh	ym	yh	i'm	i'h	bm	bh	tm	th	thm	thh	sm	sh	shm	shh	kl	km	lm	nm	nh	ym	yh	a-	u-	i-	ta	ty	`a	`y	gha	ghy	sa	sy	sha	shy	ha";
    case 253:
      return "hy	ja	jy	kha	khy	sa	sy	da	dy	shj	shh	shkh	shm	shr	sr	sr	dr	ta	ty	`a	`y	gha	ghy	sa	sy	sha	shy	ha	hy	ja	jy	kha	khy	sa	sy	da	dy	shj	shh	shkh	shm	shr	sr	sr	dr	shj	shh	shkh	shm	sh	shh	tm	sj	sh	skh	shj	shh	shkh	tm	dhm	aan	aan	(	)	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	tjm	thj	thj	thm	tkhm	tmj	tmh	tmkh	jmh	jmh	hmy	hma	shj	sjh	sja	smh	smh	smj	smm	smm	shh	shh	smm	shhm	shhm	shjy	shmkh	shmkh	shmm	shmm	dha	dkhm	dkhm	tmh	tmh	tmm	tmy	`jm	`mm	`mm	`ma	ghmm	ghmy	ghma	fkhm	fkhm	qmh	qmm	lhm	lhy	lha	ljj	ljj	lkhm	lkhm	lmh	lmh	mhj	mhm	mhy	mjh	mjm	mkhj	mkhm			mjkh	hmj	hmm	nhm	nha	njm	njm	nja	nmy	nma	ymm	ymm	bkhy	tjy	tja	tkhy	tkha	tmy	tma	jmy	jha	jma	skha	shy	shhy	dhy	ljy	lmy	yhy	yjy	ymy	mmy	qmy	nhy	qmh	lhm	`my	kmy	njh	mkhy	ljm	kmm	ljm	njh	jhy	hjy	mjy	fmy	bhy	kmm	`jm	smm	skhy	njy								*																																	sle	qle	Allah	'akbar	Muhammad	sl`m	rasul	`alayhi	wa-sallam	salla	salla Allah `alayhi wa-sallam	jalla jalalahu	Riyal	bismillah al-rahman al-rahim	*	*";
    case 254:
      return "																,	,	.	:	;	!	?	[(	)]	...																							..	-	-	_	_	(	)	{	}	[	]	[(	)]	<<	>>	<	>	[	]	[	]	'	'	[	]	-	-	-	-	_	_	_	,	,	.		;	:	?	!	-	(	)	{	}	[	]	#	&	*	+	-	<	>	=		\\	$	%	@					an	an	un	_	in		a	a	u	u	i	i	-	-	.	.	'	a	a	'	'	u'	u'	'	'	i'	i'	i'	i'	a	a	b	b	b	b	h	h	t	t	t	t	th	th	th	th	j	j	j	j	h	h	h	h	kh	kh	kh	kh	d	d	dh	dh	r	r	z	z	s	s	s	s	sh	sh	sh	sh	s	s	s	s	d	d	d	d	t	t	t	t	dh	dh	dh	dh	`	`	`	`	gh	gh	gh	gh	f	f	f	f	q	q	q	q	k	k	k	k	l	l	l	l	m	m	m	m	n	n	n	n	h	h	h	h	w	w	a	a	y	y	y	y	la	la	l'	l'	l'	l'	la	la";
    case 255:
      return "	!	\"	#	$	%	&	'	(	)	*	+	,	-	.	/	0	1	2	3	4	5	6	7	8	9	:	;	<	=	>	?	@	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	[	\\	]	^	_	`	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	{	|	}	~	(	)	.	[	]	,	-	o	a	i	u	e	o	ya	yu	yo	t		a	i	u	e	o	ka	ki	ku	ke	ko	sa	shi	su	se	so	ta	chi	tsu	te	to	na	ni	nu	ne	no	ha	hi	fu	he	ho	ma	mi	mu	me	mo	ya	yu	yo	ra	ri	ru	re	ro	wa	n	'	`		g	kk	gs	n	nj	nh	d	tt	l	lg	lm	lb	ls	lt	lp	lh	m	b	pp	bs	s	ss		j	jj	ch	k	t	p	h				a	ae	ya	yae	eo	e			yeo	ye	o	wa	wae	oe			yo	u	wo	we	wi	yu			eu	ui	i				c	GBP	!	-	|	Y	W		|	<	^	>	v	#	*											{	|	}	?	?";
    case 256:
      return "a	e	i	o	u	da	de	di	do	du	ja	je		jo	ju	ka	ke	ki	ko	ku	ma	me	mi	mo	mu	na	ne	ni	no	nu	pa	pe	pi	po	pu	qa	qe	qi	qo		ra	re	ri	ro	ru	sa	se	si	so	su	ta	te	ti	to	tu	wa	we	wi	wo		za	ze		zo	B25	B43	B85	B71	B90	B48	B29	B62	B76	B33	B68	B66	B87	B91			B18	B19	B22	B34	B47	B49	B56	B63	B64	B79	B82	B83	B86	B89																																			B100	B102	B104	B105	B105f	B105m	B106f	B106m	B107f	B107m	B108f	B108m	B109f	B109m	B120	B121	B122	B123	B125	B127	B128	B130	B131	B132	B133	B135	B140	B141	B142	B145	B146	B150	B151	B152	B153	B154	B156	B157	B158	B159	B160	B161	B162	B163	B164	B165	B166	B167	B168	B169	B170	B171	B172	B173	B174	B176	B177	B178	B179	B180	B181	B182	B183	B184	B185	B189	B190	B191	B220	B225	B230	B231	B232	B233	B234	B236	B240	B241	B242	B243	B245	B246	B247	B248	B249	B251	B252	B253	B254	B255	B256	B257	B258	B259	B155	B200	B201	B202	B203	B204	B205	B206	B207	B208	B209	B210	B211	B212	B213	B214	B215	B216	B217	B218	B219	B221	B222	B226	B227	B228	B229	B250	B305";
    case 257:
      return ",	.	*					1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70	80	90	100	200	300	400	500	600	700	800	900	1000	2000	3000	4000	5000	6000	7000	8000	9000	10000	20000	30000	40000	50000	60000	70000	80000	90000				*	*	#	*	*	*	*	*	*	1/4	1/2	1	5	50	500	5000	50000	5	10	50	100	500	1000	5000	5	10	50	100	500	1000	10000	50000	10	1	1	1	2	2	2	2	5	10	10	10	10	10	30	50	50	50	50	100	300	500	500	500	500	500	1000	5000	5	50	1/2	1/2	2/3	3/4	y	t	<	1	2	3	4	5	m	K	l	Go	x	a	a	Gr	t	0	1/4	y	I	No		=	-	S	S	S	))	X	V	IIS	II	|	>	*				TR.																																																01	02	03	04	05	06	07	08	09	10	11	12	13	14	15	16	17	18	19	20	21	22	23	24	25	26	27	28	29	30	31	32	33	34	35	36	37	38	39	40	41	42	43	44	45	46";
    case 258:
      return "																																																																																																																																a	e	b	b	g	d	i	w	z	th	y	k	q	l	m	n	m	n	u	p	k	r	s	t	t	a	e	h	x				a	p	d	l	y	r	l	a	q	b	m	o	d	t	s	s	s	?	u	n	k	n	t	p	s	i	e	y	k	k	d	w	g	g	z	z	ng	j	?	t	y	r	b	b	b	b	l	e	y																k	1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70	80	90	100	200	300	400	500	600	700	800	900";
    case 259:
      return "a	b	c	d	e	v	z	h	th	i	k	l	m	n	s	o	p	s	q	r	s	t	u	x	ph	ch	f	r	c	i	u	s	I	V	X	L										j	t'	t'	a	b	g	d	e	q	z	h	th	i	k	l	m	n	j	u	p	90	r	s	t	w	f	x	hw	o	900						a	b	g	d	e	zh	dzh	z	dz	i	k	l	m	n	o	p	r	s	t	u	ch	sh	shch	y	y	o	o	f	h	c	v	''	'	e	ie	ju	ja	ia	a	d	z	n	s						a	b	g	h	d	h	w	z	h	t	y	k	sh	l	m	d	n	z	s	`	p	s	q	r	t	g	t	i	u	s		|	a	i	u	ka	ku	ga	gu	xa	ca	ja	ji	ta	tu	da	di	du	tha	pa	ba	fa	na	nu	ma	mi	mu	ya	va	vi	ra	ru	la	sa	za	sha	sra	ha					AM1	AM2	AMHA	XS	DH1	DH2	BG	BU	:	1	2	10	20	100";
    case 260:
      return "E	A	A	O	O	U	I	E	A	O	U	U	I	Aw	W	Y	H	P	B	T	D	Ch	J	K	G	F	V	Th	Dh	S	Z	Sh	Zh	R	L	M	N	Ng	Oy	Yu	e	a	a	o	o	u	i	e	a	o	u	u	i	aw	w	y	h	p	b	t	d	ch	j	k	g	f	v	th	dh	s	z	sh	zh	r	l	m	n	ng	oy	yu	p	t	k	f	th	s	sh	ch	y	ng	b	d	g	v	dh	z	zh	j	w	h	l	m	i	e	a	'	o	u	au	aa	r	n	ii	ei	ai	u	ou	uu	oi	oo	ar	or	er	ur	'r	ir	i'	yuu	'	b	t	j	x	kh	d	r	s	sh	dh	c	g	f	q	k	l	m	n	w	h	y	a	e	i	o	u	aa	ee	oo			0	1	2	3	4	5	6	7	8	9							A	Ai	Ai	E	Br	Ch	Hch	E	Ei	H	Hy	I	K	Hk	Ky	L	M	N	O	Oi	P	Hp	S	Sh	T	Ht	C	Hc	Ch	D	U	W	X	G	Z	Zh					a	ai	ai	e	br	ch	hch	e	ei	h	hy	i	k	hk	ky	l	m	n	o	oi	p	hp	s	sh	t	ht	c	hc	ch	d	u	w	x	g	z	zh";
    case 261:
      return "a	b	c	ch	d	nd	dh	e	e	f	g	gj	h	i	j	k	l	ll	m	n	n	nj	o	p	q	r	rr	s	sh	t	th	u	v	x	y	z	zh	gh	gh	kh									a	b	g	d	e	z	e	z	t	c	y	z	i	`	l	n'	x	d'	c	j	k	l'	h	x	a	c	c	c'	m	q	n	j'	s	j	o	t'	f	j	c	p	g	r	s	v	t	s	u	c'	c	w	p	k												*	A	B	B	C	Ch	D	Dh	E	E	F	G		H	H	I	Ij	J	K	L	Ll	M	N	Nj	O	P	Q	R		S	Sh	T	Th	U	V	X		Y	Z		a	b	b	c	ch	d	dh	e	e	f	g		h	h	i	ij	j	k	l	ll	m	n	nj	o	p	q	r		s	sh	t	th	u	v	x		y	z				a	as	b	mb	c	ch	d	nd	dh	e	e	f	g	ng	gj	ngj	h	hj	i	j	k	l	ll	m	n	nj	o	p	q	r	rr	s	sh	sht	t	th	u	v	x	nx	xh	nxh	y	jy	z	zh	gh	st	sk	kh	ps	o";
    case 262:
      return "AB1	AB2	AB3	AB4	AB5	AB6	AB7	AB8	AB9	AB10	AB11	AB13	AB16	AB17	AB20	AB21	AB21f	AB21m	AB22	AB22f	AB22m	AB23	AB23m	AB24	AB26	AB27	AB28	A28b	AB29	AB30	AB31	AB34	AB37	AB38	AB39	AB40	AB41	AB44	AB45	AB46	AB47	AB48	AB49	AB50	AB51	AB53	AB54	AB55	AB56	AB57	AB58	AB59	AB60	AB61	AB65	AB66	AB67	AB69	AB70	AB73	AB74	AB76	AB77	AB78	AB79	AB80	AB81	AB82	AB85	AB86	AB87	A100/102	AB118	AB120	A120b	AB122	AB123	AB131a	AB131b	A131c	AB164	AB171	AB180	AB188	AB191	A301	A302	A303	A304	A305	A306	A307	A308	A309a	A309b	A309c	A310	A311	A312	A313a	A313b	A313c	A314	A315	A316	A317	A318	A319	A320	A321	A322	A323	A324	A325	A326	A327	A328	A329	A330	A331	A332	A333	A334	A335	A336	A337	A338	A339	A340	A341	A342	A343	A344	A345	A346	A347	A348	A349	A350	A351	A352	A353	A354	A355	A356	A357	A358	A359	A360	A361	A362	A363	A364	A365	A366	A367	A368	A369	A370	A371	A400	A401	A402	A403	A404	A405	A406	A407	A408	A409	A410	A411	A412	A413	A414	A415	A416	A417	A418	A501	A502	A503	A504	A505	A506	A508	A509	A510	A511	A512	A513	A515	A516	A520	A521	A523	A524	A525	A526	A527	A528	A529	A530	A531	A532	A534	A535	A536	A537	A538	A539	A540	A541	A542	A545	A547	A548	A549	A550	A551	A552	A553	A554	A555	A556	A557	A559	A563	A564	A565	A566	A568	A569	A570	A571	A572	A573	A574	A575	A576	A577	A578	A579	A580	A581	A582	A583	A584	A585	A586	A587	A588	A589	A591	A592	A594";
    case 263:
      return "A595	A596	A598	A600	A601	A602	A603	A604	A606	A608	A609	A610	A611	A612	A613	A614	A615	A616	A617	A618	A619	A620	A621	A622	A623	A624	A626	A627	A628	A629	A634	A637	A638	A640	A642	A643	A644	A645	A646	A648	A649	A651	A652	A653	A654	A655	A656	A657	A658	A659	A660	A661	A662	A663	A664										A701	A702	A703	A704	A705	A706	A707	A708	A709	A709-2	A709-3	A709-4	A709-6	A710	A711	A712	A713	A714	A715	A717	A726	A732											A800	A801	A802	A803	A804	A805	A806	A807																									aa	:	-	ae	b	b		dz	dz	dz	dzh	d	d	d	e	o	fng	u	g	g	g	h	h	h	j	ls	lz	l	l	l	lzh	lzh	y	y	o	oe	u	q	r	r	r	r	r	tc	ts	ts	tsh	t	v		y	'	`	pc	c	x	qc	q	s";
    case 264:
      return "a	e	i	o	u	ja			jo		ka	ke	ki	ko	ku	la	le	li	lo	lu	ma	me	mi	mo	mu	na	ne	ni	no	nu	pa	pe	pi	po	pu	ra	re	ri	ro	ru	sa	se	si	so	su	ta	te	ti	to	tu	wa	we	wi	wo		xa	xe				za			zo	'	b	g	d	h	w	z	h	t	y	k	l	m	n	s	`	p	s	q	r	sh	t		+	1	2	3	10	20	100	1000	10000	'	b	g	d	h	w	z	h	t	y	k	l	m	n	n	s	`	p	s	q	r	sh	t	<	>	1	2	3	4	5	10	20	'	'	b	b	g	d	h	h	w	z	h	t	y	y	k	k	l	l	m	m	n	n	s	`	p	s	q	r	sh	sh	t									1	2	3	4	4	5	10	20	100																																																	'	b	g	d	h	w	z	h	t	y	k	l	m	n	s	`	p	s	q		sh	t						1	5	10	20	100";
    case 265:
      return "'	b	g	d	h	w	z	h	t	y	k	l	m	n	s	`	p	s	q	r	sh	t	1	10	20	100	2	3				 	a	b	g	d	e	v	i	y	k	l	m	n	o	r	s	t	u	f	q	s	t	a	e	l	n	c						^																																																																	a	e	i	o	y	w	b	b	p	m	n	n	ne	ne	r	r	l	x	h	s	s	se	k	q	t	t	te	te	to	d	*	+	a	e	i	o	y	w	b	p	m	n	ne	r	l	x	h	s	s	se	k	q	t	te	to	d					11	.5	RMT	IMN	1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70			100	200	300	400	500	600	700	800	900	1000	2000	3000	4000	5000	6000	7000	8000	9000	10000	20000	30000	40000	50000	60000	70000	80000	90000	100000	200000	300000	400000	500000	600000	700000	800000	900000	1	2	3	4	5	6	7	8	9	10";
    case 266:
      return "a	i	u	r		e	o								m	h	k	kh	g	gh		c	ch	j		n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	z	h	k	th	t	vh			'	'							1	2	3	4	10	20	100	1000	.5								,	.	*	#	+	@	,	.	~								h	l	h	m	q	w	s	r	b	t	s	k	n	h	s	s	f	'	`	d	g	d	g	t	z	d	y	t	z	|	50	#	h	l	h	m	q	w	s	r	b	t	s	k	n	h	s	s	f	'	`	d	g	d	g	t	z	d	y	t	z	|	10	20																																	'	b	bh	g	gh	d	h	w	w	z	zh	j	jh	h	t	y	k	k	kh	l	dh	th	m	n	s	`	`	p	f	c	q	q	qh	r	sh	sh	t							1	5	10	20	100	+	#	;	,	.	:	*";
    case 267:
      return "a	a	a	a	a	a	e	e	e	e	o	o	i	i	u	u	k	x	x	xv	g	g	gh	c	j	t	th	d	dh	t	p	f	b	bh	ng	ng	ngv	n	n	n	m	m	y	y	v	r	l	s	z	sh	zh	sh	sh	h				.	:	;	.	.	*	*	'	b	g	d	h	w	z	h	t	y	k	l	m	n	s	`	p	s	q	r	sh	t			1	2	3	4	10	20	100	1000	'	b	g	d	h	w	z	h	t	y	k	l	m	n	s	p	s	sh	t						1	2	3	4	10	20	100	1000	'	b	g	d	h	w	z	h	y	k	l	m	n	s	p	s	sh	t								*	*	+	+													1	2	3	4	10	20	100";
    case 268:
      return "a	a	a	i	i	e	w	w	w	b	b	b	b	g	g	g	g	d	d	d	z	z	y	y	y	y	k	k	wk	wk	l	l	l	lt	m	n	n	n	nt	nt	nch	nch	ny	ny	ng	ng	ng	p	wp	ich	ch	ch	k	k	ik	ik	wk	wk	r	r	r	s	s	ash	sh	sh	sh	t	t	t	t	wt	bash																																																								A	A	B	Mb	C	Nc	Cs	D	Nd	E	E	E	F	G	Gy	H	I	I	J	K	K	Nk	L	Ly	M	N	Ny	O	O	O	O	O	P	Mp	R	R	S	Sz	T	Nt	Ty	Ch	U	U	U	U	V	Z	Zs	Tprus	S														a	a	b	mb	c	nc	cs	d	nd	e	e	e	f	g	gy	h	i	i	j	k	k	nk	l	ly	m	n	ny	o	o	o	o	o	p	mp	r	r	s	sz	t	nt	ty	ch	u	u	u	u	v	z	zs	tprus	s								1	5	10	50	100	1000";
    case 269:
      return "	b	p	t	t	j	ch	h	kh	f	d	d	r	r	z	s	sh	k	g	l	m	n	w	u	y	i	ng	ny	v	a	i	u	e	o		m													0	1	2	3	4	5	6	7	8	9							0	1	2	3	4	5	6	7	8	9	a	i	o	e			'	C	M	K	B	J	S	W	L	G	D	X	Y	T	R	N	F	N	P	H	K	N				e		'	'	n	-	-	'	c	m	k	b	j	s	w	l	g	d	x	y	t	r	n	f	n	p	h	k	n									+	-";
    case 270:
      return "																																																																																																1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70	80	90	100	200	300	400	500	600	700	800	900	1/2	1/4	1/3	2/3		a	b	p	p'	t'	s	c	ch	ch'	h'	x	d	z	r	r'	z	j	s	sh	s	d	t	z'	'	x'	f	v	v	q	k	k'	g	l	m	n	u	w	o	e	h	y	e				-			ll	e																	dh	th	g																																																								a";
    case 271:
      return "'	'	b	b	g	h	h	w	z	h	y	k	l	m	n	n	n	s	`	`	p	s	s	s	r	sh	t	t	t	1	2	3	4	5	10	20	30	100	.5	`d									'	b	g	h	w	z	h	y	k	l	m	n	s	`	p	s	r	sh	t	f	l	sh												1	10	20	100	,	.	*	**	<																							'	b	g	w	z	x	y	k	d	m	n	s	p	c	r	sh	t	l					,	.	;	:																																							'	-'	b	g	d	h	w	-w	z	h	y	k	l	m	n	s	`	p	r	sh	t	1	2	3	4	10	20	100																					'	b	g	d	h	w	z	h	t	y	k	l	m	n	s	`	p	s	q	r	sh	t	zy";
    case 272:
      return "m	m	h	h	h	a	a	i	i	u	u	r	r	l	l	e	ai	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	l	l	r	n	a	a	i	i	u	u	r	r	l	l	e	ai	o	au		,	.	.	:	-	+	*					1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70	80	90	100	1000	0	1	2	3	4	5	6	7	8	9		e	o	e	o	l										*	m	m	h	a	a	i	i	u	u	e	ai	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	r	dh	rh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	a	i	i	u	u	e	ai	o	au		'	.	#	#	,	.	,	.	r											#			s	t	b	c	d	g	m	n	l	n	v	p	y	r	h	k	j	n	a	e	i	u	o	e	x								0	1	2	3	4	5	6	7	8	9";
    case 273:
      return "m	m	h	a	i	u	e	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	y	r	l	w	s	h	a	i	i	u	u	e	ai	o	au	oi	o	au				0	1	2	3	4	5	6	7	8	9	*	,	.	?	lh	a	ei	v									a	i	u	e	o	k	kh	g	gh	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	r	l	v	s	h	r	'	.	*	Sri										m	m	h	a	a	i	i	u	u	r	r	l	l	e	ai	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	l	v	s	s	s	h	a	i	i	u	u	r	r	l	l	e	ai	o	au		'	h	h	Om	,	.	.	 		'			*	e	m	0	1	2	3	4	5	6	7	8	9	1	*	-	-	~	^		1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70	80	90	100	1000";
    case 274:
      return "a	a	i	u	e	ai	o	au	k	kh	g	g	gh	n	c	ch	j	j		n	t	th	d	dh	n	t	th	d	d	dh	n	p	ph	b	b	bh	m	y	r	l	v	s	h	r	a	i	i	u	e	ai	o	au	m		'		,	.	 	,	.	.		q	i	r																																																															a	i	u	e	k	kh	g		gh		c	ch	j	j		n	t	th	d	d	dh	n	t	th	d	dh	n	p	ph	b		bh	m	y	r	l	v	s	h	r	rh	.							a	a	i	i	u	u	e	ai	o	au	k	kh	g	g	gh	n	c	ch	j	j	jh	n	t	th	d	d	r	dh	n	t	th	d	dh	n	p	ph	b	b	bh	m	y	r	l	v	s	s	h	m	a	i	i	u	u	e	ai	o	au	'							0	1	2	3	4	5	6	7	8	9";
    case 275:
      return "m	m	m	h		a	a	i	i	u	u	r	l			e	ai			o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n		p	ph	b	bh	m	y	r		l	l		v	d	d	d	h		'	'	'	a	i	i	u	u	r	r			e	ai			o	au				Om							u						`	m	m	r	l	l	l			0	1	2	3	4	5	6				a	k	n	v	p												a	a	i	i	u	u	r	r	l	l		e			ai		o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	l	r	l		'	a	i	i	u	u	r	r	l	l		e			ai		o	au	u	m		m	h				r			,	.		Om	Sri";
    case 276:
      return "a	a	i	i	u	u	r	r	l	l	e	ai	o	au	k	kh	g	gh	n	hn	c	ch	j	jh	n	hn	t	th	d	dh	n	t	th	d	dh	n	hn	p	ph	b	bh	m	hm	y	r	hr	l	hl	v	s	s	s	h	a	i	i	u	u	r	r	l	l	e	ai	o	au		m	m	h	'	'	m	Om	*	,	.	,	-	.	0	1	2	3	4	5	6	7	8	9	.	-		^	'	m	h	h																															*	a	a	i	i	u	u	r	r	l	l	e	ai	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	a	i	i	u	u	r	r	l	l	e	e	ai	o	o	au	m	m	h		'	'	m	.	Om									0	1	2	3	4	5	6	7	8	9";
    case 277:
      return "																																																																																																																																a	a	i	i	u	u	r	r	l	l	e	ai	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	a	i	i	u	u	r	r			e	ai	o	au	m	m	h		'	*	,	.	-	-	-	-	-	#	*	*	*	*	*	*	*	*	*	*	*	*	*	*	i	i	i	u	u	u";
    case 278:
      return "a	a	i	i	u	u	r	r	l	l	e	ai	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	l	a	i	i	u	u	r	r	l	l	e	ai	o	au	m	h		'	,	.	.	*												0	1	2	3	4	5	6	7	8	9							@	@	@	@	@	@	@	@	@	@	@	@	@																				a	a	i	i	u	u	e	ai	o	au	k	s	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	h	r	m	h	a	i	i	u	u	e	ai	o	au		'	kh	.							0	1	2	3	4	5	6	7	8	9							0	1	2	3	4	5	6	7	8	9	0	1	2	3	4	5	6	7	8	9";
    case 279:
      return "k	kh	ng	n	t	t	p	ph	b	m	j	ch	th	r	l	s	ny	h		d	dh	g	g	gh	bh	jh	b			l	r	r	a	a	i	i	u	u	e	av	o	ai	m						0	1	2	3	4	5	6	7	8	9	10	20	,	.	*	!	c	t	th	d	dh	n	l";
    case 280:
      return "a	a	i	i	u	u	e	ai	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	r	a	i	i	u	u	r	r	e	ai	o	au	m	h		'	.																																																																																																					M	A	I	U	'	Y	I	U	E	O	N	G	K	N	J	C	N	D	T	N	D	T	M	B	P	H	L	R	R	S	S	V	m	a	i	u	'	y	i	u	e	o	n	g	k	n	j	c	n	d	t	n	d	t	m	b	p	h	l	r	r	s	s	v	0	1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70	80	90													Om";
    case 281:
      return "a	a	i	i	u	u	e			o			k	kh	g	gh	n	c	ch	j		n	t		d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	'	y	r	l	v	s	s	s	h	l	z	a	i	i	u	u	e		ai	o			m	m			n	y	r	r	'	.	-	*										0	1	2	3	4	5	6	7	8	9																																																																							a	a	i	i	u	u	r	r			e	ai	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	l	r	a	i	i	u	u	r	r			e	ai	o	au	m	h		'	*	~	e";
    case 282:
      return "	i	u	u	e	o	o	ai	au	i		k	kh	g	gh	ng	c	ch	j	ny	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	ts	tsh	dz	dzh	zh	z	'	y	r	l	v	sh	s	s	h	ks			m	m	m	m	h	r	y	r	l	v	@	#	-	,	.	:	@	#											i	u	u	e	o	o	ai	au	r	l		k	kh	g	gh	ng	c	ch	j	jh	ny	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	ts	tsh	dz	zh	z	'	y	r	l	v	sh	s	s	h	ks	h	h	r	l	sh	s	g	k	ng	d	n	b	m	r	l	sh	s	'	m	h			-	,	.	`	@	@	@	#	#														hi	hii	hu	huu	ha	haa	shri	shrii	shru	shruu	shra	shraa	spe	spi	spo	spa	p	k	l	m	d	z	v	ng	h	g	kh	s	b	c	t	th	n	ph	r	f	ch	a	e	i	o	u	ua	ia	p	k	t	m	n	l	w	ng	y			'			'						'					'			'";
    case 283:
      return "#	#	5	6	8	9	5	9	9	0																																																																																																																																																																																							d	t	e	i	r	u	k	m	a	p	g	h	c	n	b	j	l	o	s	v	y	v	a	d	th	ph	n	kh	s	ch	t	th	'	Pvo															0	1	2	3	4	5	6	7	8	9";
    case 284:
      return "a	a	i	i	u	u	r	r	l		e	ai	o	au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	a	i	i	u	u	r	r	l		e	ai	o	au	m	m	h		'	,	.	 	-	^											0	1	2	3	4	5	6	7	8	9	1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70	80	90	*				@	,	k	kh	g	ng	c	ch	j	ny	t	th	d	n	p	ph	b	m	ts	tsh	dz	w	zh	z	'	y	r	l	sh	s	h				k	kh	g	ng	c	ch	j	ny	t	th	d	n	p	ph	b	m	ts	tsh	dz	w	zh	z		y	r	l	sh	s	h			i	u	e	o	m	m";
    case 285:
      return "a	a	i	i	u	u	e		ai	o		au	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	s	h	l	ks	jn	tr	a	i	i	u	u	r				e		ai	o		au	m	h	'	'			r	r									0	1	2	3	4	5	6	7	8	9							a	a	i	i	u	u		e	ai		o	au	y	v	b	bh	m	k	kh	t	th	l	g	gh	d	dh	n	c	ch	t	th	l	j	jh	d	dh	n	p	ph	h	r	s	a	i	i	u	u		e	ai		o	au	m	h		Om								0	1	2	3	4	5	6	7	8	9";
    case 286:
      return "																																																																																																																																																																																																																																k	g	ng	p	b	m	t	d	n	c	j	ny	y	r	l	w	s		-	i	u	e	o	,	.";
    case 287:
      return "m	ng	r	h	a	a	i	i	u	u	re	ro	le	lo	e	ai	o		k	kh	g	gh	ng	c	ch	j	jh	ny	t	th	d	dh	n	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	w	s	s	s	h	jny	a	a	i	i	u	u	re				e	ai	e			,	.	#	#	*	-	:	:	:	*	*	@	@	0	1	2	3	4	5	6	7	8	9	'																																																																																						yh																1	2	4	5	8	10	12	15	16	20	20	32	40	48	60	64	80	160	160	240	/	N	C	A	U	M	K	P	M	K	P	P	V	P	K	V	N	P	N	U	V	#	N	S	P	A	V	M	M	V														~";
    case 292:
      return "2	3	4	5	6	7	8	9	3	4	5	6	7	8	9	4	5	6	7	8	9	1	2	3	4	5	6	7	8	9	1	2	3	4	5	2	3	3	4	5	6	7	8	9	1	2	3	3	4	5	216000	432000	1	2	3	3	4	5	3	3	4	4	4	4	6	7	7	7	8	8	9	9	9	9	2	3	4	5	6	1	2	3	4	4	5	5	2	3	1	2	1/3	2/3	5/6	1/3	2/3	1/8	1/4	1/6	1/4	1/4	1/2	1/3	2/3	40	50	4	5	6	7	8	9		|	:	\\	\\	\\";
    case 303:
      return "																																																																																																																																																1	2	4	5	6	7	8	9	10	11	12	12b	13	15	17	19	21	23	24	25	26	27	28	29	30	33	34	35	36	37	38	39	40	41	44	46	47	49	50	51	52	53	54	55	56	58	59	60	61	62	63	64	66	67	68	69	70	71	72	73	74	75	75b	76	78	79	80	81	82	83	84	85	86	87	88	89	90	91	92	94	95	96	97	98	99	100	101	102	103	104	105	107	108	109	110	112	114	301	302";
    case 304:
      return "A1	A2	A3	A4	A5	A5A	A6	A6A	A6B	A7	A8	A9	A10	A11	A12	A13	A14	A14A	A15	A16	A17	A17A	A18	A19	A20	A21	A22	A23	A24	A25	A26	A27	A28	A29	A30	A31	A32	A32A	A33	A34	A35	A36	A37	A38	A39	A40	A40A	A41	A42	A42A	A43	A43A	A44	A45	A45A	A46	A47	A48	A49	A50	A51	A52	A53	A54	A55	A56	A57	A58	A59	A60	A61	A62	A63	A64	A65	A66	A67	A68	A69	A70	B1	B2	B3	B4	B5	B5A	B6	B7	B8	B9	C1	C2	C2A	C2B	C2C	C3	C4	C5	C6	C7	C8	C9	C10	C10A	C11	C12	C13	C14	C15	C16	C17	C18	C19	C20	C21	C22	C23	C24	D1	D2	D3	D4	D5	D6	D7	D8	D8A	D9	D10	D11	D12	D13	D14	D15	D16	D17	D18	D19	D20	D21	D22	D23	D24	D25	D26	D27	D27A	D28	D29	D30	D31	D31A	D32	D33	D34	D34A	D35	D36	D37	D38	D39	D40	D41	D42	D43	D44	D45	D46	D46A	D47	D48	D48A	D49	D50	D50A	D50B	D50C	D50D	D50E	D50F	D50G	D50H	D50I	D51	D52	D52A	D53	D54	D54A	D55	D56	D57	D58	D59	D60	D61	D62	D63	D64	D65	D66	D67	D67A	D67B	D67C	D67D	D67E	D67F	D67G	D67H	E1	E2	E3	E4	E5	E6	E7	E8	E8A	E9	E9A	E10	E11	E12	E13	E14	E15	E16	E16A	E17	E17A	E18	E19	E20	E20A	E21	E22	E23	E24	E25	E26	E27	E28	E28A	E29	E30	E31	E32	E33	E34	E34A	E36	E37	E38	F1	F1A";
    case 305:
      return "F2	F3	F4	F5	F6	F7	F8	F9	F10	F11	F12	F13	F13A	F14	F15	F16	F17	F18	F19	F20	F21	F21A	F22	F23	F24	F25	F26	F27	F28	F29	F30	F31	F31A	F32	F33	F34	F35	F36	F37	F37A	F38	F38A	F39	F40	F41	F42	F43	F44	F45	F45A	F46	F46A	F47	F47A	F48	F49	F50	F51	F51A	F51B	F51C	F52	F53	G1	G2	G3	G4	G5	G6	G6A	G7	G7A	G7B	G8	G9	G10	G11	G11A	G12	G13	G14	G15	G16	G17	G18	G19	G20	G20A	G21	G22	G23	G24	G25	G26	G26A	G27	G28	G29	G30	G31	G32	G33	G34	G35	G36	G36A	G37	G37A	G38	G39	G40	G41	G42	G43	G43A	G44	G45	G45A	G46	G47	G48	G49	G50	G51	G52	G53	G54	H1	H2	H3	H4	H5	H6	H6A	H7	H8	I1	I2	I3	I4	I5	I5A	I6	I7	I8	I9	I9A	I10	I10A	I11	I11A	I12	I13	I14	I15	K1	K2	K3	K4	K5	K6	K7	K8	L1	L2	L2A	L3	L4	L5	L6	L6A	L7	L8	M1	M1A	M1B	M2	M3	M3A	M4	M5	M6	M7	M8	M9	M10	M10A	M11	M12	M12A	M12B	M12C	M12D	M12E	M12F	M12G	M12H	M13	M14	M15	M15A	M16	M16A	M17	M17A	M18	M19	M20	M21	M22	M22A	M23	M24	M24A	M25	M26	M27	M28	M28A	M29	M30	M31	M31A	M32	M33	M33A	M33B	M34	M35	M36	M37	M38	M39	M40	M40A	M41	M42	M43	M44	N1	N2	N3	N4	N5	N6	N7	N8	N9	N10	N11	N12	N13	N14	N15	N16	N17";
    case 306:
      return "N18	N18A	N18B	N19	N20	N21	N22	N23	N24	N25	N25A	N26	N27	N28	N29	N30	N31	N32	N33	N33A	N34	N34A	N35	N35A	N36	N37	N37A	N38	N39	N40	N41	N42	NL1	NL2	NL3	NL4	NL5	NL5A	NL6	NL7	NL8	NL9	NL10	NL11	NL12	NL13	NL14	NL15	NL16	NL17	NL17A	NL18	NL19	NL20	NU1	NU2	NU3	NU4	NU5	NU6	NU7	NU8	NU9	NU10	NU10A	NU11	NU11A	NU12	NU13	NU14	NU15	NU16	NU17	NU18	NU18A	NU19	NU20	NU21	NU22	NU22A	O1	O1A	O2	O3	O4	O5	O5A	O6	O6A	O6B	O6C	O6D	O6E	O6F	O7	O8	O9	O10	O10A	O10B	O10C	O11	O12	O13	O14	O15	O16	O17	O18	O19	O19A	O20	O20A	O21	O22	O23	O24	O24A	O25	O25A	O26	O27	O28	O29	O29A	O30	O30A	O31	O32	O33	O33A	O34	O35	O36	O36A	O36B	O36C	O36D	O37	O38	O39	O40	O41	O42	O43	O44	O45	O46	O47	O48	O49	O50	O50A	O50B	O51	P1	P1A	P2	P3	P3A	P4	P5	P6	P7	P8	P9	P10	P11	Q1	Q2	Q3	Q4	Q5	Q6	Q7	R1	R2	R2A	R3	R3A	R3B	R4	R5	R6	R7	R8	R9	R10	R10A	R11	R12	R13	R14	R15	R16	R16A	R17	R18	R19	R20	R21	R22	R23	R24	R25	R26	R27	R28	R29	S1	S2	S2A	S3	S4	S5	S6	S6A	S7	S8	S9	S10	S11	S12	S13	S14	S14A	S14B	S15	S16	S17	S17A	S18	S19	S20	S21	S22	S23	S24	S25	S26	S26A	S26B	S27	S28	S29	S30	S31	S32	S33	S34	S35	S35A	S36	S37	S38	S39";
    case 307:
      return "S40	S41	S42	S43	S44	S45	S46	T1	T2	T3	T3A	T4	T5	T6	T7	T7A	T8	T8A	T9	T9A	T10	T11	T11A	T12	T13	T14	T15	T16	T16A	T17	T18	T19	T20	T21	T22	T23	T24	T25	T26	T27	T28	T29	T30	T31	T32	T32A	T33	T33A	T34	T35	T36	U1	U2	U3	U4	U5	U6	U6A	U6B	U7	U8	U9	U10	U11	U12	U13	U14	U15	U16	U17	U18	U19	U20	U21	U22	U23	U23A	U24	U25	U26	U27	U28	U29	U29A	U30	U31	U32	U32A	U33	U34	U35	U36	U37	U38	U39	U40	U41	U42	V1	V1A	V1B	V1C	V1D	V1E	V1F	V1G	V1H	V1I	V2	V2A	V3	V4	V5	V6	V7	V7A	V7B	V8	V9	V10	V11	V11A	V11B	V11C	V12	V12A	V12B	V13	V14	V15	V16	V17	V18	V19	V20	V20A	V20B	V20C	V20D	V20E	V20F	V20G	V20H	V20I	V20J	V20K	V20L	V21	V22	V23	V23A	V24	V25	V26	V27	V28	V28A	V29	V29A	V30	V30A	V31	V31A	V32	V33	V33A	V34	V35	V36	V37	V37A	V38	V39	V40	V40A	W1	W2	W3	W3A	W4	W5	W6	W7	W8	W9	W9A	W10	W10A	W11	W12	W13	W14	W14A	W15	W16	W17	W17A	W18	W18A	W19	W20	W21	W22	W23	W24	W24A	W25	X1	X2	X3	X4	X4A	X4B	X5	X6	X6A	X7	X8	X8A	Y1	Y1A	Y2	Y3	Y4	Y5	Y6	Y7	Y8	Z1	Z2	Z2A	Z2B	Z2C	Z2D	Z3	Z3A	Z3B	Z4	Z4A	Z5	Z5A	Z6	Z7	Z8	Z9	Z10	Z11	Z12	Z13	Z14	Z15	Z15A	Z15B	Z15C	Z15D	Z15E";
    case 308:
      return "Z15F	Z15G	Z15H	Z15I	Z16	Z16A	Z16B	Z16C	Z16D	Z16E	Z16F	Z16G	Z16H	AA1	AA2	AA3	AA4	AA5	AA6	AA7	AA7A	AA7B	AA8	AA9	AA10	AA11	AA12	AA13	AA14	AA15	AA16	AA17	AA18	AA19	AA20	AA21	AA22	AA23	AA24	AA25	AA26	AA27	AA28	AA29	AA30	AA31	AA32	V11D	:	*					+	(	)																																								A1F	A1D	A1H	A1G	A1I	A71A	A426B	A1E	A68B	A68A	A69A	A426	A72A	A3D	A3B	A2F	A2A	A2G	A2H	A2I	A7A	A4B	A4G	A4H	A4C	A478	A4I	A75	A75A	A76A	A8A	A8B	A8J	A8G	A8I	A1C	A76	A426A	A73E	A73D	A62A	A78	A109E	A80	A80C	A195	A202B	A81	A81A	A81B	A359	A362	A363	A364	A364B	A31C	A31A	A31B	A366	A84	A83B	A85	A86	A27A	A28A	A343	A365	A364C	A526	A16D	A16A	A16G	A16C	A16B	A87	A87A	A90	A92C	A91	A372	A15F	A15G	A15H	A92	A92B	A92E	A92D	A93	A93A	A95	A97	A97A	A98	A374	A99	A96	A100C	A100B	A102	A101	A101E	A101D	A21A	A21B	A21C	A21D	A109J	A23F	A19X	A19D	A113	A332	A108	A109H	A109I	A109	A109C	A109A	A109B	A110A	A111A	A111	A112A	A114B	A114	A116B	A115	A410	A410A	A117E	A57E	A57F	A57B	A9G	A9C	A9D	A72C	A72D	A119	A119C	A401	A121	A121D	A121E	A482B	A184	A376	A377	A378	A379	A512	A512A	A380	A516	A357	A402	A131C	A9B	A123	A124A";
    case 309:
      return "A124	A125	A126A	A119A	A121C	A407	A406	A131B	A131A	A338B	A395B	A525	A525A	A399A	A399B	A190	A6P	A6R	A6Y	A6V	A6W	A133A	A133D	A6C	A6D	A6X	A6E	A6K	A6O	A133B	A6G	A135H	A135I	A135B	A135C	A135D	A136	A60A	A60B	A5C	A5H	A5B	A421A	A141	A142	A143	A143C	A144	A148	A150	A34B	A34C	A34D	A35E	A35I	A35F	A35H	A35G	A158	A158B	A158D	A158F	A36C	A36A	A143A	A152A	A398	A415	A416	A417	A420	A139A	A139E	A316	A351	A413	A418	A513	A160	A47I	A47L	A49E	A48A	A48B	A48F	A47C	A47F	A47H	A461B	A47M	A47D	A47E	A48H	A49D	A453	A461	A462	A462A	A48G	A33A	A33I	A166	A33D	A165	A383	A419	A33E	A168	A168A	A355	A169	A170	A171	A385	A384A	A174	A174A	A176A	A457	A369	A242A	A181	A182	A183	A184A	A187	A187B	A186	A458	A188	A188A	A189	A376A	A376B	A384	A340	A412	A412A	A174B	A174C	A174D	A527	A196A	A199C	A199B	A199	A199D	A200	A59A	A59C	A25A	A202A	A199E	A203A	A206	A12C	A12D	A12K	A76C	A76E	A211	A221B	A211A	A212A	A207A	A77	A12L	A12M	A12O	A12N	A12A	A212B	A212D	A212C	A12P	A13A	A13B	A13Y	A14P	A14Q	A13Z	A14R	A13E	A13F	A13G	A13AA	A14S	A14T	A216	A219A	A219	A216B	A216C	A216D	A216E	A216M	A216N	A216F	A216H	A216O	A216P	A216Q	A221	A222A	A14G	A14N	A14I	A14B	A14C	A14H	A14D	A14U	A223E	A223	A223A	A225	A223K	A226B	A422	A424	A527	A527A	A32N	A32H	A32I	A32F	A32D	A233	A32G	A32B	A320	A82	A82A	A236	A409	A239	A239C	A240G	A239B	A302D	A302G	A239A	A239S	A239F	A239N	A239R	A239O	A239P	A239Q	A239G	A239M	A241	A243A	A482A	A244	A245A";
    case 310:
      return "A245C	A245E	A245D	A528	A247	A248	A248B	A249	A427	A249A	A249X	A249C	A250	A251	A252	A253	A253A	A254	A517	A428	A256	A342	A259	A257	A429	A248D	A431	A430	A261	A17D	A275	A262	A263A	A529	A530	A267	A270	A272	A272B	A273	A273A	A274	A18A	A17C	A264A	A264B	A442	A444	A446	A491	A491A	A276A	A278A	A278B	A17B	A279	A281	A281A	A441	A531	A17I	A282	A50B	A50H	A50C	A51A	A51Q	A51B	A51C	A51D	A51H	A51R	A285	A63A	A63C	A63B	A50A	A288	A51G	A50G	A50I	A532	A515	A41B	A515A	A40B	A40S	A40P	A40C	A42F	A40D	A40E	A42C	A290	A291	A292	A40G	A533	A296E	A21G	A296	A23C	A296B	C261	A23A	A508	A23E	A23H	A455	A298	A30A	A43N	A43X	A43U	A43Q	A43B	A43R	A43C	A43J	A43S	A43D	A43L	A43E	A43I	A43F	A43G	A43P	A43T	A274A	A299G	A299I	A299H	A300	A300K	A300H	A300I	A300J	A521	A45X	A45F	A45C	A45D	A45G	A45E	A302B	A301	A301A	A302H	A302I	A302J	A303A	A57D	A304	C32B	A304A	A304C	A304D	A304E	A304F	A304G	C32	A305	A310E	A307	A307A	A311	A311A	A311B	A311D	A311C	A311E	A311F	A466	A466A	A534	A535	A52J	A52A	A52B	A52E	A52F	A341	A341A	A53A	A55A	A23I	B73	A313	A333	A333A	A336	A450	A450A	A536	A66B	A33C	A103	A104	A104D	A104C	A104B	A153	A153A	A153B	A537	A432	A433	A437	A438	A470	A470A	A488	B1A	B1B	B7C	B7O	B7A	B7P	B7J	B7E	B7F	B7I	B7N	B1F	B1G	B1I	B1E	B51	B53	B56	B76	B1D	B1K	B1J	B1Q	B1C	B10	B54	B18A	B29	B8A	B8C	B8B	B8D	B105	B8G	B12	B13	B65	B16	B15	B59	B11	B19	B82	B120";
    case 311:
      return "B21A	B21B	B21J	B21	B21H	B23B	B94	B22	B23X	B23A	B23G	B23F	B121	B21D	B78	B32A	B27	B27B	B28A	B28	B88	B24	B24A	B64	B65A	B34	B35	B36C	B52	B58	B49C	B49B	B72	B68	B106	B122	B70	B77	B77B	B79	B83	B31A	B38	B38A	B39	B40A	B41	B43	B81	B45D	B45	B45B	B45A	B57	B45C	B2A	B3A	B3B	B3F	B3G	B3H	B5D	B5G	B5B	B5C	B6C	B6A	B6B	B37A	B36A	B67	B67A	B85	C118A	C118	C118B	C119X	C119B	C119	C121	C122	C123	C340	C124B	C341	C125A	C126	C127	C129B	C132	C133	C136	C262A	C342	C140A	C270	C343	C308	C309	C12A	C12K	C12B	C12C	C12L	C12D	C12E	C12M	C304	C311A	C12I	C6B	C6D	C6E	C6A	C21B	C22B	C22A	C22N	C22P	C22C	C23B	C24A	C25	C25B	C25A	C26	C26C	C27E	C27A	C28	C22D	C22F	C22P	C22H	C27B	C27D	C250A	C250B	C27	C22Q	Q44	C30	C30A	C30B	C272	C280	C34	C104X	C104Y	C104D	C39	C40	C39A	C39C	C39D	C39E	C39F	C268A	C2L	C268B	C268C	C268	C2F	C2M	C2I	C2D	C268D	C268G	C268L	C268M	C43	C43A	C43B	C43C	C43D	C43E	C43G	C43H	C43I	C291	C292	C45	C46	C46C	C17A	C17B	C17F	C48	C49	C49A	C50A	C50	C52	C52A	C52B	C52D	C344	C53B	C54A	C55A	C56B	C56C	C312	C337	C58	C59C	C345	C61	C61A	C64	C64C	C64A	C64B	C66	C65	C65A	C67	C68	C69	C69A	C70	C293	C293A	C71	C72	C71A	C71B	C73	C76	C76A	C74	C77	A73C	C11M	C11N	C11A	C11L	C110	C11I	C11B	C11Q	C11C	C11E	C346	C11G	C11J	C11P	C78	C78A	C78C	C78B	C78G	C78H	C78I	C78J	C78D";
    case 312:
      return "C78E	C78P	C78Q	C78R	C79A	C79	C347	C338	A272C	C84B	C84	C4J	C4A	C4B	C4D	C4K	C4L	C4M	C4F	C4I	C4G	C4N	C35	C348	C349	C336A	C36A	C88	C316	C87	C8B	C8A	C38B	C89	C91	C92A	C91A	C91B	C92	C92B	C94	C94C	C339	C95	C96	C95B	C97A	A479	C98A	C98	C99	C98B	C98D	C98G	C98H	C101	C101A	C102A	C102	C102D	C102I	C19A	C19C	C20C	C20A	C20D	C20E	C1D	C1A	C1B	C1F	C1G	C103	C7A	C7D	C7G	C106B	C105D	C105C	C105E	C264	C107	C107A	C107B	C253	C303	C108A	C111	C111B	C111D	C112	C18F	C18A	C18I	C18C	C18E	C18J	C18D	C283A	C350	C3A	C3E	C3F	C114	C114A	C115A	C295A	C322A	C322B	C116	C116A	C116B	C117	C285	C274	C286	C307	C351	C148	C148A	C149	C149A	C138	C138B	C138C	C9P	C9J	C9A	C9B	C9C	C9D	C9G	C9H	C9E	C9K	C9M	C9Q	C9R	C9T	C9S	C151	C151A	C152A	C152B	C153	C228	C228A	C299A	C282	C154B	C315A	C155E	C157	C154A	C155B	C155F	C155X	C159	C159A	C159B	C159D	C159E	C159H	C159I	C159J	C159C	C159G	C260	C161	C161B	C163	C163A	C310	C320	C164	C164A	C164B	C164C	C275	C164D	C275A	C164E	C164F	C165A	C165G	C165D	C165E	C319A	C289	C166A	C170	C171A	C171	C171B	C171C	C166B	C360	C353	C354	C355	C10B	C10C	C10D	C10F	C10G	C10E	C175B	C175	C175A	C176A	C177A	C177	C178A	C179	C174	C180	C276	C276A	C180B	C180C	C182	C182A	C183A	C183B	C183C	C184A	C224	C356	C357	C185	C185D	C185A	C185G	C185H	C306	C188	C188Y	C188B	C187A	C188D	C323	C190	C190C	C190D	C193	C195B	C195	C195A	C196	C196B	C197A	C197C	C199	C199A	C204B	C205";
    case 313:
      return "C206C	C206	C207	C208	C209	C211	C198	C231	C352	C214	B80	B80A	B80B	B80C	B80D	B80E	C233	C233A	C233E	C234	C234A	C216B	C218	C218A	C235	C141	C217	C277	C278	C298	C222B	C229	C255B	C255C	C313A	C239	C240	C240A	C241A	C238	C238A	C267	C242	C358	C359	D1C	D1D	D72	D65A	D68	D67K	D67J	D1E	D392	D440	D77	D77B	D77A	D124	D82C	D82	D82A	D82B	D123	D86	D81	D84	D85	D78A	D79	D80	D83	D115	D125	D116	D121	D106	D106B	D98	D96	D100	D101	D394	D112	D113	D114	D87	D103	D89	D88	D97	D117	D91	D92	D93	D118	D99	D94	D95	D104	D109	D119	D102	D107	D126	D90	D3A	D127	D3B	D129	D128	D131	D129A	D130	D432	D4B	D134	D433	D138	D6B	D334A	D139	D7A	D140	D141	D7G	D7F	D135	D7C	D7B	D8B	D8E	D8C	D434	D9A	D143	D143A	D143C	D143B	D143D	D10A	D10B	D144A	D12A	D76	D19A	D149	D146	D150	D151B	D153	D24A	D25A	D154	D154B	D152	D26B	D26A	D156	D159	D28B	D28A	D441	D176	D177B	D177C	D32B	D32D	D32A	D32C	D194	D198A	D197	D200	D405	D330A	D33C	D33B	D333	D33E	D33F	D33G	D33H	D34D	D34C	D34F	D34G	D34B	D34H	D346	D369	D371	D372	D421	D35A	D36A	D207	D37A	D211	D210	D228	D41A	D43B	D220	D217	D218	D219	D219A	D229	D229B	D229A	D231	D230	D212B	D212C	D212D	D221	D261	D382	D234	D236A	D235	D235A	D263	D264	D237	D238	D239	D240	D241	D242	D243	D244	D442	D258A	D336A	D245	D246	D259	D262	D260	D250	D251	D253	D254	D358	D257	D46D	D46F	D443	D47B	D47A	D266	D444	D267	D48B";
    case 314:
      return "D273	D272	D272A	D274	D275A	D50L	D445	D280	D53B	D53C	D283	D284	F181	D280B	D446	D412	F182	AA55	D286	D287	D447	D291	D292	D288	D289	D56A	D57E	D57C	D57D	D300	D300A	D340A	D413	D63H	D63C	D63A	D63F	D63G	D63I	D63B	D63E	D322B	D319	D323A	D323	D326A	D326B	D373	D327	D329	D157	Z25	D158	D417	E221	E34F	E20B	E214A	E214	E214C	E216C	E216	E216F	E216A	E216L	E216M	E216D	E216I	E148N	E216G	E216H	E216J	E215A	E215	E215B	E215D	E146	E21A	E21E	E147A	E148	E148A	E148D	E148I	E21D	E149	E149A	E243	E244	E244A	E77	E205	E72A	E198	E73	E78	E78A	E74B	E73C	E73D	E76	E76A	E76B	E11A	E179	E180B	E181	E191	E223	E224	E226	E183	E184	E11B	E239	E193A	E310	E103A	E103	E104	E105	E9B	E9D	E9C	E17B	E227	E139	E195	E294	E294A	E141A	E141B	E19B	E228	E14B	E15A	E15C	E204	E15B	E15D	E143	E16F	E16D	E16E	E145A	E145C	E145D	E19C	E143A	E143B	E145	E206	E231	E13C	E86A	E88	E232	E13F	E13A	E13D	E89A	E299	E90	E91	E311	E6C	E6A	E6E	E6B	E233	E186	E8B	E186A	E31B	E80A	E80	E235	E236	E132	E132A	E133	E134	E134A	E137	E298	E273B	E283	E82	E258	E34G	E34H	E34C	E81	E278	E22A	E200A	E23A	E23B	E108A	E108	E238	E107	E110	E110A	E111	E112	E114	E109	E116	E116A	E240	E241	E117	E118A	E312	E120	E121	E122	E302	E120A	E124	E127	E125	E242	E266	E295	E313	E314	E314A	E24A	E24B	E282A	E35A	E35B	E36B	E37	E37A	E38A	E39	E40A	E42	E48	E43	E44	E270	E196	E247	E45A	E46	E46A	E47	E47A	E49	E50	E194	E301";
    case 315:
      return "E51	E51B	E51A	E53	E54	E57	E58A	E58	E60	E61	E61A	E63	E63B	E63A	E63C	E66	E67	E68	E70A	E248	E130	E151A	E151	E153	E156	E154	E157A	E157	E158A	E158	E303A	E159	E276A	E274A	E159B	E154A	E162	E152	E259B	C274A	C274B	E164	E170	E1C	E219	E167	E169	E171	E1F	E174I	E174	E174E	E174H	E174G	E174A	E174D	E175	E176	E174C	E315	E165	E199A	E201	E207A	E207	E209	E210	E173	E92A	E94A	E101	E5B	E94	E95	E95C	E97	E255	E280A	E100A	E102D	E101A	E102A	E4B	E99A	E290	E291	E254	E1A	E268A	E83	E178	E131	F53C	F53D	F55	F54	F7B	F7D	F7C	F7A	F164	F164A	F170	F8A	F8B	F58	F1D	F1C	F2A	F61	F61A	F2B	F116	F63C	F63A	F63B	E177	E177B	F67A	F67M	F67B	F67D	F68A	F68C	F68B	F69	F71	F70	F70C	F12A	F11A	F11B	F66	F12B	F78	F81	F82	F83	F85	F86	F88	F89	F84	F3A	F154	F92	F4A	E128	E129	F90	F93B	F97	F97C	F98	F98A	F98D	F97B	F98B	F98E	F98F	F98C	F100	F80	F3B	F173	F14A	F102	O44A	F177	F190	F107	F107A	F18B	F18A	F187	F112	F121	F122	F19B	F20B	F20D	F20A	F21F	F178	F25A	F114B	F115	F119	F114	F25C	F118	F25D	F118E	F118B	F118C	F118A	F158A	F124	F124B	F27A	F27B	F27C	F125	F123	F29C	F29D	M223	F127	F30A	F30B	F30C	F31B	F128	F32A	F33B	F131	F132	F132C	F132B	F131B	F132A	F35B	F35A	F36D	R26A	R26D	R26B	F172	F38E	F38B	F37C	F37M	F37P	F37F	F37Q	F37L	F39A	F40A	F40E	F40B	F41C	F41B	F41A	F42B	F43A	AA34	AA34A	F140	F161	F141	F142	F113	F147	F46B	F144	F144A";
    case 316:
      return "F144B	AA3A	AA3B	AA1C	AA1D	D279	F146	F130	F139	AA52	AA53	G34A	G228	G4A	G68	G68A	G39A	G39B	G276	G276A	G330	G40A	G305	G72	G73	G41A	G80A	G74	G75A	G75B	G76	G76A	G78	G81	G82	G83	G84	G172	G167	G168	G173	G174	G175	G254	G17C	G17D	G17A	G17B	G17F	G307	G166	G300	G29A	G255	G29D	G29B	G29C	G227	G30A	G225	G225A	G298	G299	G299B	G33A	G222	G224	G224A	G212	G51A	G51B	G213	G213A	G213B	G31A	G211	G211A	G25A	G31J	G31F	G31E	G215	G217A	G216	G216B	G216A	G216D	G217	G31D	G31B	G321	G190	G26C	G26E	G278	G191	G191A	G192	G195	G195A	G196	G196A	G197	G198	G198A	G199	G199A	G287	G285	G9A	G286	G105	G106	G106A	G106B	G263A	G107	G107A	G117A	G322	G108	G109	G112	G112A	G7C	G274	G289	G264C	G264A	G113	G7D	G114	G114A	G115A	G120	G121	G121A	G123	G125	G125A	G266A	G127	G127E	G127F	G127C	G129	G290	G129E	G129F	G129D	G130	R13B	G131	G131B	G132A	G132	G132B	G133A	G133	G134A	G136	G280B	G280C	G265	G139A	G8A	G8B	G7E	Q41	G141	G142	G143	G291	G144	G144B	G145	G147	G152B	G151	G151A	G152A	G152	G153	G153A	G153B	G155	G331	G154	G148	G260	G293	G158	G158A	G158B	G158C	G161	G161A	G162	G162C	G162D	G162E	G13A	G164A	G164	G165	G162B	G295A	G229	G220	G37C	G22X	G22A	G251X	G53A	G53C	G53B	G201	G202	G202B	G204	G204A	G204B	G250	G296	G306C	G230	G306	G48A	G235	G237	G237A	G309	G310	G232A	G232	G49C	G49B	G49E	G49F	G238	G207	G21A	G21B	G21D	G21C	G210	G210A	G23A	G200	G24C	G24A	G24B	G14A	G176	G176A	G177";
    case 317:
      return "G179	G284	G283	G182	G16A	G16B	G185A	G185	G282	G186	G186D	G186F	G186B	G64	G66	G332	H13	H14B	H14C	H14D	H14	H14A	H15	H16	H16A	H18A	H17	H18	H19	H20	H2A	H44	H5A	H5B	H30	H26	H45	H41	H31	H32	H25	H34	H46	H38	H39	H40	H42	I28	I1A	I2A	I5D	I5C	I3A	I18D	I106B	I106D	I106	I3C	I3B	I3G	I3K	I3P	I3E	I3J	I18	I5B	I4B	I4C	I18E	I18C	I18F	I18G	I18H	I134	I19	I20	I6D	I6A	N28C	I6B	I6C	I21	I21A	I8A	I9D	I25A	I25C	I24A	I126	I9C	I114	I96A	I112	I9B	I118	I24B	I25	I26A	I117	I96	I150	I27	I10B	I123	I30	I31C	I31A	I121	I119	I122	I124	I33	I99	I120	I151	I40	I40H	I40F	I40C	I40D	I41	I64	I13A	I43	I43A	I44	I45	I46	I47	I47A	I50	I105	I50A	I51	I54	I53B	I55	I56	I58	I59	I60	I62	I62A	I63	I12B	I12A	I65	I67	I59A	I68	I69A	I70	I70E	I70A	I70B	I71	I73	I74	I75	I76	I107	I107A	I77	I78	I78A	I79A	I79	I139	I90A	I130	I152	I80	I81	I80A	I80B	I84A	I85	I89B	I89A	I81A	I86X	I86	I127	I15B	I14C	I88	I89	I86A	I86B	I86J	I86K	I86I	I86E	I86F	I86G	I86D	I14A	I92	I15C	I86H	I87	I93	I109	I110	K40	K31	K3A	K4C	K28C	K15	K15A	K4A	K17	K4B	K18	K18B	K18C	K18A	K14	K23	K23A	K23B	K24	K24A	K26	L1A	L1D	L9	L12A	L12	L11	L11A	L14	L15	L15A	L29	L32	L33	L3A	L16	L2B	L17	L19	L28	L25	L36	L38	L37	L34	L8A	M1C	M50A	M51	M217	M260	N113A";
    case 318:
      return "M1J	M1D	N112A	M46	M1I	M46B	M1H	M1E	M54	M55A	M54A	M2C	M2A	M2B	M85	M3B	M3G	M3J	M3E	M3F	M62	M187A	M57	M60	M210	M4C	M4A	M4B	M4D	M5B	M5A	M5C	M7A	M7B	M64B	M64A	M64	M65	M67	M247A	M66	M69	M69A	M70	M8F	M8E	M8R	M8H	M8A	M8B	M8G	M8S	M8T	M8I	M8U	M8C	M10B	M72A	M73	M75	M76	M198	M134	M250	M76A	M9B	M77A	M237	M9C	M9D	M82	M9A	M86B	M86C	M86D	M238B	M238A	M235	M86	M224A	M224	M71	M90	M91	M240	M240A	M94	M95	M96	M11A	M11E	M11D	M12K	M102	M106	M104	M105	M107	M109	M111	M112	M230	M13A	M13B	M131A	M131	M113	M116	M117	M118	M119	M125	M129	M133	M83	M16C	M15D	M139A	M97	M261	M140A	M138A	M135	M137	M140	M138	M138B	M142	M215	M262	M232	M263	M17D	M233	M148B	M148	M149	M150	M264	M255	M22E	M152	M153	M24B	M154	M245	M155	M156	M157	M162	M163	M23A	M26A	M26B	M165	M242A	M167	M244	M170	M171A	M171	M32A	M30A	M31F	M236	M33D	M175	M174	M36A	M177A	M38A	M37C	M38B	M37D	M182	M37B	M36C	M39E	M39B	M40E	M40C	M185	M185A	M43A	M43C	M194	M191	M201	M181	M173	M190	M192	M265	M195	N50	N1B	N1A	N44	N45	N46	N3A	N46A	N46B	N3D	N3B	N46C	N49	N4G	N4B	N4E	N122	N6A	N6B	N51	N6C	N51A	N6D	N52	N142	N55	N108	N55C	N8G	N8D	N8A	N8B	N56	N55A	N116A	N150	N151	N58	N58A	N133C	N59	N60	N60A	N132	N133	N132B	N132A	N133B	N132D	N62	N62B	N63	N64	N18D	N18E	N67A	N70A	N16D	N16E	N16A	N16B	N16C";
    case 319:
      return "N97B	N106	N23A	N24B	N24H	N24F	N24D	N24A	N71	N120	N24E	N24C	N73	N74	N111	N113	N113B	N113C	N119	A337	N76	N76A	N77	N82	N117	N149	N83	N85	N118	N115	N88	N33C	N92	N95	N138	N137	N28F	N30A	N30D	N97	N97E	N31H	N31J	N31E	N31F	N31G	N31A	N31L	N35D	N102A	N140	N97C	N36D	N36B	N36A	N99	N100	N101	N103A	N152	N37D	N36C	N139	N135	N141	N40B	N40A	N97A	N104	N104C	N34D	Z24	N124	N124A	N57	N107	O53	O70	O71A	O71	O72B	O72	O262	O4B	O1B	O6L	O285A	O84	O6J	O6K	O216	O88	O88A	O96	O307A	O92F	O9B	O9C	O12F	O383	O12G	O11A	O11B	O99	O98A	O260	O13K	O13L	O13M	O13N	O381	O303	O105A	O123B	O36M	O37A	O118	O36K	O36L	O120	O36N	O121	O121B	O129	O130	O131	O131A	O33S	O33C	O33M	O132	O337	O33T	O33D	O33R	O33U	O137	O138	O152	O21B	O21D	O18D	O280	O21C	O329B	O21F	O32B	O32C	O276	O145A	O32D	O16G	O16A	O16B	O16F	O18E	O18B	O18A	O18F	O148	O150	O329A	O329	M211	O154	O153C	O19C	O156	O275	O157	O158	O160	O20E	O20D	O161	O21A	O166	O329E	O167B	O184	O185	O382	O21G	O169A	O169	O175D	O175C	O346	O22A	O22B	O22C	O180	O23L	O23B	O189A	O23C	W4A	W37	W37B	O23Q	O23T	W35A	W35	W35C	O23D	O23V	W37D	W37A	O23E	O23F	O23U	O23P	O23K	O182	O342	O283	O24C	O194	O191	O191A	O190	O195A	O196A	O28D	O28E	O164A	O28B	O201	O210A	O206	O207	O211	O210	O209	O214	O357	O215	O212	O217	O218	O219	O34C	O222	O14C	O225A	O42A	O42B	O42C	O42D	O42F	O42J	O42I	O42K	O43A	O43B	O51B";
    case 320:
      return "O51F	O51C	O51D	O51A	O229	O229A	AA50A	AA50	O233B	O234	O44C	O44B	R131	O45A	O45B	T26K	O47X	O237	O237A	O238	O231	O48A	O50E	O243	O338	O380	P13	P15A	P16	P22	P19	P17	P17R	P1B	P1D	P104A	P22A	P24	P20	P25	P23	P23A	P26	P30	P30A	P107A	P27	P27A	P106	P28	P29	P34	P4A	P71	P71A	P32	P3D	P3E	P3F	P111	P71B	P2E	P2C	P2H	P2A	P2B	P2I	P36	P36B	P37	P37A	P36A	P39	P40	P42	P42B	P42C	P42E	P44	P44C	P44D	P44F	P44G	P45	P46	P51	P98	P98A	P98B	P53	P108A	P110	P54	P55	P56	P56A	P57	V47B	V47A	P58A	P58	P59B	P59A	P59D	P115	P60A	P60B	P63	P68	P66C	P66A	P66	P116	P69A	P61B	P66B	P97A	P97C	P4F	P4B	P4C	P4G	P74	P5Q	P5S	P5B	P5F	P5O	P5A	P5AB	P5M	P5D	P5I	P5J	P5H	P5K	P5Y	P5L	P5G	P118	P6C	P76A	P6A	AA23A	P83	P8A	P10B	P86	P90	AA5A	AA5C	AA5B	P93	Q1C	Q1B	Q1D	Q12A	Q12B	Q12	Q2E	Q13	Q2C	Q2A	Q3A	Q2B	Q16	Q4A	Q42	Q18	Q23	Q18A	Q19	Q20	Q22	Q43	Q51	Q24	Q25A	Q27	Q28B	Q28C	Q28A	Q29	Q31	Q37	Q14	Q33	Q6I	Q6K	Q6D	Q35	Q47	Q6G	Q6A	O159	Q6B	Q6C	Q6E	Q7A	Q7G	Q7I	Q7B	Q7E	Q7F	Q36B	Q36A	Q50	R1E	R1H	R1C	R1D	R121	R30	R3R	R33	R3C	R3N	R3E	R3O	R3M	R3D	R3AJ	R3AF	R3AB	R3F	R3AM	R3AP	R3W	R3AC	R35	R3AO	R36	R40	R40A	R36C	R36A	R37	R36B	R36D	R1I	R36E	R38A	R12O	R6B	R6A	R42A	R42	R42B	R42C	R7C	R7A	R7B	R8A	R105A	R8B	R45";
    case 321:
      return "R46	R107	R107A	R47	R9A	R49	R50	R10I	R10H	R10D	R10G	R10J	R10K	R10L	R10M	R10N	R10E	R108	R55	R122	R140	R56	R91	R12A	R92A	R123	R92	R59	R58	R60	R61	R14A	R63	R14B	R63A	R65A	R65B	R65	R70	R124	R15H	R72	R15C	R15A	R72A	R76	R127	R15B	R127A	R15J	R141	R80	R17A	R17D	R17E	R83	R18A	R18F	R18B	R18D	R18H	R17C	R82	R82A	R81	S40A	R109	R19A	R20A	R22A	R23B	R118	R88	R85	R62A	R88A	R114	S1A	S1B	S46A	S47	S47D	S47A	S48	S2B	S49A	S182	S50	S4A	S183	S173A	S5A	S55	S56A	S56B	S57	S57C	S57B	S57A	S59	S10A	S82A	S8A	S186	S8B	S60A	S60	S61	S61A	S61D	S62	S63	S63A	S9A	S68	S67	S64	S64A	S72A	S72	S75	S74	S73	S76	S77	S79B	S78A	S75A	S80A	S80B	S187	S82	S83	S84	S85	S188D	S188A	S11E	S11B	S11A	S11D	S91	S92A	S92	S91A	S91B	W107	S96	S191	S12A	N4J	N4F	S17D	S17B	S15A	N4A	N4D	S220	S197	S18C	S18B	S98	S98A	S100	S100A	S101D	S101C	S100B	S19A	S20A	S22B	S22A	S105	S105A	W109	S26C	S109	S207	S114	S115	S116	S117	S118	S113A	S28D	S28C	S124	S124A	S124C	S124D	S124E	S32B	S32A	S128A	S129	S130	S106	S133	S134	S135	S176	S176A	S36D	S36B	S36A	S36C	S36F	S37C	S37D	S37B	S37A	S198	S151	S152	S152A	S152B	S42A	S153	S44A	S43A	S43B	S43E	S168	S44C	S44D	S109A	U26A	S167	S167C	AA21A	AA21D	AA21E	AA42	AA20B	T137	AA20C	AA20A	AA20D	S221	AA41	S222	S89	S107	S112	S88	S104	S203	T3C	T3H	T3B	T1A	T117A	T3F	T117	T150	S14E";
    case 322:
      return "T44	T36C	T49	T49A	T7B	AA70	T53	S18A	T9D	T9B	T126	T151	T11B	T11D	T125	T131	T58A	T58C	T60	T60A	T63	T63E	T63F	T63C	T64	T116B	T64B	T116	T116A	T62	T63A	T63D	AA18A	AA17A	AA17B	AA18D	T67	T67A	T12A	T12B	T12D	T13A	T14A	T72	T133	T142	T124	T73	T73B	T73A	T73C	T73D	T130	T74	T18A	T75	T19A	T76A	T79	T76B	T19E	T19F	T76	T19C	T120	T21A	T144	T21D	T11C	T21G	T21C	T21E	T80	T80B	T22E	T22A	T22B	T22D	T83A	T83	T83C	T83D	T84	T84B	T128A	T128	T84A	T85	T136	T88B	T88	T88C	T24B	T88A	T88D	T24A	T89	T25E	T25F	T25C	T25A	T25B	T26B	T26E	T26F	T26G	T26M	T26H	T26A	T26J	T26D	T51	T90	U100	T90A	T93	T30A	T95C	T95A	T95	T95B	T101	T102	T102A	N78	T103B	T103A	T146	T141	T31A	T30D	T29C	T29A	T145	T32B	T140	T33C	T106	T113	T86	T87	T109	T94	U131	U7B	U7C	U7E	U7A	U7D	U52	U50A	U50B	U55A	U54B	U54	U55	U13A	U13C	U14A	U13B	U58	U13D	U117	U15B	U15A	U16A	U16D	U122	U140	U17A	U119	U19A	U134	U20A	U21A	U64	U65	U22A	U24E	U127	U27B	U128	U27A	U23B	U23E	U23F	U23G	U72	U25C	U25B	U25D	U24M	U24J	U24K	U24R	U24I	U24A	U24O	U142	U24D	U24H	U74	U24S	U25F	U25G	U25A	U24C	U24G	U24B	U26B	U75	U24T	U27D	U27C	U24Q	U24N	U30A	U30C	U32D	U32F	U32B	U33A	U34A	U88A	U141	U89	U38A	U38C	U91	U39A	U39C	U39P	U39F	U39O	U39S	U39N	U39I	U39B	U39Q	U39H	U3F	U39E	U39D	U94	U94A	U95	U96	U96A	U39T	U97	U97A	U99A	U99B	U99C	U99H	U99E";
    case 323:
      return "U143	AA23S	AA23C	AA23R	AA23D	AA23B	AA23J	AA23L	AA23Y	AA23K	AA23F	AA23P	AA23O	AA23Z	AA23I	AA23M	AA24A	AA24B	S132	U101	U103	U93	AA27C	AA27D	AA27E	U98	U109	U105	U107	AA29A	V2B	V43A	V46	V45	V48	V49	V54	V129A	V58	V59	V62	V63	V16C	V16A	V16B	V17C	V17B	V21A	V21C	V117	V117A	V23B	V65A	AA27A	V65	V28F	V28B	V28C	V119	V84B	V84A	V149	V28G	V29B	V91	V89	V148	V31B	V96	V115	V97	V32D	V32E	V32B	V98	V98A	V36G	V36E	V36A	V36H	V36K	V36B	F143	V131	F143C	V132	V102	V110	V110B	W1B	W27B	W27	W27C	W2B	W29	W27A	W30	W32	W32A	W3C	W5B	W38	W39	W9E	W9B	W9F	W40	W41	W10B	W11A	W14D	W15A	W15B	W15D	W45	W99A	W99C	W47	W48	W48A	W16A	W17B	W17C	W17D	W17F	W18B	W18D	W19A	W20A	W50	W121	W52	W53	W53A	W54	W57	W56	W21D	W122	W21A	W21B	W21C	W123	W59	W60	W61	W113	W125A	W63	W101	W124	W126A	W64	W65	W65A	W65B	W66	W130	W67	W119	W70	W120	W69	W112	W72	W73	W78A	W62	W76	W77	W78	W79	W80	W85	W125	W128	W131	W117	W88	W89	W92	W93	W95	W132	W7A	W100	W104	W98	X2D	X2E	X2A	X2B	X3A	X3B	X3D	X4K	X4J	X4X	X4L	X4E	X4C	X5A	X6D	X6G	X6B	X13	X10	Y1B	Y23	Y3B	Y3C	Y3D	Y11	Y12	Y13	Y27	Y30	Y7A	Y7D	Y7C	Y7E	Y16	Y17	Y17A	Y24	Y18A	Y18	Y18E	Y8A	Y8B	Y21	Z2F	Z15J	Z11A	Z11B	Z26	Z20	Z22	Z30	Z36	Z6A	Z31	Z37	Z49	Z50	Z51	Z52	AA8A	AA25B	AA78	AA80";
    case 324:
      return "1	2	3	4	5	6	7	8	9	10	10a	11	12	13	14	15	16	17	18	19	20	21	22	23	24	25	26	26a	27	28	29	30	31	32	33	34	35	36	37	38	39	39a	40	41	41a	42	43	44	45	45a	46	46a	46b	47	48	49	50	51	52	53	54	55	56	57	58	59	60	61	62	63	64	65	66	66a	66b	66c	67	68	69	70	71	72	73	74	75	76	77	78	79	80	81	82	83	84	85	86	87	88	89	90	91	92	93	94	95	96	97	97a	98	98a	99	100	100a	101	101a	102	102a	103	104	104a	104b	104c	105	105a	105b	106	107	107a	107b	107c	108	109	110	110a	110b	111	112	113	114	115	115a	116	117	118	119	120	121	122	123	124	125	125a	126	127	128	129	130	131	132	133	134	135	135a	136	137	138	139	140	141	142	143	144	145	146	147	148	149	150	151	152	153	154	155	156	157	158	159	160	161	162	163	164	165	166	167	168	169	170	171	172	173	174	175	176	177	178	179	180	181	182	183	184	185	186	187	188	189	190	191	192	193	194	195	196	197	198	199	200	201	202	202a	202b	203	204	205	206	207	207a	208	209	209a	210	211	212	213	214	215	215a	216	216a	217	218	219	220	221	222";
    case 325:
      return "223	224	225	226	227	227a	228	229	230	231	232	233	234	235	236	237	238	239	240	241	242	243	244	245	246	247	248	249	250	251	252	253	254	255	256	257	258	259	260	261	262	263	264	265	266	267	267a	268	269	270	271	272	273	274	275	276	277	278	279	280	281	282	283	284	285	286	287	288	289	289a	290	291	292	293	294	294a	295	296	297	298	299	299a	300	301	302	303	304	305	306	307	308	309	309a	310	311	312	313	314	315	316	317	318	319	320	321	322	323	324	325	326	327	328	329	329a	330	331	332a	332b	332c	333	334	335	336	336a	336b	336c	337	338	339	340	341	342	343	344	345	346	347	348	349	350	351	352	353	354	355	356	357	358	359	359a	360	361	362	363	364	364a	365	366	367	368	368a	369	370	371	371a	372	373	374	375	376	377	378	379	380	381	381a	382	383	383a	384	385	386	386a	387	388	389	390	391	392	393	394	395	396	397	398	399	400	401	402	403	404	405	406	407	408	409	410	410a	411	412	413	414	415	416	417	418	419	420	421	422	423	424	425	426	427	428	429	430	431	432	433	434	435	436	437	438	439	440	441	442	443	444	445	446	447	448	449	450	450a	451	452	453	454	455	456	457";
    case 326:
      return "457a	458	459	460	461	462	463	464	465	466	467	468	469	470	471	472	473	474	475	476	477	478	479	480	481	482	483	484	485	486	487	488	489	490	491	492	493	494	495	496	497	501	502	503	504	505	506	507	508	509	510	511	512	513	514	515	516	517	518	519	520	521	522	523	524	525	526	527	528	529	530";
    case 353:
      return "a	k	kh	g	gh	n	c	ch	j	jh	h	t	th	d	dh	w	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	s	a	i	i	u	u	e	e	ai	o	o	au		y	w	h	m	r		0	1	2	3	4	5	6	7	8	9";
    case 360:
      return "ngku mfon	gbie fon	pon mfon pipemgbie	pon mfon pipemba	naa mfon	shunshut	tita mfon	nza mfon	shinda pa nji	pon pa nji pipemgbie	pon pa nji pipemba	memgbie	tu memba	ngangu	memvux	mansue	mvuengam	sunyam	nto'pen	kukutnda	nkindi	suu	ngkunzum	lapa'	let kut	ntap mfaa	mekup	pashe	ghuere	pamshe	mon ngguet	nzun mut	u yu' ne	ghueghue	ntap ntaa	sisa	mgbasa	munjomndu'	moompu'	kafa	pa lerewa	nda lerewa	pet	memkpen	nika	pup	tuep	luep	sonjam	tutuwen	menyi	ket	ndaangguet	kuo'	moomut	shum	lomme	fir'i	rom	kpo'	so'	map piet	shire	ntap	sho' nshut yum	nyit mongkue'	paare	nkaare	*	nggen	mesi	njam	mbanyi	nyet	tuen	sot	paam	nshie	mem	nyi	ka'	nsha	ve	lu	nen	na'	mba'	nshut	tu memgbie	sie	set tu	lom ntum	mba mele	kiem	yure	mbaare	kam	peshi	yafu lerewa	lam nshut nyam	ntie shuo'	ndu njaa	ghughuem	pit	tu nsie	shet nja'	shueshtu	mfon tue'	mbit mbaaket	nyi ntum	kupu'	ghughen	kuyux	laane	parum	vum	ngkindi mvop	nggu mbu	wuet	sakue	taam	mu'	ngguo'	ngguo'	mfiya'	su	mburi	montien	nyeme	punggaam	mut ngget	fux	mbuo'	fe	kuem	ma njuena	ma nju'a	let	nggaam	nsen	ma	ki'	nggom	ngku memba	nza	yum	wangkuo'	nggen	nduere	ngka'	ghare	mbeket	gbayi	nyir mkpara' mun	ntu mbit	mbum	pirien	ndombu	mbaa	kushuep	ghap	kuka'	yu muome	nzem	mbu	nsuen	mbit	yu'	kpara'	kaa	sux	ndida	taashe	nju'	tita yu	suet	ngguen nyam	vux	nansana'	ma kueri	ntaa	ngguon	lap	mbirien	mgbasa'	ntungba	tutux	nggum	fu	ndut	nsa	nsha'	bung	vuepen	mbere	ru	njem	lam	tituep	nsuot ngom	njee	ket	nggu	mesi	mbuem	lu	kut	njam	ngom	wup	ngguet	nsom	nten	kuop nkaare	nsun	ndam	ma nsie	yaa	ndap	shu'	shetfon	mbi	memba	mbanyi	kusux	mbux	kum	mbaa	yuwo'	njux	mie	mue	shi'	ken	ken	nga'	na'	li'	pin	pen	tet	mbuo	wap	nji	mfon	njie	lie	njut	nshe	nggaame	nyam	wuen	ngkun	she	ngkap	kuetmun";
    case 361:
      return "tut	shue	njap	su	ket	yemme	kuom	sap	mfut	ndux	maleri	mut	sue'	yen	njuem	kuot mbue	ngkuri	tu	ghaa	ngkye	fufuet	nde	mgbofum	luep	ndon	moni	mgbun	puut	mgbie	mfo	lum	nsiep	mbaa	kwet	nyet	tuen	sot	yuwo'	kum	rem	tee	ngkue'	mfue	nsiet	kup	pip	pute	nyu	let	nggaam	mfie	nggwen	yuom	pap	yuop	ndam	ntum	sue	kun	nggux	ngkie	tuot	mun	ku'	nsum	tun	menjet	nggap	lum	ngguom	nshut	nju'	ghue	ku	ren	te	to'	nyi	rii	lee	mee	m	suu	mu	shii	shux	kye	nu	shu	nte	pe	n'i	sho'	pu'	mvop	lo'	ren	ti	ntuu	samba	sa'	faa	ndap	toon	mbum	lap	vom	loon	paa	som	ra'	nshuop	ndun	pue	tam	ngka	kpux	wuo	se	ngguet	paam	too	kuop	lom	nshie	nggop	mem	ngkux	ngo'	nshu	rimgba	njux	pem	saa	nggure	mgba	ghux	ngkuem	njemli	map	loot	nggee	ndi'	ten ntum	set	pum	ndaa	nggueshe nyam	yie	ghun	tue	yue	po	tume	kue	suen	tue'	vue	wux	laam	pu	taa'	ghaame	ngurut	shue'	mgben	mbe	nza'	nkom	gbet	tum	kut	yap	nyi	yit	mfu'	ndia'	pie'	yu'	luem	fu	gbux	ngkup	ket	me	ngkaami	ghet	fa	ntum	put	yum	nggue	nyi	nzu'	poon	mie	fut	ne	mue	ghue	fu i	mvi	pua'	ngkum	kut	piet	ntap	yuet	nggup	pa	fu	fom	nje	a	to'	o	i	la'	pa	taa	ta'	ndaa	shi'	yux	ngue	yuen	yo'	yo'	yu'	yun	kux	pux	nje	pu	wu	fe	ve	lu	mi	rux	re	nguet	nga	sho	sho'	fu	na	pi	lo'	ko	men	ma	ma'	tu	ki	mon";
    case 362:
      return "ten	fa'	ghom	ka	u	ku	e	re	te	nyi	la	rii	rie	mee	taa	ndaa	njem	m	suu	shii	si	sux	kye	ket	nue	nu	njue	yo'	shu	ya	nsha	pux	nte	wu	pe	ru	n'i	rux	ken	ngkwen	ngga	sho	pue	fom	wa	li	lo'	ko	mben	ren	ma	mo	mbaa	tet	kpa	samba	vu'								t	ng	y	m	b	d	a	ph	kh	h	i	c	k	l	m	n	p	o	o	r	sh	th	e	w	e	k	l	l	hai	o	tek		0	1	2	3	4	5	6	7	8	9					,	.	oz	oc	oq	ox	az	ac	aq	ax	vz	vc	vq	vx	ez	ec	eq	ex	iz	ic	iq	ix	uz	uc	uq	ux	awz	awc	awq	awx	uiz	uic	uiq	uix	ng	uex	uez	awx	uec	uez	ueq	uex	uiuz	uiuc	uiuq	uiux	mz	mc	mq	mx	k	kh	g	ng	s	y	w	p	ny	ph	b	m	n	h	l	ht	t	d	r	nh	sh	c	ts	gh	htt	th	x	f	dh	ch	z		0	1	2	3	4	5	6	7	8	9							n	k	s	f	mb	ny	g	d	kp	j	xw	w	z	gb	nd	c	hw	t	b	v	h	p	l	a	o	o	u	e	e	i								.";
    case 363:
      return "eeb	eev	ib	iv	aub	auv	ub	uv	eb	ev	aib	aiv	oob	oov	awb	awv	uab	uav	ob	ov	iab	iav	ab	av	wb	wv	aab	aav	v	nts	l	h	nl	r	nk	qh	y	hl	m	ch	nch	hn	plh	nth	n	'	x	c	m	d	j	v		s	g	?	!	,	&	%	+	-	*	/	~	`	-	-	^	@											0	1	2	3	4	5	6	7	8	9		Caum	Pua	Vam	Roob	Neev	Ruav	Tas		'	Xyoo	Hli	Hli	ZT	Hnub	Nqig	Xiab	Ntuj	Av	TC	MT	Tau	Los	Mus	CHLNN	CCT	CT	CTC	CPD	CNT						Cheng	Yeng	Lee	Lor	Xiong	Kong	Her	Moua	Thao	Chang	Pha	Khang	Hang	Vang	Fang	Yang	Chue	Kw	Vue";
    case 365:
      return "																																																																n	m	'	a	k	kh	g	gh	n	c	ch	j	jh	n	t	th	d	dh	t	th	d	dh	n	p	ph	b	bh	m	y	r	l	v	s	s	h	a	i	u	u	e	ai	o	au			.	,	.	0	1	2	3	4	5	6	7	8	9";
    case 366:
      return "																																																																M	S	V	W	Atiu	Z	Kp	P	T	G	F	I	K	A	J	E	B	C	U	Yu	L	Q	H	Ng	X	D	O	N	R	O	Ai	Y	m	s	v	w	atiu	z	kp	p	t	g	f	i	k	a	j	e	b	c	u	yu	l	q	h	ng	x	d	o	n	r	o	ai	y	0	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	1	2	3	,	.	Aiva	!";
    case 367:
      return "b	b	b	bl	m	m	m	f	v	v	d	d	d	d	dr	dr	n	n	n	n	nr	nr	l	l	hl	hl	dl	dl	dli	dli	g	g	g	gh	gh	ngg	ngg	ngg	h	hx	hx	hx	j	j	ni	ni	zh	zh	zh	zh	j	sh	x	r	r	z	z	z	s	r	r	y	y	y	yi	yi	w			bl	sh	j	d	z	dr					`	n	'	`	'	a	au	ah	an	ang	o	oa	wo	w	e	en	eng	eu	i	ia	ian	iang	io	ie	ii	iu	ing	u	ua	uan	uang	uu	uei	ung	yu	yi	e	e	yu	yu	i	i	ai	ei	ao	ou	n	ng	uog	yui	og	er	w	ig	ea	iong	ui								x	b	d	s	x	b	l	t	s	k	f	b	x	l	t	s	f																																																																	-	-	,	-";
    case 368:
      return "do	sa	chha	sho	ngwu	zar	gwyr	gon	tson	ke	chha	pho	chha	khi	rer	par	je	le	shon	she	chha	zar	lo	tsew	thwy	phy	sho	khi	ngwu	vor	to	ni	phy	chha	sho	har	ngwu	tew	?	de	thwu	de	li	pho	thew	thwu	thew	thwy	lhy	pho	chhew	chyr	?	me	thon	khu	te	zi	nyr	tshwin	ka	tew	tsewr	li	ko	ve	dzew	ku	mo	la	be	ly	twa	phe	ba	ta	dir	bu	ji	ko	mo	ly	ly	ty	ta	ta	do	me	rer	kyr	kyr	la	vor	gew	chha	ku	von	phi	lha	dzy	dzy	cho	be	tew	bi	tin	thew	sy	thon	jwo	chhi	khy	?	e	me	a	ly	e	phe	kha	si	tha	kir	lhe	be	tshe	ta	ta	ko	khy	shu	chhwa	ghwa	mer	ze	kwe	zhy	vi	jwa	nar	or	lhi	tshen	u	tshwa	kwar	kwar	tew	sa	me	born	khy	ker	pha	e	by	tshi	ji	me	var	hon	pyr	di	vi	ba	ne	ir	lhe	cho	rur	ngyr	gu	ar	pha	kyr	gar	li	ly	dzen	chyr	chyr	pha	ryr	twi	bi	lhy	lhy	dwe	e	e	mo	tu	tswy	pha	khy	ler	lwy	vir	ar	la	swy	ge	pho	ver	ver	nga	er	ko	?	tew	ly	tew	tsewr	zhi	mu	bu	o	jen	ne	lon	li	bu	ky	ky	ne	pu	shi	rir	mi	ky	dy	le	o	ge	rir	pew	li	u	jon	dy	he	bu	jen	myr	khu	pu	mi	khy	hy	sa	ly	ny	ky	var	ny	zhi";
    case 369:
      return "?	thwo	chwe	chwon	di	chwo	char	?	shwo	zi	zi	zhi	chwy	chwo	li	chwen	chi	ngorn	shwo	gy	shwon	she	ji	che	chwen	chwa	chwy	bir	ve	kin	vy	ngwu	ngwu	ky	ly	ko	ror	lhe	je	ly	lu	bi	nu	lew	dzen	dzy	ga	me	phy	pe	?	ma	twi	ghwen	chhew	my	chha	pe	bu	nwy	la	shan	se	lu	rur	u	rar	lwu	la	ew	den	ten	ten	non	lhi	mi	ghor	lwen	khwy	la	la	me	dzwa	ne	na	li	zi	me	ji	me	be	len	khew	be	lhy	rewr	gur	khwy	sew	rur	mar	tu	u	gu	me	lwon	kwe	kewr	dzew	ngewr	du	ky	lwen	ten	ten	ge	le	me	twy	j?	kwy	a	tshy	tshy	to	tew	no	dze	u	san	phe	pu	pu	?	kwen	ngwyr	gi	ko	ka	shwy	bu	lew	tshe	chu	le	ga	lon	me	ka	di	rar	ke	khy	lhi	dzu	sa	tsar	ryr	me	mi	bu	u	khwy	e	khan	khwa	di	siw	me	phy	e	lyr	vir	jew	lhwo	tshy	la	tha	dzi	e	la	la	rar	la	bu	e	lwon	a	ew	chhy	ge	phar	phy	shan	sar	hwa	mi	chhy	shar	hwa	khwa	khwa	the	mer	lu	lhew	ve	le	di	ha	sha	sha	ly	la	chyr	zir	lhew	lwyr	shy	te	wya	wya	khon	khy	bi	len	ka	ko	tswa	?	la	khy	ma	lon	di	di	lwan	ka	ryr	da	ma	nga	lu	kho	dzon	lhwi	che	ka	zy	khan	lu	nen	gwan	dzu	don	de";
    case 370:
      return "ly	vu	ka	su	ny	le	tshe	la	jan	ni	zhi	tsur	de	tsa	?	de	my	dzi	kewr	le	ka	zhi	?	di	hwin	chu	gu	gu	ka	tsin	dzar	te	dzi	zorn	tshu	kewr	shu	je	lha	she	lo	o	a	lwe	a	khwa	ghir	ghir	nar	rar	khwa	o	ror	jy	sy	ngewr	chhon	si	na	chew	pu	pi	lhwa	tsha	tshwa	i	ghi	te	ja	tsa	pi	tsa	tsa	je	jwe	chon	pu	shwa	be	kwon	chon	dzwy	?	phi	chew	chyr	tshen	mi	chhy	di	thu	zhi	dze	shi	ghu	a	chu	kew	shwa	phi	chhy	gwe	?	tshen	chyr	go	chhen	khe	gwe	chen	chhy	ka	chhy	shwu	chhew	kwa	chhy	vi	my	chhu	hon	bu	sha	tshe	gha	sy	shar	ror	ghu	na	dzwy	mur	ten	di	no	sa	hwi	no	lo	tsi	nu	kwi	don	ni	zyr	dzwan	pa	my	ba	shy	o	lhe	ghe	hwin	ni	tshew	zhu	ja	gi	so	ge	ha	ly	ku	cha	my	dy	chhwan	ty	hon	lon	na	ku	se	la	kha	lu	dzo	?	chwen	se	chhu	lhu	len	no	lwo	ha	sho	da	by	kyr	shin	chy	de	shwo	si	su	lwu	khwar	ghu	ngwu	ja	rer	chor	ne	tswu	chhyr	thwu	chhu	den	ke	zyr	thwi	tha	ka	swi	khwar	vy	vy	nwy	tsa	lwu	ner	ker	ja	na	kwy	khar	zyr	vir	lhu	?	lir	vir	wo	tew	pho	di	shwi	ngwyr	ge	di	li	kwan	?	su	tswen	tsi	ma	no	kwi	dzon	chhy	zyr	zhu	ur";
    case 371:
      return "ha	di	chwi	tun	lon	san	shwe	ky	mur	ner	nwy	ha	na	hwar	di	ur	tswa	chwan	chor	?	thwan	?ar	?ar	gu	nwy	lhu	nen	hwar	nor	se	na	chiw	na	than	gu	gu	?	pa	pho	ur	jwon	pen	lwy	chwu	dar	ku	mor	vi	pu	ben	va	va	vi	kon	ner	po	ne	ner	vi	ar	ly	dy	thwy	pen	ghu	vi	nwe	ew	ne	kyr	kyr	shon	kon	hy	su	khy	jwe	tsir	pa	su	khin	khy	va	rewr	kir	kyr	kyr	vi	pa	vi	zar	ky	pa	on	ngwy	dy	khin	su	po	ba	da	ghy	lhu	li	zur	hy	tshen	ny	lu	lon	dewr	?	po	zy	la	ni	dir	chwa	dzen	dzen	par	tsewr	cha	ja	ve	tshwu	ve	lew	cha	rir	cha	ki	vyr	ghor	vi	vyr	wo	ky	rer	vyr	jon	khi	kwi	me	ky	mur	da	kewr	je	ku	khi	ku	bu	pha	mir	ku	ku	pha	my	thar	er	ku	then	pon	me	mi	kha	kha	vu	ka	?	tser	jyr	mi	vu	vu	chy	tser	jwe	kha	ti	vu	kon	cha	cha	bu	va	kon	swew	mi	mi	po	mi	ngwy	mi	e	ngwy	wy	hwan	di	ngwu	ghur	ghar	si	?	?	ba	shy	tshe	no	du	li	cho	rir	rer	j?	ghar	dzwyr	be	win	pe	zo	u	lo	ghar	ku	ghur	rer	tha	lu	ba	?	ghur	by	vi	lu	kor	ma	tshe	pen	te	li	phe	kar	ju	ma	pho	gy	ma	u	rer	jyr	nwy	rer	la	la";
    case 372:
      return "rer	ti	ti	sha	pen	be	cho	lho	be	mar	pen	gha	va	ke	py	lhu	hon	shi	gha	swy	ghar	pe	chi	lhu	kho	du	ror	var	gha	ghew	chy	chi	chy	chy	chy	lu	ve	kwy	lu	ne	shi	shi	khon	ve	ky	shwa	len	ke	phy	ni	by	che	nu	li	la	sy	se	an	min	y	jwa	tshon	swin	ngwi	ji	on	vyr	chin	chu	gy	ty	ma	dzy	me	nga	khon	ke	la	sy	tha	lew	mor	shwa	di	my	ji	ngwir	se	swe	ghan	gar	zyr	gu	tsewr	khew	vi	rir	rir	?	ghwa	ghwa	che	shwyr	to	ngon	gi	kwin	by	dzu	nwy	dy	gur	tshe	ka	chhew	na	lwan	tsy	zew	to	ghwe	an	nu	gha	ne	kha	ngwu	la	tshwew	dzu	na	la	la	shyr	hwa	nwew	jen	la	?	shon	ly	dzwy	on	go	ghwe	y	mi	chha	ngon	lwe	jy	khe	ghe	ghe	by	u	jwa	min	na	nwo	ke	dzwy	she	bi	gur	on	na	gha	ba	nu	va	gew	ly	khy	kha	khi	rir	shwi	chi	khu	chhwy	kwa	jwa	rar	ly	sha	tshew	kur	khwe	thu	mi	lu	lu	mi	sy	gu	ngwe	ka	le	ky	lhwu	ky	khon	ghe	?	sha	lwu	ji	ghy	wer	dzu	chhe	tshe	von	ga	ju	hen	py	ma	nwy	khor	ve	chu	ngwyr	de	rir	vy	je	je	shon	dwu	gha	mi	ben	swin	phu	ver	lwe	ma	?	na	te	bo	na	phy	er	lo	khwan	na	lwe	vy	khar	ngwi	lo	tshew	rir";
    case 373:
      return "va	si	tsi	chi	ba	kew	so	u	chan	chhon	kwon	bon	zi	ngon	ghe	lwu	nu	ka	vy	?	lhu	nir	tsewr	sha	mo	chhi	phy	gwi	lwen	kew	myr	n?	su	ly	ti	len	kwi	dzi	mer	su	chy	ghe	kwe	du	vi	ngewr	ngon	dzi	nu	ly	tshew	zar	ur	ku	korn	chon	ba	er	li	ar	ghwe	khwy	khy	lwyr	o	chi	gu	tson	rir	me	lu	lu	nu	shon	?	ler	zhin	ler	new	chyr	ky	khy	ni	di	the	phy	ko	rer	ngy	phy	ma	te	va	phy	dzo	ty	kho	zor	khy	tsha	shwa	bi	thy	dwu	lo	lwu	me	rur	shy	chhwyr	chhi	lo	lhi	ghi	chhwyr	shy	tsen	jwa	gha	ngwe	chhon	ta	ngwu	kho	lu	da	ku	ne	dzen	dzu	chhwo	?	nwi	swi	ge	kha	pha	tho	shy	swy	gy	la	ke	nwo	bu	lu	da	lho	ha	na	ny	sin	nwo	sa	sa	ghi	ta	ne	che	ka	ngwe	ta	ne	zhir	tu	chhwi	shwon	i	rir	li	lhorn	na	kewr	nu	chhon	a	lwyr	wu	lhu	la	kewr	bu	swy	du	ngwu	ka	ku	pu	le	e	thy	thy	shy	shy	mo	wu	lu	shwe	sin	gu	do	ngwe	ku	te	go	le	pwyr	pwyr	ew	ku	ku	ngon	e	len	len	e	len	e	ngon	lha	thorn	e	le	e	lha	len	the	lwy	lwy	zhi	phy	ka	zhi	pha	ki	tsir	lwu	chon	lwu	che	khwy	jy	khi	khwy	tshwy	khi	ny	ni	va	shwa	ly	na	na	jy	va	ta";
    case 374:
      return "kew	rir	khwy	na	ta	gu	kew	chu	ngwir	ngon	tshwu	ka	shwon	ngwyr	ngwyr	shwen	kwe	by	kwe	hu	tshwu	ngwyr	hu	tshwu	ngwyr	ngon	tshwu	tshwu	ga	lu	lha	lu	rer	chhen	chhen	wyr	lhew	lhew	je	jir	je	nyr	lhew	lu	swa	tha	nyr	ve	ba	ngwu	len	du	mu	khi	gy	horn	khan	khan	me	do	gu	thwy	kwy	po	bu	my	dewr	lin	shyr	hyr	ha	zew	va	ghar	jan	dzon	ky	khwy	sew	ghi	si	ghi	la	lwin	hwan	ha	phan	da	ghi	kin	phin	ly	shwe	kha	khwy	ge	ja	kwar	van	ha	pin	de	jin	mer	er	hew	kan	a	shon	rar	chhwy	zir	ky	ky	rir	ky	rar	cha	tsen	rir	rir	lhon	u	cho	u	ny	kwen	u	cho	du	so	ky	do	lu	lu	le	gha	u	ngur	chi	si	dzwan	hon	sha	le	do	khu	tu	dzwy	li	lhor	da	tsir	thwo	zew	mu	pu	dzi	my	kwan	khu	ny	pha	pha	tshe	zyr	tu	my	dzew	rer	bi	ven	ghor	jar	tshon	le	le	lha	tsyr	ku	jy	by	zhu	chhy	chhwi	shwan	tsi	shy	tshan	du	khi	lew	kwo	bi	shwu	ly	lwu	du	var	tshwa	shwi	khe	sha	ka	ngwi	da	dzo	rar	she	lhorn	zon	lon	zhu	bu	ky	ba	khu	len	dze	ku	len	rer	dy	vi	ghu	ky	lu	lon	par	dza	khi	lu	nar	vor	gew	ghor	du	tu	vy	vu	rer	shin	lon	?	ne	la	dzi	pha	vu	tshon	o	da	twyr	?	khe	ko";
    case 375:
      return "tsew	jo	o	to	o	vu	lhe	gu	zon	y	cha	ngon	?	sa	ror	my	my	pa	kha	sha	ja	ke	cho	lon	be	che	jo	?	o	ge	chho	gew	khwi	tshon	twi	lu	kew	ke	lwi	me	my	la	lew	si	lo	da	lu	ly	tsun	sho	dzi	jan	khu	le	vi	bo	gu	lhi	?	dwu	len	ryr	i	tshe	tshe	lo	ryr	pen	swan	?	tho	zon	zew	va	swi	ga	sha	da	khu	du	gha	ja	ghy	ky	rur	lu	khe	no	nwy	tsorn	sy	nir	dyr	ngwyr	de	gu	si	la	lan	da	rir	mur	si	tsha	to	dzon	kan	khew	rir	ve	se	pa	mar	ver	my	na	tur	ghe	cha	kew	ge	vu	na	kwy	di	pho	ten	chhe	rer	dzi	lu	dy	rur	chwan	gu	chho	bi	si	pu	lhor	zhiw	ka	vi	nwu	tsi	lwe	zhwy	nwy	sha	phe	hwin	shew	ryr	twe	ge	jy	ur	ge	da	ko	hen	po	ban	ghy	ngwir	le	kur	da	ky	ni	er	chi	len	vi	di	hu	ne	li	do	shwu	mer	rur	ne	kwan	tsy	?	lhon	ky	nu	ba	kwon	tshwe	rar	thwo	ge	ghew	ly	khy	lhon	tsy	my	zhwy	len	vi	thwo	ur	dzwy	len	ku	i	pi	tan	ko	cha	kon	phi	po	thwyr	lor	ba	dzyr	ghe	li	po	ju	lwu	gi	ly	chew	te	man	rir	lhwi	ra	gi	nir	lwe	vo	ker	chho	lhwi	py	ngwu	ngwu	khy	a	ir	py	ka	ne	py	phi	di	mor	ka	phi";
    case 376:
      return "dzwy	bu	rir	tu	ka	gy	po	ti	dzo	myr	jan	chha	va	tu	khy	ko	du	kar	by	ba	pho	tha	ghar	pi	ky	byr	the	lhu	bi	a	nwi	sho	do	by	phy	bo	dzi	do	ti	ky	jwu	mi	bi	jwew	ror	ki	a	tshar	thi	the	do	shi	a	pa	zhy	pho	dy	dzi	li	thar	le	ka	tsu	mo	lo	nga	thwo	tshe	dzi	dzi	phyr	?	ar	bi	?	dzi	?	pi	li	mi	ka	mi	phy	tha	ngwu	nu	?	ar	dy	on	tsew	li	ke	ka	tu	bi	bi	vy	to	dzi	ma	yr	yr	dzi	jo	hwi	tsew	sho	len	khy	shwo	ji	la	se	?	le	shwa	de	she	non	si	korn	ber	ly	ber	chwen	no	swa	swa	hy	hy	gwyr	shwan	ni	shwy	kew	tsa	tsa	vu	je	pin	ni	ghar	si	u	rir	dzu	nga	rir	lhyr	tshwen	chhwew	swu	nar	zo	u	?	u	le	chwi	my	vi	dzi	lhi	la	da	gi	mir	dzwo	tsa	pi	lhy	dzew	gy	gwi	lhwa	na	tshon	ga	tha	rer	vor	jon	khy	la	y	rir	mi	ze	de	kwen	tshwin	rer	lhy	lhy	gwi	thwo	ngwu	tsha	ngon	lho	la	mi	khan	mi	my	rar	lu	ty	du	lon	gi	tu	vi	shon	ze	chon	thew	no	kew	thu	me	tswyr	ver	de	thy	dzew	tshi	py	ngon	shwew	pho	the	tha	bi	tsen	vo	tshin	e	de	kwi	dzi	bo	se	vin	be	gy	lhy	ne	tsi	rar	lhy	chha	li	gy	lhwe";
    case 377:
      return "she	chhiw	di	na	yr	me	ly	dew	gi	nga	su	me	tu	be	sar	kyr	ka	phe	kew	tho	mu	tsan	te	?	den	da	mi	chon	lon	chi	pen	tsir	var	gi	bi	ma	thu	nga	shy	chu	ju	ghwan	ngewr	kyr	ni	win	nwy	dzi	chhwyr	len	tshon	my	be	chyr	ne	ka	chi	ghu	lhwy	va	na	sin	lo	lhy	li	shon	khe	lyr	ty	ty	mer	ty	thy	de	ge	my	ne	gu	gu	o	nor	hu	ngo	ngo	lhew	zu	twy	phy	li	tshan	zi	ryr	kwy	du	gu	la	me	lu	ji	tsu	tse	rir	ghu	khar	jwo	lwu	len	e	e	le	kur	gwi	la	dze	pin	li	khon	khy	lu	la	ngwu	lo	ngwy	phi	a	chyr	gy	pa	ho	ghi	dzi	hwe	dir	khe	tsin	lew	thew	be	lhwe	ne	swan	?	rar	ghyr	lhy	hu	ngwyr	dy	so	chhan	mer	so	khy	si	tshon	dzyr	so	je	kwy	my	vy	on	dza	nwi	le	dzen	na	mer	?	to	thy	ew	gu	zu	phe	ghu	shar	hwa	rir	dzu	mi	py	zhiw	li	ni	vi	phan	me	zhiw	na	u	pen	lew	rer	?	gi	?	ghyr	ta	lwyr	swy	vi	to	rer	no	kon	ke	chho	bi	pha	lhy	nga	lu	lu	chon	chhwen	vo	ly	den	ge	lhu	mo	tsi	zhy	ke	tse	dy	na	pha	zir	gy	li	rer	bo	pe	pho	tho	ghyr	di	e	khe	swy	lew	kha	thu	sar	ni	lwu	ze	ngir	thon	jy	dzu	tsorn	thy	mi";
    case 378:
      return "j?	phu	en	la	ew	lhy	shen	chon	bir	ni	kyr	ghwy	nwy	hwa	ngewr	jon	pe	cha	rir	sa	new	bo	pa	dzu	ba	lhe	kar	ryr	dzi	shin	lhe	j?	lhy	de	li	gu	dzo	tswy	by	kwy	ror	pa	ky	ghu	rur	zhe	ka	chyr	la	nu	ti	ti	lon	kwy	to	lhy	ghy	ghy	le	vi	jwe	par	he	twar	kwyr	bi	mer	?	do	lhor	gwi	vin	bu	si	tsor	my	lhu	vy	tew	tshi	gu	ku	kwar	ew	mi	dza	dzu	dzen	no	phu	du	no	tsir	pen	bi	che	ba	ve	shwa	shu	bi	bo	ko	mi	tsy	van	lho	my	shi	chon	ke	swe	kwa	nwi	vi	jwi	new	by	chhwen	i	khar	i	?	chwo	la	chor	zi	si	khu	gi	ko	thu	thu	cho	swy	bu	my	zwi	bi	khy	kwyr	my	ni	si	ke	khwar	ku	tsha	lon	bi	lon	dzwyr	shi	mur	du	jwon	nor	ghwe	u	ghu	ghu	gwo	dza	phon	chi	chi	pa	shu	me	pen	shwu	li	kon	dy	mi	gi	gi	by	ghiw	vi	dew	che	pir	dy	rar	dzo	ghi	mar	ten	bur	ku	la	nor	wi	ta	phon	dzwy	new	?	shu	se	be	by	chhon	ni	shi	my	thwi	su	nu	ba	shor	i	tho	win	gwyr	?	ly	khwi	li	ew	?	dzi	phon	gwyr	ny	by	pa	nu	jy	ghew	nwy	dwewr	jyr	?	hon	cha	lhu	dan	lhi	par	khan	khe	kir	ma	kir	de	de	i	ghwy	tshwin	je	ly	khe	ly	kwi";
    case 379:
      return "lwu	den	var	si	tswa	ma	phi	la	vi	si	ghwy	ghwe	zin	gu	shon	len	sy	chy	da	tshwu	lha	mer	vi	vi	lo	chhu	ny	rir	ko	rir	be	zir	ba	bin	gwy	py	shu	de	hew	vy	py	ki	lho	dyr	de	ja	dyr	kwy	ji	zhu	da	pe	len	jwon	kwa	norn	na	len	rar	kor	yr	?	lu	nir	len	bur	so	hon	ten	jy	ta	ge	bi	chy	e	chy	don	je	shi	ge	lu	shu	khy	ghe	le	le	khy	py	tsa	?	sy	swen	ja	thwo	bi	le	khan	tswyr	chhwew	thwo	pu	par	chhwew	dy	swi	vi	si	pi	pi	dy	zhon	on	tsha	ga	thu	thu	on	rer	go	nir	pe	bar	pyr	le	swew	di	bu	zwe	bu	zwe	pho	tswi	phon	rer	li	dir	na	li	pho	kew	i	dzi	jyr	ge	thu	thu	my	ly	swew	my	shwi	by	shwi	shwi	bi	chon	?	lhon	shwya	tshwi	li	by	lhon	bu	thu	my	chi	lhi	khi	li	su	chhy	ly	li	ni	shwa	si	sa	ge	gur	ma	ghu	pwyr	zwy	py	so	tsy	bu	pe	rer	nir	kwy	shew	shew	ven	rur	ka	swu	my	le	vi	ly	khan	be	tshi	khan	twy	by	ghor	tsho	tsha	dzo	le	le	khwu	le	lo	gwy	gu	kwy	lhe	lhe	be	ngwu	khwu	le	gwy	gu	ky	lhe	len	khy	rur	twu	tu	lo	ver	ve	thwu	te	thi	ghwy	lu	nwy	khu	chy	ma	kwen	pan	lu	dwar	ja	ja	mar	lu	ver";
    case 380:
      return "thwu	jon	hwo	tshy	gwe	ge	lha	lhon	jwa	lhon	tsar	tsar	tsar	jew	u	me	me	tyr	bon	lo	ew	?	sho	gha	u	khwi	ly	dze	myr	pi	na	wi	shi	ka	ga	ze	la	khwa	lwo	lhor	ew	wo	lhew	to	to	sha	vyr	lhy	kir	gu	?	lhy	gu	gu	?	zwyr	khwy	tson	dzwy	lhi	o	dzwy	ni	wi	o	thy	si	thy	thy	lhi	ngwi	li	li	lhe	thy	thy	thu	thu	cha	pu	tho	chew	ge	jy	han	rur	zhwu	che	ghyr	kur	dzu	my	lu	jwi	lan	?	je	zhwu	na	vi	che	lhi	ky	me	lu	nwe	i	su	py	shew	ten	dew	lan	tsha	du	rer	vi	li	du	ky	lu	zewr	me	na	khwa	dzy	dew	ghwy	lo	cha	ngur	len	chhon	chhwen	ghyr	vy	ghew	jo	thy	lu	ma	lor	ver	na	be	dew	en	bo	ngur	tsi	tshew	syr	rur	jwi	kwe	kwe	ky	ky	rar	py	nga	hin	lu	e	thy	tse	vi	me	zir	khwa	jan	by	ka	vy	zher	tswe	kwe	chhon	lwu	jwyr	lu	li	chew	ngwu	ty	lu	shu	tha	tswy	er	swin	me	me	me	rur	bi	kyr	vi	lho	dzu	rar	the	chon	ge	te	so	si	then	rar	bi	ngwu	shar	jwa	pe	ngwu	?	ngwi	ka	ka	ka	lhi	o	lha	ven	bi	shwi	je	mer	lhwy	ju	ka	mi	ja	o	zir	lhyr	dwu	er	u	u	?	tha	lhen	shy	chhy	dzwy	chhi	chhu	tha	chhu	tha	cha	gew	lon	chha	ka";
    case 381:
      return "so	ka	phon	phon	yr	ki	jwy	lwe	don	phe	lhi	kwan	zon	ton	ton	tsa	ghar	khen	ka	rir	la	pa	ve	pe	ngwy	zew	pe	chwon	kwu	zew	rir	pa	ten	ga	bu	vyr	ew	mew	zha	vi	sy	sy	myr	ki	chu	swu	de	gwan	gwan	ror	jwe	lher	rer	lu	?	la	tswa	no	ma	me	khew	lo	ve	ku	von	khu	ly	vi	lu	lwu	shen	tshi	rir	don	mu	jon	wer	lu	shen	bu	ne	o	ki	lon	thar	by	tswin	ror	cha	bo	bu	lu	lwyr	lon	shon	tshwan	chho	che	u	chew	se	thu	to	de	shy	lon	jwe	ge	ve	ko	di	chy	ti	kir	ror	no	dza	tsu	he	she	he	my	va	sha	ghy	lu	ba	bi	lu	mi	tsi	chi	my	chu	ghwa	di	di	zyr	ne	tsir	?	bi	jwy	lu	mi	chwo	?	bi	ba	an	cha	cho	cho	jwy	ne	swy	jy	lu	ngwu	bu	dzu	hu	ner	mi	lu	kew	ka	jwi	dar	thi	to	lew	?	ghu	ga	sha	ne	cho	ta	kho	ha	shi	shy	shy	zo	shi	hu	shwy	shy	shy	e	lhon	tshwew	dza	shi	je	zho	shy	phi	phi	ty	she	ta	?	ti	je	kar	bu	hwi	phi	?	twe	twu	?	tshwew	two	ke	lwi	li	ke	di	me	li	ghan	chwe	ker	chon	jwu	du	du	by	du	en	en	du	ny	chhwor	kin	von	kir	t?	jen	gin	du	dwyr	ty	by	lhi	ew	dzur	ma	te	ni	?	le	ma";
    case 382:
      return "u	lwo	shwe	vi	ni	chhwin	khon	de	di	jen	lu	tsewr	vo	tsu	kwy	lwi	yr	jyr	su	dwyr	yr	khwy	ga	dzyr	ha	tshyr	ga	khwy	khwy	ghon	ne	ga	hwa	dzen	twa	ty	tin	tu	jwu	?	ngwyr	le	ar	le	lhen	vy	vy	jwu	ton	no	zur	lan	nwy	shon	lhwe	lhwe	thu	sy	swy	byr	lhi	chon	di	u	chen	mar	gon	swo	sy	khew	ki	swy	o	gon	ku	hwin	sy	morn	twan	don	twu	chen	?	chen	lhwe	don	lu	go	don	tser	ner	che	jwy	ne	my	my	rer	kir	do	ngwu	she	rer	my	my	en	ki	le	te	se	be	dy	ror	chy	hen	ba	je	my	lan	du	ngorn	lhon	phe	ghan	dew	khwa	che	phe	de	lin	hen	ve	ror	ma	sa	lha	de	the	chhi	gi	chhi	rewr	jwy	chhy	en	lhon	ba	?	twi	tsha	ki	tsa	ja	ew	zur	swa	?	dzu	ton	tu	ghor	tu	ja	po	shi	py	be	rur	phon	nir	sha	rur	by	dzwy	jon	vi	ghu	lon	shwy	li	va	tho	so	ew	zur	zwy	hew	si	ha	pa	rar	var	pa	bi	de	de	kwa	kwin	lan	sha	sha	pu	lu	do	lhew	tshy	bu	lew	ka	bu	rur	jwan	on	ju	sha	rir	shu	tsha	jon	no	kew	phe	zin	gu	hin	i	lho	tshew	khwa	shwy	?	zin	she	rir	zin	new	vor	zhyr	a	le	zur	tshew	tsewr	tswy	pen	tho	ku	ho	thu	gha	bu	va	cha	shen	ba	vu	swy";
    case 383:
      return "gwi	vu	ba	shen	chir	nwy	shon	mi	na	swe	sew	dzwy	ka	sa	my	po	kwan	lhi	khu	zy	chho	lo	lo	den	phon	ghu	on	chir	ghi	lo	kon	shwu	khwy	pe	zyr	ghyr	von	ka	dzu	kew	ngwi	gha	di	su	ban	dzu	dzu	ta	li	dzew	bu	var	le	hon	ngur	gha	lwi	jwo	dzu	ly	khu	sew	nin	ne	lhy	ghy	ghew	bu	ly	chy	lwu	chha	li	ti	me	dzon	en	dwy	dwy	di	dzy	de	phon	rewr	by	kon	tshi	ly	gy	rewr	kew	pa	vi	kwa	then	ghwe	lu	ver	kew	lon	chhe	gur	hon	khwa	ta	ti	ghwe	nwe	tshi	khew	na	phen	bu	dan	ge	dzen	dan	phy	?u	ar	ly	shi	kur	kon	lwi	ku	sar	dzu	dzu	ke	ku	khar	ly	rar	jew	bi	mi	sew	ve	ti	ver	gwi	kwi	vir	lhwi	mo	no	ly	bi	rir	gor	ha	ve	lew	ne	nu	chwew	zhew	ny	va	rur	born	so	dzi	ghu	sa	cho	na	myr	hwan	na	se	ghew	ne	zy	bo	?	ne	tshy	?	bu	khu	hu	ji	bi	tshwu	be	tsu	bo	bo	rir	rir	tsir	phy	ke	dy	khu	y	she	kewr	khe	ghu	lon	bo	che	sha	lew	tshwu	chwew	hwyr	khwe	lhy	ngwi	wu	nga	me	tshy	khu	ha	ban	chhi	dzi	di	mu	chwew	vin	zur	mer	jwon	vy	ma	tsy	kwen	che	sa	kwy	kwy	my	py	di	ke	me	sho	dzen	born	gha	le	je	vi	on	nu	ku	jwon	ma	vi	de";
    case 384:
      return "dwyr	tho	khu	gu	gu	gu	ne	zhiw	phu	zhiw	ly	ge	tsir	na	mur	pu	zhiw	pu	jan	tse	phu	tsir	ge	tshwu	phe	bo	chho	ly	tshwu	wy	zer	o	kwi	dy	tha	len	dy	lu	me	me	?	gwar	rar	zy	gha	kwe	lhy	ma	tsha	?	kha	kha	zwan	ku	la	ryr	zwan	kha	kha	ghew	ni	tshi	tshon	no	kir	dze	a	a	my	phu	khan	y	shy	ngwo	lhi	?	lwy	lwy	thy	by	bu	bo	ror	bu	rer	bu	by	za	kwy	jwa	kwy	zy	dzu	ne	ghwy	do	a	za	thew	ghen	chhew	te	te	chhe	bu	korn	zy	ne	te	ghwy	zy	dzi	lwi	ka	za	dew	ghwy	tse	dzy	dzar	thy	dzar	lhen	shwi	shwi	shwi	ngwo	kwi	se	shew	nwy	li	on	ew	tsy	pen	lo	di	?	zi	ngwy	ghy	la	be	be	tsha	shi	dan	lo	ta	tsy	pyr	shon	pa	lo	tshi	zar	dzen	le	dew	lon	tswo	tsha	li	kha	shon	han	kha	be	shi	dze	vy	o	lwe	nwo	bo	sho	bo	su	zha	me	?	vi	khin	ken	ne	chi	lew	da	ne	ka	vy	zewr	len	vy	zewr	dzwy	vi	vi	rer	lin	ngwy	y	dzu	ti	no	pa	pa	tshe	mi	dzew	na	dy	da	zar	dy	ke	ly	dzwy	rar	rar	vi	ly	wan	du	vi	lew	vi	vo	du	ly	go	ghyr	chhwo	jwa	kwy	o	kho	ly	go	dzwew	dzwew	ve	kew	le	ryr	swo	nu	le	vy	my	in	la	o	lhy	la";
    case 385:
      return "chu	ky	gi	li	zi	lhi	pho	mi	o	len	li	ghy	te	ba	gi	ju	?	ba	pa	pen	pen	sy	du	dzwy	ghon	che	du	lwa	no	shwa	u	tsha	chha	se	a	khu	phy	se	ten	a	tsu	tsu	rer	tsu	len	tsu	khy	lhwe	chwa	then	ly	ly	tshi	o	bwe	ma	ner	twin	ba	lwa	khe	nga	norn	te	ta	rir	la	nga	sa	du	swe	ti	?	te	le	ngwir	bu	ze	len	tsur	phu	bon	la	zorn	chwi	zon	by	zi	ner	rar	den	ku	di	lwu	ner	tshi	twu	se	tshu	da	rar	tsur	?	kwi	nga	che	ta	chu	thy	ta	tsorn	dzy	ghu	twa	tshi	tshi	lwa	lwa	tewr	ner	li	ner	den	ghan	twon	?	o	bu	ver	lwen	le	by	ny	ka	le	le	lu	?	ghon	wo	tshen	ka	rir	ly	?	gi	ghu	lha	bar	ga	tshy	jy	tshy	ge	ge	na	tshy	rer	khi	zewr	khe	tshe	ta	ka	shon	?	dze	tshe	ti	mi	ta	ten	she	li	chi	dzi	kwe	kwe	tshwu	bi	so	ni	su	tar	phi	myr	bi	tshew	kwe	ge	dzi	she	chho	she	gu	wu	lwu	rer	tsor	bu	ta	li	le	she	dzwi	wu	na	phe	shon	ghu	vir	vor	dza	dzew	lu	lu	len	van	mi	pen	bi	bi	bi	khy	bar	thu	thu	lo	ge	pho	kwen	on	shwi	ni	bo	ny	tswar	swi	da	ni	chhin	pa	vi	ma	vi	chhy	vi	khwu	chu	shy	jo	mu	ge	no	ji	ni";
    case 386:
      return "var	shy	lu	rar	chy	no	ghor	rar	mi	tshwu	vi	phe	vo	no	to	rar	ar	myr	dze	rar	bi	shwo	vi	kan	shwy	de	gy	thwo	thwo	shwo	me	ly	ke	khon	len	khi	har	sa	lhu	de	nur	lew	ta	u	de	u	jen	by	jen	me	by	mo	ga	ni	ryr	gi	ror	on	ly	vyr	ma	swen	du	?	tser	mi	dzen	dzu	lwu	dza	tsha	dzew	dzew	ba	ba	ar	zyr	bi	dwa	tsho	on	my	mo	ba	dwa	len	pwyr	on	zyr	the	dwa	dwan	tsho	na	na	pu	tshi	pu	dwe	pu	vir	ja	ja	ja	dzwy	lew	nwo	gi	rar	hon	phe	tsir	nga	shew	gew	lhi	dzi	rer	tsyr	kwyr	dyr	tsu	tsyr	lhi	tho	dzi	ve	tsu	zhy	khew	ni	se	non	po	bo	shon	norn	ke	sew	po	jew	po	phar	ke	ke	no	kon	la	j?n	j?	pa	kewr	pen	my	vi	dzo	khi	ir	lu	ngwo	ze	lu	to	so	thu	j?	thu	jew	thew	thu	shy	pha	sa	tswyr	tar	twi	pha	pha	pha	bo	thu	thu	ny	nu	ba	ka	nwy	ny	thwe	thin	ka	ba	gur	jwi	phu	chhwi	phu	san	hwa	hwi	no	jon	jon	dwu	chy	u	kwan	ne	gha	kwa	gy	gy	le	ho	khe	dzu	ko	rir	dzu	ben	rar	rewr	zar	rewr	my	phi	tshy	my	jan	dew	zha	lo	dzwy	do	tyr	cha	tshy	chha	ar	en	bo	tshy	lu	gwi	en	bo	gwi	?	bo	gwi	shon	zhu	kur	gha	shon	ne";
    case 387:
      return "er	ghorn	u	rir	ghon	ze	ka	no	u	kwo	gew	lhi	shen	nga	shi	khur	khi	so	kon	khon	rir	jon	zhwyr	kewr	ghon	dwu	ly	lwi	pi	pu	tsy	pe	phen	lwi	zu	zu	dy	be	zur	ti	la	chhwi	yr	rar	vy	chwo	kha	chhen	phy	dzi	zhew	vi	hwen	shi	tshi	lu	to	lhy	phi	phi	ly	thy	bar	phi	la	chyr	mo	char	ki	gwar	la	gwar	zir	kha	tew	rar	phi	phi	o	tsi	rer	len	dzwe	khwy	chi	chu	war	gu	ben	gu	pu	chu	py	o	o	tsy	dewr	e	e	chon	bi	dewr	e	ma	hi	han	hu	khwi	ha	swi	har	swi	chha	chha	chha	ge	li	vi	ghwyr	te	phi	vi	vi	la	vi	vi	gi	?	shy	phi	?	vi	vir	?	jwy	pon	jy	lho	dzi	jy	chhwew	chhwew	swu	chhew	che	zha	chhwew	lu	khew	khew	dzew	lhy	li	khew	ve	shi	ta	si	na	sha	si	no	ta	khwy	ty	to	vyr	va	lhi	swe	tshe	ki	kwi	nwy	pi	kar	do	chwe	lhu	vi	ka	ze	kwy	nwy	ta	du	di	shy	thy	khew	khen	ky	de	swe	kwe	ky	ti	?	so	rir	va	chhwo	kur	sy	ka	gha	dzu	ty	ghwi	phu	phi	se	phyr	vir	ten	chi	rur	sha	ti	be	tew	phon	po	a	tso	khe	kwen	lwi	lyr	du	ten	a	ly	hwen	ne	ha	kar	chy	ne	shi	vy	sew	tser	sha	ghor	?a	twew	di	shy	tsy	tar	rur	chhew	swi	tse	ka";
    case 388:
      return "phy	lu	nwy	?	lhwa	gi	la	la	kwa	va	tshu	vu	la	chhwi	pi	ti	ma	rer	er	ta	tshwew	chew	lu	ty	ku	dzwy	shwy	ly	pir	shen	ngwi	na	ngwo	chy	gi	phy	tshwe	vu	vu	pi	la	phy	chy	khi	bo	go	gar	rir	kwy	dew	lho	?	ngyr	phy	jwo	kar	zyr	phi	lo	rer	chir	chwe	ka	ky	ty	ror	lho	?	du	ky	phy	i	ka	khu	khu	tewr	je	lhi	te	ta	rer	rewr	ky	chhar	cha	rar	la	ngyr	shi	ma	?	khwy	se	me	zon	my	vor	vor	khwy	se	e	chhu	sew	sew	wu	lo	khwy	kan	dwewr	zi	dwu	u	dwewr	shwe	chon	lhorn	lhorn	thy	tse	?a	rorn	zi	di	di	ror	zi	du	lon	du	du	ha	lu	chho	zhy	twe	tshi	ghu	lo	zhy	tshe	bo	twi	lhor	ga	lo	jwe	lo	par	twe	to	lo	pan	pan	twi	be	ba	the	chhew	zhu	zhon	?	me	me	da	li	phy	thu	dwu	phe	dzu	du	zew	ne	zew	zew	zew	zew	ta	tyr	to	ta	to	hwy	wy	vy	lhu	nar	lwe	nar	khwar	shwy	lwi	lwi	ly	ly	ly	rur	khy	ly	ly	ju	lhew	zyr	lon	lhew	si	swi	rur	dzwo	ghwan	chyr	vy	my	rur	kon	dzy	gu	rur	rur	dzwi	dzi	chy	ti	je	gha	rur	dze	ba	va	u	le	?	ror	mu	be	che	gu	di	rur	khon	ghyr	ngwy	ngwyr	ngorn	?	ghyr	gu	kwyr	ghyr	va	ngwyr	gha	py	lo	an	vi";
    case 389:
      return "vu	bi	jy	tswu	lo	zur	?	lha	dwyr	dwyr	py	thwu	je	u	dan	bi	nga	ne	ne	chwi	nu	ne	ne	nin	hun	ne	ne	jy	chhin	ne	hon	dzy	ne	ne	khwa	tha	ku	ku	rir	gu	ne	dwyr	dzen	lu	bi	dzen	var	khu	o	pa	me	lwew	du	kwy	khwu	se	o	by	khi	kho	non	non	lhon	lhorn	dzi	zyr	je	je	tan	tan	tan	ghew	chy	vi	khy	jar	twu	chhew	ne	gewr	ly	u	ku	no	ly	so	ve	ku	tsy	tsy	ne	ke	ga	be	dzi	zewr	chor	zewr	by	va	u	la	?	da	si	si	ghew	ngewr	bi	bi	hy	hi	phu	shu	ku	ku	dzen	shew	phu	porn	ta	chhew	gu	gu	gu	gu	ner	gha	si	tsha	ngewr	va	khy	vi	len	len	len	khe	my	ngy	my	gi	ve	my	my	my	my	li	shwa	tso	my	jy	jy	no	no	shon	kwi	?	kyr	bi	kyr	?	gi	kyr	khe	tswar	ta	gha	lon	ko	kyr	by	nu	kha	khu	ryr	tshwa	zhu	?	gi	tswan	khwu	ngyr	ma	tshu	lhy	nu	chhwa	van	?	ngur	gwi	nwy	ja	tshon	vi	dzon	tshi	tshu	chhwa	len	ran	ryr	ge	zir	lhu	tswu	dzwy	de	v?	bu	gwi	da	zher	khe	po	dar	bu	de	bu	ngon	lu	vor	ne	gha	kur	gha	du	tsyr	jy	?	zwi	my	chu	lwu	la	ju	ju	ju	lor	dew	dew	no	chwen	kir	rar	rar	ny	vi	vi	vi	khon	khen	zo	lhe	lhe";
    case 390:
      return "shi	sho	cho	gi	shwi	ke	la	shwi	chir	ke	shwi	me	shu	di	tswyr	wu	she	vir	vir	khwe	ja	vur	li	li	sa	je	dze	kew	she	dze	ka	za	po	za	gi	y	jy	y	chhwo	ka	zy	ky	ton	bi	jy	vi	mo	gha	ke	shar	so	gi	gwon	son	vo	vir	gi	ky	ky	yr	lhwi	me	dwar	mur	tar	se	bi	y	ghwen	ku	vy	ryr	myr	ken	lwi	rir	ky	lhu	lhi	tso	va	lho	pi	pi	tew	ky	ky	zi	ky	?	zwew	dzew	ny	lhy	zhyr	lho	kon	zwi	ba	shi	my	lhi	se	gwi	son	chhi	sy	sho	ton	lew	lew	be	lew	be	jo	ve	kor	dzu	rir	lu	lo	e	e	lhew	mu	chhew	hon	le	sa	vi	lhan	du	ky	lhan	tu	vo	tu	yr	yr	don	rer	khy	jon	swo	son	son	son	va	me	lon	lwo	lon	lhi	py	py	lhi	lhwe	lu	?	lhi	ly	ly	je	ge	thwyr	lu	ba	?	on	khe	dzi	ly	ghin	vo	ko	ly	ly	ly	ly	shan	ly	ko	ly	ly	dzi	swy	khen	di	lwy	lwy	dy	me	be	be	be	lu	?	dzy	swen	gu	ka	tswy	ka	kha	rewr	nwu	new	na	twu	chhew	ngewr	be	nwy	shwy	zhyr	zhyr	shy	li	ne	ten	zi	tsu	mo	ve	?	ji	mer	sha	rur	rur	se	len	kwa	ky	bi	lew	vir	se	khe	gu	khe	gan	gu	la	gu	to	chyr	ryr	jwu	rewr	be	di	?	lu	lu	ge";
    case 391:
      return "myr	tsa	dzen	dzi	ngwir	li	on	chho	jo	phi	phar	phan	phon	ar	le	nar	dza	pa	shu	chhi	ngewr	kir	du	ma	rir	chu	ko	ghwe	be	tser	tse	by	shar	shar	kwar	dzyr	ha	kwar	lhwyr	kwu	chhwe	tho	er	ke	ke	ngur	ngur	i	ge	thy	shu	tha	ma	shu	tha	bi	tshy	dzon	ryr	pha	pho	khu	ke	?	phi	thy	jar	tsi	vir	chhy	la	shwi	jar	?	mir	dzwy	len	chu	vir	ju	ghe	tswi	shwu	shwu	shwu	ne	ew	ew	ew	dzon	kwyr	chhon	kur	?	wyr	shwy	thy	lor	chhy	nen	non	tshe	jy	bo	zo	?	jon	?	le	zyr	lwu	bo	gin	kho	dwu	my	ga	e	the	la	kha	vir	vu	kwo	kwo	kwo	li	li	na	li	dzy	jon	ly	la	bi	bi	tan	le	khy	tsen	zhyr	tewr	ka	lu	shu	kin	shy	ve	phar	van	sew	swy	ew	ge	be	swy	thwan	dzwy	chha	dzwy	pho	dzon	dzon	dzon	lon	lon	lon	lhew	zhe	lu	te	gewr	ghwin	twar	gi	ji	li	vi	thwe	wa	va	dza	phu	khe	pen	dy	dy	dy	si	zy	by	ve	le	bi	ngwu	no	ghy	chhe	chhe	lo	shy	chhew	dziw	zar	tsar	zhi	tshwu	bi	hyr	han	hwi	tsen	lhi	lhen	ki	korn	ghiw	ne	dy	zhyr	dzon	o	byr	khe	dzu	lhy	vi	du	swu	by	by	norn	norn	ten	shon	gha	vi	?	?	?	?	?	?	?	?	?	?	?";
    case 392:
      return "1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	21	22	23	24	25	26	27	28	29	30	31	32	33	34	35	36	37	38	39	40	41	42	43	44	45	46	47	48	49	50	51	52	53	54	55	56	57	58	59	60	61	62	63	64	65	66	67	68	69	70	71	72	73	74	75	76	77	78	79	80	81	82	83	84	85	86	87	88	89	90	91	92	93	94	95	96	97	98	99	100	101	102	103	104	105	106	107	108	109	110	111	112	113	114	115	116	117	118	119	120	121	122	123	124	125	126	127	128	129	130	131	132	133	134	135	136	137	138	139	140	141	142	143	144	145	146	147	148	149	150	151	152	153	154	155	156	157	158	159	160	161	162	163	164	165	166	167	168	169	170	171	172	173	174	175	176	177	178	179	180	181	182	183	184	185	186	187	188	189	190	191	192	193	194	195	196	197	198	199	200	201	202	203	204	205	206	207	208	209	210	211	212	213	214	215	216	217	218	219	220	221	222	223	224	225	226	227	228	229	230	231	232	233	234	235	236	237	238	239	240	241	242	243	244	245	246	247	248	249	250	251	252	253	254	255	256";
    case 393:
      return "257	258	259	260	261	262	263	264	265	266	267	268	269	270	271	272	273	274	275	276	277	278	279	280	281	282	283	284	285	286	287	288	289	290	291	292	293	294	295	296	297	298	299	300	301	302	303	304	305	306	307	308	309	310	311	312	313	314	315	316	317	318	319	320	321	322	323	324	325	326	327	328	329	330	331	332	333	334	335	336	337	338	339	340	341	342	343	344	345	346	347	348	349	350	351	352	353	354	355	356	357	358	359	360	361	362	363	364	365	366	367	368	369	370	371	372	373	374	375	376	377	378	379	380	381	382	383	384	385	386	387	388	389	390	391	392	393	394	395	396	397	398	399	400	401	402	403	404	405	406	407	408	409	410	411	412	413	414	415	416	417	418	419	420	421	422	423	424	425	426	427	428	429	430	431	432	433	434	435	436	437	438	439	440	441	442	443	444	445	446	447	448	449	450	451	452	453	454	455	456	457	458	459	460	461	462	463	464	465	466	467	468	469	470	471	472	473	474	475	476	477	478	479	480	481	482	483	484	485	486	487	488	489	490	491	492	493	494	495	496	497	498	499	500	501	502	503	504	505	506	507	508	509	510	511	512";
    case 394:
      return "513	514	515	516	517	518	519	520	521	522	523	524	525	526	527	528	529	530	531	532	533	534	535	536	537	538	539	540	541	542	543	544	545	546	547	548	549	550	551	552	553	554	555	556	557	558	559	560	561	562	563	564	565	566	567	568	569	570	571	572	573	574	575	576	577	578	579	580	581	582	583	584	585	586	587	588	589	590	591	592	593	594	595	596	597	598	599	600	601	602	603	604	605	606	607	608	609	610	611	612	613	614	615	616	617	618	619	620	621	622	623	624	625	626	627	628	629	630	631	632	633	634	635	636	637	638	639	640	641	642	643	644	645	646	647	648	649	650	651	652	653	654	655	656	657	658	659	660	661	662	663	664	665	666	667	668	669	670	671	672	673	674	675	676	677	678	679	680	681	682	683	684	685	686	687	688	689	690	691	692	693	694	695	696	697	698	699	700	701	702	703	704	705	706	707	708	709	710	711	712	713	714	715	716	717	718	719	720	721	722	723	724	725	726	727	728	729	730	731	732	733	734	735	736	737	738	739	740	741	742	743	744	745	746	747	748	749	750	751	752	753	754	755	756	757	758	759	760	761	762	763	764	765	766	767	768";
    case 395:
      return "378	1	2	383	381	382	3	392	4	5	6	395	7	8	9	10	11	12	13	14	459	15	454	16	17	390	18	19	20	21	22	455	23	24	25	26	27	28	29	30	31	32	33	34	35	36	37	38	39	452	453	396	384	385	40	41	42	43	?	450	45	46	47	48	49	50	51	52	389	53	54	55	388	56	57	58	59	60	61	62	63	64	391	386	66	67	68	69	70	71	72	73	74	75	76	77	78	79	80	387	?	?	379	81	82	83	84	393	85	86	394	87	88	89	90	91	92	93	105	106	107	108	109	110	111	112	113	114	115	116	65	117	118	98	94	99	100	101	102	103	397	398	399	104	95	96	97	44	400	401	403	279	280	281	282	283	284	285	286	287	288	289	290	291	292	293	294	295	296	402	297	298	299	300	301	302	303	304	305	306	307	308	309	310	404	405	406	407	408	311	312	313	314	315	316	317	318	?	319	411	412	409	410	413	320	321	322	323	324	325	416	417	419	420	164	165	451	166	167	168	169	170	171	172	173	175	174	176	177	178	430	?	179	180	427	?	428	429	?	432	181	182	183	431	184	185	186	?	187	188	189	190	457	191	192	193";
    case 396:
      return "194	195	196	414	197	198	199	200	201	415	202	203	204	205	206	207	208	209	210	220	221	222	223	224	225	226	418	227	228	229	230	231	232	233	234	235	?	236	237	238	239	241	242	245	250	251	253	240	422	356	243	248	254	358	359	244	421	246	247	249	252	255	423	256	257	258	259	260	261	425	262	263	?	426	264	265	266	424	267	268	269	270	326	327	328	329	330	331	332	333	334	335	458	336	337	438	439	440	338	437	339	340	341	436	342	343	344	345	346	347	348	349	350	351	352	353	354	355	357	360	361	362	433	434	435	363	364	365	366	367	368	369	370	371	372	373	374	375	376	377	119	?	120	121	122	123	124	125	126	127	128	129	130	?	131	132	133	134	135	442	443	136	137	138	139	444	140	141	441	142	143	144	145	146	147	148	149	150	151	152	153	154	155	156	157	158	159	160	161	162	163	445	211	212	456	213	214	446	216	217	218	219	215	449	447	274	448	275	276	277	278	271	272	273																																										_";
    case 397:
      return "ga	ta	ghu	bu	shi	le	kwe	mi	le";
    case 432:
      return "e	e	a	a	a	a	i	i	i	i	u	u	u	u	u	e	e	e	e	e	o	o	o	ka	ka	ka	ka	ka	ka	ka	ka	ka	ka	ka	ka	ki	ki	ki	ki	ki	ki	ki	ki	ku	ku	ku	ku	ku	ku	ku	ke	ke	ke	ke	ke	ke	ko	ko	ko	ko	sa	sa	sa	sa	sa	sa	sa	sa	shi	shi	shi	shi	shi	shi	su	su	su	su	su	su	su	su	se	se	se	se	se	so	so	so	so	so	so	so	ta	ta	ta	ta	chi	chi	chi	chi	chi	chi	chi	tsu	tsu	tsu	tsu	tsu	te	te	te	te	te	te	te	te	te	to	to	to	to	to	to	to	na	na	na	na	na	na	na	na	na	ni	ni	ni	ni	ni	ni	ni	ni	nu	nu	nu	ne	ne	ne	ne	ne	ne	ne	no	no	no	no	no	ha	ha	ha	ha	ha	ha	ha	ha	ha	ha	ha	hi	hi	hi	hi	hi	hi	hi	fu	fu	fu	he	he	he	he	he	he	he	ho	ho	ho	ho	ho	ho	ho	ho	ma	ma	ma	ma	ma	ma	ma	mi	mi	mi	mi	mi	mi	mi	mu	mu	mu	mu	me	me	me	mo	mo	mo	mo	mo	mo	ya	ya	ya	ya	ya	ya	yu	yu	yu	yu	yo	yo	yo	yo	yo	yo	ra	ra	ra	ra	ri	ri	ri	ri	ri	ri	ri	ru	ru	ru	ru	ru	ru	re	re";
    case 433:
      return "re	re	ro	ro	ro	ro	ro	ro	wa	wa	wa	wa	wa	i	i	i	i	i	e	e	e	e	o	o	o	o	o	o	o	n	n	wu	yi	ye	wu																ko																														wi	we	wo			ko															wi	we	wo	n									i	na	tsha	ie	poe	swe	phiu	u	cya	tie	njie	toe	tchye	fwe	liu	siu	thu	njyu	vai	kai	khau	kou	tciou	liang	ciang	tsheng	song	ma	fa	la	thoe	tsoe	fwe	tswe	ti	ci	fu	fu	fu	tcyu	tcyu	fai	hau	lou	liou	tciou	ciou	tchyn	fang	vang	sang	khang	theng	neng	piong	iong	va	khua	tchya	nie	lie	tcie	tchie	njie	njie	ie	ie	mwe	vwe	vwe	twe	tswe	swe	swe	tci	ci	i	liu	njiu	ciu	mu	yu	tchy	njy	y	pai	pai	lai	ai	hau	tou	liou	iou	tsew	tsew	suow	huow	huow	nguw	mang	thang	kang	liang	tciang	njiang	peng	seng	piong	tshiong	tcing	pa	la	sie	tcie	ie	poe	loe	tsoe	soe	koe	khuoe	ye	pwe	pwe	tchi	tsiu	fu	vu	khu	hu	pw	fw	sw	kw	hw	mai	thai	sai	sai	thau	lau	lau	nw	kou";
    case 434:
      return "ciou	lew	sew	thuow	uow	kuw	tcyn	yn	vang	tsang	sang	khang	tciang	iang	teng	neng	piong	miong	ciong	ciong	njing	ng	tsa	sa	kua	kua	cya	cie	phoe	foe	loe	tshoe	tshoe	oe	tchye	fwe	tswe	ni	tshi	tshi	si	fu	ang	tchyu	cyu	phw	fai	tsai	lou	tsou	piou	miou	tchiou	njiou	iou	nuow	kuow	huow	pang	ngu	tsiang	tsiang	ciang	iang	liong	tshiong	ciong	cing	la	cya	poe	thoe	noe	tshoe	kue	tsiou	kue	ye	pwe	vwe	thi	tsi	tsi	tci	tci	tshiu	pu	tsu	ku	tcyu	njyu	tchy	pw	hw	phai	mai	lai	sai	hai	mau	tshau	hau	kou	ou	kue	tshiou	siou	tciou	ciou	thuow	fang	vang	lang	tshang	khang	khang	liang	siang	ciang	ciang	neng	leng	nong	long	liong	tsiong	siong	tcing	tcing	cing	ing	ng	va	sa	lie	tshie	sie	ie	moe	loe	tchye	cye	pi	ti	tci	tsiu	pu	fu	thu	hu	tcy	cy	pw	khw	lai	sai	sau	tsou	ngou	tsiou	njiou	ciou	iou	yn	tang	lang	kang	hang	hang	siang	tciang	iang	meng	tsiong	siong	tchiong	pa	tshie	sie	tsoe	koe	tcye	tcye	pwe	swe	ti	i	tciu	ciu	tsu	tshu	ku	lw	mai	kau	thou	hou	pang	fang	tang	lang	meng	teng	tseng	cing	ing	tsa	tsie	cie	moe	li	tsi	tci	i	mu	lu	hu	cyu	hw	tau	siou	lew	tshew	yn	tong	ie	voe	tswe	i	tu	lu	lou	tsou	tsuow	mang	tciang	tchiang	tciong	tsie	moe	ku	cyu	pw	tsiang	tshai	nguow	nong	fu	ku	fang	tcye	fi";
    case 444:
      return "h	x	p	t	f	k	l	b	d	v	g	r	pn	ds	fn	km	rs	th	dh	dh	kk	j	hl	lh	rh	m	n	j	s	mn	nm	jm	sj	m	ng	zh	j	z	s	ms	ns	js	ss	mns	nms	jms	sjs	ch	jn	jns	st	str	sp	spr	ts	trs	w	wh	wr	sn	sm	krs	grs	sk	skr	a	ow	oa	o	aou	i	e	ie	i	ui	ee	eh	i	ee	i	ye	u	eu	xw	un	u	u	uh	u	ooh	ow	ou	wa	wo	wi	wei	wow	u	o	i	a	an	am	en	an	on	m						'	'	'	'	'	'	'	'	'	'	'	'	'				'	'	`	`	'	'	'	'	'								'	'	`	`	'	'	'	'	'	'			+	r	-	.";
    case 460:
      return "#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	|	-	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	0	1	2	3	4	5	6	7	8	9";
    case 461:
      return "#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#";
    case 462:
      return "#	#	#	#	#	#	#	#	#	#	#	#	#	-	-	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	-	#	#	^";
    case 463:
      return "																																																																																-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-";
    case 464:
      return "-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-";
    case 465:
      return "|	|	|	|	|	|	|:	:|	:	D.S.	D.C.	S	*	/	%	%%	^	^	'	//	{	[	#	#	#	#	#	#	#	#	G	8G	G8	C	F	8F	F8	N	N			-	##	bb	b	b	#	#	#	#	#	b	44	22	8va	8vb	15ma	15mb	-	-	-	-	-	-	-	-	-	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	.	#	#	#	#	#	#	#	#	#						/	//	///																							~	~								r	s	z	p	m	f	<	>	*	*	tr	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	HT	NT	T	*					Ped.	*	^	/	\\	*	*	*	#	#	#	#	#	#	#	#	#	#	#	-	-	-	-	-	-	*	*	*	*	*	*	*	*	*	C	F	b	#	#	#	#	#	#	#	#	#	#	#	C	&	#	#	#	#	#	#	#	#	b	#	b";
    case 466:
      return "1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	21	22	23	24	50	51	52	53	54	1	2	4	5	7	8	11	12	13	14	17	18	19	23	24	25	26	27	29	30	32	36	37	38	39	40	42	43	45	47	48	49	50	51	52	53	54	3	4	5	-																																																																																																																											0	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19													0	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19";
    case 467:
      return "Ren	TianRen	DiRen	RenTian	RenDi	RenRen	Zhong	Zhou	Xian	Xian	Shao	Li	Shang	Gan	Shu	Xian	Cha	Tong	Zeng	Rui	Da	Jiao	Ruan	Xi	Cong	Jin	Shi	Ge	Yi	Le	Zheng	Wu	Shi	Geng	Duan	Yi	Zhuang	Zhong	Mi	Qin	Lian	Qiang	Sui	Sheng	Ju	Fa	Ying	Ying	Yu	Zao	Da	Kuo	Wen	Li	Tao	Tang	Chang	Du	Yong	Kun	Jian	Jin	Shou	Xi	Ju	Ji	Shi	Yi	Shi	Chen	Nei	Qu	Hui	Meng	Qiong	Ge	Zhi	Jian	Cheng	Zhi	Shi	Ju	Xun	Jiang	Nan	Qin	Yang										1	2	3	4	5	6	7	8	9	1	2	3	4	5	6	7	8	9	1	2	3	4	5	1	5";
    case 468:
      return "A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g		i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	A		C	D			G			J	K			N	O	P	Q		S	T	U	V	W	X	Y	Z	a	b	c	d		f		h	i	j	k	l	m	n		p	q	r	s	t	u	v	w	x	y	z	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v";
    case 469:
      return "w	x	y	z	A	B		D	E	F	G			J	K	L	M	N	O	P	Q		S	T	U	V	W	X	Y		a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	A	B		D	E	F	G		I	J	K	L	M		O				S	T	U	V	W	X	Y		a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r";
    case 470:
      return "s	t	u	v	w	x	y	z	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	i	j			A	B	G	D	E	Z	E	Th	I	K	L	M	N	X	O	P	R	Th	S	T	Y	Ph	Ch	Ps	O	D	a	b	g	d	e	z	e	th	i	k	l	m	n	x	o	p	r	s	s	t	y	ph	ch	ps	o	d	e	th	k	ph	r	p	A	B	G	D	E	Z	E	Th	I	K	L	M	N	X	O	P	R	Th	S	T	Y	Ph	Ch	Ps	O	D	a	b	g	d";
    case 471:
      return "e	z	e	th	i	k	l	m	n	x	o	p	r	s	s	t	y	ph	ch	ps	o	d	e	th	k	ph	r	p	A	B	G	D	E	Z	E	Th	I	K	L	M	N	X	O	P	R	Th	S	T	Y	Ph	Ch	Ps	O	D	a	b	g	d	e	z	e	th	i	k	l	m	n	x	o	p	r	s	s	t	y	ph	ch	ps	o	d	e	th	k	ph	r	p	A	B	G	D	E	Z	E	Th	I	K	L	M	N	X	O	P	R	Th	S	T	Y	Ph	Ch	Ps	O	D	a	b	g	d	e	z	e	th	i	k	l	m	n	x	o	p	r	s	s	t	y	ph	ch	ps	o	d	e	th	k	ph	r	p	A	B	G	D	E	Z	E	Th	I	K	L	M	N	X	O	P	R	Th	S	T	Y	Ph	Ch	Ps	O	D	a	b	g	d	e	z	e	th	i	k	l	m	n	x	o	p	r	s	s	t	y	ph	ch	ps	o	d	e	th	k	ph	r	p	W	w			0	1	2	3	4	5	6	7	8	9	0	1	2	3	4	5	6	7	8	9	0	1	2	3	4	5	6	7	8	9	0	1	2	3	4	5	6	7	8	9	0	1	2	3	4	5	6	7	8	9";
    case 472:
      return "S100	S101	S102	S103	S104	S105	S106	S107	S108	S109	S10a	S10b	S10c	S10d	S10e	S10f	S110	S111	S112	S113	S114	S115	S116	S117	S118	S119	S11a	S11b	S11c	S11d	S11e	S11f	S120	S121	S122	S123	S124	S125	S126	S127	S128	S129	S12a	S12b	S12c	S12d	S12e	S12f	S130	S131	S132	S133	S134	S135	S136	S137	S138	S139	S13a	S13b	S13c	S13d	S13e	S13f	S140	S141	S142	S143	S144	S145	S146	S147	S148	S149	S14a	S14b	S14c	S14d	S14e	S14f	S150	S151	S152	S153	S154	S155	S156	S157	S158	S159	S15a	S15b	S15c	S15d	S15e	S15f	S160	S161	S162	S163	S164	S165	S166	S167	S168	S169	S16a	S16b	S16c	S16d	S16e	S16f	S170	S171	S172	S173	S174	S175	S176	S177	S178	S179	S17a	S17b	S17c	S17d	S17e	S17f	S180	S181	S182	S183	S184	S185	S186	S187	S188	S189	S18a	S18b	S18c	S18d	S18e	S18f	S190	S191	S192	S193	S194	S195	S196	S197	S198	S199	S19a	S19b	S19c	S19d	S19e	S19f	S1a0	S1a1	S1a2	S1a3	S1a4	S1a5	S1a6	S1a7	S1a8	S1a9	S1aa	S1ab	S1ac	S1ad	S1ae	S1af	S1b0	S1b1	S1b2	S1b3	S1b4	S1b5	S1b6	S1b7	S1b8	S1b9	S1ba	S1bb	S1bc	S1bd	S1be	S1bf	S1c0	S1c1	S1c2	S1c3	S1c4	S1c5	S1c6	S1c7	S1c8	S1c9	S1ca	S1cb	S1cc	S1cd	S1ce	S1cf	S1d0	S1d1	S1d2	S1d3	S1d4	S1d5	S1d6	S1d7	S1d8	S1d9	S1da	S1db	S1dc	S1dd	S1de	S1df	S1e0	S1e1	S1e2	S1e3	S1e4	S1e5	S1e6	S1e7	S1e8	S1e9	S1ea	S1eb	S1ec	S1ed	S1ee	S1ef	S1f0	S1f1	S1f2	S1f3	S1f4	S1f5	S1f6	S1f7	S1f8	S1f9	S1fa	S1fb	S1fc	S1fd	S1fe	S1ff";
    case 473:
      return "S200	S201	S202	S203	S204	S205	S206	S207	S208	S209	S20a	S20b	S20c	S20d	S20e	S20f	S210	S211	S212	S213	S214	S215	S216	S217	S218	S219	S21a	S21b	S21c	S21d	S21e	S21f	S220	S221	S222	S223	S224	S225	S226	S227	S228	S229	S22a	S22b	S22c	S22d	S22e	S22f	S230	S231	S232	S233	S234	S235	S236	S237	S238	S239	S23a	S23b	S23c	S23d	S23e	S23f	S240	S241	S242	S243	S244	S245	S246	S247	S248	S249	S24a	S24b	S24c	S24d	S24e	S24f	S250	S251	S252	S253	S254	S255	S256	S257	S258	S259	S25a	S25b	S25c	S25d	S25e	S25f	S260	S261	S262	S263	S264	S265	S266	S267	S268	S269	S26a	S26b	S26c	S26d	S26e	S26f	S270	S271	S272	S273	S274	S275	S276	S277	S278	S279	S27a	S27b	S27c	S27d	S27e	S27f	S280	S281	S282	S283	S284	S285	S286	S287	S288	S289	S28a	S28b	S28c	S28d	S28e	S28f	S290	S291	S292	S293	S294	S295	S296	S297	S298	S299	S29a	S29b	S29c	S29d	S29e	S29f	S2a0	S2a1	S2a2	S2a3	S2a4	S2a5	S2a6	S2a7	S2a8	S2a9	S2aa	S2ab	S2ac	S2ad	S2ae	S2af	S2b0	S2b1	S2b2	S2b3	S2b4	S2b5	S2b6	S2b7	S2b8	S2b9	S2ba	S2bb	S2bc	S2bd	S2be	S2bf	S2c0	S2c1	S2c2	S2c3	S2c4	S2c5	S2c6	S2c7	S2c8	S2c9	S2ca	S2cb	S2cc	S2cd	S2ce	S2cf	S2d0	S2d1	S2d2	S2d3	S2d4	S2d5	S2d6	S2d7	S2d8	S2d9	S2da	S2db	S2dc	S2dd	S2de	S2df	S2e0	S2e1	S2e2	S2e3	S2e4	S2e5	S2e6	S2e7	S2e8	S2e9	S2ea	S2eb	S2ec	S2ed	S2ee	S2ef	S2f0	S2f1	S2f2	S2f3	S2f4	S2f5	S2f6	S2f7	S2f8	S2f9	S2fa	S2fb	S2fc	S2fd	S2fe	S2ff";
    case 474:
      return "S300	S301	S302	S303	S304	S305	S306	S307	S308	S309	S30a	S30b	S30c	S30d	S30e	S30f	S310	S311	S312	S313	S314	S315	S316	S317	S318	S319	S31a	S31b	S31c	S31d	S31e	S31f	S320	S321	S322	S323	S324	S325	S326	S327	S328	S329	S32a	S32b	S32c	S32d	S32e	S32f	S330	S331	S332	S333	S334	S335	S336	S337	S338	S339	S33a	S33b	S33c	S33d	S33e	S33f	S340	S341	S342	S343	S344	S345	S346	S347	S348	S349	S34a	S34b	S34c	S34d	S34e	S34f	S350	S351	S352	S353	S354	S355	S356	S357	S358	S359	S35a	S35b	S35c	S35d	S35e	S35f	S360	S361	S362	S363	S364	S365	S366	S367	S368	S369	S36a	S36b	S36c	S36d	S36e	S36f	S370	S371	S372	S373	S374	S375	S376	S377	S378	S379	S37a	S37b	S37c	S37d	S37e	S37f	S380	S381	S382	S383	S384	S385	S386	S387	S388	S389	S38a	S38b																1	2	3	4	5		1	2	3	4	5	6	7	8	9	a	b	c	d	e	f";
    case 479:
      return "fng	g	g	k	l	lzh	y	ng	r	t	q	qc	qc	t	x	q	k	l	dzh	l	ng	r	r	tsh	zh	dzh	i	o	tsh	c	s							d	l	n	r	s	t";
    case 480:
      return "a	b	v	g	d	e	zh		z	i	j	i	g	k	l	m	n	o	p	r	s	t	u	f	h			sht	c	ch	sh	u	i	e		ju	e		jo	je	o	jo	th						a	b	v	g	d	e	zh	z	i	k	l	m	o	p	r	s	t	u	f	kh	ts	ch	sh	y	e	yu	dz	a	i	j	o	u	h	a	b	v	g	d	e	zh	z	i	k	l	o	p	s	u	f	kh	ts	ch	sh	'	y	g	i	dz	dzh	s	y	u																																		i";
    case 481:
      return "m	ts	nt	t	h	n	x	nk	c	l	s	z	nc	nts	k	d	ny	nr	v	ntx	tx	f	r	q	y	nq	p	xy	np	dl	npl	'	ml	pl	g	r	a	aa	i	u	o	oo	e	ee	w				b	m	j	v	s	g	d						-				0	1	2	3	4	5	6	7	8	9					$	@";
    case 482:
      return "																																																																																																																																																p	b	t	d	k	g	m	n	ng	s	ch	y	w	j	h	r	l	i	ih	iu	iuh	u	e	eh	eo	eoh	o	ae	aeh	a																			aa	a	b	c	d	g	y	ph	l	n	p	t	th	f	s	sh	j	z	w	v	k	o	au	r	m	kh	h	e	i	ng	u	lh	ts	tr	ong	aang	ang	ing	on	en	aan	ny	uen	x					0	1	2	3	4	5	6	7	8	9						Rs";
    case 484:
      return "																																																																																																																																																																																																																o	p	l	y	m	a	j	b	n	h	i	s	d	t	h	u	c	d	k	r	e	n	g	m	n	t	l						0	1	2	3	4	5	6	7	8	9";
    case 485:
      return "																																																																																																																																																																																																																o	m	n	r	o	y	a	d	b	h	l	w	i	t	p	t	d	n	u	k	d	j	n	r	e	s	h	c	n	g	m		'	0	1	2	3	4	5	6	7	8	9					.";
    case 487:
      return "																																																																																																																																																																																																																																hye	hyu	hyi	hya	hye	hy	hyo		hwe	hwi	hwe	hwi		mwi	mwe		k'wi	k'we	k'wi	bwi	bwe	kwi	kwe	kwi	gwi	gwe	gwi	fwi	fwe	pwi	pwe";
    case 488:
      return "ki	ka	ku	ke	ke	ko	ko	kua	wi	wa	wu	we	we	wo	wo	wui	wei	wvi	wva	wve	mi	ma	mu	me	mo	mua	mue	bi	ba	bu	be	be	bo	bo	i	a	u	e	e	o	o	ei	i	i	a	e	si	sa	su	se	se	so	so	sia	li	la	lu	le	le	lo	lo	lee	di	da	du	de	do	do	ti	ta	tu	te	te	to	to	ji	ja	ju	je	je	jo	jo	joo	yi	ya	yu	ye	ye	yo	yo	fi	fa	fu	fe	fe	fo	fo	fua	fa	ni	na	nu	ne	no	hi	ha	hu	he	he	ho	ho	hei	hou	hi	ha	hu	he	ho	hua	nggi	ngga	nggu	ngge	ngge	nggo	nggo	nggaa	nggua	nggee	nggoo	nggoo	gi	ga	gu	ge	guei	gua	nge	ngo	ngua	pi	pa	pu	pe	pe	po	po	mbi	mba	mbu	mbe	mbe	mbe	mbo	mbo	mbuu	mbee	mboo	mboo	kpi	kpa	kpu	kpe	kpe	kpo	kpo	gbi	gba	gbu	gbe	gbe	gbo	gbo	ra	ndi	nda	ndu	nde	nde	ndo	ndo	nja	nju	nje	njo	vi	va	vu	ve	ve	vo	vo	nyi	nya	nyu	nye	nyo			1	2	3	4	5	6	7	8	9";
    case 489:
      return "A	D	L	M	B	S	P	Bh	R	E	F	I	O	Dh	Yh	W	N	K	Y	U	J	C	H	Q	G	Ny	T	Nh	V	X	Gb	Z	Kp	Sh	a	d	l	m	b	s	p	bh	r	e	f	i	o	dh	yh	w	n	k	y	u	j	c	h	q	g	ny	t	nh	v	x	gb	z	kp	sh				'				'					0	1	2	3	4	5	6	7	8	9					!	?";
    case 492:
      return "																																																																																																																	1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70	80	90	100	200	300	400	500	600	700	800	900	1000	2000	3000	4000	5000	6000	7000	8000	9000	10000	20000	30000	40000	50000	60000	70000	80000	90000	1L	2L	L	cr	2cr	1	2	3	4	5	6	7	8	9	-	1/4	1/2	3/4	Rs	1	2	10000	L";
    case 493:
      return "	1	2	3	4	5	6	7	8	9	10	20	30	40	50	60	70	80	90	100	200	300	400	500	600	700	800	900	1000	2000	3000	4000	5000	6000	7000	8000	9000	10000	20000	30000	40000	50000	60000	70000	80000	90000	*	2	3	4	5	6	7	8	9	10	400	600	2000	10000	1/2	1/6";
    case 494:
      return "a	b	j	d		w	z	h	t	y	k	l	m	n	s	`	f	s	q	r	sh	t	th	kh	dh	d	dh	gh	b	n	f	q		b	j		h			h		y	k	l	m	n	s	`	f	s	q		sh	t	th	kh		d		gh							j					h		y		l		n	s	`		s	q		sh			kh		d		gh		n		q		b	j		h			h	t	y	k		m	n	s	`	f	s	q		sh	t	th	kh		d	dh	gh	b		f		a	b	j	d	h	w	z	h	t	y		l	m	n	s	`	f	s	q	r	sh	t	th	kh	dh	d	dh	gh						b	j	d		w	z	h	t	y		l	m	n	s	`	f	s	q	r	sh	t	th	kh	dh	d	dh	gh																																																					mh	hd";
    case 496:
      return "1z	2z	3z	4z	:mahjong:	6z	5z	1m	2m	3m	4m	5m	6m	7m	8m	9m	1s	2s	3s	4s	5s	6s	7s	8s	9s	1p	2p	3p	4p	5p	6p	7p	8p	9p	1b	2b	4b	3b	5b	6b	7b	8b	j	-					-	00	01	02	03	04	05	06	10	11	12	13	14	15	16	20	21	22	23	24	25	26	30	31	32	33	34	35	36	40	41	42	43	44	45	46	50	51	52	53	54	55	56	60	61	62	63	64	65	66	-	00	01	02	03	04	05	06	10	11	12	13	14	15	16	20	21	22	23	24	25	26	30	31	32	33	34	35	36	40	41	42	43	44	45	46	50	51	52	53	54	55	56	60	61	62	63	64	65	66													-	As	2s	3s	4s	5s	6s	7s	8s	9s	Ts	Js	Ns	Qs	Ks			Ah	2h	3h	4h	5h	6h	7h	8h	9h	Th	Jh	Nh	Qh	Kh	0		Ad	2d	3d	4d	5d	6d	7d	8d	9d	Td	Jd	Nd	Qd	Kd	:black_joker:		Ac	2c	3c	4c	5c	6c	7c	8c	9c	Tc	Jc	Nc	Qc	Kc	0	0	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	21";
    case 497:
      return "0.	0,	1,	2,	3,	4,	5,	6,	7,	8,	9,	0	0	CC0	ShareAlike	NonCommercial	(A)	(B)	(C)	(D)	(E)	(F)	(G)	(H)	(I)	(J)	(K)	(L)	(M)	(N)	(O)	(P)	(Q)	(R)	(S)	(T)	(U)	(V)	(W)	(X)	(Y)	(Z)	[S]	C	R	CD	WZ	Copyleft	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	HV	MV	SD	SS	PPV	WC	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	MC	MD	MR	CreativeCommons	PublicDomain	Attribution	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	PX	IC	PA	SA	AB	WC	DJ	CL	COOL	FREE	ID	NEW	NG	OK	SOS	UP!	VS	3D	2ndScr	2K	4K	8K	5.1	7.1	22.2	60P	120P	d	HC	HDR	Hi-Res	Lossless	SHV	UHD	VOD	*M*																																																									A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z";
    case 498:
      return "hoka	koko	sa														Shou	Zi	Shuang	de	Er	Duo	Jie	Tian	Jiao	Ying	Wu	Liao	Qian	Hou	Zai	Xin	Chu	Zhong	Sheng	Fan	Sheng	Chui	Yan	Tou	Bu	Yi	San	You	Zuo	Zhong	You	Zhi	Zou	Da	Jin	Kong	He	Man	You	Yue	Shen	Ge	Ying	Pei					[Ben]	[San]	[Er]	[An]	[Dian]	[Da]	[Dao]	[Sheng]	[Bai]								De	Ke															Fu	Lu	Shou	Xi	Shuangxi	Cai";
    case 499:
      return ":cyclone:	:foggy:	:closed_umbrella:	:night_with_stars:	:sunrise_over_mountains:	:sunrise:	:city_dusk:	:city_sunset:	:rainbow:	:bridge_at_night:	:ocean:	:volcano:	:milky_way:	:earth_africa:	:earth_americas:	:earth_asia:	:globe_with_meridians:	:new_moon:	:waxing_crescent_moon:	:first_quarter_moon:	:waxing_gibbous_moon:	:full_moon:	:waning_gibbous_moon:	:last_quarter_moon:	:waning_crescent_moon:	:crescent_moon:	:new_moon_with_face:	:first_quarter_moon_with_face:	:last_quarter_moon_with_face:	:full_moon_with_face:	:sun_with_face:	:star2:	:stars:	:thermometer:	*	*	:white_sun_small_cloud:	:white_sun_cloud:	:white_sun_rain_cloud:	:cloud_rain:	:cloud_snow:	:cloud_lightning:	:cloud_tornado:	:fog:	:wind_blowing_face:	:hotdog:	:taco:	:burrito:	:chestnut:	:seedling:	:evergreen_tree:	:deciduous_tree:	:palm_tree:	:cactus:	:hot_pepper:	:tulip:	:cherry_blossom:	:rose:	:hibiscus:	:sunflower:	:blossom:	:corn:	:ear_of_rice:	:herb:	:four_leaf_clover:	:maple_leaf:	:fallen_leaf:	:leaves:	:mushroom:	:tomato:	:eggplant:	:grapes:	:melon:	:watermelon:	:tangerine:	:lemon:	:banana:	:pineapple:	:apple:	:green_apple:	:pear:	:peach:	:cherries:	:strawberry:	:hamburger:	:pizza:	:meat_on_bone:	:poultry_leg:	:rice_cracker:	:rice_ball:	:rice:	:curry:	:ramen:	:spaghetti:	:bread:	:fries:	:sweet_potato:	:dango:	:oden:	:sushi:	:fried_shrimp:	:fish_cake:	:icecream:	:shaved_ice:	:ice_cream:	:doughnut:	:cookie:	:chocolate_bar:	:candy:	:lollipop:	:custard:	:honey_pot:	:cake:	:bento:	:stew:	:cooking:	:fork_and_knife:	:tea:	:sake:	:wine_glass:	:cocktail:	:tropical_drink:	:beer:	:beers:	:baby_bottle:	:fork_knife_plate:	:champagne:	:popcorn:	:ribbon:	:gift:	:birthday:	:jack_o_lantern:	:christmas_tree:	:santa:	:fireworks:	:sparkler:	:balloon:	:tada:	:confetti_ball:	:tanabata_tree:	:crossed_flags:	:bamboo:	:dolls:	:flags:	:wind_chime:	:rice_scene:	:school_satchel:	:mortar_board:	*	*	:military_medal:	:reminder_ribbon:	*	:microphone2:	:level_slider:	:control_knobs:	#	#	:film_frames:	:tickets:	:carousel_horse:	:ferris_wheel:	:roller_coaster:	:fishing_pole_and_fish:	:microphone:	:movie_camera:	:cinema:	:headphones:	:art:	:tophat:	:circus_tent:	:ticket:	:clapper:	:performing_arts:	:video_game:	:dart:	:slot_machine:	:8ball:	:game_die:	:bowling:	:flower_playing_cards:	:musical_note:	:notes:	:saxophone:	:guitar:	:musical_keyboard:	:trumpet:	:violin:	:musical_score:	:running_shirt_with_sash:	:tennis:	:ski:	:basketball:	:checkered_flag:	:snowboarder:	:person_running:	:person_surfing:	:medal:	:trophy:	:horse_racing:	:football:	:rugby_football:	:person_swimming:	:person_lifting_weights:	:person_golfing:	:motorcycle:	:race_car:	:cricket_game:	:volleyball:	:field_hockey:	:hockey:	:ping_pong:	:mountain_snow:	:camping:	:beach:	:construction_site:	:homes:	:cityscape:	:house_abandoned:	:classical_building:	:desert:	:island:	:park:	:stadium:	:house:	:house_with_garden:	:office:	:post_office:	:european_post_office:	:hospital:	:bank:	:atm:	:hotel:	:love_hotel:	:convenience_store:	:school:	:department_store:	:factory:	:izakaya_lantern:	:japanese_castle:	:european_castle:	*	*	:flag_white:	:flag_black:	:rosette:	*	:label:	:badminton:	:bow_and_arrow:	:amphora:";
    case 500:
      return ":rat:	:mouse2:	:ox:	:water_buffalo:	:cow2:	:tiger2:	:leopard:	:rabbit2:	:cat2:	:dragon:	:crocodile:	:whale2:	:snail:	:snake:	:racehorse:	:ram:	:goat:	:sheep:	:monkey:	:rooster:	:chicken:	:dog2:	:pig2:	:boar:	:elephant:	:octopus:	:shell:	:bug:	:ant:	:bee:	:lady_beetle:	:fish:	:tropical_fish:	:blowfish:	:turtle:	:hatching_chick:	:baby_chick:	:hatched_chick:	:bird:	:penguin:	:koala:	:poodle:	:dromedary_camel:	:camel:	:dolphin:	:mouse:	:cow:	:tiger:	:rabbit:	:cat:	:dragon_face:	:whale:	:horse:	:monkey_face:	:dog:	:pig:	:frog:	:hamster:	:wolf:	:bear:	:panda_face:	:pig_nose:	:feet:	:chipmunk:	:eyes:	:eye:	:ear:	:nose:	:lips:	:tongue:	:point_up_2:	:point_down:	:point_left:	:point_right:	:punch:	:wave:	:ok_hand:	:thumbsup:	:thumbsdown:	:clap:	:open_hands:	:crown:	:womans_hat:	:eyeglasses:	:necktie:	:shirt:	:jeans:	:dress:	:kimono:	:bikini:	:womans_clothes:	:purse:	:handbag:	:pouch:	:mans_shoe:	:athletic_shoe:	:high_heel:	:sandal:	:boot:	:footprints:	:bust_in_silhouette:	:busts_in_silhouette:	:boy:	:girl:	:man:	:woman:	:family:	:couple:	:two_men_holding_hands:	:two_women_holding_hands:	:police_officer:	:people_with_bunny_ears_partying:	:person_with_veil:	:blond_haired_person:	:man_with_chinese_cap:	:person_wearing_turban:	:older_man:	:older_woman:	:baby:	:construction_worker:	:princess:	:japanese_ogre:	:japanese_goblin:	:ghost:	:angel:	:alien:	:space_invader:	:imp:	:skull:	:person_tipping_hand:	:guard:	:dancer:	:lipstick:	:nail_care:	:person_getting_massage:	:person_getting_haircut:	:barber:	:syringe:	:pill:	:kiss:	:love_letter:	:ring:	:gem:	:couplekiss:	:bouquet:	:couple_with_heart:	:wedding:	:heartbeat:	:broken_heart:	:two_hearts:	:sparkling_heart:	:heartpulse:	:cupid:	:blue_heart:	:green_heart:	:yellow_heart:	:purple_heart:	:gift_heart:	:revolving_hearts:	:heart_decoration:	:diamond_shape_with_a_dot_inside:	:bulb:	:anger:	:bomb:	:zzz:	:boom:	:sweat_drops:	:droplet:	:dash:	:poop:	:muscle:	:dizzy:	:speech_balloon:	:thought_balloon:	:white_flower:	:100:	:moneybag:	:currency_exchange:	:heavy_dollar_sign:	:credit_card:	:yen:	:dollar:	:euro:	:pound:	:money_with_wings:	:chart:	:seat:	:computer:	:briefcase:	:minidisc:	:floppy_disk:	:cd:	:dvd:	:file_folder:	:open_file_folder:	:page_with_curl:	:page_facing_up:	:date:	:calendar:	:card_index:	:chart_with_upwards_trend:	:chart_with_downwards_trend:	:bar_chart:	:clipboard:	:pushpin:	:round_pushpin:	:paperclip:	:straight_ruler:	:triangular_ruler:	:bookmark_tabs:	:ledger:	:notebook:	:notebook_with_decorative_cover:	:closed_book:	:book:	:green_book:	:blue_book:	:orange_book:	:books:	:name_badge:	:scroll:	:pencil:	:telephone_receiver:	:pager:	:fax:	:satellite:	:loudspeaker:	:mega:	:outbox_tray:	:inbox_tray:	:package:	:e_mail:	:incoming_envelope:	:envelope_with_arrow:	:mailbox_closed:	:mailbox:	:mailbox_with_mail:	:mailbox_with_no_mail:	:postbox:	:postal_horn:	:newspaper:	:mobile_phone:	:calling:	:vibration_mode:	:mobile_phone_off:	:no_mobile_phones:	:signal_strength:	:camera:	:camera_with_flash:	:video_camera:	:tv:	:radio:	:vhs:	:projector:	*	:prayer_beads:";
    case 501:
      return ":twisted_rightwards_arrows:	:repeat:	:repeat_one:	:arrows_clockwise:	:arrows_counterclockwise:	:low_brightness:	:high_brightness:	:mute:	:speaker:	:sound:	:loud_sound:	:battery:	:electric_plug:	:mag:	:mag_right:	:lock_with_ink_pen:	:closed_lock_with_key:	:key:	:lock:	:unlock:	:bell:	:no_bell:	:bookmark:	:link:	:radio_button:	:back:	:end:	:on:	:soon:	:top:	:underage:	:keycap_ten:	:capital_abcd:	:abcd:	:1234:	:symbols:	:abc:	:fire:	:flashlight:	:wrench:	:hammer:	:nut_and_bolt:	:knife:	:gun:	:microscope:	:telescope:	:crystal_ball:	:six_pointed_star:	:beginner:	:trident:	:black_square_button:	:white_square_button:	:red_circle:	:blue_circle:	:large_orange_diamond:	:large_blue_diamond:	:small_orange_diamond:	:small_blue_diamond:	:small_red_triangle:	:small_red_triangle_down:	:arrow_up_small:	:arrow_down_small:	*	*	+	+	+	*	*	M	+	+	+	:om_symbol:	:dove:	:kaaba:	:mosque:	:synagogue:	:menorah:	*	:clock1:	:clock2:	:clock3:	:clock4:	:clock5:	:clock6:	:clock7:	:clock8:	:clock9:	:clock10:	:clock11:	:clock12:	:clock130:	:clock230:	:clock330:	:clock430:	:clock530:	:clock630:	:clock730:	:clock830:	:clock930:	:clock1030:	:clock1130:	:clock1230:	*	*	*	@	@	*	*	:candle:	:clock:	*	*	:hole:	:levitate:	:detective:	:dark_sunglasses:	:spider:	:spider_web:	:joystick:	:man_dancing:	@	@	@	@	@	@	@	@	@	@	@	@	:paperclips:	*	*	:pen_ballpoint:	:pen_fountain:	:paintbrush:	:crayon:	*	*	:hand_splayed:	*	^	v	V	:middle_finger:	:vulcan:	v	<	>	<	>	<	>	^	v	^	v	^	v	:black_heart:	:desktop:	*	*	:printer:	*	*	*	*	*	*	*	*	:mouse_three_button:	:trackball:	*	*	*	*	*	*	#	#	#	:frame_photo:	#	#	#	#	#	:dividers:	:card_box:	:file_cabinet:	#	#	#	#	#	#	#	#	#	#	#	#	:wastebasket:	:notepad_spiral:	:calendar_spiral:	#	-	+	#	*	X	aA	Aa	:compression:	:key2:	:newspaper2:	#	#	:dagger:	*	:speaking_head:	v	^	>	<	:speech_left:	@	@	@	@	@	@	:anger_right:	*	*	*	:ballot_box:	x	x	x	x	v	v	:map:	:mount_fuji:	:tokyo_tower:	:statue_of_liberty:	:japan:	:moyai:";
    case 502:
      return ':grinning:	:grin:	:joy:	:smiley:	:smile:	:sweat_smile:	:laughing:	:innocent:	:smiling_imp:	:wink:	:blush:	:yum:	:relieved:	:heart_eyes:	:sunglasses:	:smirk:	:neutral_face:	:expressionless:	:unamused:	:sweat:	:pensive:	:confused:	:confounded:	:kissing:	:kissing_heart:	:kissing_smiling_eyes:	:kissing_closed_eyes:	:stuck_out_tongue:	:stuck_out_tongue_winking_eye:	:stuck_out_tongue_closed_eyes:	:disappointed:	:worried:	:angry:	:rage:	:cry:	:persevere:	:triumph:	:disappointed_relieved:	:frowning:	:anguished:	:fearful:	:weary:	:sleepy:	:tired_face:	:grimacing:	:sob:	:open_mouth:	:hushed:	:cold_sweat:	:scream:	:astonished:	:flushed:	:sleeping:	:dizzy_face:	:no_mouth:	:mask:	:smile_cat:	:joy_cat:	:smiley_cat:	:heart_eyes_cat:	:smirk_cat:	:kissing_cat:	:pouting_cat:	:crying_cat_face:	:scream_cat:	:slight_frown:	:slight_smile:	:upside_down:	:rolling_eyes:	:person_gesturing_no:	:person_gesturing_ok:	:person_bowing:	:see_no_evil:	:hear_no_evil:	:speak_no_evil:	:person_raising_hand:	:raised_hands:	:person_frowning:	:person_pouting:	:pray:	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	#	#	#	#	-	|	-	|	&	&	&	&	&	&	"	"	"	!?	!?	!?	/	\\	/	\\	:rocket:	:helicopter:	:steam_locomotive:	:railway_car:	:bullettrain_side:	:bullettrain_front:	:train2:	:metro:	:light_rail:	:station:	:tram:	:train:	:bus:	:oncoming_bus:	:trolleybus:	:busstop:	:minibus:	:ambulance:	:fire_engine:	:police_car:	:oncoming_police_car:	:taxi:	:oncoming_taxi:	:red_car:	:oncoming_automobile:	:blue_car:	:truck:	:articulated_lorry:	:tractor:	:monorail:	:mountain_railway:	:suspension_railway:	:mountain_cableway:	:aerial_tramway:	:ship:	:person_rowing_boat:	:speedboat:	:traffic_light:	:vertical_traffic_light:	:construction:	:rotating_light:	:triangular_flag_on_post:	:door:	:no_entry_sign:	:smoking:	:no_smoking:	:put_litter_in_its_place:	:do_not_litter:	:potable_water:	:non_potable_water:	:bike:	:no_bicycles:	:person_biking:	:person_mountain_biking:	:person_walking:	:no_pedestrians:	:children_crossing:	:mens:	:womens:	:restroom:	:baby_symbol:	:toilet:	:wc:	:shower:	:bath:	:bathtub:	:passport_control:	:customs:	:baggage_claim:	:left_luggage:	^	X	i	m	f	:couch:	:sleeping_accommodation:	:shopping_bags:	:bellhop:	:bed:	:place_of_worship:	:octagonal_sign:	:shopping_cart:	^	^	:hindu_temple:	:hut:	:elevator:					:wireless:	:playground_slide:	:wheel:	:ring_buoy:	:tools:	:shield:	:oil:	:motorway:	:railway_track:	:motorboat:	^	^	^	:airplane_small:	^	:airplane_departure:	:airplane_arriving:				:satellite_orbital:	#	#	:cruise_ship:	:scooter:	:motor_scooter:	:canoe:	:sled:	:flying_saucer:	:skateboard:	:auto_rickshaw:	:pickup_truck:	:roller_skate:';
    case 503:
      return "QE	A	F	E	W	AF	AR	AR	SV	SV	+	+	+	*	*	*	*	*	*	*	s	n	n	v	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	T	T	T	T	T	A	MB	VB	R	h	n	dn	m	drss	ozss	*	*	*					*	*	*	*	*	<	^	>	v	*	*	*	*	*	*	*	*	*	*	#	#	#	#	#	#	#	#	#	*	*	*	*	*	*	*	*	*	*	+	+	+	+	+	+	+	x	x	x	x	x	x	x	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	+	+	+	+	+	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*	*							:orange_circle:	:yellow_circle:	:green_circle:	:purple_circle:	:brown_circle:	:red_square:	:blue_square:	:orange_square:	:yellow_square:	:green_square:	:purple_square:	:brown_square:					:heavy_equals_sign:";
    case 504:
      return "<	^	>	v	<	^	>	v	<	^	>	v					<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v	<	^	>	v									<	^	>	v	\\	/	\\	/	-	|							<	^	>	v	\\	/	\\	/	<	^	>	v	\\	/	\\	/	<	^	>	v	\\	/	\\	/	<	^	>	v	\\	/	\\	/	<	^	>	v	\\	/	\\	/									<	^	>	v	<	^	>	v	<	^	>	v	-	-	-	-	<	>	<	>	<	>	<	>	<	>	<	>	-	-			\\	/	>	v	<	^	>	v	\\	/	\\	/					<	>";
    case 505:
      return "+	+	+	*	*	*	*	*	^	^	^	^	:pinched_fingers:	:white_heart:	:brown_heart:	:pinching_hand:	:zipper_mouth:	:money_mouth:	:thermometer_face:	:nerd:	:thinking:	:head_bandage:	:robot:	:hugging:	:metal:	:call_me:	:raised_back_of_hand:	:left_facing_fist:	:right_facing_fist:	:handshake:	:fingers_crossed:	:love_you_gesture:	:cowboy:	:clown:	:nauseated_face:	:rofl:	:drooling_face:	:lying_face:	:person_facepalming:	:sneezing_face:	:face_with_raised_eyebrow:	:star_struck:	:zany_face:	:shushing_face:	:face_with_symbols_over_mouth:	:face_with_hand_over_mouth:	:face_vomiting:	:exploding_head:	:pregnant_woman:	:breast_feeding:	:palms_up_together:	:selfie:	:prince:	:person_in_tuxedo:	:mrs_claus:	:person_shrugging:	:person_doing_cartwheel:	:person_juggling:	:person_fencing:	+	:people_wrestling:	:person_playing_water_polo:	:person_playing_handball:	:diving_mask:	:wilted_rose:	:drum:	:champagne_glass:	:tumbler_glass:	:spoon:	:goal:	+	:first_place:	:second_place:	:third_place:	:boxing_glove:	:martial_arts_uniform:	:curling_stone:	:lacrosse:	:softball:	:flying_disc:	:croissant:	:avocado:	:cucumber:	:bacon:	:potato:	:carrot:	:french_bread:	:salad:	:shallow_pan_of_food:	:stuffed_flatbread:	:egg:	:milk:	:peanuts:	:kiwi:	:pancakes:	:dumpling:	:fortune_cookie:	:takeout_box:	:chopsticks:	:bowl_with_spoon:	:cup_with_straw:	:coconut:	:broccoli:	:pie:	:pretzel:	:cut_of_meat:	:sandwich:	:canned_food:	:leafy_green:	:mango:	:moon_cake:	:bagel:	:smiling_face_with_3_hearts:	:yawning_face:	:smiling_face_with_tear:	:partying_face:	:woozy_face:	:hot_face:	:cold_face:	:ninja:	:disguised_face:	:face_holding_back_tears:	:pleading_face:	:sari:	:lab_coat:	:goggles:	:hiking_boot:	:womans_flat_shoe:	:crab:	:lion_face:	:scorpion:	:turkey:	:unicorn:	:eagle:	:duck:	:bat:	:shark:	:owl:	:fox:	:butterfly:	:deer:	:gorilla:	:lizard:	:rhino:	:shrimp:	:squid:	:giraffe:	:zebra:	:hedgehog:	:sauropod:	:t_rex:	:cricket:	:kangaroo:	:llama:	:peacock:	:hippopotamus:	:parrot:	:raccoon:	:lobster:	:mosquito:	:microbe:	:badger:	:swan:	:mammoth:	:dodo:	:sloth:	:otter:	:orangutan:	:skunk:	:flamingo:	:oyster:	:beaver:	:bison:	:seal:	:guide_dog:	:probing_cane:					:bone:	:leg:	:foot:	:tooth:	:superhero:	:supervillain:	:safety_vest:	:ear_with_hearing_aid:	:motorized_wheelchair:	:manual_wheelchair:	:mechanical_arm:	:mechanical_leg:	:cheese:	:cupcake:	:salt:	:beverage_box:	:garlic:	:onion:	:falafel:	:waffle:	:butter:	:mate:	:ice_cube:	:bubble_tea:	:troll:	:person_standing:	:person_kneeling:	:deaf_person:	:face_with_monocle:	:adult:	:child:	:older_adult:	:bearded_person:	:woman_with_headscarf:	:person_in_steamy_room:	:person_climbing:	:person_in_lotus_position:	:mage:	:fairy:	:vampire:	:merperson:	:elf:	:genie:	:zombie:	:brain:	:orange_heart:	:billed_cap:	:scarf:	:gloves:	:coat:	:socks:	:red_envelope:	:firecracker:	:jigsaw:	:test_tube:	:petri_dish:	:dna:	:compass:	:abacus:	:fire_extinguisher:	:toolbox:	:bricks:	:magnet:	:luggage:	:squeeze_bottle:	:thread:	:yarn:	:safety_pin:	:teddy_bear:	:broom:	:basket:	:roll_of_paper:	:soap:	:sponge:	:receipt:	:nazar_amulet:";
    case 506:
      return "K	Q	R	B	N	P	N	n	N	K	Q	R	B	N	P	k	q	r	b	n	p	K	Q	R	B	N	P	N	n	N	K	Q	R	B	N	P	k	q	r	b	n	p	K	Q	R	B	N	P	N	n	N	K	Q	R	B	N	P	k	q	r	b	n	p	K	Q	R	B	N	P	N	n	N	E	e	E	E	e	E	NQ	NR	NB	nq	nr	nb													G	A	E	H	R	C	S	g	a	e	h	r	c	s			:ballet_shoes:	:one_piece_swimsuit:	:briefs:	:shorts:	:thong_sandal:	:light_blue_heart:	:grey_heart:	:pink_heart:	:drop_of_blood:	:adhesive_bandage:	:stethoscope:	:x_ray:	:crutch:				:yo_yo:	:kite:	:parachute:	:boomerang:	:magic_wand:	:pinata:	:nesting_dolls:	:maracas:	:flute:	:harp:						:shovel:	:ringed_planet:	:chair:	:razor:	:axe:	:diya_lamp:	:banjo:	:military_helmet:	:accordion:	:long_drum:	:coin:	:carpentry_saw:	:screwdriver:	:ladder:	:hook:	:mirror:	:window:	:plunger:	:sewing_needle:	:knot:	:bucket:	:mouse_trap:	:toothbrush:	:headstone:	:placard:	:rock:	:mirror_ball:	:identification_card:	:low_battery:	:hamsa:	:folding_hand_fan:	:hair_pick:	:khanda:	:fly:	:worm:	:beetle:	:cockroach:	:potted_plant:	:wood:	:feather:	:lotus:	:coral:	:empty_nest:	:nest_with_eggs:	:hyacinth:	:jellyfish:	:wing:	:leafless_tree:	:goose:	:anatomical_heart:	:lungs:	:people_hugging:	:pregnant_man:	:pregnant_person:	:person_with_crown:	:fingerprint:								:moose:	:donkey:	:blueberries:	:bell_pepper:	:olive:	:flatbread:	:tamale:	:fondue:	:teapot:	:pouring_liquid:	:beans:	:jar:	:ginger_root:	:pea_pod:	:root_vegetable:			:splatter:	:melting_face:	:saluting_face:	:face_with_open_eyes_and_hand_over_mouth:	:face_with_peeking_eye:	:face_with_diagonal_mouth:	:dotted_line_face:	:biting_lip:	:bubbles:	:shaking_face:	:face_with_bags_under_eyes:							:hand_with_index_finger_and_thumb_crossed:	:rightwards_hand:	:leftwards_hand:	:palm_down_hand:	:palm_up_hand:	:index_pointing_at_the_viewer:	:heart_hands:	:leftwards_pushing_hand:	:rightwards_pushing_hand:";
    case 507:
      return "#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	|	|	|	|	|	|	-	-	-	-	-	-	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#		#	#	#	#	#	#	X	X	/	\\	/	\\	X	X	X	X	X	X	X	X	X	X	X	X	X	X	X	-	^	v	>	<	<	<	>	v	^	[	]	#	]	#	#	#	X	>	>	>	?	+	+	+	+	+	^	X	[	^	#	#	X	X	X	X	X	X	X	X	X	X	X	X	X	X	X	X	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	#	0	1	2	3	4	5	6	7	8	9";
    case 512:
      return "He	Qi		Qie		Hai		Sho	Kyu	Qiu	Cao	Jo		Shi			Ki		Hei	Si	Jue		Khang	Khenh	Ten	Rei	Fu	Yu		Kong			Ki	Tin	Zi				Xing	Ba	Cup	Tei	Kha	Khe	Ten	Hei	Ki			Mou	Dua	Re	Trut			Ji	Ye	Jun		Gen	Qian	Lu	Bui	Xuoi	Doi	Dou	Dua		Luon	Sho	Bik		Kun	Chu	So				Lin			Duoi			Sanh	Kon		Shi		Cha	Cui			Gom	Bui	Gom	Qie	Boku			Shi	Ga	Chu	Chu	Cung	Chu	Nham			Qi	Shuku		Kai	Shi			Ki	Giua		Chan	Suot	Giua	Xuyen	Chuoi	I	Gan	So	Tan			Shu		Huan		Yi	Zuo	Jie					Ban	Ay	Ju		Zou			Zi	Shi	Tei						Ho	Za	Ko	Jin	Han		Pai	I	Dui	Cong		Shen	So	Shi	Ben	Ben	Ga		Shin	Kai		Shi	So	So		Yo	U	Ko	Huang	Sui	Shi		Ten	I	Hai	Shu		Bi	Hi	Fu	Yu	Mai				Itsu	Yin	Ko	Gun	Waang		Kyu	Kai	Saam	Ya	Yang	Wan	Shu	Jiu	Ul						Ut	Rei	Ya	Chu	Man	4	It	Ko	Kyo		Hi		Chin		Shen		Shi	Tam	Ut	Bi		Setsu	Ki			Lyun	Ut			Jiu		Shi	O	Ki";
    case 513:
      return "Vu				Ken	Ye		Raku	Rin	Dong	Ken	Ken	Jue	Jie	Dai	Diao	Le	Jue	Chui	Shu	Gen	Dai	Ling	Shu	Sing	So	Ting	Yo	Tho	Yo	Sho	Ka	Er	Go	Sen	Gen	Jun		Gop	Vai	Ko	Hai			Jo	Ko	Ya	Ban	Ro	Yi		Kep	Hi	Sei	Nham	Sei		Kyoku	Gieng	Lam	Nam	Vai		Wei			Jie	Eki		Matsu			Do				Yi	Mat	Mat		Mat		Mat	Yu	Koku		Ho	Die	Tei	Loeng	Qi		Le		Sho	Sho	Kyo	Koku	Haku		Xi		Ben			Shuku	Katsu	Sho	Bao				Tei	Xie		Quen				Kaku		Zhang		Quen	Mat					Ra	Sui				Shun	O		Ki	Kon		Yong	Son	I	Sa	Xu	O		Ta		Ha				Die	Sui	Dan	Sei	Sho		Wei				Gua	Tei		Sa			Fan	Ko	Coi		In	Mo	Saku	Sho	Xi	Yan	Trum	Do	Ni	Dan		Bu	Shi	Ken	Kei	Ko			Wu		Jan	Ko				Joeng				Ka	Dan		To		Tao	Yu		Gong		Mou	Va	Bom	Kua	Chu	Ko	Ko	Futsu	Shi	Ko	Ki																Mei	Qu		Mo	Jau	Shi	Kai	Gan		Sheng		Ging			Hua	Top	Kyu	Hatsu";
    case 514:
      return "Shi	Tuo		Ho	Waan	Shou	Kai	Shuku	Shi	Kan	Nie	Ju	Jyu	Bi	Shi	Ken	Shin	Ko		Ryo	Lap		Yo												En		Yun	Gua		Eki	Zok		Yo		Xiao	Lao	Ki	Hei	Dan	Suo	Katsu	Heki	Chi	Mang	Yi	Hi	Te	Jau	Bi	Keki	Shun	I	Sai	Eki			Ta										In			Ho			Ryo		Hei	Shi	Bo	Luo				Sing	Vai	Nghi	Nay	Xien	Tray	Choku	Xi	Hun	Da	In	Shuku	Ju	Kyo	Du	Jip	Kyo	An	To	Ken			Phuong		Gyo	Jyu	Ding																				Mei	Shoku	Ryo	Ran		Ai	Yu		Bai	Jian		Qi		Rei			Ji	Ngai	Nguoi	Nho	Thay	Zung	Min	Fan	Vung	An	Zhou	Zhi	Zhong	Nao	Bing	Sen	Zhuan	Shu	Xun	Jue	Qian	Bo		Gua	Ko	Tu	Ben	Taku	Ta	Ying	Zhi	Heki	Teki	In	Ho			Kui	Syun	Jung						Chen			Tobi								Shoku	Mei	Jaku		Kyo	Lian	Ya				Shu	Guo	Miao	She	Yu		Si	Sou	I	Zhi	Mei	Mu	Qie	Shi	Fu	Kan	Ko	Ju	Bei	Shu	Bi	Seki	Setsu	Suo	Ki	Tan	Qian	Ming	Chan	Kyo	Jun	Sao	Ji	Gu		Ho	Sa";
    case 515:
      return "Ho		San						Ron	Han	Paa											Gong	Qiong	Toku	Yu		Rong		Kei		Sou	Sou	Yao	So	Keki			Wu	Nap	Na	Phia	Hyo	Chou	Hitsu	Chi	Shuai	Zhe	Li	Gai	Sui	Zhan	Kya	Zhuang	Jo	Ka	Shu	Hei	Choku	Sui			Fu	Gi	Sho	To	Man		Ji	Dou	Mak	Lei	Caan																Hui	San		Jian	Yan	Zhi		To	Ka			Bo	Bay	But	Bom	Hen	Kyo	Mei	Yao	Di	Yi	Taku	Gap	Sui	Bie	Chi	Shu	Qu	Yi	Ken	Yang	Ju	Hoku	Shu	Zha	Ka	Chu		Sha	Jin		Git			San		Caemh					Xum														Kin	Lai	Ron	So					Ging	Ben	Kyo					Git	Cap	Bay	Lu	Chau	Dang		Jue	To	Qi	Ken	Shun	Yu	Vai	Ngai	Zai	Sa	Se	Ai	Kai	Dun	Hyo	Kei	Ken	Jie	Ke	Ka	Chi	Yue	Tei			Jian	Yao	Gon		Jyu								Xian	Shuku	Xiao	Qiao	Ryo			Yu	Qu				Bam	Ga	Xian	Luo	Kyo	Guang	Ngai	Dung	Cheng	Chuang	Yi	Kai	Zheng	Hei	Zong	Dui	Ken	Zhai		Tho	Giong		Fung				Hotoke			Gaa			Fei";
    case 516:
      return "Yi	Meng				Nghe	Hyo	So	Bian	Jie	Shu	Liao	Bi	Su	Ban			Di		Jing	Lou						Rei	Ken			Troi	Liu		Bei	Wen	Kan	Kai	Yoku	Kai	Meng	Ken	Chan			Doi					Kan				Dao			Doi		Pin	Jian	Lin	Gui	Qi	Hong			Ji	Ji	Xie	Zheng	Chan		Trom	Thoi	Gen	Long		Tai	Hyo		Yao	Chan				Ngua	Ngoi	Sen	Dian	Chong	Nei	Nei			Zhai	Bian		Chan	Nghe		So	Cau				Kaku	Xiao	Sen	Nhau			Cu	Xin	Jing	Qian		Qing		Ki	Cho		Gu	Ten	Cho		Shu	Shi	Cho	San	Shi		Shi	Wu	Shi	Ji	Ji			Shi	Kyo	Kyo	Yu	Fu		Miriguramu	Jyun	Jan				Gyo		Hekutoguramu	Gan			Yuan	Bing	Gen				Wan	Hang		Rang	Ro	Hoku	Ryo				Vac	Miriguramu		Nhoc	Niao	Heki	Cin			Lian		Tin	Rao						Fan	Di	Truoc	Rang				Vang	Kyo	Sang	Miriyaguramu		Hui	Yi	Xian		Dun	Daam	Quanh	Ro			Mong		Lan	Fu		Xiong			Liang	Tao	Ji	Ho	Hen	Shi	Jie	Zha	Shi	Hen		Kai	Vao	Nhui	Qi	Bian	Lan	Lan	Lin			Gu		Sen	Sen	Hetsu	Zhi	Bi	Sheng	Lon	Vo	Tron	Sip	Sheng	Cyun	Qin";
    case 517:
      return "Han	Hetsu	Biao	Xi	Ya		Kyo	Shi	Chu	Juan	Cho	Ji	Kyaku	Xi	Qin	Kyo	Ki	Hai	Shi	Ten	Yo	Lun	Kyo	Chu	Futsu	To	Ki	Ki	Kon	Ki		Datsu	Yue			Katai		Ken	Linh	Kon	Lian					Tam	Gom	Ban	Ten	I	Heng	Lim			Qi		Ki	Shin	Qian	Zheng	Mao	Jin	Shu	Bo	Mo	Cong	Sai	Mo	Na			Mou	Bo		Ting	Satsu	Zong	Kan			Saku	Tan	U		Ko	Jiong	Zhao		U		Bo	Katsu		Da	Ji	Nian	Cheng		Shaku	Qia	En	To	Yu	Jiao	Ki	Hai			Bo	Zhao	Ku		Da		U	Di	Jiu	Ko			Sui	Ten	Yo	Yao				Wang			Liao		Tong	Yu	Meng	Mei	Xuong		Ka	You	Kan		Zeot					Si	Ka				Nap			Lou	En	Lieng		Yin	Ko			En	Bay	Chong	In	Bitsu	Mong	Ten		Gan	Jiu	Leo		Ngat	Day	Go		Mat		Ko	Qin	Jiong	Sho	Xie					Mat	Rong			He	Jan	I		Tao		Qiu	Xie	Jing	Nian	Jing	Hi	So	Ji						Zeon	Nigo	Retsu	Tian	Kan	Cui	Die	Sei	Qing		Mui	Maang		Retsu	Lun	Vang	Ping	Ping	Ce	Die	Lou		Wun				Quan	Tron		Ryo	Lian	Han	Pang	Tang		Cong	Ret	Yi	Xuan	Suo	Liu	Shuang	Shen";
    case 518:
      return "To	Bu	Sou	Dong	In	Qin	Shen	Kaku	Chan	Hong	Nong	Ting	Jiang	Ritsu	Hui		Chan	Hei	Kaku			Xi	Zhi	To	En	Lok	Mo			Lai	Li	Li	Huai	Rin	He	Jiao	Rei	Yan	Ya	Shu	Shu	Bu	Shi			In		Ju	Fung	Zhen	Tai	You		Shuku	Hi	Ei	Ki		Suo	Wu	Kutsu	Min	Sho			Chang	Cong			Sap	Ju	Ya	Fu	Shi	Fu	I			Shu	Keki	Fu	Ya	Fu		Jiu	Wei	Pang	Fu	Shaku	Kan	Sho		Shitsu		Huo	Sho	So		Kyo	Bay	Jie	Hyo	King						Zao	Shi							Kyo	Ko	Ou	Shin	Kan	Shi	Sei	O	Gua	Faai	Shi	Kan	Shi	Shin		Hao	Li	Zhi	Xian			Bu	Chang	Shi	Un	Cho	To	So	Moc	Men	Shi	Yun	He		Kyoku	Kan	To	Kei		Kai	Tao	Dai	To	Hin	Biao	To	Ra	To		Diao	Shi	Er	Jiu	Haku	Ju	Gai	Haku	Di	Yi	Kun	Koku	Zhe		Kuo	Zhou	Ju		Shi	Ko	Shan	Sha	Diao	Ban	Ji	Ga	San	Zhong	Yo	So	Yi	Gai	Kou	Wu			Katsu	Ge	Ba	Cham	Setsu	Gou	Shu	Sei	Xian	Gua	Liu	Chi	Guai	Chuan	Kyo	Li	Cu	Shua	Katsu					Wan	Bi		Dut	Chem	Bing	Li	Haku	Shitsu	Jiu	Tiao	Duo	Jing	Yan	Quan	Sei	Betsu	Lie		Ke	Satsu	Gen	Zhen	Katsu	Fen	San		Satsu				Kai";
    case 519:
      return "	Yi	San	Jiu	Xu	Jiao	Sho	Koku	Lu	Jiu		Chou	Chaku		Xian	Deo	Kuai	Dui	Ritsu	Teki	Sei	So	Luo	Xi	Qin	Bu	Kei	Ko	Katsu	Ko		En	En				Qia	Ritsu			Kai				Dan	Dam	Hui	Cao		Pi	Ya	Beng	Guo	Gua	Do	Dan	Sei	Ju	Retsu	Kaku	Qia		Jue		So	Sei	Ken	En	Li	Dan		Bao								Ken	Hua	Jiao	Ho	Xe	Thai	Cun	Tach	Dut	Qia	Kyu	Zha	Qia		Zhe	Cha	Ying	Shu		Yan	Sen	Chong	Kei	Sei	Ryu	Chi	San	Wan	Me	Sou	Peng					Kan	Yuan						Gaai	Mo	Cham	Mo	Chou	Ko	Suo	Tu	Saku	Sei	Zhe	Ti	Shoku	Wu	Hei	Da	Li	Cha	Soku	Ho	Fun	Kyu	Kyo	Za					Rong	Gong	Que		Li		Thien	Retsu	Retsu	Tao	Cao	Chat	Got	Bam		Li	Ma	Saku	Mi	Riku	Chi	Ko	Koku	Gun	Lou	Chuang	Suo	Jiao	Jin	Ri	Gwaai		Fa	Zhai	Kaku	Deo	Dut	Lan	Shitsu	To	Sen	Jin	Cui	Deo		Ceng	Zun	Reki	Zhao	San	Sho	Pie	Zhan	Xi	Yao	Fu	Chong	Gaku	Saku	So	Batsu		Cui	Soku	Shu	Kyu	Gua	So							Batsu				Ji	Thien	Hoat	Se	Zhan	Ling	Se	Ye	Ritsu	Sei	Soku	Ketsu	Sho	Ju	Kai	Vac	Hei		Geki	Tu		Gat	Rua	Ru	Ze	Huan	Katsu	Sho	Sho";
    case 520:
      return "San	Xian	Rei	Qian	Zhao	Ken	Ken	Taku		Bua	Cung	Can	Ryo	Ri	Kuo	Li	Rou	Tet			Du			Lie		Riu	Xe	Kaku	Ying	Li	Ri		Du	Teki	Ling	Bi			Fuku	Hyo		Truoc	Wan	Rei	Cim	Chom	San	Die	Kaku	Rei	Ryoku	Jiu		Li	Ku	Keng		Zhen	Ko	Ka					He		Bi	Sa	Pi	Chitsu					Hang	Ei		Kei	Ran	Sieng		Zhuo	Dui	Itsu	Yi	Kei					Gang	Nhan	Ke	Yi	Mo	Kyu	Loi	Can		Geng	Ke	Shi	Nen	Ran				Ei	Ai	Ling	Beng	Shi	Kutsu	Duan		Min			Juan	Nao	Zi	Zan	Khuot	Zong	Kyoku	Kei	Yoku	Hei				Tang		Ken	Xia	Han	Kyo	Yoku			Lue	Qian	Kyu	Ken		Nhoc	Hetsu	Mo	Ou	Hao	Ben	Teki		Zha	Juan	Cong		Vam	Giup	Giup	Li	Zha	You	Dian	Jue	Bei	Sei	Sho		Yao	Pie		Lu	Ketsu		Riku	Yo	Jin	Kai	Se	Yang	Jin	So	Kon		Ke	Ken	Ryo	Kun		Ro	Rai	Kyo	Ro	Ruon	Kyo	Chan		Hyo	Nian	Ren	Wan	Lu	Ryo		Kan	Yo	Katsu	Yun	Yao	Bao		Sui	Jun	Xuan		Zhou	Shun	Shun	Moc			Gun	Shun	Kui	Shun		Katsu	Shun	Cho	Gun	Su	Gi	Yaku	Qu	Shao	Sun			Kai	Du	Kai	Kuai	Pao	Fuku	Fu	Bit		Fuku		Bao			Kyu	Fu	Jiu";
    case 521:
      return "Ran				Ju	O	Cho	Fuku	Ho	Zetsu	Qiong	Shitsu	Cho	Zhou	Hua	Bao	Cho	Gi	Shi	Yo	Shi	Yi	Me	Yi	Yi	Kyu	Taku	Shin	Gi	Mao	Taku	Taku			Kyu	Ci	Shin	Ju	Ruan	Thia		Bay	Itsu	Ci	Ho		Han	Hai	Cong	Ho		Ho	Xi	Sei			Yo	Quan	Tiao		Diao		Han	Kan	Hai	Kitsu	Kyu	Tei	Jin			Ye	Kham	Hi	Ki	Kotsu	Hi	E	Wei		Cang	Diao	To	Ho	Wui	E	Di		Suan	Quan	Ko	I	E	Ou	Xuan				Wu	Hen	Giau		Yi		Mou	Ki	To	Hen	Kyu		Ro	Tei	Hu	Getsu			Han	Ya	Tei		Tei	Au	O	Shitsu	Toto	Shi	Sotsu	Shi	Ho		To	Sa	Wai	Nen	Han	Gai	Bi		Han	Jing	Xi	To	Qin	Cuo	Ci	Shuku	Ban	Hi	Sei	Kyo		Dui	Kyo	Shi	Nen	Hei	Xi					Ko	Kyo	Shu	Tan			Zhi	Luan	Muoi	Hu	Ji	Guai			Gan			Pang	Nghin	Sha	Shi	Kaku		Sotsu	Chuc	Ruoi	Lung				Xung	Zhu					Bi	Tron	Yu	Ton				Nhay	Nhu	Ran	Ran		Jo	Qi	Haku		He	Chu	Ro	Ken	Shao	Chi	Bo	Sei	Kyo	Cho	Reng	You	Sen	Sen	Kin	Nai	Rei		Sai		Hui	Tiao	Ban					Xu		Ko	Koku	You	Chi	Koku	Yu	Ro	Koku	Ken	Koku	Shoku	Ko		Heng";
    case 522:
      return "Tei	Setsu	Ga	Wai		Jo	Xie	Sho	Setsu		Jue	Cho	Sui	Qing	Zhuan		Go	Mong	Hitsu	Sen	Yoku	Ji	Sen		Bi	Gyo	Xi	En	Kotsu	En	Hing	Ken	Ji	Trung	Jun	To		Liao	You	Sen		Sen	Ngheo		Shi	Ju	Soku	U	Jo	Shin	Yue		Kai	Bang	Ko	Shin	Pi	Hai	Seki	Ze			Yi	Di	Kiku	To	Qie		Suo		Ci		Zhu	Yue	Shi	Seki	Seki	O	Sa	Jiao	San				Shi	Me	Ko	Yi	Xia	Ga		Seki	Mo	Ho	Ko	Shin	Yuan				Gen	Guo	I	Ke	Do	Shoku	Cui	Yi	Tai	Jun	Jun	Cyun	Ko	To				Li		Dian	Ki	Shu	Xi	Tan	To	Sho		Bi		Dao	Bian	Mei	Li		Ketsu	Sou	Ko	Sa	Lim	Ko	Sho	Yu		Ketsu	Liu	Gui	Ke	Do	Gin			Yi	Gin	Xi	Yin	Sho	Sho	Ten	Saku	Ke				She		Gen	Ko	Wo	Ten		Sui	Batsu		Go	Pi	Yo	Gen	Lik		Ko	Co		Yue	Hong	Rap	Bo	Li	Fu	Ketsu			Rei			Lou	Jue	Xian	Day	Day		Kei	Dian	Teng		Li		Sho	Rot	Gen			Tu	Ko	Kyo	Ko		Jian	Kyu	Bo	Bai	Di	Zhang	Tai	Kyo	To			Yu	Leon	Kyo	Tei		Dui	So	Riku	Ka	Yu	Can	Tu	Rui	San	Sei		Kyu		San	Tan	Ji	Qi	Shan	Nian	Hon	Sei	3	Di	Han";
    case 523:
      return "Chiku	Fun	Ka	Bo			Guan	Ki	Bi	Tranh		Xing		Zeon	Sei		Sei	Kyo	Cut	Zhen		Bo	Bo		Sei	Sa	Ki	Mo	Han	Fu	Kyo	Ko	Mot	Han	Tao	Bang	Yi	To	Do	Shu	Setsu	Fuku	Biao	Shun	Xi	Kai	Jie	Ki		Hi	So	Ko			Jin		Botsu	Ki	Yu	Ho	Hon		Qian	Hei	Jaku	Toku	Ko				Shi	Ho	Si	Jing	Ka	Chi	So	Ko	Kei	Shi					Han	So	Kan	Jing	Sei	Shin	Jaku	Ben	Shin	Zen	Jaku		Shun	So		Ton	Tro	Sui	Ho	Ju	So							Zha	Li	Ryu	Yo	Ko	Zhuo	Ju	Sen		Kai	Bian		Yo	Shun		Shi	Tun		Satsu		Bi	Setsu		Fei	Shi		Ei	De	Sai	Zhu	Shu	Fu	Jeoi	Shutsu	Ju	Kyo	Hen		Yu	Ren	Ran	Sai	Yi	Ko	Shi	Ya		U	Chi	Gua	Zhi	Yu	Go	Kan	Sho	Sho		Reng	Leo	Kyo	You	Yu	Bo		Ji	Pin	U	U	Ying	Yang	Mang		Kichi					Kyo	Long	N	Sa	Chuan	Soku	Ci	Wu	Ren	Duc	Jyu	Ri	Dai	Ji	U	Yi	Rin	Ran		Kitsu	Huo	Gua	Ka	Zhe	Pi	Jin	Kan	Za	Ban	Jie	Ko	Rin	Hou	Tei	Tei	Xian	Hui						Cai			Zha	Dai	Ge	Setsu	Pi	Hin	Pian	Shi	Liang	Yue	Hu	Bian	Go	Ku	Reng		Reng		Waan	Danh	Zi	Tuou	Luk";
    case 524:
      return "Dieu	Gay	Ngoen	Nham	Yi	Zhi	Kitsu	Jin	Weng	Chao	Hitsu	Qiu	Mut	Zhu	Hi	Zha	Po	An	Ja	He	Bo	Chu	Yan	Ko	Ko	Katsu	Shi	Hu	E	Ki	Fuku		Keoi	Kin				Jaku								Meo					Eot	Phinh	Shi		O	Lou	En	Tuo	Dai	Wai	Po	Rong	Ju		Bo	Tam	Dat	Nip	Mieng	Quai	Dang	Hoet	The	Rin	Se	Ro	Nhai	Phom	Tei		Yu	Dou	To	Gui	Shou	Setsu	Jin	Suo	Ni	Zhou	Long	Bing	Zun	Ye	Ran	Chi	Ling	Sa	Hi	Tei	Lei	E		Zhong	Ji	Kun		E	Shu	Kun	En	Zuo	Kun	Tei	Na	Yun			Vo	Ming					Haau														Xie	Zui	Shu	Diu	Fa	Ren		Bang	Han	Hong	Yi		Yi	Gatsu		Ke	Yi	Hui	Zheng			Gan	Thau	Hao	Dau	Huyt	Nho	Lai	Nhung	Thuc	Tre	Gatsu	Yaku			Yu	Jing	Kai	Gin	Ge	Rin	Shin	Nou	Qie	Ben	Die	Nan	Ji	Yi	Yi	Getsu	Fu	Shuo	Shuo	Yong	Ken	Hua	Hong	Rei	Mon	Sai	He	Rin	Tei	He	Qian	Qia	Tei	Si	Ce	Bang	Uc	Loi	Bei	Keoi	Caau	Dap	Xac	Nhu	Thay	Cai			Fau	Jue										Hoi			Ho	Jing	Ke		Ko	Kai	Jin		Ai	Lou		Tu	Kyo	Kei	Chuang	Rin	Rin	Song	Cheng		Wei";
    case 525:
      return "A		Nu	Koku	Jiu			Bin		Ngoen	Ro	Phao	Nhanh	Nhan	Oc	Mang	Nuc	No	Renh	Day	Chieng	Miu	Voi	Do	Thon	Bo	Toac	Gung	Ke	Uong	Ban	Me	Bieng	Xiao	Sheng	Hou	Vum	Ngoam	Zhu	Sei	Guan	Ji	Setsu	Ji	Cho	Xi	Fun	She	Ou	Hu	Ta	Xiao	So	Zao	Ai	Keki	Bo	Qi	Wa	Tuo	Dao	Rin	Na	Hi	Shi	Shu	Ran	Ko		Ka	Daam	Keu	Mui	Hong	Zen	Net	Ji	Zaat	Gu	Xap	Mep	Ku	Sai	Gen					Mun		Ngan						Zhai	Satsu	Kaku	Ya		Go	Wu	Zhen	De	He	To	Ang	Pi	Se	Fen	Gua	Kyo	Ji	Ka	Po	Ming	An		Xuan	Han	Gang	Ba	Zong	Meng	Faat	Huo	Pe	Tham	Nhu	Sua	Ngoam	Ga	Treu	Moi	Vieng	Se	Bang	Pha	Ria	Can	Chum	Be	Phinh	Nghenh	U	Dat	Beo	Quai	Nhau	Wong	Suc	Sat	Bop	A	Kieng	Zai	Sua	Nhinh	Ep	Tre	Troi	Du	Mai	Suong	Kung	Meo	Dian	Xi	Ko	Ko	Da	Nang	Ro	Hei	Chut	Diao	Luo	Ke	Kei	So	Ki		Yi	Jue	He	Ko	Ji	Kyo	Kan	He	Nie	Run	Qian	Dai	Shao	Ke	Zhu	Saku	Shi	Lu	Jia	Pian	Hou	Ji	Ta	Chou	Wo	Jing	Po	Zhai	Xin	So	Sui	Bian	Gen	Shu	Xu	Sa	Ki	Ko	Ki	Gu	Jie		Yuri	Xian		Phao	Danh	Mieng										Hi								E		Bo	Piao	Jiku	Saku	Kyoku	Za";
    case 526:
      return "Ko	Pai	Tu		Ying					Kak	Tap			Mei	Naa	Ge	Kam	Soek	Bou	Quat	Niu	Dan	Ling	Xua	Tuc	Song	Cau	Ten	Ten	Saap	Dum	Bai	Bi	Huc	Phuc	Hong	Giai	Ke	Khan	Khac	Lay	Ren	Vac	Tau	Xam	Shi	Xiang		Yu	Nuo	Ge	Bo	Xie	Kyo	So	Fu	Zhen	Yu	Ni	Sho	Moi	Chia	Map	Dan	Xun	Wa	Shi	Ang	Han	Hong	Dan	Hi	Nuo	Sho	Cao	Ji	Neng	Yong	Xiao	So	Chua	Yao	Ko	Ge	Tang	Bao	Chan	Tatsu	Xu	Ketsu	Un	Hai		Chou		Jian	Zuo	Ko	Koku	To	Wei	Da	Pi	Sho	So	Gun	Fu			Ko		Be	Bem	Khu	Chu	Git	Quan			Ngo	Kam	Lan	Maai	Zam	Ria	Cay	Chiu									Hei					Gwe		Ba	Shi	Huan		Xi	Gai	Pen	Liu	Mu	Mie	Lang	Tui	Ban			Ge		Ku	Lung		Jia	Bo	Tetsu	Chiu	Choi	Dieu	Ri	Trou		Leu	He	Bong	The	Vong	Xang	Hung	Chan	Ghe	Hat	Chac	Naap	Choac	Tim	Ri	Que	Cop	Xui	Suot	Chau	Ngoan	Do	Guong	Ngon	Han	Oang	Bep	Gian	Dai	On	Quat	Tuech	Bua	Kyo	Huan	Sei	Zu	Luo		Ngoam	Thoi		Sai	Sei	Li	Zeot	He	Mo	So	Shui	Shen	Kang	Chi	Ling	Luo	Ko	So	Yan	Zhao	Chua	Gu	Qin	Cho	Tan	Fen	Tu	Ko	Shoku	Tatsu	Fu	Ling		Ugai	Lang	Mang	Baku	Hen	Zi	Tim	Aa	Bai	Dau	Moi";
    case 527:
      return "																					Paai	Lan	Zan	Wu		Hai		Ketsu	Li	A	Lue	Zhi	Chou	Jiang	Setsu	Jian		Maan			Lun	Yi		Shang	But	Ngai	Ho	Kang		Nhoi	Can	Khoach	Danh	Nin	Thay	En	Gan	Dan	Ji	Biu	Mach	Song	Ran	Ngau	Xo	Dan	Zap	Tham	Thung	Nuot	Nat	Thin	Tham	Mon	Nac	Syut	Ram	Nhai	Ham	Ngo	Xia	Neng	Ngon	Thua	Thep	Giuc	Nhan	Hang	Nha	Chong	Oam	Yi	Nin	Hon	Zuki		Hui	Haku	Zha	Kik	In	Han	Tetsu	Yin	Bi	An	Xia	Ni	Tei	Tei	Tei	Di	Jian	Pan	Han	Zen	Yu	Chuai	Za	Kyo	Cha	Gin	Zhe	Se		Pen	Gu	Zhe	Gei	Shoku	Sho	Zen	Yo	Li	Dou	Yu	Chou	Da	Zui	Po	He		She	Long		Nha	Treu	Thue	Doi	Qi					Ngoang							Shu	Kin	Jin	Ling	Hi	Kyu	Kang	La	En	Xu	Jin	We	Chuan	Kyo	In		Yue		Bang	Zaa	Ging	Vao	Seu	Nuot	Zen	Giam	Toet	Nhun	Nhap	Hang	Sao	Si	Xep	Moi	Ngau	Kan	Mai	Xie	Jiu	Ji	Kitsu	Yue	Yo	Ten	Kai	Jian	Ban	Han	Katsu	Sa	Hui	Qiao	Hyu	Se	Zui	Ho	Cho	Lu	Hua	Chu	Shan	Wo	Ji	Zhuo	Xian	Yi	Guo	Kui	Gin	Sho			Gaa	Saau	Soe	Wet	Am	Ngui	Sut	Nhao	Dat	Lem	Ngay	Khan	Choan	Nhao	Ngat	Nham						Gi";
    case 528:
      return "		Loi					Dong									Cho	Zhou	Ho	Rei	Lu		Bo	Shi	Ying	Ku				Nam	Zip		Bei	Nich	Tuong	Can	Du	Phao	On	Oai	Bo	Lok	Voi	Bam	Tui	Cau	Neu	Chuyen	Thoi	Hao	Goi	Quan	Ua	Khoac	Ngon	Ron		Zhi	Xie			Ye	E	Lu	Han	Ye	Chi	Saku	Utsu	Zan	Luo	Chuo	Fan	Zhi	Ying	Wen	Wa	Ai	Yu	Am	Eki	Hua	Kitsu	Lie	Jing	Za	Gyo	Kyo		Khay	Hon	Non	Wo	Hang	Xao						Cac			Zang	Dui	In	Ji	Shi	Gin	Hai	Wo	Dyut	Ji	Xi		Zhan	Tuan	Gan	Zit	Doeng	Kwaat	Do	Ngon	Ziu	Pheu	Cha	Thot	So	Khao	Xong	Ngo	Hun	Pho	Mom	Reu	Mom	Buk	The	Yu	Tan	Xin	Eng	Loc	Lie	San	Han	Zhi	Shi	Seki	Lao	Lai	Wei	Pao	Chi	Ying	Dou	Setsu	Dou	Gei	Bao	Qie	Shu	Kyo	Zhi	So	Tan	Sho	So	Gin	Lie	Ze	Peng		Zhe	Ngau	Rang	Ran	Dang	Ray	Troi	Lin	Nhanh	Ketsu	Khoan		Thom						Ou		Leng	Xie	Ji	Lai	Ying	Ceng	Bai	Aak	Gaa	Khe	Tron	Nhang	Chem	Phan	Doe	Dan	Thanh	Boc	Bo	Treu	Gung	Le	Mua	Nhom	Mut	Ren	Ngoi	Xac	Lun			Hi	Long	Xi	Sen	Laai	Ton	Lin	Heoi	Ki	Gui	Kai	Gen	Sho	Ka	Chu	To				Xing	Ceoi		Sek	Li	Ci	Chen	Gheo	Dang	Theo	Nho	Phac	Thot";
    case 529:
      return "La	Lum						Qing	Kei	Do	Kitsu			Ruc	Gam	Ham	Ung	Jian	Dao	Jian	Qing	Xie	Ying	Haku	Ki	Saku	Sho	Ki				Ha	Zen	Zhe	She	Mi	Huan	Liem	Lom	Dang	Non	Khan	Toe	Khem	Hun	Thung	Ren	Jik	Tot	Cu	Ru	Sa	Huo	Yi	Tei	Di	Yo	Luan	Hyo	Yi		Soe	Can				Bo	Pang	Tan	E	Zang	Cong	Laa	Dang	Bun	Hum	Gion	Nheo	Trom	Lai	Lanh	Ngong	Nhau	Zhai	Gen	Xi	Mang	Geki	La	Yun	Gin	Zan	Ho	Gen	Kan	Sho	Xang	E	Gam			Die		Nan	Them	Dem	Nguyen	Gheo	Hoai	Guan	Gen	On	So	Huan		Khuyen	Gen	Shi	Jian	Ngay	Kan	Zhan	Ji	Huan	Han	Kan	Gen	Tan	Gwang	Nhau	Xon		Nhep	Wan	Luo	Wok	Sac				Keu	Sac	Ten	Dou	Kan	Gan	Kan	Chu	Go	Lian	Trom	La	Hen	Giem	Gu				Giau		Jitsu	Ki		Nie	Nan	Jiu	Yue	So	Ryo	Yao	Chuang				Can	Li	Dun	Nan	Nan	Kotsu	Chu	Ko	Mo	Kotsu	Ri			Koku	En	Yue	Kei	Koku	You	Jitsu	Yin	Yu	Guo		Kotsu	Kei	Dang	Kotsu	Ho	En	Kai	Kaku	Koku			Zhen	Mi	Die	Ro	Koku	Zhen	Jitsu	Yo	Doe	Kua	Choku	Han	Song	He	Ji	Zhe	Moku	Men	Ko	Bing		Wei	Tou		Tu	Ko	Sho	Gang	Lou	Quan	Hun	Zhuan	Que	Tai	Hong	To	Dang	He	Tai	Guai	Getsu	Yu	Nhot	Ya	En	Bo	Wan";
    case 530:
      return "Qun	Kuni				Jue	Ou	To	Chuong	Quan	Zhi	Kon	Bo	Ling	Wu	Xin	Da	Koku	Yuan	Yuan		Ken	To	Mo	Bo	You	Zai	Waan			Wu	Kan	Zhang	Chuong	Kin	Xuan	En		Rao	Gun	Yu	Chuong	Man			Goku	Xia	Bian	You	Yu	Yin	Kin	Xuan	You	Lei	Kin	Yu	Yu	Tron		Ting	Do	Ei	Zhen					Zai	Ga	La		Zai	Que	Ki				Ju	Ji	Chun	Da	Tun	Ai		Kuro	Cong	Zi	Ho	Ki	Huang	Yi		Ki		So							Ngo			Bao	Chi		Chi	Ri				Tan	Kin	Chi	Lu	Cho	Shi	Jie	Shi		Zuan	Sai	Sing	Loc	Tum	Moc	Tai	Yi	Sa	Han	Fen	Fen	Shi	Shi	Shi	Mo	Hi	Ho	Ta	Shu	Sa	Shi		Saai					Hachi			Za		Ao		Pi	Ping	Po	Jia	Zhou	Tan	Qiu	Ho	Cho	Ko	You	Tan	Juk		Rong	Ko	Mi	Jyun	Kura	Tin	Chau	Cho	Sanh	Dei	Ta	Yi	Gin	Rong	Shu	Bi	Lie	Qiong	Ho	Taku		Ray	Nieu	Nen	Loi																				Kure	In	Hui	Ji	Dai	Shi	Shi	Ko	Gao	Ho			Kwai	Zeon	Cat	Vach	You	Cha	De	Yin	Yu	Yu	Bei	O	Bo	Gyo	Ro	Za	Gin	Shun	Ki	Kan	Sa	O					Hake	Bit	Lo";
    case 531:
      return "Bet	Kei	Fan	Kok	Ce	Fat	Yo						Gin								Qiao	Ko	Ko	Kan	Jo	Tai	Cha	Ya	Xin	Yo	Chi	Gai	Day	Dia	Ham	Zao	Kui	Aku	Fei	O	Hi	Ta	Guai	Dai	Dai	Duo	Bo	Ya	Dei	O	Gui	Yoku	Zhi		Baan		Hi		Mang			Dam		Genh					I						Fun		Chan	Nao		In	Hu	Chi	Tao	Chi	Taku				Che	Vung	Lam	Dum	Mun	Nui	Them	Xui	Shoku	Yi	Go	Ben	Nie	Zhai	Huan	Hotsu	Du	Taku	Qi	Ce	Boku	Kon	Chui	In	Batsu	Zo	Da	Ki	Cho	Zeon	Zhi	Geng			Ju	Weng	To												Ho	Du				Chi	Sai		Gei	An	Kuo		Wo	Gi		Retsu	Ying		Pian	Bun	Nam	Coi	Trieng	Hang	Gieng	Mo	Ngoi	Chau	Me	Ngoi	Ngoi	Bai		Ko	Ko	Zha	Zhua	Thong	Su	Kai	Chi	In	Dai	Ni	Gung	Sai	Ei	Koku	Kin	Shin	Zhu	Chan	Kai	Fu	Beng	Ni	Zhi	Hui	Ten	Ei	So	Long	Joeng	Chi																Ta	Xia		Zhi	Xi			Jiang	Dum	Hong	Luong	Ma	Xo	Ngach	Tret	Xay	Bui		Dui	Fu	Taku		Jiao	Chao	Bai	Fun	Ra	Ki	Kin	Gin	Lie	Fun	Shin	Shi				Ao	Dap	Gei";
    case 532:
      return "									Dai		Zao	Chu		Ko	Tuo	Ho	Boku	Hao	Kang	Yin	Hi	Xian	Hoc	Nut	Dat	Ngua	Zan		Fu	Bie	O	Kui	Tai	Fun	Fuku	Qie	Sa	Da		Je	Shun	Jin	Shi			Ve	He			Kei	Kin						Kei					Tei	Da	Ye		Sen		Zhang		Liang	Gaku	Dui	Fuku	Ta			Lao	Xun	To			Gam	Chum	Kwan	Sam	Doi	Thoai	Zhi	Taku	Ku	Ko	Rin	Lan	Sui	Wo	Shoku	Kan	Cho	Ku	Ra		Ban			Neo	Cat			Kure	Soku	Jian	Vuon	Con	Gom	Con	Den	Vong	Jiang	Ai	Tai	To	Sei	Zhui		Shuang	Yu			Sa	Ki	Yu	Lan		Ten		Kotsu	So	Yu	Ko	Qian	Ju	To	Lie	Shi		Shu	Xian			Gai	Mun	Dao									Fun	Tai	Kin	So			Tian	Hin		Ech	Cau	Ghe	Nieu	Suong	Meng	Tsui	Di	Jin	Mian			Joeng					Chat	Keki	Kai	Hui	Chi		Bai	Dung	Loi	Vung	Am	Xep	Cho	Ghe	Duo	Hai	Duoi		Lie	Vai	San	Gaku	Jun	Lai	Yin	Lan		Jiao	Da	Huo	Haku	Kon	Kaku			Doc	Chinh	Tho	Ranh	Chem	Guo	Kai	Chen	Zhan		Wan				Chi	Mi	Ngoi	Chum	Kui	Yo	To	Sho	Fun	In	Gin	Duo					Gaku	Fan	Ray	Yin";
    case 533:
      return "	Cho	Sai	Nan				Lei	Sho	Ri	Juku	Ton		Chau		Yo		Lom	Nen		Lan	Gong	Ben	Kaku	Chin	So	Jin	Ting	Yao	Kei	Wang	Hyo				Jie	Sa	Ko	Ko		Xiu	Wa	Shu	Ko	Sai			Ki	Ka	Wei		Ko	Yu	Ko	Kon	Ko		Itsu		A	Dai		Itsu	Trau		Zhan					I		Un	Ang		Itsu	Itsu	Itsu	To	Sang	Chou	Chu	Kua	Sei		Gaku	Ju	Hai	Ro		Kaku	Ko	Kutsu	Shi	Boku	Yo	Hoku	Hoku	Mian	Cho				Hang	Fuku	Ban	Chou	Ban	Ko	Ka	Ling	Yo	Zong		Sho		Fuku	He	Shun	Hing		Yo	Gyo	Ka	Kon	Kon	Ka	Ki	Kon	Kiku	Kwai	Ka	Gai	En	Hoku	Ta	Ta	Kun	Shuku	Eki	Zhong	Ya	Zhao		Die	Gou	Yun	Dan	Nuo	Shuku	Hing	U				Bing	Kyu	Ran	Chan	Chi		Nhom	Rong	Yin	Chan			Zhi	Kai	Ta	Guai	Nuo	Shen	Da		Su	I	Bon	Wo	Chi	Kyo	Dem	Baku		In	Ta	Mie	Zhi	Sanh	Shoku	Qi	Ka		Gou	Sai	U	Gom	Ve	Lou		Zi	Nhieu	Nhieu	Lam	Yo	Dang	Tum	Xian	Muong	Rou	Kai	Ritsu		Eki		Peng			Jo		Hatsu	I	Xi	Kai	Nai	Sei	Kua		Gui	Chun	Jie		Tei										Jie	Xi	Ka	Ku	Gioi	Gu	Zha	Fan	Gun	Hitsu	Xie	Gun	Go	Go";
    case 534:
      return "		To	Ban	Tei		Ka	O		Futsu	Fan	Hei	Kai	Huan	Ko	Niao	Xi			Hau						Taai		Cu		Gun	Ban	Kan	Ro	Xi	Kyu	Ho	En			Qia		Kon	Mang	On		Zhe	Mat	Lon	Juan		Bo		Bie	Itsu	So	To	Ken	En	Shitsu	Ko	Shitsu		Zong		Bie	So			Kei	Quan		Ketsu	Ho	Ko	Shin	Xi	Tai		Jiao	Ko	Quan	Zhi	Tian	Kai		Shu	Ketsu	Ren	San		Sai	Zi	Datsu	I			Shi	Gang		Jie	Kan		So	Muong	In	Shoku	Bie	San	Dou	Zui	Chitsu						Canh	Nhon	Yan		Datsu	So	Sai	Mu	Hetsu					Bi		Xon	Kech	Kuai	Ketsu	Yan	Wei	Shitsu	Huan		Hao		La	So	Seki	Gong	Fan		Meng			Lei		Di	Lon	Bing	Huan	Co		Wa	Jue	To	To		Hi		Hai	Hi	Chi					Ba	Jiu	Ko					Aken			Di	Maa	Zhang	Jyun	Da	Shi	Hao	Shu		Tong	Mat	Ji										Ye	Un	Ta		Kai		San	Daan	Gai	Taai		Bi	Pi	Yao	Ko	No	Di	Can	Pin	Yue	Qie	Pi	Gen		Nua		Bing		Kaa													Tuo	Xie	Zi		San	Jau	Wing	Juk	Ye	Dai";
    case 535:
      return "Fan	Gua	Hu	Ru	Setsu	Ryo	Ketsu	Kei	Sai	Ran	Fou	Huang	Sai	Zat	Datsu		Syu										Ru	Sai	San	To		Nin		Ko	Mao	Do	Di	Dui	Hui	Xi	Xiu	Kitsu	Do	Ran	Yi	In	Ka	Zhe	Ru	Ji	Gao	You	To	Pu	Katsu	Hin	Ru		Hang	Saam	Wui	Sai					Sho	Bua					Chu	Cu	Zhe	Niao	Shin	Qie	Kan	Hin	Cha	Hi	Niao	Sui	Kep	Va	No	Kwan		Cha	Cheng	Yao	Du	Wang	Hi	Nian	Mi	Bi	Tetsu		Lau	Setsu	Nou	Xi	Ru	Yao	Kon	Chan	Bou	Mou	Ji	Dai	Laai	Fan	No	Zi	Jyun																							Can					Hei	Ki		Sho	Ru	Vo	Di	Bong	Xie	Mie	Keng	Ko	Cu		Sheng	Pan	Hu	Kyo	Ke	Xian	Sen	Hou	Qiong	Zong	Ju	Un	Fu	Nai	Tetsu	Ni	Kyo	Ku	Ci	Leoi	Ping	Gwai	Ping	Wun									Nen					Jyun				Fui					So	Ge			Sen	Hou	Yo	Ai	Yoku	Shi	Ba	Kan	Jo	Sing	Jing	Bing	Goeng	Sui	Xiu	Cong	Jiao	Kei	Zha	Xiao	Lian	Qu	Da		Shan	Xie	Shi	Gong	Mie	Chai	Ki	En	En		Kai	Dou	Tai	Go				Zi	Haa	Jan	Fui	Sa";
    case 536:
      return "						Kou	Nayamu	Ri		Tiao	Shi	Pi			Sang	Sen	Saku	Guan	Ki			Hao	Zhi	Yang	Tong	Bi	Dan	Mo		Fu	Zuk	Tong	Sen	Riku	Cuoi		Qiang	Shi		Tai	Gin	Mun			Syut										Joku	Sei	Zhi	Wing	Zou	Sou	Bei		Niao	Juan	Shitsu	Yang	Cho	Huang	Leo	Min	Todomeku	Beng	Mo	Chao	Ru	I	Sen	Lu	Shao	Bu	Zeng	Si	Shu	Zui	Yue	Zan	Luan	Shi	Ta	Bi	Sei	Rei		Seon	No		Ging	Cong	Guk	Gei	Qu	Doi	Di	Bo															Ling		Hetsu	Miao	Mei	Ru	Kan	Bi	Teki	Zhuan			Haan	Man	Wan	Do	Yo	Dang	Ju	Yuan	No					Sau	Tatsu	Ju	Kai	Ei	Hui	Qi	Yo	Yun	Ko	Man	Ren	Mo	Ki	Jing	Co	Wo	Kwan	Jyu	Ei														Piao	Seki	Jin	Ryo	Yo		Tatsu	Ken	Yao		No	Vo	Onnanarukami	Gam		Chi	Ni	Sou	I	Niu		Bu	Ei	Shu	Wai		Piao	Sen	Ei	Shin	San	To	Hin	Soku		Han	Ban	Soeng	Gaa	Mung	Caai							Yao	Yo	Nei		Kan			Mai	Cuoi	Ba	Shi	Boku	Yuan	Ryo	Cai	Jie	Sho	Ken		Sen				Fu	I	Xie	Wai	Sen	Shi	Yan	Xiao	Jo";
    case 537:
      return "Un	Hin		Gaan	Haan	Can			En		Chua	Xie	Li		Fan	Setsu	Coi	Coeng	Geoi	Moi	Moi	Haa	I	Zhu	Dai	Na	Hyo	Zhuan	Ji		Kui	Gioi	Re	Ken	Luo	Ren	Shaku	Shuku		Bou	Ren			Qia	Waku		Sen	Rui		Ran	Den				Wan		En	Han	Fu	Lyun	Ketsu	Shu	Son	Cheng	Ho	Yi		Ko	Zi	Son	Hao	Botsu	Jiao	Haau		Hui	Nhat	Xiao	Ci	Botsu	Shi	Shun						Yo	Hou	Chau	Ga	Shu	Ji	Ji	Ji						Noi	Dua	Ni	Laai	Ni	Ti	Seon			Fu						Kyo	Nit	Con	Ju	Sei	Ming	Ketsu	Tetsu		Me	Li		Zhong	Long	Xu	Chu	Qiong	Fu	Su	Bin		Gu		Ji	Kan	Dai	Qi	Xi	Gi		Ki			Deng	Er	Mun	Ju	Ju			Shu	Tong	Xiao		Pi	Ki	To	Cho	Getsu				Rot	Dan	Ko	Ji	Chat		Ko	Nhang			Ko		Xiao			Coi	Cong		Kan		Bin	Rong	Bo	Totsu	Shu				U					U			Hin	Gwai	Mian	Hin	Mo			Mian		Shu	Xiao	Bao	Wa	Seki	Pao	Ka	Fu	Taku					Tei	Niku	Gai	Seki	Hu	Heng		Zhu	Guai	Taku	Ki	Ko	Gui	Yo	Zik	Ho	Gai	Giua	Coi						Dai	Kan	Jaku	Bin	Huang";
    case 538:
      return "Cha		Go	Kyu	Xia	Ju	Gi	Yao	Sen	Go	Ken	Mei	Giua		So	Gun				Ritsu	Sai		Fen	Zao			En	Feng	Seki		Shin	Go	On		Ju	Yu		Ko	Shin	Sai	So	Hun				Cung					Jie	Xiong	Ning	Nai	Mei	Kyo	Chu	Giu	Tru	Nou	So	Sheng	En	Yu	Ten	Shin	Huan	Geng	Wan	Gaa	Tuo	Qiao	Byo	Kyo		Ning				Hin									Yin	Ka	Jia	Hekutaru				In	Shin	Suo	Cho	Jie	Xi	Weng	Sen	Ho	Shin	Mang	In			Etsu									Yang	En	Yao			Shin		Mang	Ou	Soku	Gi	An	Ri	O	Cho	Lou	Kyo	Chua					Seki		Bo	Sen	Ten	E	Zi	Ho			Mitsu	E	Bei	An		Hin	Xum		Huo	Sei	Ceng	Kan	Shin		Sai	Kyo	Cho										Xiong	Ji	Jitsu	Zuo	Shuku	Qi	Kan		Senchiaru		Zheng	Co	Ko	Ki	Gu	O	Ji	Qi	Juan	Ning	Kyu	Hin	Sho										Rem		Shin	Ten							In	Ben	Kan	Ryo	Yu	Se		Sao			Ru	He	Rong	Qin	Kin	Sai		Lan	Ju	Kiku	Kan	Li	Seki	Ryo		Soku		Shi	Lung	Ho	Ni	Xian	Fu	In	Soku	Ru	Kan";
    case 539:
      return "	Xiong	Gui	Kyu	Ji	Ten	Meng	Fu	Xuong	Sai	Yu	Jiao	Meng	Long	Qiang		Mi	Go	Gei	Yi		Long	Han	Ni	Lao	Seng	Sei	Nei	Lin	To	Yu	Shuku	Shaku				Sha	Nuo		Shuku	Kei		Tai	Wu	San		Shu	Bian	Jin	Kei	Bian	Xuan	Shu	Jian	Cam	Tac	Bian	Do		Jin	Gang	Hyo	Ju			Riku	De		Cyun		Son	Zhuan	Ryu	Ban	Tai	Rong	Bo		Do		Shuan	Do	Chi	Hyo		Shi		Ji	Jia	Ki	Maba	Hui	Mon	Bei	Zhan	Sa	To		Bai	Lie		Xie	Bun	Chut		Hitsu		Shuku	Be	Jian	Shou	Ma	Xiu	Chut	Trut	Kao	Gwik			Guan	Luan	Byo	Nhi	Nhon	Hi	Gwik	Nou	Chang	Sei	Hi	Gwik		Hoen	Nhe	Mon	Chut	Nho	Mon	Dep	May	Be	Chut	Liang		Sho		Ot	Choai	May	I		Hoan	Mo	Nai	Ru	Nit	Xiu		Zhi		May	Ma		Be	Be	Be	Cao	Ki	May	Be	Khi	Nhen	Mon	Nhon	Mon	Teo	Li	Geki	Tho	May		Chuong	Chuong	Hen	Nhon	Mong	Hen	Lan		Nhon	Nheo	Chan	Oat	Wang	Wong		Li			Wu	Pao	You	Yu	Gan	Ho	Kan	Mong	An	Xiu	Shui	Rui		Kai		Kutsu		Ban	You	Ho	Sa	Katsu	An			Katsu		Huo			Hui		Yo	Zuo	Xiao		Mian		O	Keki		Ga	Yuan	O	Bo	Chao	Tui	Shu	Bo	O		Tai	Tei		Ga	Ki	Tiao";
    case 540:
      return "Na		Wai	Yo		Hu	Nie	Shutsu			Kotsu	Hui	Lou		Ti	Ghenh	Qiao	Qiao	Zhong	Ro	Shu	Sho	Di	Shu			Lin		Shu	Quan	Zhuan	Ra	Lei	Kei	Xie	Shi	Gatsu	Ren	Shoku		Dang	Ryo	Du	Nian	Shin	Yo	Gatsu	Shi		Ji	Xian				Kan		Kek	Zhi	Shun	Hi	Ko	Ai	Ci	Pu	Koku	Shi	Ton	I		Qu	Shu	Dian	Kyoku	Xiao	Shui	Yu	Huan	Gai	Ken	Ka	Yi	Juan	Ton	Bi	Zhi	Bi	Kubo						Zhao	Sai		Yo	Koku	Tetsu	Shi	Xu	Nyo	Sai	Shi	Ko	Ko	Thuoc						Long	Tyun	Zhu	Bi	Suo	Nyo		Go	Die	Gang		Qu	A	Ke	Hu	Ju	Eki	Qing	Cho	So	Oku					Ve				Ji	Bing	Hi	Ki	Nyu	Shi	Kutsu		Shi	Ti	Shi	Jue	Nyo	In	Qiu	Ko	Hen	Ei	Ko	Ri	Ha	So	Ke	Jiang	Va	Sang				Hi	Yun	Vai	Gwat	Mei	Pi	So	Qu	So	Kuwa	Deki	Shi	Bi	Kutsu					Gun	Mi		Tai	Ti	Ngoe	Xai	Kai	Cuoi	Bi	Kei	Qu	Ryo	Shon	Shun				Ku	Va	Tiao	Ri	Chu	Ve						Ju		Xi	Cut	Cuoi	Rot	Lin	Ku	Shi	So	Do	Do	Do	Toi		Hei		Vo	Duoi	Ro	Ro	Chi	Ji		Cu			Cuoi	Lu	Cu	Cu		Li	Voi	Via	Bi		Noc	Jue	Shi";
    case 541:
      return "Ho	Sen	Han		Shi	Zhu	Lu		Kyoku	Vom		Bai	Ko	Ko	Nie	Sei	Sei	Sei		Shi	Quan	Bai	Nan		Ko			Doku	Shin	So	In	Nan		Hon	Nhon		Shu	Chi	Kun	So	So	Hon		Riku	Hai	Ya	Gai	E	Ko	Hu	Ngai	Gaku					Ki			Ki	Ha		Ki	Kan	Mang	Ngai				Hoki	Zi			Wu	Gitsu	Gitsu	Cha		Kan	Sen		Qin	Jie	Hong	Ko	Dan	En	Ze	Hu	Ang	Jie	Fu	Yong	Zung	Feng				Nagi										Mu		Chi	Ho	Ryu	Ki		Fun	En	Boku	Se	Cong	Eki	Gaku	Ko	Kang	Tan		Koku		Nui	Dun	Yao	Ai	Bao	Ha	Po	Mitsu	Shi	Fan	Da	Ju	Pi	So	Wei	Ku	Qie	Gan	Futsu	Gaku							Shima		Gan					Sako	Kuang	Sui	Beng	Jia	Ya		Ngan	Ko	Kan	Nie	Ko	Xing		Xi	Bo	Lin	Duo	Gaku	Chan		Gong		San		Pui											Ho	Kan	Ko	Shi	Sei	Dou	Dui	Ho	Jiang	Yu	Lu	En	Ci	Gaku	Gu		Wei	Che	Huan	Bie	Da	Tei	Han	Tui	Na	Qi	Ro	Tou	Yuan	Wang	To	Wu	Gao	Setsu	Gin	Keng	Sui	Yi	Sing		San	Shi										Xiao	Jin	Gui	Ya	Sui	Song		Zhuo";
    case 542:
      return "	Sui	Tu	Xian				Deo	Ze	Li	San	Shu	Zhu		Jie	Voi		Ti	Rotsu	Kyo	Xie	Qiong	Kai	Ya	Ju	Kin	San	Yin	Zhi		Kan	Zi	Tai	Ke	Getsu	Nie	Qiang	Wan	Ze	Bin	Ju	Ki	Zi		Tai							Gyo	Ken	So		Kei						Zik						Ryo	Ya		Doku	Lin		Qi	Gin	Bin			Hui	Ko				Qi	Ho	Yang	Sui		Qi	Gui					Ghenh	Chom	Nghi	Ghenh	Qin	E	Kin	Zuo			Ze	Qi	Ji	Kei	Tuo	Die	En	Hui	Mao		Xu	Hon		Hou	Yan	Xiang	Cong	Hu	Sho	To	An	Kyo	Bing					Coeng			Ta	Duo		Lei							Zhu	Die	You	Qi	Shi	Xun	You	Kan	Qiao	Sen	Shu	Qiang	Pen	Ko		Quan		Ying			Laam	Ngong	Din	Sha	Wai			Tao	Ai	Hong	Pi	Yao	Katsu	Bu	Shun		Tu	Chai	Sai	Xia	Qi	Ken	Qiong		Getsu	Jin	Tai	Ryo						To			Zhen			Kutsu	Zhu	Ga	Xi		Weng	Zhong		Voi	Rang	Sui	Von	Ten	Ke	Kuo	Kang		Tetsu	Chao	Bi	Mo	Zhu	Han	Yu	Yi	Ma	Bi		Qi	Gun	Man	Liao	Lin	Zu	Lei	Hu	Chuang	Qi	Lei	Boku		Shun	Rin					Yo				Min	Shin";
    case 543:
      return "	Chi		Po	Die			Mom	Chop		Lei	Ki	Ken	Yo	Yi	Gaan	Bin	Gaku	Shin	Dian	Ko	Zeon	Dun	Gao	Hu	Ka	Xiao	Ga	Peng	Fun	Sei							Kan							Shen			Tan	Gaku	Wei					Shin		Vot	Rung	Sho	Dui	Chao	Yin	Kuai	Ku	So	Zui	Gu	Ta	Kyo	Yun	Zhi	Rei	Kutsu	Ji	Cheng						Ko			Sa	Shi	Sai	Xie	Xian	Ro		To	Zui	An	Hao	Saku	Ryo	Po	Zan	Di	Ye	Rin	Ga	Ro	Nao			Fai	Non	Sho	Rai				Jie	Bang	Lan	Cang	Tai	Bi	Riku	In		Gaku	Zhan	Qi	Kun	Lom		Ka		Nao	Satsu	So	Lu	Gaku	Kuang	Kyu	Mo	Rai	Lei	Pao	Jitsu			Ketsu	Sa	Li	Ceng		Dang	Lei		Kaku	E	Rai	Beng	Jue	Kai	Hei	Hei		Zam				Xuan	Nie	Sui	Hai	Ro		Doi	Doc	Lom	Xian	In	Jian	Mi	Nie			Ngoi		Rai				Cang	Song	Zeng	Yi			Gi	Chong		Cang	Ngong	Gi	Ra	Rai	Lei	Nuo	Li	Reki		Li	Luo		Rin		Tang	Rui	Gen	Nie	Nie	So	Ji		Lei	Rui	Nang			Lin	Ling	Ki	Zan	Xian	Yu	Kon	Zai	Quan	Lie	Retsu	Ko	Ko	Kon	Totsu	Yu	Huang	Kei		Sho		Ko		Yo	Ki	Shi	Nao	Shu	Xun	Jun	Ju	Huo";
    case 544:
      return "Ryu	Yi	Ryo	Sai				Shi	Shi	Shi	Xi	Se	Jiao	Yong	Ka		Shi	Kyo	Ki	Kyo		Shi	Jing	Wan	Ye	Jiu			Gong	Shin	Sa		Sa	Hui		Fu		Vang	Sua	Tron	Sang	Sa	Er	Bang	Lon	Giau	Sam	Sho		To	Lon		Yaku	Han		Kin		Chin			Fu			Kin	Fu	Zhuo	Ji	Sei	Gi	Seon				Seon	Xuc	Trang	Son	Va		Bang	In	Trai	Qi	Shi	I	Diao	Pei	Xian	San	Fu	San	Satsu		Chang	Yue	Ben	Gong		Wu	Bo	Fen	Fun	Hi	Chan	In	Nei	Jue	Ki	Zhao	Ban	Qian	Jin	U	Ao		Gai	Kei	Futsu	Wang	Zhong	Phuon	Huang	Ko	Bu	Zhu	Bi	Chao	Zheng	Fu	Kou	Do	Zuo	Xuan		Fu	Tei		Ki	Yao	Kei	Day	Bo	Du	Bei	Xie	Shi	Yi	To	Hong	Cui	Shi	Yi	Zhuan	Ko	Coek		Vua	Chi		In					Po	Rei	Taku		Yin	Ko	Ko	In	In		Chitsu	Eki	Tranh	Yuan	Keki	Bo	Shi	Kai	Jiong	Ko	Tai	Mao	Qian	Jin	Yi	Kun	Ko	Ko	Wu	In	In				Kun	Lei	Long	Bit	Vua	Shi	Shi	Bei	Huo	Cong	Kong	Sho	Sai	Sho	Sen	Ta	Chu	Han	Qian	Kan	Kon	Ki	Zhi	Toku					Se		Koku	Qian	Guo	Sho	Ko	Gun	Sho	Ko	Jian	Zhong	Mian	Gui	Shi	Mou	E	Ba	La	In	To	Bo	Zhou	In	Ji		Mei";
    case 545:
      return "Zao		Cho	Phoi	Zha	Yi	Saku	Gou		Ton	Gui	Ying	Shai	He	Bang	Mo	Meng		Sen	Wu	Dai	Kin	I	Jiong	Chiku		Gi	Chu	Han	Bau	Hei	Tong	Kou	Li	Zhi	Hui	Zan	I	Diao	Cu		Dai	Lau		Kyoku			Man	Yaku	Zhi	Sen	Kua	Da	Xiang	Hua	Liao	Cui	Qiao	Jiao	San	Xu	Er	Mei	Tuo	Tan	Zhi	Chu		Vai	Quat	Manh		Nao	Mao	Di	Ceng		Taku	Jiao	Lian	Sen	Sha	Dan	Betsu	Cho	Sui	Lian	Guo		Saku	Biao	Lung	Ci	Dian	Lu	Ni	Yan	Lan	So	Yoshi	Gai	Chu	Ki	Men	Ki	Bi	Zu	Hui	Chan	Lai	Xian	Fen	He	To		Lim		Beki			Ren	Yao	Zhan	So	Nei	Hyo	Luo		Yuan	Rem	Neng	Nan	Ran	Sai		Raku	Ei	Ren	Tei	An	Kin	So	Ko			Shuku	Sen			Phang			Nen	Hei		Ken	Ge		Jian	Ping	Lai	Nin	Hei	Bie		Nam	Jian	May	May	Bing	May	Tuoi	Ken	Nen		Mi	Hu		Yo	Cho	Diao		You	Yao	Beng		Chen	Ji	Ki	Yao	Yu	Shi	Dei	Si	Gwaan	Si			Shi	Guan	Yan	Doi	Sho	Ei	Shi	Zetsu		I		Yu	Kitsu	Kitsu	Yu	Chi	Ji	Sha	Yan	Yi	Yi	Che	Bu	Tei	Han	Huang	Ton	Khuya	Sen	Ren	Shui	Sui	Ren	Tan	Zhi	Hai	Fan	Feng		O		Fu	Tan	He	Mi	Pi	Bu	Na	Tian	Ba	Yi	Shi	Kei	Chi	Ki";
    case 546:
      return "		Yan	Ji	Tiao	Ka	Yao	Shen	Ke	Tong	Ko	Xuan	Ki						Kai	You		Bai	Chai	Yo	Roku	Xia	Lu	Kun	Zang	Qiu	Yu	Shi	Cu	Zui	Lou	So	Xia	Shin										Shen		Loi	Pu	So	Jing	Qiang	Yi	Hi	Nie	Dui	Rin	Jie	Sui	Zhan	Cou	Waku	Ro	Beng	Guan	She	Kin	Jin	Di		Sho									Dan		Nai		Nou	Roku	Ji	Yan	Sho	Nou	So	Du	Wei	Pian	Hei	U	Shi	Hu	Ho	Jia	Ye	Jun	Lan	La	Yin	Shi	Kan	Ei	Tui							U	Nao	Fu				Zu			Kho	U	Ma	Si	Zhi	Sho	Ei	Hui	Zhui	Reki	Hui			An			Chu	Shitsu	Che	I	Vua	Xiu	Lan		Cong	Shen	Mo	Yi	Yao	Xi	Zui	Bing	Kai										Yu		Lu	Ko	Vom		Chitsu	Tui	Wei	Sen	Fen	Shen	Shi	Ren	Bi					Ryu	Liao					Shi	Kyu	Shu	Dan	Juan	Yu	Xin	Yao	Su				Ki					Bu	Huo	Kin	Qian						Ma		Ho	Kai			Day	Lu	Sho	You			Shoku		Ten		Ko		Choi	Rei	Xian	Ren	Bu	Saku	Fu		Day					Wu		Yin	Xi	Kaku	Sho	Zhai";
    case 547:
      return "Xie		Ka	Gin	Qu			Ho	Li	Ka	Rong	Bu	Rong	Qian	Nghit			Bi	Rei	Kaku	Ling	Luan					Chan	Sei	Ting	Chin	Kai			Gwing				Cing	Zheng		Yan			Ten	Kyu	To	Ro	Kai		Yo	Yin	Kui	Son	Kai		Qu	Eki	Fu	San	Yu	Sho	Netsu	Eki	Hi		Qi	Bi	Hon	Shi	Kan	Qi	Ji	Yuan		Ken			Ben	Gao	Juan	Shu	Qi	Ken	Gai	En	Quan	I	Gen	Ben	Ben	Wei	Ri	Son	Rei	Ki		Kei		O	Kyoku				Zhi	Fun			Jian	Gen	Si	Fu	Kyo	Yi	Qian	Jun	Son			Han	Reki	Kei	Sen	Jik	Ju	Li	Chu		Zang	Yi	Bu	Cai	Yi	Ge	Ka	Die	Sai	Zhi	Yi	Shi	Zai	Dai	Shi	Su		Ji	Tai	So	Shi	Jie	Chen	Qu	Dai	Han	Xian	Dan		Kyu	Dan		Setsu	Quan	Jie	In	Cho	Sha	Juan	Shu	Dai	Cho		Dan	Dan	Dan	Jin	Tei	I	O	Cho			Bing	Hu		Bo	Tei	Jue	Gen	Yu		Kap				Tei	In	Li	Qiang	Shui	Ku	Hitsu	Zhen	Kyu				Fu	Shen		Wang	Ban	Chui	Shin	Ken	Tong	Gei	Yi	Kei	Yang	Shu		Tuo	Zhou	Ji	Kyo	Giang	Ten	Cong	Cong	Xun	Kan	Shen	Xuan	Hetsu	Dai	Hen			Liu	Yuan	Hu	Zheng	Bi	Sho	Peng	Zui	San	Chi	Jue	Gen		Bat		Sho	I	Ro	Von";
    case 548:
      return "Hitsu	Gen	Zhi	Pian	Yuan	Jaku	Jian	Sho	Hitsu		Pang	Shi	Soku		Zhuan	Shi	Xian		Beng	Sho	Cong	Sho	Mo				Guo			Hitsu	Cheng	Qiao	Han	Hitsu			Hitsu	Yo	Bi	King	So	Qiang		Zhou	Yo	Ki		Gi			Fan	Bie	Ho		Bi	Kyo	Ro	Sen	So	Ton	Sho		Bo	Rong	Bi	Sho	Yo	Bi		Ding	Quan	Jiu	Yao	Yo	San	Sen	Ko	Shuku			To	Ta	Ko	Xia	Chu	Riku	Zao	Roku	Bi	Bi	Shin	Bi	Chu	Dan	I	Wu	Tuo	Shi	Hu	Tei	I	Wui	Sho	Xi	Shi	I	Ku	Shu	Lai	I	Fei	I	Ta	Ji	I	Cho		Han	So	I	Go	Hu				Da		No	Shin	Shin		Shi	Ko		Xian		Kei	Shan	Gen	Wing		Fei	Bay	Ho	Cuo	Coeng	Fu	Choku	Chu	Sho	Iku	Ba				Hen	Hyu	Diu	Lan	Hen	Ba	Shitsu		Shu	Kon	Kyu	Hen	Ba		Xi	Hen	Jin	Ei	Hen	Boku	Biao	Yu	Sui	Xi	Ju	Ba	Hyo		Pou	Shoku	Shan			Ji	Kyo	Jiao	Han	Yi	Gung	To	Wan	Ji	Ju	Wan	Tui	Jun	Faan	Shi	Ang	Liu	Tian	Chi	Zen			Ran	Saku	Sa	Yin	Pi	Ci	Tong	Yin			Ge	Tiao	Zheng	Zhou	Shin	Yi	Kua	Song				Di		Nin	Shi	Shin	Xie	Seon	Xiao	Guang	Tuo	Feng	Wu	Hei	Tai	Xiu	Tsu	Gyo	O			In	Kon	Kei	Zoku	You";
    case 549:
      return "Shin	Ling	Yan	Ri	To	Dong	Qi	Tao	Han	Kei	Chi	Song	Hi	Itsu	O	Ko	Jun	Quan		Fung	Han				Kyaku		Ho	Hang	Shu			Rou	Qi	Kai	Yu	Cha	Cheng	Yu	Tei	Bing	Toku	Cong	Zhu		Yu	Tei			Mei	Jue	Liu	Sao	Yu	Ko	Toku	Kyo	Reki	Kyo										Shu		Shuai		Sho				Yuan		Ryu	Zhang	Hitsu	Sen	Shuai	Fuku	Chu	Zhang	San	Xian	Ki	Cui	Meng	Di	Fuku	Gyo	Ho	Zhi	Ao							Xiu	Bi	Pian	Ju	Jiao	Kuan	Sa	Xian	Zha	Dian	Jun	En					Fuku	Yi	San	Tetsu	Hui	Shan	Kan		Hi		Suot			Boku	Chong	Yi	Xie	Zhi	Tiao	Tetsu	Ping	Xian		Hang	Xian	Su	Hyo	Cuan	Yu			Sau	Sau	Song	Ken	Reki		Hei	Sho	Xian	San	You		Yu	No	Hyo	Tai	Bi	Jue	Nang		Dian	Ei	Yi	Bi	En	At	Gei		Nai	Taku	Xu	Yi	Ru	Kyo	Gong	Kyu	Sho	Yi	Ai		Zhi	Faan	Zhi	Xin	Nen	Ji	Ku	Xia		Ruon	Shaku	Zhao	Ne	Xie	Shun	Ha	Shi	Yi	Ki	Sam	Shin	Ho	Yo	Ben	Ko	Jin	Setsu	Kotsu		Tech						Thit											Fu	Ka	She	Kyo	Yuan	Fan	Shi	Fu	Wu	Xi	Hong		Thoai	Sau	Ji	Chang		Lo	Te	Nguong	Mo";
    case 550:
      return "Pei	Sen	Do	Mu	Qiu	Mao	Ko	Da	En	Xia	Shen	Te	Hong	Bi	Zen	Wai	To	Shin	Ji	Bo	En	Bo	En			Long		Cik	Si	Ni		Qiao	Kyo		Tei	Soku			Kai	Ruan	Hai		Kai	Zing	Sa	Rung	Rap						Ron	Ron	Totsu	Chu	Jiang	Cha	Mi	Shitsu	Sen	Yi		Suo	Saku	Wu	Xuan	Kon	Kyo	Xi	Soku	Yi	Shin	No	Shi		Kyo	Shitsu	Kei		Nao	Mai	Hiu	Wei	Lay	Ghiec	Ten												Hung						Cyun	Rui	Doi	Nhon	E	Tim	Kan		Gen	Long	Lu	Zhuang	Ai	Rin	Kan	Kyo	Ai	Teki	Zhi	Shuku	Xing	Kai	Geng	Jin	Xian	Ji	Cuo	Retsu	Lao	Fen	Ju	Kyo	Kyo	Kon	Shitsu	Miao	Xia	Seki	Yo	Jo	Yu	Su					Ti		Ji														Hai		Zhi		Hu	Kou		Suo	Ni	Kyo	No		Cay	Xon	Dan	Dai	Thoa	Gian	Long	Khuay	Teng	Zhu	Ngop	Men				Da	To	Qiu	Ya	Ko	Xian	Shu	Sen	Nei	Zui	En	So	Zhi	Bie		Cho	Ko	Chong	Lan	Dong	Qun	Xiang	Ken	Xiao	Wan	Ru	Wang	Ni		Bai	Ya	Kyaku	Bo	Ko	Metsu	Go	Si	Yin	I	Yu	Mon	En	Aku	Mitsu	Ai	Li	Huo				Toku	Mang	Zang	Ngo";
    case 551:
      return "														Kei	Mung			Leon		Zi		Toku	Bang			Ken	Jan	Ho	Suc	Luoi	Gong	Mung	Thiep	Be	Xi	Ai	Jiu			Xie	Qian	Nuo	Xing	Duo	Ji	Wu	Mu	Yan	Qi	Na	Chi	Hou	Ko	Sao	Deki	Nao	Katsu	Ai	Cheng	Cheng	Kui	Kai	Jia	Tu	Hong	Du		Ka	Xia	Zhong	Huo	Chong	Da	Yu	Ryo	Mao	Yao	Kyo	Aku	Ken	Kei	Sho	Juan	Soku	Shitsu		Sei	Net	Vui	Ray	Khit	Danh																Shi	Kyo	Ken	Yin			Shu	Gu	Wu	Fit			Guo	Ti		Hu	Gyo	Bo				Fung	Buon	Hong	Cau	Eo	Ngan	Re		Yi	Kyoku	Tun			Hai	Qiong	Hai	Da	Qi	Ryu	Deki	Huo	Ti	Pi	Yu	Da	Geng	Kei	Xie	Sai	Mi	Gao	Ta	Xiang	Kei	Shu	Deki	Ran	Fu	Shun	Kei	Ken	Kyo	Teki	Zhuan	Liu	Saku	Kei	Bin	Shitsu		Kyoku	Jan	Fit	Kai													Kyo	Jiku	You		Ai			Cheng	Dui		Lik	Dua	Set	Chua	Hen	Nan	Te	Thoi	Nep	Tom	Net	Chac	Cham	Quen	Rieu	Yu	In	Nhong	Dat	Fun	Hai	Li	Yang	Li		Kon	Lu	Mu	Sui	Ai	Bei	I	Kou	Bon	Zhe	Ai	Teng	Joku	Lu	Tui	Bi	Kyo	Han	Kaku	Joku	Ryo	Tan	Mung	Bo	Hui	Huan";
    case 552:
      return "Toku			Geng	Sung	Thung	Thuong	Ho	Ban	Ngau							Ngo											Kuo	Botsu	Xin	Kei	Kai		Sao		Gian	Dan	Gan	Hon	Mam	Man	Mo	Ngoay	Shu	Que	Ba	Tui	Lang	Soengx	Dan	Fu	Bie	Ren	Tang	Kan	Xiang	Tan	Si	Bo	Tai	Mai	Dang	Kei	Gui	Hei	Xi	Dang	Yi	San	Bi	Kon	Gu	Cui	Se	Ken	Ko	Ru	Ge	Yu	Na	Sei	Li	Zhi	To	Ku	Teki	San	Bo	Kei	Kan	San	Man				Mau	Ci		Da		Kaku							O					Zhao	Kok		Shun	Ji	Ruan			Byo	Chong		Bin		Seki	Byo	Kan		Son	Jie		Ngung	Chieu	Then	Tui	Han	Nuc	Doi	Nhang	Chang	Zhe					Su	Yong	Man	Shu	Qi	Zhuo	To	Ritsu	Kai	Ro	Ye	Sui	Qi	Daku	Da	Go	Kaku	Kai	Jo	Soku	Hi	Shu				Kotobuki	Gom	Jyu		Nguoi		Shuku	Dep							Xiong	Mung			Khan			Ngay	Gung	Nghi	Tui	Quo	Nhac	Tuong	Ham	Nao	Yi	Chou			Hai	Tuan	Ai	Pin	Hen	Kon	Lie	Mian	Ai	Da	Mo	Wei	Ying	Ni	Do	Ren	Ta	Bo	Yo	Liu	Boku	Kyo					Khuay												Rui		Chu	Ren	Dik	Ngo	Hung	Kokoro	Lu	Cha		Ma	Chu";
    case 553:
      return "Ko	Sao	Li	Toku	Song	Sei	Li	Dei	Ton	Chu	Toku	Xi	Katsu	Yan	Cuo	I	Liu	Soku	Kan	Go					Meng	Kei	Zhan	Bo	Chanh	Cham	Hon	Chan	Len	Doi	Nhit	Ten	Zhuang		Dung	Miao	Ei	Li	Sui	Ju	Fun	Rin	Kei	Xie	Xie	Long	Long	Kai	Ben	Ki	Kaku			Goe							Yu	Kei	Teng	Zhu		Cam	Lung	Chan	Lo	Nhang		Chan	Xian	Ryu	Sei	Ying	Pei	Haku	Ro	Tsui			Trai	Ri	Xie		Jiao	Soku	Soku	Do	Chong	Baku	Sung	Hyo	Ngan	Gion		Sho	Tai	Jyun	To	Hi	Nan	Wan				Do	Chu	So	Tai	He			Ngung	Ngoi				Ha	So	Tun			Zong		Laan		Tho	Hong			Man	Ku	Jin		Qu	Dou	Qiu	Zai	Ga	Sheng	Zai	Ngo		Yi	Ga		San	Waku	Hua	Kaku	Sen		Sen	Kan	Ga	Kan	Tei	Ei			Ju	Bo	Yu	Sei		Seki	Kai				Yue	Ni	Si	Shi	Wo		Kai	Go	Can	Metsu	Jian	Ka	Mie	Shao	Koku	Rong	Gan	Sai				Qiang	Kan	Shu	Zhuo	Saku	Kei	Shun	Koku			Shi	Zin	Ti			Shun	Hatsu	Zha	Zhan	Ka		Nen		Tit	Fen	Mie	Bo	Ze	Sai	Geki	San	Zhi	Qian	Han	Ge	Shun				Shun		Can		Guo	Jiao	Ta	Yong	Ao	Setsu	Ko	Kaku	Shun	Wai		Zha	Wai	Xi	Shi	Zo";
    case 554:
      return "	Xu	Wu	Mac				Tai	Saku	Zo	Iki	Hotsu	Kitsu	Sho	Shun	Jue	Ji	Zo	Chi	Shi	Wan		Mie	Zei		Shi	Tai	Ki	Jie	Shi	Shi	Xi		E		Shun		Hu	Hu	Haku	Li	Yaku	Shi	Chu			Yi	Mao	Xu	Zhong	Bo	Yi	I	Ngo		Sho	Chu	I	Liao				Rei	Jian	Jian	Ju	Rei		Zhu	Ko	Kan		Wu	Cong	Quanh	Ko		Ko		Ke	Ke	Li	Bi	Ge		Xu	Sha	Ling	Ke	Rei	Shi	Cong	Ho	Rei	Bo	Bian	Shuan	Qi	Shan	Buong	Muon	Shitsu	Ji	Hat	Qiao		Triu	Shin	Katsu	Son	Yi	Jue	Zhang	Ho	Xin					Tuo	Hai	Xia	Bo	Tuo	Yi	Day	Chop	Se	Nghi		Kai	Cu	Sotsu			Jiang	Nan	In	Haku	Peng		Jie	Xue	Hu	Sho	Ki	Kyo	Geoi	Tei	Ki	Bun	Haku														You	Nu	Ye			Yin		Kong	Giam	Moc	Thay	Ngat	Vat	Nang	Vap	Hen	Sho	Xiao	Xiang	Wan		Hatsu	Sho	Nao	Sho	Zhang	Ko	Ken		Hatsu	Keo	Giat	That	Vun		Go		Deoi		Tha			Kam	Jie	Jo		Nu	Shan	Wing	Trot	Phach	Lou	Day	Xao	Ngoac	Trum	Rung	Quay	Say	Oan	Dung	Jia	Bac		Sen	Paak	Zhou	Rong	Ko		Lu	Sa	Nu	Ko	Bo	Zhe		Qin		Ci	Zu	Hai	Wo	Wu	To	So	Nie	So	Yoku	Shi	Xian";
    case 555:
      return "Hong		Zong	Yoku	Bung	Tem	Shu	Giu						Jip	Wun		Muc							Chui							Shu				Diu	Tay	Khuong	Giang	Lay	Nem	Nhu	Phiet	Sotsu	Ting	Jin	Doi	Vot			Jie	He	Tu	Zhe	Pin	Jin	Nan	Katsu	Cho		Do	Dun	Hai	Xi	Xie	Sen	Xi	Lao	Duan	Ji	Cha	Chou	So	Gang	So	Yo	Ketsu	Yo	Zui	Xiang	Dao	Ro	Thuoc	Satsu	Satsu				Lang					Xac	Nhan							Kyo	Bian	Xiao	Xin			Hak	Ngon	Gan	Quao	Cay	Quet	Tro	Dan	Voi	Giau	Khuay	Nho	Vay	Vom	Tua	Lan	Dui	Xoi	Diu	Cham	Buong	Phay	So	Yu	Xian	Li	Qian	Hi	Hai	Mei	Fun	Qiao	Ya	Sho	Qia	Qiong	Kaku	Bang	Zheng	Luk	Tai	Sei	Bo	Setsu	Kon	Wan	Wan	Ken	Ze	Shuan	Ki	Da	Sao	Katsu	Hai	Atsu	Shu	Ran	Ha		Ken	Hi	Sen	Co	Ron	Nho	Chut	Co	Yoku																	Quay						Lu		Yu		Xie	Dik	Fu	Zhai		Ngaau	Be	Co	Quai	Bop	Va	Quat	Ngoi	Khep	Quay	Nagusami	Che	Nho	Sap	Buoc	Ven	Vo	Dut	Va	Roc	Sua		Ngang	Ngon	Lay	Xo	Niu	Ze	Taku	Duan	Ko	Deng	Yu	Chi	Lu	Sau	Wan	Xue	Jiao	Yue	Zhi	Wei	Hatsu	Ge	Ju	En	Yan	Cuo	Mao	Ho";
    case 556:
      return "Jo	Tan	Tei	O	Ki	Sen	Fu	Ai	Ryo	En	Xuan	Tan	Gang	An	Ko				Ji		So	Sen	Ro	Chitsu	Pi	Zhi	Sui	Hai	Nuo	Mote							Ki	Day	Ceon	Jau	Ko											Eo					Wo		Phu			Gap	Zung	Pan	Shu	Yi	Atsu		Jie	Sho	Zi	O	Jia	Wai			Jia		Boi	Danh	Gieo	Waa	Me	Ray	Bon	Dap	Mo	Go	Ngan	Cai	Phung	Xoi	Day	Nhot	Dot	Chan	Sho	Suo	Suo	Ji	Song	So	Ti	Pi	Po	Shuku		Ko	Kiku		Mi	Lam	Ben	Sen	Yo	Ki	Ye	Ho	Qin	Jin		Ho	Jue	Shu	Yu	Yuan	Ruan	Fu	En								Kik								Sai				Ban	Ki	Za		Tan			Tou		Run		Tia	Dom		Ro	Rung	Cau	Cham	Xuc	Gay	Hai	Kap	Mai	Mo	Tho	Phui	Sai	Thiep	Bin	Cau	Long	Nen	Wei	Zao	Qie	Sou	Lu	Chi	Jo	Satsu	Die	Chuai	Bi	Zhu	Ma	Fei	Pie	Yin	Xuan	Sei	Ao	Zhuo	Zu	Keoi	Gei	Bi		Sen	Hai	Chu	Sei	Lang	Betsu	Ti	Shuku	Seki	To	Taku	Yo	Tiao	Jian		Saai		Dom	Tong	Muong					Dao														Luon										Duo	Dong";
    case 557:
      return "Shuku		Bian					Zap	Daat	Dua	Chop	Chong	Van	Dan	Thoat	Giam	Day	Dut	Paang	Mop	Phen	Ning	Khay	Dam	Xay	Lay	Nuc	Gay	Xau	Ngon	Nhung		Zhi	Ken	Fen	So	To	Kei	Kang	Zhi	Zhai	Bi	Kuan	Ryo	Ban	Jue	Qu		Qi	Lei	Xie	Tang	Retsu	En	Jo	Shi	Getsu	Sui	Ketsu	Satsu	Sou	Hai	Bei	Cho	Shun	Hyo		So	Cou			Yang	Jian	Bam		Dua	Deoi		Yo	Sen				Paang	Suon			Kiku												Dok		Zao		Gaan	Vao	Doi	Phay	Nen	Don	Roi	Lu	May	Gop	Khoi	Ngang	Sum	Quay	Quo	Don	Cat	Xap	Moi	Cham	Chua	Vot	Ro		Kyo	Zhuai	Tan	Utsu	Fan		She	Ketsu	Qiong	To	Po	Ken	Tie	Sha	Za	Ka	Hyo	Ki	Niao	Guai	Cui	Ban	Zin	Yu	Go	Kai	Ki	Hyo	Son	Ngung	Sho		Cui	Saau	Qiao	Chong	Die	Loe	Choang	Tan					Quay				Maan				Pin	Ci	Kutsu	Bang	Co	Bum	Mam	Dom	Bung	Ngoi	Am	Chia	Don	Giu	Nem	Xan	Niu	Giet	Tro	Chen	So	Kutsu			Hyo	Taku	Yin	Baai	Hoku	Chi	Xian	Ketsu	Kaku	Yi	Miao	Duan	Zhou	Ken	Kong	Ryu	Kyo	Sho	So				Chaku	Zhang	Do	Ban	Fun								Jo	Deoi	Xo	Khenh	Ru	Hang	Khuynh	Quay	Vo	Liu	Chaku	Zhi	Chan	Du	Yuan	Sa	Kai	Suo	Jie";
    case 558:
      return "Li	Gong	Hyo	Kan	Sen	Han	Satsu	Hai	Teki	Sa			Bang	Zan							Buenz			Guo	Liao	Shen	Bong	Deo	Lan	Dim	Dung	Kem	Khoac	Xia	Chen	Niao	Ki	Cuan	Wei	Sen	Tuo	Shin	So	Su	Kai	Long	Bu	Sen	Shin	Sen		Xiao	Yan	Bich	Cyut		Douh										Kwai	Qing		Choc	Gai	Mac	Rung	Nhoi	Xe		Chia	Xi	Jo	Yu	Haku	Zheng	Xie	Chai	Fen	Ken	Guo	Tatsu	Jing	Lan	Xian			Ling						Keo	Xau	Ep	Luom	Xo	Tum	Suong	Tom	Khit	Yo	Yo	Lei	Haku	Hyo	Sho	Jun	Xiao	Tan	Satsu			Cung				Za	Giam	Que	Lay	Mo	Phoc	Tatsu	Ken	Guan	Qie	Luo	Yao	Luan	Ta	Jo	Naan	Bu	Rap	Rap			Luo	Bung	Dim	Bau	Jo	Jo					Son	Trac	Uon	Ba	Chan	Yo	Zhuo	Rai		Luon		Ken					Tiao	Tan			Wan	Ling	San		Maan	Yu	Qi	Shi	Qi		Chia	Chia		Ji	Bo		Shi	Fu		Gui	Shi	Ko	Dian		Hao	Shi	Gai		Qi	Shi	Kyo		Ki				Cheng	Hui			Xia	Shi	Zhi	Qi	Ro	Hai	Hen	San	Jiao	Li		Liao		Qiao		San	Toku	Sa	Shi	Qi	Shi	Fu	Haku	Jie	Hok			Fu	Fu	Ton	Bei	Bian	Ba	Jun	Pi		Kei	Dan	Tei	San	Tang";
    case 559:
      return "Kui	Ku		Kou	Kyu	Kyo				Shi	Shi	Ji	Bao	Setsu	Saku	I	Ke	Kuang					Min		Shi	Liao	E	Ge	Sha	Yo	Satsu	Wang	Duo	Satsu	Satsu	Qia	Hua	Hitsu	Hong	Shin	Ki	Peng	Ton	Jiao	Ko			Satsu	Qu	Zi	Zhou	Kuang		Sha	Han	Ji	Wei	Pu	Xue	Ta	Shao	Ko	Kai	Kan	Sha	Yo	Lang	Zhi	Ting	Satsu	Satsu	Da		Ko												Yang	Jin	Zhi	Satsu	Ve	Zhuo	Hei	Za	Chan	Tatsu	Choku	Cho	Cho	Mao	Kan	Kan	So	Kong	Zhou	Hu	Peng	Shin	Kai	Chin	Jiu	Satsu	Satsu	Fu				Duk				Chuo	Min	Satsu		Va		Xiao	Kan	Du	Wei	Chi	Can	Yu	Du	Kai	Pi	Satsu		Cheng		Ki	Go	Chun	Kaku	Shao	Yan	Kuai	Boku	Yue		Dou										Kei					Kei	Qi	Zheng	Rei	Ke	Qi	Zhi	Lu	Fu	To	Joku	Ki	Pi	Nuo	Pao	Tatsu	Gyo	Sho	Cho	So	Cho	Fei				Fu	Wen			Meng				Shi		Shan	Boku	Den		Xiong		Duo	Biao	Rei	Setsu	Kan	Kai	Satsu				Su	Su	You	Ku	Man		Liao	Shu	Fun	Xie	Luan	Qiao	Deng	Ha	Cheng	Cheng	San	Kei	Teki	Sei	Boku	Chuo	Ran					Ran				San	Ce	Saat		Ran	Tuom		So";
    case 560:
      return "Lei	Zhan	Li	Lian	Qun			Eki		So				Chen	Satsu	Cheng	Gu		Zong	Chou	Chuan	Hai	Kei				Ki	Haku	Lei	Shuo	Lu	Va				Fu	Kai	Li	Ton	San	Futsu		Futsu	San	I	Su	Jo	Sa	Fun			Nie		Hen	Zuan	Li				Shu			Fu					Gaku	Geoi					Bi	Han	Mei		Dao	Yo				Shi		Lon		Gan	Tan		Kin	Li		Man	Sai		Li			Bi	Ran			Pan	Bun	You			Bi	To	Jiu		Guo	Liao	Shin	Dong	Wo	Qia	Dou	Cho	Lie		Jiao	Ho	Lie	Ho	Fui	Dau	Cho		Tiao	Yu	Gia	Guo		Pang	Qiao		Di	Yun	Gao	Shoku		Mun			To	Le		Seki	Shi	Si	Xin					Xin	Xiang	Luo	Setsu	Kin	Taku	Dan		Beng	Tiao	Ki	San	Tei		Taku	Setsu	Xiao	Kaku	Dou	Sei	Tei	Dan	Setsu	Dang	Ting	Zhuan	Sei	Kan		Setsu	Shin	Ou	Kan	Wo			Saku	Zuk	Taku	Taku	Xin	Ruan	Taku		Zhuo	Dang	Tei	Taku	Rin	Cui	Kin	Taku	Tai	Zhuo	Tei		Dan		Ku	Cong	Chan	Bo	Hong			Yang	Bo	Bo	Rei		Sei	Vua	Vua		Butsu	Yan	Ryo		Bo					Sen		Khuong	Vuong	Yan	En	Zhen					Goc	Chin	Sen	Nuo	Yan	Cho";
    case 561:
      return "Sei	Ju		Kei		Fang	Ryo	Vuong	Fai	Yan	Yu			Ti	Fu	Ben	Ko	Yan	O	Hui	Hyo		Vuong		Yo	Huang	Sui		Gui	Yan	Shi	Hu	Biao	Hyo	To		Yo	Chech	Hyo	Sui	Ki		Hyo	I	Lech		Zi	Ji	E	Ji	Kui		Liang	Ryo	Ryo	Ryo	Huo		Wei	Zhuo	Kon	Doek	Kon	Ting	Shi	Tai		Zai	You	Nay	Ki	Bo	To	Ren	Sho	To	Shi	Mian	Go		Bin						So	Kia	Khuya	Khuya	Na	Shoku	Kai	Tu	Ketsu	Dan	Ki	Jue	Sai	To	Xu	Di	Shoku	Tan								Chu	Xiang	Ji	Ketsu	Shoku	Ju	Tam	Luc	Xiong	Gei	Ben	You	Gua	So	Pui	Xi			Sho	Jyun		Joeng			Mitsu	He	Ko	Shun	Shin		Ding		Phoi	Lu	Saku	Xu	Jitsu	Zhou	Xian	Huang	Cha	Shi	Gan	Nuo	An	Bai	Dan	Ze	Xie	Ki				Fong	Fong		Hao	So	Saku		Sho			Chang	Hang	Giay	Don	Qin	Geng	Shan	Fu	Ban	Cho	Kan	Jo	Sho	Bo	To	Ze	Kon	Kan	Bou			Sho	Setsu			Dan	Hiu	Gwan	Bua												Dian	Shen		Zu	Shun		Buoi	Ranh	Gio	Sao	Kia	Kia	Bie		Kotsu	Ken	Chui	Zhe	Dai	A	Jiu	Wo	Qiong		Seki	Bo	Lin	Mei	Hun	Ji		Sayakeshi	Mut	Fong	Ceon	Man	Ten";
    case 562:
      return "					Cao	Shin			Toku	Mu			Die	Wei	Sik			Kia	Phoi	Dem	Mai	Bong	Ngay	Dem	Ray	Chang	Quat	Ngay	Cu	Hong	Yo	Bian	Ti	Tia	Ying	Shun	Tu	Gu	O	Kan	Shu	Rui					Jyu	Nau	Coeng	Mei	Min	Miu		Geng														Chi	Cou	Ti	Soku	Kon		Gyo			Ui	Trua	Linh	Thoat	Kyu	Huo	Qi	Sao	Sang	Xuan	Ang	Nai	Kan	Yang	Shu	Sha		Gou			Ting	Mai							Ya	Huang	Yo	Sho	Mo	Bin		I		Chech	Buoi	Choi	Rua	Hao	De	Kia	Gio	To	Chi	Ai		Ou	Cao	Ko	Ao	Shu	Mao	Kei	Katsu				Gei	Hou	Se	Noi	Mo	Chop				Shi		Meng	Sho	Tian		Ngu	Zan	Yo	So		Sang	Xu	Kan	Hyo	Ken		Seki	No	Ko	Seki	Lang	Shun			Luk	Seon	Luk							Bo	Dan	Bie	Cong	Kotsu		Xian			Bin	Bay	Chieu	Sao	Toi	Chieu	Rang	Tun	En	Nhoang	Doi		Yu	Dan	Ying	Yo	Zhao		Pu	Cho	Dip	Kwai	Yo				Ka	Hui		Hom	Lat	Com	Rao	Ai	Mo	Cai	Mung	Jing	Lan		Kon			Xom	Lat			To			Kon	Bao	Hang	Lie	Piao	Boku	Bo	Qiong	Ko	Dan	Bi		Mit	Gio	Som	Thua	Yong";
    case 563:
      return "Hei	Trua	Trua			Li	Trua	Shin	Haku	Khuya	Haa	Som	Rua	Nie		De			Doi	Huan	Tran		Dan	Yue	Ton		Chun	Tran	Li	Nang	Zhang	Ling	Chun			Ryo			So	Ce	Xun	Ryo			Ju	Hui							Ngoat	Quap	Cong			Vay	Xeo		So	Ki	Tong		Nguc	Vay	Goc	In	I	Veo	Ning	Ju	Ho		Het	Cui		Oam		Cha		Ban		No	Ketsu	Ngoeo	Zao	Cong	So	Ten	Sai	Yu	Ko	Shu	Fuku	Ken	Ki	Ki	Bo	Ki	In	Kitsu	Kuang	Fei	Ji				Sen		Saku	Yun	Qian		Saotome		Quan	Han		Ro	Po	Chin	Pei						Dem			Thang	Geng	Yi	Luo				Me		To	Cho	Ryo	Co		Kuan	Sho	Xuan	Nian		Chap				Hu	Ju	Sho		Trang	Jin			Chieu	Kyo	Han		Rang			Ye				No	Xi			Yue	Tang	Pin	Dun	Bei		Ot	Liao	Kyu	Kan		Ho		Da	Da	Yong	Bai	Caat	Shi	Kon							Jip	Zi		Ya		Shaku	Jiao	Kurumi	O	Kun	Hai	Zhen	Shu	Fu	Kai	Shi	Ko	Men	Chin	You	Pai	Xiao	Ji	Tyun		To		Muk	Mukunoki											Hei	Go	Jan		Qi	He		Zoi	Kong	Da		Mai	Dak	Then";
    case 564:
      return "Man	Shi	Ye	Chi	Truong	Nhum	Thot	Rai	Shi	Chi	Kao	Yue	So	Ketsu	Wa	Nian	Bi	Ci	Kei	Yi		Ging								Xop							Jiu					Shiraki		Yang	Li	Ka	Dai	Chong	Ko		Queo	Su	Say	Yi	Kai	Kai	Ten	Sho	Han	Kan		Shin	Ko	Yi	O	Chong	Hu	Zhua	Kan	Gyaku					Yamabuki	Tsuikushi	Trat		Roi		Diu	Suru												Tyun								Ko	Qiong	Duo	Bu		Sen			San		Tou	Shitsu	Sen	Pui	Choi	Gian	Tsubaki	Re	Sim	Tong	Xian	Tabu	Nen				Fu	Sen	Chin	Dian	Xi	Xie	Zhen	Qiao	Tu	Kyo	Kai			Gwo											Hat									Vay			Mang					Kon	To	Kotsu	Bai	Shitsu	Sai		Kan	Sen	Xoai	Sao	Cong	Tau	Cai	Ri	Han	Kuang	Suo	Chi	Shou	Tiao		Vong		Zhen	Hon	Bi	Nei		Qian	Yin		Liang	Sha	Zi	Pi	Gao	Bo	Yo	Jin	You	I	Shan	Shun	Mi	Ou	Ken	Hu	Kaku	Sho		You	So	Meng	Saku	Choku	Ryu	Ko			Do	Jau	Phim	Ten		Hon	Hei																					Lou";
    case 565:
      return "											Kikugi			Nan	Getsu	Zhi	Kiku	Saku	Bi	Ki	Sho	Shu	Shen	Qi	Xian	Pan	Kang		Don	Cui	Bap	Can	Pha	Xoi	Ngoc	Su	Chanh	Nhai	Do	Kang	Bo		Shuan	Pi	Kutsu	Zai	Zhu	Zi	Sou	Jiong	Tok		Chan	Fan	Xiao	Yin	Hou	Mao	Tu	Gan	Ji	Sui	Kan	Ketsu	Yi	To	Yu	Jiong	Pao	Kei	Xiao	Sa	Gou	Ten	Setsu	Gou	Sun	Xian	Zhuan	So	Co	Ju	Shi					Hay		Mau													Gaa					Noc						Gang											O	Chou	So	Ko	Ko	Getsu	Ta	Qiao	Ti	Yun	Choku		Shan	Lie		Zhi				Pai				Ho	Peng	Chay	Chay	Hong	Mei	Ca	Chot	Wai	Se	Bi	Ghe	Suot	Trac	Trot	Ju	Lai	Ko		Soi	Zi		Qu	Gu	Jue	Zhi	Ang	Qin	Pi	Zui	Shi	Qian	Choku	Cuo	Boku	Ji	Ti	Ru	Ryo	Hai	Xun	Shin	Bei	Zhi		Dun	So	Tsui	Taranoki						Mun	Dang	Me	Kei	Cyun	Fung	Reng	Chan	Cham	Chua																		Kyoku					Cha							Le	Gan	Syu	Ritsu	Gang	Ta	Ken	Tuo	Yang	Ku	Zhi	Ven		Son	Tu";
    case 566:
      return "Sau	Ca	Uoi	Cay	Thot	Fu	Nep	Ko	Son	Cum	Do		Choac				Kyoku	Kei	Kan	Bay		Shin	Jian	Ni	Shen	Bang	Shuai	Dou	Chi	Qian	Han	Qia	Gan	Sa	Go	Chun	Cha	Bi	Yi	Fu	E	Shi	Lao	Hao	Li	Ko	Hei	Ko	Ko	Te	Shen	Koku	Yin			Jian	Koku		Kyo	Cha	Kai	Nau	Vai		Zap		Ken					Tsugu							Man						Nashi			Nie	Cou	Cuk	Yo	Yi	Kaku			Tang		Ji	Juan		Gi	Goi	Tri	Nhan	Be	Song	Yuka	Sop	Lat	Giau	Chay	Rui	Chi	Gou		So	Jie	Zhe	Hu	Mang	Sot	Con	Mam	Zou	Si	Reki	Etsu	Fei	Zi	Zi	I	Jie	Si	Taku	Chun	Pao	San	Kyu	Ji	Ye	Di	Oku	Lei	Xu	Ru	To	Pa	Juan	Xi	Ye	An	Sho	Yi	Jian	Zuk	Kyo	Song	Wo		Se	Zhi	Bi	Zhuan	Ko	Ju	Iku	Jiang	Hao	Mu	Chi	Dun			Guk	Trom												Hong						Ryo																			Bo	Ji	Chua	Ko	Luo	Sha	Yaku	Rui	Hizakura	Aioi			Zoeng	May	Gu	Va	Tarai	Trai	Be	Du	Chuom	Cheo	Then	Tu	Hu		Du	Sing	Rao		Dan		San	Han	Que	Sha	Zhan	Ze	Chuan	Qi	Die	Gi	Zha	Tou	Yo";
    case 567:
      return "Etsu	Ci	Sa	Jau	Luo	Zen	Sen	Ji	Shin			Mo	Kurobe		Sho								Dip						Tochi				Hei		Luo	Qin	Sa	Geki	To	Qiong	Juan				Ai	Jian		Hyun	Lim	Son	Dun	Vong	Do	Heo	Ot	Sau	Vung	Ti	Wen	Nhu		Qiao	Chua	Jip	Can	Pai	Hun	Ko	Ko	Ai	Gai	Shuo	Lian	Dui	San	Ta	Jin	Bi	Yan	Gao	Piao	Yu	She	En	Taku	Jian	Bai	Hu	Ho	Chun	Lie	Kyo	Bian	Su	Jiao			Joeng		Shaku	Sai	To	Ceoi									Shin					Han			Chu	Zhui	Roku	Ka	Sho	Hen	Han	Shin		Dan	Wing	Kushi	Khu	Cuoi	Chum	Sen	Dun	Hyo		Son	Sho		Tho	Tram		Xie	Meng	Fu	Lu	Tan	Gei	Sai	Liu	Xian	Sang	Sa	So	Cou	Zhuang	Boku	Chen			Ze	Baku	Bu						Muc						Lian		Sen		Li	Jin	Sen	So				Buoi	Joeng	Dang	Trau		Peng	Tuo	Fun	Mong	Tuo	Ei	Liao	Xiao	Chui	Huai	Niao	Qian	Li	Rei	Da	Pao	Tiao	Liu	Wu			San	Mo	Ji													Ying	Oku	Zha	Hishi	Ki	Dui	Noc	Nhan	Ran	Ma	Mem	Ken	Yu	Kyo	Xian	Xuan	Shuan	Xi	Sho		Mei	Sen	Lian	Yoku	Jiu	Lao	Yu	Nagi";
    case 568:
      return "				Rei										Xiao	Zou	Kaku	Bong	Tham	Pheo	Hyo	Chua	Chua	Que	Gau	Hyo	Liu	So	Zhao	Chi	Zhe	Shin	Lei	Yu			Kan					Tram				Duan	Mu		Gian	Tram	Re	Mem			Do	Jian	Shuan	Zuo	Qie	Hai	Lao	Ha	Ra					Den			So			Yu	Yi	Ni	Getsu	Kyoku	Cen					Tram		Yan		Ruan	So	Trai	Trai	Kyu		Vui	Yan	Die	Mian			Tan	Nen		Do	Lei		Wan	Do	Shaku		Cho		Bay	Na			Tai	Kiku		Yan	Ritsu	Utsu	Sieng	Lei		Ritsu	Sha	Hu		Shin	Xi	Xi	Shi	You	Han	Ki	Hai		Wa	Xu	Pi	Tan	Xi	Xi	Bin	Qin	Xi	Yu	Xi		Ci	Qian	Xia	Shin	Shi	Wa	E	You	Xing	Ni	Han	Bi	Sheng	Yu		Zhan	Dian	Yu	Yu	Ou	Kyo	Gui	Wang	Qian	Yi	I	Kutsu	Zu	Ka	Qian	Ding	Keng		Chu	Yi	Kan	Loi	Han	Kuan	Shoku	Kan	Fun										Dian	Xi	Zi	Ling	Zi		Yu	Hun	Ki	Si	Kan	Ken		Ko	Kan			Kan	An	Sui	You	Ji	Hun	Qia	Hou	Hou	I	Dian	Kon	Ko	Ka	Yu	So	Xie			Shi	She	Sha	Shi	Shi		Xie	Yao	Da	Yo	Xie	Chi	You	He	Sha	Kan	Yaku	Kin	Aku	Tai";
    case 569:
      return "Zen	Zhu	Kan	Ai				Que	Ze	Tan	La	Lou	Chuai	Yo	You	Yu	Iku	Ka	Ka				Ti	In	Shi	Kyo	Sho		Sai			So	Etsu	Xiao	Xi	Yo					Huo	Chi	Yi		Yaku			Shu	Yue	Chan	E	Xi	Xi	Ying	Zu	Za		Sho	Za	Shoku	Kyo			Kon	Shoku	Tan	Ta	Wan	Ho	Shi		Xin	Kai	Shi	Wang	Fu	Gen	Kin	Sen	Ryo	Lu	Zen	Shu	Ryo	Sei		Ki	Tatsu	Ko	Ko					Jian		Hatsu	Yan		Bi	Ken	Guan	Kon	Cho	Zi	Jo	Kin	Shi		Sen	Kui	Zhou	Zhi	Trai	To	Tu	Shi			Ta		Chu	Cheng	Cheng	Zhu	Doku	Da	Sho		Sho	Sho	Sen	Kyo	Sui	Trai	Bi	Cho	Jia		Shi	Yi	Ngay	Thang	Yue	Gang	Ku		Gieng	Sei	Dan	Gan	Shi		Dan		Thang	Qiao	Son	Ki	Sen	Chu	Chu	Bi				Gui	Sei	Ki	Gu	Bing	Yin	Zhui	Gu	Tuoi	Li	Trai	Hi	Ei			E	Dai	Satsu	Shi	Shi	Ten	San	Can	Shuku			Ko	Kyu	Ti	Du	Yi		Ketsu	Shi	Die	Kyu	Niu	Shi	Xue	Ne	Gui	Kao		Kyo	Chuan	Shu	Jun	Yo	Zha	You		Bai	Shi	Dian	Pa	Qiu	Chi	Min	Ten	Xue	Ten	Mo	Ke	You	Jiao	Bo	Shi	Shu	Kutsu	So	Xiu	Gaku	Ko				Mi	Luo	Yu	Xue	Hi	Duo	Shi	Er	Shan	San	Kui	Nao	Mian	Li";
    case 570:
      return "Luan	Shi	Die	Yu	Qia	Lei	Bo	Mao	Hyo	Heng	Che	Zhi	Gen	Gu	Cuo	Botsu	Cou	Ei		Wu	Tao	Gia	So	Xi	Yao	Wei	Yo	Zu	Ma	Yu	Peng	Yi	Qin	Yue	Jue	Jiang	Xu	Beng	Sen	Giuoc			Luo	Zhui	En	Quan	Giam	Fan	Thac	Ka	Du	Xiang	Bai	Ai	Hui	Ka	Rei	Gen	Gu	Kao	Tai		Xing	Hun	Bian	Chet	Chet	Kei	Ke	Kao	Bei	Fu	Cuo	Ei		So		Riku	Baku	Lu	Shuku	Zui	Zao	Jiao	Guan	So	Sui			Yan	Er		Qing	Kan	Kan	Deng	Si	Sui	Liao	Yo			Ngoeo	Shan	Yo	Bi	Wei	Ye	Shi	Zhai		Ye	Diao	Ai	Kin	San	Jiang	Ban	Kai	Su	Toi	Huai	Yu	Kai	Ran	Rang	Ko	Ra	Dian	Zuan	Ban	Tan	Qin	O	Satsu	Jia		Pi	Kaku	Kyu	Tou	Den		Kan	Chou					Gui	Satsu	Kaku	Gwai	Kyu	San	Kaku					Ji	I		Ki				Jan	Xue	Satsu	Dian			Bian	Zai	Tong	Wan		Saku	Kaku		Din	Shan	Ki	Gu	Que	Huk		To	Kyo	Shu		Gu	Ko	Guk			Huk			Hu	Kuai	Ko	Guk	Gou		Su		Chou		Keng	Koku	Du	Den	Ki		Kaku	Yi	Ki	Ngai	Dao	Qiang	Saku	To		Kan		Long	To	Li	Kei	Li	Qing	Saku	Wei	Saku	Mou	Mai	Hou	Han		Qi	Dung	Jiang	Xie			Van		Dai	Juk	Lou";
    case 571:
      return "		Guan	Ro		Hi	Pei		Hi	Pi	Hai	Juan	Ji	Bei	Jue	Juan	Shi	Kon	Shi	Hai		Xie	Hi	Zui	Rui	Jing	Po	San	Toku				Ji	Ki	Ho	Ko						Fen	Bei	Jie	Sa	Zen	Pi						Di	Mao	Ba	Ba	Tiao	Ling	Sheng	Zhen	Pi	Wu	Hai	Ze	Bao	Hi		Su		Bo		Lu									Mari						Hao	Dou	Fu	Ni	Bou	Bom	Boku	Ge	Ji	Sen	Ru	Xian	Bo	Sen	Bi									Ri	Mao	Ria	Mao	Sho	Rong	Qiu	Su	Shu	Sho	Bo	Katsu	Hao	Nao	Yan	Nyo	Do						Pao	Sui		Tuo	Ngu	Qu	Li	De	Ri	Jie	Jie	Gun	Jian	Bi	Sho	Sho		Ku	Kiku											San	Bang	Chun	Sho			Nai	Bang		Jo	Rong	Jia	Sou		Bi	Shu	De	Ka	Ta	Bo	Kiku				Shu						Xian	Zhan	Mao		Ho	Zi		Ji	Qi	Katsu	To	Cho	Ho	Ru	Suo	Rong	Wu	Rong	Rong		Ku	Ho		Ri					Ta		Sou	Zei		Ho		Long	Sa	Men	Li	Sho	Kei	Cui	Zong	Men	Xi	Ru	Mang	Nie	Sho	Sui	Sho	Pei	Kiku		Bi	Di	Saam		Qu	Qiao	San	Fen	Su	Ho	To";
    case 572:
      return "			Xu			To	Rong	Ji	Sho	Do	Qu	Lie	Sho	Su	Ngoi	Kyu				Sen	Sao	Sei	Sei	Kun	Quam	Cui	Ye	Bing	Ru	Jie	Shu	Qu	Qu				Meng	Ran		Bin	Chao		Ryo	Du	Cho	Shoku				Jo	Long	Long	Long	Rang	Xian	Cho		Tao	Qu	Nie			Shu	Lu		Kun		Zen	Bo	Ho	Shi	Min	Min	Shi			Dan	Tetsu	O	Yin	In	In	Xiao		Ki	Ki	Ji		In	Ki	Ki	Yin	Dung	Ki		Ritsu	Shun		Kwan	Gitsu		Fen	Zhong		Sho	So	Gu	Hoi	Bum	Kei	So	Ram	Cha		Liu	O	Ei	Bu	Ka			Pa	Si	Dao	Zhen	Leo	Nuka	Shan	Kitsu	Chuai	Ton	Jiu						Ke	Chi		Ngut	In	Yu		Hu	Li	Sha	Kyu	Tan	Pai	Wei	Wu	Zeoi	Jan	Sing	Ying	Bing		Setsu	Seki	Sha	Di			Dan	Seu		Ko									Tu	He	Po	Futsu	Zhi	Niu	Ni	Kai	Tan	Ketsu	Kyo	Ki	Rong	Guai	Do	Zhi	So	Koku	Ji	Tan	Rei	Pang	Zo	Sin	Si	Shitsu	Han									Dong				Setsu	So	Botsu	Ryu	Fan	Han	Ko	Jie	Hai	Mo	Ngoi	Kiku	Zhan	To	Xi	Sen	Deoi	Zi	Shi	O	Xi	Piao	Chi	Ji	Ben	Ketsu	Jian	Sai	Ho		Hi	Hyo					Doe	Pui	Taai	Jyu";
    case 573:
      return "Su	Shu						Iemq							Sho			Ryu	Ken	Jian	So	Ko	Za			Du	Hup	Nhung	Thac		Ben	Mao	Katsu	Hitsu	Zao	Zhuang	Yoku	Kuang	O	To	Bi	Hin	Pai	Ha	Botsu	Bo	Sai	Kai	O	Yo	Yoku	Sha	Kai	Kai	Shitsu	Sa	En	Kyo	En	Shu	Mao	Tan	Da		Nit																											Sau			Tun	Luo	Taku		Tan		Sen		Den	Kun	En	Tei			To	O	Bung	Xoi	Lan	An	Bon		Ngam	Ngap	Xuoi	Han	Zhu	Jo	Duo	Duo	Gan	Yoku	Gwai	Sen	Bu	Seki	O	Cho	Retsu	Kyo	Qiong	Sai	Wang	Ko	Mo	Zhe	Wen	Zhuang	Haku	Jie	Pao	Kyo	Jyun	Sai	Kan	Kyo		In	Su	Sen	Sen	Sen	Sen	Ju	Tan	So	Qi	Can	Ho	Tuan	Sha	Kaku	Tuo			Hua		Yi				Mboen							Coi	Daam	Bing	Jin	Ji	Dik	Fan	Wan		Bi																				Nagi									Sen	Gyo		Kei	Min	Zhong	Sho	Gong	Kotsu	Shuo	Shitsu	Fu		Yi	Wang	Ao		Be	Loi	Can	Nhom	Sua	Sua	Day	Veo	Shoku	Su	Bien	Zi	Ten	Soma		Tan	Shin	Gui	Tuo";
    case 574:
      return "Hui	Shin	Kai	Xu	Zan	Katsu	Zi	Bian	Shu	Da	Yin	Quan	Ka	Hatsu	Huai	Na	Za	Loeng	Ti	Sei	Kyo	Sui	Kei	Shi	Yi	Tan	She	Shuo	Fun	Xing	Man	Retsu	You	Shitsu		Fen				Sam					Ciu	Juk	Jam	Jau	Jim	Jyun	Ketsu						Ten	Ping												Sen	Ko	Ke		Kan	To	Fu	Shu	Sei	Sen				Min	Day	Hoanh	Lut	To	Tran	Dai	O	Pi		Ji	Qiao	Zhong	Gan	Yuan	Chi	Kan	Shu	Jo	Qian	Shin	Zuo	Sei	Xie	Mao		Hu	Ryu	Pi	Xun	Shin	Xia	Ti	Ryu	Sei	Na	Chua	Ryo	To	Metsu	Sen	Sen	Tan	Tei	Jun	Bo	Wu	Ketsu							Ji	Lam	Gaa	Sin		Ki																															Huang	Xue	Tao	Shitsu	Qiao	Hitsu	Hei	Jiao	Sei					Zin	Do	Dam	Dang	Bai	Nhua	Fung	Nuot	Cham	Set	Bui	So	Cat	Tuon	Xoi	Bong	Duoi			Yo	Dang	Kou	Kyo	Ju	Sha	Jing	Sei	Hyo	Mo	Nou	Ji	Shuo	Rin	Shu	Zhuang	Fu	Sen	Shi	Zang	Xie	Lang	Tong	Sho		Fu	Kan	Sen	Nyo	Zhe	Shuku	Hyo	Can	To	Yue	Ei		Zhou	Shi					Wai	Soeng	Gin	Gei		Hou	Kenh	Nit";
    case 575:
      return "													Son												Bi	Tan	Ban	En	Deki	Yan	Lu	Yan	Shin	Ryo	Ro			Ze	Shuai		Am	Bot	Cha	Denh	Doi	Thia	Vui	Lung	Ngau	Doi	Xop	Nhang	Lei	Van	Lot	Nhot	Don	Mem	Ko	Tran	Lang	Leo		Ngau	Zung		Tan	Kei	Guo	Zhu	So	Ru	Ru	Zeon		Kan	Ji	Gao	O	Kaku	Tatsu	Xie	Ryo	In	Ou	Jian		Jo		Zhi	Zha	Sha	Hong	Ki	Kuan	Hei	Bo	Yoku	Ko	Se	An	Jian	Shin	Teng	Ryu	Bi	Song	Kan	Meng	Yin	Tan	Guo	Sei		Ruan	Wei	So	Kotsu	Si						Saan	Ito	Cing	Wui	Kei	Gaai	Ngot		Sen								Lian		Kei																				Tatsu	Qi		Zhang		Bi	Ko	Teki	Shu	En	Cho	Den		Shitsu				Buk	Choet	Doi	Kiu	Dia	Giat	Khoi	Cha	Vuot	Xoi	Bui	Oi	Pou			Ngau		Dong	Fu	Shen	Su	Yi	Lian	Ko	He	Roku	Zhen	O	Ze	Ko	Cui	Cui	Tatsu	Sen	Hyo	Go	To	Shi	Ritsu	Katsu	Shu	Feng	Li	Kou	Shu	Gyo		Xiao	You							Dip	Wui	Ji	Kwai	Sam	Zeon		Kotsu	Ro	To";
    case 576:
      return "			Hao	Mo	So		Han	Iku	Han	Ken	En			Taku	Thia	Day	Ning	Nho	Loc	Am	Ray	Ngoi	Rua	Vung	O	Luon	Lay	Leot	Yu	Chua				Bu	Huan	Suo		La	Zan	Dou	Jian	Po	Bian	Hon		Ji	Gyo	Xue	Tatsu	Bian	Bin	Kyo	En	Ko	Wei		Zeon	Gaa	Sam	Luk	Ji												Kan	Kan	Reki	Iku	Shu						Dao	Khoi	Lat	Loa	Min	Trong	Bot		Chua				To	Dao	Dan	Jie	Bai	Tan	Nian	Xian	Se	Kyu	Giot	Hua	Chua	So		Ou	Lie	Di	Cai	Tetsu	Zha	Kyo	Lu	Tei	Teki	Ryo	Huo	Sa	Hen	Li	Ying	Rai	Wei	Bi	Guo	Teki	Pi	Soku	Zing	Biao	Ji				Ziu	Kit	Lin				Nung					Ko										Yan	Yo	Sai	Sho	Zhuan	Teki	Kan	Bong	Mo	Rua	Dan	Phun	Loi	Toe				Re	Hong		Ki	To	Lin	E	Jun	Yin	Lan	Yo	Yao	To	Katsu	Xuan	Li	Shitsu	Jin	Han	Kyo					Lik	Boku											To		Kan	Kai	Boku		Beu	Leo	Rach	Muong	Ung	Noi	Wing	Lom		Nhao	Rem		Thuot	Lan	Ling	Xi	Hong	Kan	Jiao	Zhuo	Kaku	Bi	Bi	Zhi	Han	Katsu	Bo	Teng	An	Haku	Reki	Xun	Lei	Zang	Hui";
    case 577:
      return "			Katsu	Gau					Ryu		Tong	Giet	Ruou	Xi	Hong	Ryu	Fan	Jian	Cong	Za	Yo	Ca	Haku	You	Siu	Hyo	Dui	Pan	En								Ta	Ro	Pan	Kei	Sho	Fun	Fan	Xi	Re	Nhieu	Trong	Nhan	Dan	Can		Toku	Sen	Yao	Luo	Shin		Bian	Sen	Jin	Li		Lik	Jing				Lim	Bu	Ko	Ran		Rang	Yan	Dou	No	So	Man		Gong	Rang	Can			Cau	Pan	Jing				No	Piu	Kaku		Lou		Hou	Yaku	Men	Bi		Tan	Xon	Saku	Tan	Saku	Rei		Jo			Yaku	Gu	Shuan	Hitsu	Chi		Bien	Ling	Yan	Bi	Jam	Kaku	Tan	Tan		En	Biao	Cheng	Kui	Tai	Huo	Sha	Kai		Nay			Sai		Chi	Sai	Wo	Kyu	Cou	Zhi							Shui	Ton		Gua	Pu	Xu	Si		Wu	Leon	Saap	Jung	Wan							Mou		Fu	Sho	Shi	Dan	Sai	Hui	Huang	Pa		Loa	Tom	Nha	Hong	Thep	Zhu	Sen	Yi	Kei	In	Kai		Li	Shan		En	Ten			Bung		Kho	Seot													Taku	Ko	Min	Futsu	Ge	En	Hu	Gen	Baak	Xen	Xao	Lap	Mo	Say	Phoi	Tat	Chin	Shu		Lung	Bep	En	Fa	Do	Jin	Xu	Yi	Gai	Sho	On					On		Ying";
    case 578:
      return "																	Teki	Fu	Sho	Chi	Shi	Ho			Yi		Gwong	Chay	Nghe	Lui	Nhu	Sot	Ngut	Ko	Fu	Hong	Di	Hui	He	So	Zha	Kai	I	Man	Sho	Sai	Iku	Iku	Ketsu	Sho				Yun	Xian																Sakannimoeru			Tatsu	Zing	Xian	Lao	Shao	Shi	Zhuo	Kan	Giai	Tro	Tac	Tro	Ce	Heo	Ngun	Fan	Soi	Toa	Rang	Kyo	Ryo	Zetsu	Chuom	Ji	Sho	Sai	Bie	Jiu	Wo	Jiao	Fu	Retsu	Xiang	Kai	So	Ko	Hai	Gyo								Jin	Geoi	Futsu	Ko	Ko									Kei	Jo													Luk			Coi		En		Sho	Ko	Sho	Tai				Roi	Bong	Ngoi	Tro	Nhem	Ling	Phong	Ruc	Vac	Rom	Ro	Phoi	Phoi	Lom		Ton	Ben		Nao		Huo	Ji	La	Hai		Hotsu	Kutsu	Fou	Shan	Liao	Mie	Che	Keki	Joeng	Mo	Shu	Bu	Kei	To	Shi		Jyun	Ping					Lou													Sho												Duo	Netsu	Baku	Nao	O	Ji	Hei	Sha	Zhu	Hun		Gyo		Dai	Ranh	Nau	Khet	Kho	Zing	Phoi	Kho	Choi	Um	Dot";
    case 579:
      return "Kip	Ko	Su	Duo	Cha	Nhang		Jiong	Hyoku	So	Zai	Hui	Ying	Hu	Lin	Weng	Han	Hyo	Ei	Kan	Nan	Da		Ko			Wui		Ten							Rat																	Git			Xi	Sho	Gan	Sen	Kai	Ko	So	He	Ji	Xiang	Sha		Hay	To	Ret	Ngot	Nau	Hei	Ngun	To	Huc	Thieng	Mu			Tui	Chong	Zhao	Shu	Kei	You	Jian	Hotsu	Hin	Sen	Man	Sho	Zao	San			Re		Jim	Kwan	Zhang	Heoi		Ei															Loa							Ruo	San			Retsu	Sho		Yan							Cui	Tong	Quac	Mo	Nong	Nuc	Mom	Phap	Thieng	Rang	Tat	Hong	Ji	Shang	Shaku	Ryo	Ram	Long	An	Ryo	En	Do	Kan	Sen	E	Lao	Tan	Ko	Zhu	Hetsu	Sui		Ko	Sho	Lin	Netsu	Zeng	So	Juan	Hu	Seki	Sen	Sen	Ki	Shi	Gyo		Zaan	Siu	Nigi	Gun			Sa	Hei															Ran							Shen	Huo	Dan	Gan	Hyoku	Kui	Sen	Rin	So	Bo		Nhoi	To	Ho	Thui	Khet	Thap	Se	Fan	Lou	Buot	Rang	Kan	Hotsu	En	Hotsu	Chu	Zhou		Ki	Eki	Ao	San	Zhuo	Hyoku	Go	Sho	Jin	Xing	Sei	Mie";
    case 580:
      return "Hu				Zin														San	Khe	Tan	Ki		Ryo		Bi	Ham	Nau	Ngoi	Soi	En	Koku	Luoc	Khoi		Ding		Ko	Shi	Hyoku	Sen	Kai	Rin	Biao	Seki	Chu		Yaku	Huo	Lie	Cuan	Ko		Gaa	Hou	On											To	Xian	Re	En	Zen		Chang	Ro	Ho			Hung					Ei	Yue		Xun	San	Liao			Jing	Fan				Ro		Sho	So	Sha	Gan	Baku	Shi	Satsu	Sha	Jin	Xie	Bung	Loe	Loi	Mo	Sem		Ki		Xiao	Ton	Sho	Sen	Ye	Lan	Yi	Beki		Yo	Gyo	Sui	Lian	Yaku	Ho	Yo				Juku	San	Jin	Futsu										Futsu	Bo	Cao	So	Sha	Duoc	Chin	Nung	Nau	Futsu	Yao	Tai	Nhui	Do		Lom		Ren	Ren	Lian	Ryo				Yo	Kutsu		Sui				Chon		Thap					Jip	Haku	Ta	Fong	To	Hyo						Shaku	Ten	Ram	Quang	Shaku	Zen	Haku				Zaan	O	Ko	Ji	Bi	Lo	Xi	Zhi	Lyun	So			Xi	Diu	Hyoku	Yue	Hyoku	San	Sen	Shaku	Nen		Xian	San	Zhuo			Ben	Sho	Sui	Sho	Utsu	Utsu	Zhang		Kyu	Ran	Sai	Retsu	Zu	Da	Na	I		Vau			Fu	Dao	Lie";
    case 581:
      return "Na	Hei	Rechi			Dit	Nezumi	Ji	So	Pao	Kei	Ju	In	Ho			Ran	Rei	Ran		Luan	Kei	Luo	Kaku	Yo	Shua	Shang	Su	Fuku	Luo		Fen	Ai	Wai	So	Bao	Ai	So	Ran	Ji	Li	Kaku	Ren	Xiong	Ran		Satsu	Vuot	Sho	To	Shi				Dang	Danh		Sho		Mong		Mong	Mong		Cheng				Zhang	Ran		Sou	Lyun		Shen	Ju		Ran			Ku		Ge	Ya	Cha	Ha			Yu		Hui	Che		Jiao	Zhu	Shu	Sho		Xiao	Ki	So	Hatsu	Ning	Do	Ji	Han	Baan	Daku		Jiang	I	Jiang	Bo	Zen	So		I	Rei	So	Diao	Zong		Shitsu		Shitsu	Qiang	Qiu	Yo	Feng	So			So	Sho	Zhan	Ke	So	Hei			I	Itsu		Shitsu	Hai		Die	Ze		Sho	Guang	Se	Fen	Sho	Itsu	Jiang	Rei	Yan	Zhi		Sho	Riu	Li	Sho	Bi		Ling	Sho		Sa	Yi	Han	Qu	Pan	Gou	Hai	Jia	He	Ko	Peng	Taku	Ju	Banh	Che	Chua	Lop	Lie	Shi	Po	Xiang	Kyo	Pi	Luo	Cu	Kyu	Yu	So	In	Mui	Kong	Xie	So	Cho	Hai	Hi	Wan	Yan	Pei				Cheng		Ka	Manh	To	Ti	Che	Bi	Lian	Jia		Ting		So		Ti	Cho	Cong	Gyo	Kaku		Die	Bi	Shu	Li	Lu	Xia	So	Cui		Yu	Tam	Bo	Tui	Pu	Ko	Lin	Fen	Phuon	Bo	Chan			Dang	Tai";
    case 582:
      return "Dao	Mong	Mong	Li	Toku	Ya	Ya	Zhan	Ga	Ga	Yi	Nga	Qi				U	Gai		Nanh	Hu		Ting		Kou		So	Chun	You	Fen	Da	Nuo	Tian	Jin	Pi	Chen	Pi	Hin	Jie	Gui		Gushi	Daan	Jun						Hai	Zhuang	Tei	Boku	Hu	Chou	Shu	Tao	Pi	Rong	Rong		Hou	Peng	Hai	Ho					Bai		Xia	Chitsu		Tei	Qin	Ni	Hai	Tao	Qu		Ka	Xie	To	Zhao	Hua	Xin	Ho	Shou			Tu	So	Liang	Bi	Chu	Kyu	Xing	So	Xin	Fu	Hak			Soku	Jie	Chi			Fu	Ngau	Lao	Te	She	Sei	Hi	Chao	Chui			Toku				Ran	Hou	Beng	Da	Cai	Zen	Shu	Tei	Shu	Mu	Be	Nghe	To	Xu	Die		Sai	Chan	Yu	Zhong		Sha	Ryo	Li	Shou	En	Kyo	Syun			Du	Men	Mao	Huang	Go	Tao		Du	Ti	Sheng	Mei	Ban	Co	Sao	Zhen	Qin	Pi	Tang	Cang	Yao	Jun	Xiu	Bang	Gu	Ko	Ken	Bo	Bu	U						Gou	Bo	Shin	Shin	Toku	Wen			Ji	Chiku		Chan		Hat	La	To	I	Cui	Min	Cu	Ou	Yong	To		Maan		Mao	Ke	Mang	Ding	Huan	Duo	Jiang	Su	Nghe	Hi	Trau	Rui	Ceng	Ta	San	Huang	Jue	Xun		Ta	Xiong	Sei	Mi	Qun	Lao	Toku	Kan	Zhi	Wei	Kai	To		Rei	Se	An	Goku	Ri	Zang	Ri		Jo	Rei";
    case 583:
      return "	An	Wei	Jun	Huai	Goku	Lung	Zhan	Haku	Ying	Ge	Hui	Haku	Quan		Rai	So	Hi	Rai	Lie	Ju	Ba	Lei		Man	Ling		Han	Li	Ji			Nai	Hui	Xin	Shi	Zhe	Ji		Bo	Ton	Shaku		Cha	San	Tu		Cha	Jing	Ba	Bei	Shi	Yu	Yan	Ko	Hu	Yaku	Yu	En	Bi	Chuan	Datsu	Ji	Keki			Mu	Ko	Mao	Zhong	Yu	Ye	Dou	Ye		Van	En	Ri	Yin	Hen	Hao	Han	Na	Tie	Fu	Mu	Zai	Ten	Hu	Kyo	Chen	Tuo	Hai	Bi	Chu	Fu	Doku	Haku	Ze	Hyo	Yaku		Sai	Bao	Yu	Yoku		Nhim	Di	Cai	Lu	Po	Da	Ye	Go	Yi		Kyo	Kyo	Xiang	Bi	Zhu	Ji	Yi	Sei	Lu	Do	Kuang	Ko	Keki	Zhi	Wai				Wa	Di	Shu	Lie	Zao	Zhi	Nao	Yoku	Si	Chon	Hoi	Ngong	San	Thac	Tay	Loi	Chai	Se	Ko	Xiao	Zang	Hai	Tai	Yu	Dou	Cha	Xie	Yang	En	Xian	Bao	Moi	Khon	Bo	Ro	Ro	Rai			Zhai	Cho	Qiu		Hu	Zai	Jue	Hyo	Han		Kan	San	Cao	Hum	Lon	Muong	Tan	An	Zao		Doc	Sha	Ko	Xian	Chi	Yan	To	An		Ko	Sho	Zhe	Jue	Shuku	Sei	Li	Sho	Le	Cho	Sho	Cai	En	Lu	Zen	Jia	Tho	Ken	Xia	Xiao	Yan	Xu	Ko	Dun	Ying	Hui	Ti	Nou	Xi	Shu	Toku	Tu	Shu	To	Chaku				Tajihi			Ki	Rei	En	Wai	Chen			Katsu	Hong	Sha	Ti	Xuan";
    case 584:
      return "Za		Duoi	Kenh	Ga	Voi	Uoi	Ge				Lou	Chai	Pan	Ji	Do	Ta	Lau	Si	Xi	En	Kyu	Xiao	Kyu	Sao	Jia	Su	Huang	Tei	Cuo	Hi	Ta	Shuai	To		Hau	Hoang	Sei					Fu	Li	Kyo	She		Tang	Gau	Uoi	Khai	Khi	Vuon	Ketsu	Dian	Se		Sei	Bi	Teki	Gou	Cu	Jyu	Qian	Yo	Ban	Lei	Su	Chin	San	Zong	Hao					Muong		Ken	Chi	Cao	Hyo	Ya	Wo	Xiao	Lie	Yan	Shu	Kan	San	Khai	Nanh	En	Bi	So	Huan	Do	Xi	Chi	Xu	Nao	Yan	Gan	Xie	Zha	Rin	Sui	Reki	Xi	Beng	Ran	Shuo	Ban	Gui	Kai	Chen	Toku	Rei	Xu								E	Li	Xi	Huan	Su	Kyo	Chang	Zen		Vuot	San		Lu	Yan	Chi	Zui	Dang	Dan	Yang	Ki	Zhai	Ju	Ketsu	Duo	Sao	Lai	Su	Ryo	Ju		Doku	Go	Man	Ze	Katsu		Jo	Bi	Bam	Vuon	Yin	Shaku	Hao	Sui	Lie	Ngao	Duoi	Hao	Yang	Rin					Shuo	Ai	Qiong	Sen	Ryo	Lei	Xie	Sei	Shi	Nhat	Nhim	Soi				Lu	Beo	Que	Lian				Ko	Rei	Xiao	Rei	Ying			Xie	Sho	Kaku	Sen				Ling	You	Nhim	Yu	Do	Sen	Dang	Lan	Xiao	Doc		Kyo	Rei	Jyun		Ro	Yi	Juk	Gyoku	To	Wu	Shin	Yi	Tuo	Bu	Ji	Xin	Cin	Bo	Si	Jin		Ba	Fa	So	Mo	Ruo	Bo		Hoi";
    case 585:
      return "Tyun	Fong							Ko	Ho	Da	Ji	Jung	Bin		Ketsu	Su	Qiong	Ba	Ho			Fat		Kyu	Jai		Tama											Tian	You	Kai	Tuo	San	Wai	You		Dong	Wing	Vua	Xi	Kong	Ji	Gok		Qiong	Dui	Duo	Kyoku	Yi	Han	Do	Chin	Jin	Baak	Do	Ming	Jik												En			Vong	Xi	Qin	Su	Sen	Ho	Liu		Wan	Kan	Gin	Botsu						Kok	Hak					Zuo					Che	Zhu		Mao				Zi	Gaap		Quan	Rin			Jin	So	Yu	Kyo	Yi	Mi			Lai	Zhi				Fan	Hyun	Daap	Bing	Ji	Pui	Leon	Cung			Koku		Gyun							Bo					Kai	Kin			Ni	Ei	Ban	Zi	Sei		Dong	Ling		Cing	Zhi	Shin	Ryu	Kei	Kyo	Kon	Ro			Jin	Bou	Zing	Kei	Loeng	Wan									Ping											Cau	Fung				Yi	Kan	Ka	Ling	Yu	Cong	Di	Zhi		Mei	Ting	Ruan		Rin	Jian		Paak		Ei		Wan	Chin	Jin	Wun	Pang	Ta	Ban	Hi		Ha				Haa	Zin	Hei	Ci	Sen	Ting";
    case 586:
      return "	Jin												Lu	Qu	So	Xi	Da	Jan	Caa	Kan	Lak	Hu	Luo	Han	Le		Sa	Ro	Shitsu				Long	Taan	Gau	Zan	Gei	Ji	Piu	Man	Sau	Caan			Yo									Gong		Mon	To	Chin	Ling			Kwan		San	Kyo	Lao	O	Zhuan	Syun	Kan	Shuku	Shuku	Shuku	Jiu	Sen		Tsumagoto	Gaan	Cing	Si	Hoi	Ki											Kiu		Kin		Syun		Bi	Yu	Seon	Git	Daan	Zao	Hao	Xiang	Kai	Kyo	Hao	Li	Reki	Ritsu	Dian	Ge	Hon	Ten	Kyo		Syun	Kwai	Bik	Ji			Huan						Ryo	E	Yo	Xia	Ra			Cuom	Jian	Qi	Xia	You	Rin	Yo			Syun		Mou	Fai											Zheng	Reki	Kin	Wing		Ji	Fung		Sa	Zhuan	Ki	Kyo		Chan			Sau	Lai	Wai	Shitsu					Kan	Sam	Syun	Lin			Kai	Syun					Heki	Shi	Jin		Xie	Ling		Yo	Kin				Haa			Yo	Nao			Do					Ji	Tian	Lai			Lou	Yan	Rui	Rai		Hao	Xin	Ling	Ton	Ban	Beng	Ton		Chin	Tetsu	Gou	Ling	Shi	Tetsu	Kuo	Qia	Jiao		En	Yao	Du	Tetsu		Yo	Dua";
    case 587:
      return "Dua	Huo	Du	Pei				Yo	Ko	Kei			Yuan	Yo	Tetsu	Lou	Xing		On	Lian	Yao	Xi	Yao	Ko	Xi		Ren	Lu	Ro	Yan			Quan	Hyo	Hyo	Hyo	Rei	Rang	Wa	Zu	Fan	Yi	Du	Sui	Shu	Pi	Hei	Han	Ken	Xu	Ngoi	Gong		Di	Yo	Na	Sanh		O	Rei	Datsu		Duo	Wa	Zen	To	Nie	Ryo	Kaku				Diao	Huang			Ti	Fan	Bu	Teki	Bo	Wu	Ang	Kei	Ping	Ko	Cho	Datsu	I	Han	Gao	Gang	Li	Kei	Dun	Fu	Na	Datsu	Cei	Shi			Shi	Jie	Ta	Qing	So	Ying	Xiang		Cung	Hanzo	Shu	Hu		Kaku	Su	Am	Hong	Chau	Binh	O	Ko	Ge	E	Xu			Ci			Ang	Gach	Kei	Xi	Yo	Ketsu	Rui	Kang	Guo	Jie	Chuan	Lei	Heng	Zun	Be	Hu	Shi	Ken	Pie	Kaku	Lo	Deng	Xi	Lei	Keki	Shan		Ngoi	Ngoi	Muong	Jo	Bu			Au	Tan	Lu	Lung	Dui	Jun	Cho		Chan	Rei	Xie	Wa	Zhe	Yo	Zhuan		Ryo		Liu	Lei	Rei	Kan	Shi	Dai	Gan	Ngot	Ngot		Katsu	Go		Shi	Jin	Ngon	Yan	Sha	Tan	Che	Sha	Gan	Kan	Kan	Bai	Yan	Lam		Sei	Jin	Sei	Sui	On			Zhong	Sho	Shi		Sei	Yoku	In	Sheng	Sei	Sei		Chan	Don	Sei	Song	Song			Sei	Sanh		Don	De	Ga	Ryu	So		Jing	Cu	Huang	Yin		Sieng	Meng		Shi		De";
    case 588:
      return "Ko	Cu	Rang	Yo		Xiang	Yo	Bei	Bei	Jung		Yo	Chuan		Yo	Sen		Pu	Ko	En		Gyun	Se			Ke	La	Ryu		Quan	Hi	Hang	Chi	Mang	Ko	I			Zha	Kyu	Sei	Yo	Fen	Ho	Chao	Shi	Kei		I	Kaku	I	Jing	I	I	Shin													Lie	Sen	Na	Na	Tong	Mau		Ryu	Ran	Zu	Pi	You	Shin	Shu		Riku	Shin			I					Lie	Shou	Tuan	Ten	Gao	Shao	Tuo		Nan	Cho	Shin	Ko	Tuo	Gong	Diao	Kaku	I	Seon	To	Bi			Sai	Ki	Ko	Meng	Bang		Xie	Si	Ting	Gui		Shin	Fu	Gui				Duoi	Hitsu	Bi					Gui	Ho	Shun	Ruong	Ko				Zhu	Hei	Lai	Ji	Lun	Tian	Ran	Cho	Hon	Dong	Hon	Hitsu	Shoku	Jyu	Cing			Ryu	So				Bo	Juan	Yan		Tan	Ruan	Dan	Chu	Kaku	Mao		Fun			Ji	Luan	Shoku	Xu	Tetsu	Xi	Kyo	Dai	Ko	Aru	Kaku		Jo	Ma	Qi	Boi	Cha	Trai	Trai	Shang	Han	Ping	Shoku	Sho		Ji	Rai			San	Li	Sho	Yu	Ban	Han	Teng	Jyun		Ha		Chou		Zen	Chou		Trong		Qi	Xi	Bei	La	Roc	Rin	Ye	Hei	Kei	Guang	Sho	Zhu	Ve	Ruong		Lei	Lei	Cha	Sa	Boi	Boi	Ki		Rui	Sho	Ruong		Tan";
    case 589:
      return "Guang	Die	Ryaku		Ki	Ro	Cau	Sei	Rui	Cho		Tan	Rai	Die	Tan	La	Leoi	Rai	Rai	Ya	So	Soku		Sho	Nie	Shu		Zhi	So	Chi	Ka	Zhi		Chi	Zhi	Pi	Rei	Jiu	Jiu	Yi	You	Soku	Jiu	Daku	Dau	Bot	Kyu	Huan	Gotsu	Du			Jin	Nhuc	Soi		Gitsu			Tao	Qie	Qin	Xin	Chan	Ji	Chi	Qin	Chu				Kai			Du	Zhi		Seki	Ou		Wu	Ki	Wen		Jin	Kho	Vet	Ho	Bi	Sei	To	Bei	Chin	Mu	Jin	Tao	Liao	Ko	Ken	Hei	Bin	Cao	Zha	Sen			Seo	Ta	Chi	Ya	Kui	Yin	So			Bon	Say	Yu	Si	Sen	Long	Qia	Ei	Hang	Shang	Hai	Cha	Ro	Jiao	Lao			Nham	Shitsu	Do		Xi	Yu	Gui	Bo	Shu	Shu	Chau	Choang	Chon	Nhan	Ben	Zhi	Kyu	Tun	Fu	Gai	Hu	Zaa	Nie	Yi	Zhuang	Chin			Cha	Chu	Chi	Eki	Suan	Shitsu		Yun	Kon	Kyu	Yo	Kyu			Du	Shu	Xi	Chuan	Xing	Jiao	Shen	No	O	So	Naa	Guoc	Xoai	Nghen	Mang	Mut	Lan	Hau	Wang	Bei	Fei	Jian	Quan	Yi	Dong	Xu	Na	Ji	Yu		Zhen	Qi	Dui	Yin	Bo	Jiu	Pi	Xin	Lun	Cai	Ling	Bie	Dao	De	Shoku	Sho	In			La		Xi	Ju		Xiao	San	Jing	Wa	Shu		Mang	Cek		Diec	Vang	Loet	Bung	Mon	San	Nhom	E	Pho	Buou	O	Wa	Wai	So	Nao	Xiang	Que	Qie	Tu";
    case 590:
      return "Xu	Hui	Shu	Shu	Kan	Min	Wei	Ryu	You	Tui	Dai	Kai	In		Ke	Na		Fu	Yu	Zhi	Hin	Han	Ai	Fu		Ko					Sei	Ji	Byo	Yang	Do		Shi		Chan	Hoen	Xiu	Do	Chi	Yun	Shuai	To	Su	Sang	Yo	E	Zheng	Ai	Suo	Bu	Hai	Qun	Yi	Yan	Kai	Na	Wu	Ei	Sei	Taku								Li	Li	Ka	Xi	Jue	Shi	En	Ya	Ren	Lit	Rom	Khu	Quan	Bang	Uon	Hen	Ong	Nhoc	Choc	Nhuc	Chen	Ying	Bi	Che	Sho	Seki	Zha	Tuo	Hu	Teng	Ying	Bi	Ning	Lian	Xin	Yu		Toku					Ka	Bei	Ma	Mo	Dui	So	Dao	Qi	Tan	Kai	No	Buou	Not	Hui	Gyo	Shuai	Shu		Xiao	Zhong	Zhui	Yoku	Bian	To	Wei	Xi	Shin	Deng	Kan	Xie	Pan	Nie	Shin	Shi	Bie	She	Fei	Min	Qi	A	Do	Sei	Gaan	To	Gyaku								Daap	Ei	Zang	So		Shan	Suo		Buot	Gua	Mun	Khom	Nhen	Son	Te	Buou	Om	Ngua	Ji	Wai		Dan	Juan	Lu	Kun	Ao	Ro	I	Yo	Yi	Shu	Sui	Wei	Wan	Chu	Yo	Gan	Teoi		Wo	Yu	Cum	Hui	Hom	Rem	Toi	Gay	Ngua	Yo	Bi	Ra	Yin	Huo	Hai	Setsu	Kai	Ning	Shin				Ai	Shitsu	Li	Kan	Zhai		Tan	En	Nho	Nhoi	Thuot	Ngua	O	Shu		Lu	Ryo	Rai	To	Setsu	Bian	Pan	Sa	Rei	So	Met	Ro	Xai	Ran	Gui";
    case 591:
      return "Su	Meng	Xian	Long	Hyo	Qi	To					Chan	Yi	Hang	Mak	Lian	Guan	Ba	Wei	Rom	Ngom	Nhuc	To	Jue	Lei	Luan	Li	En	Pi	Do	Gay	Hi	Ra	Yo	Huan	Ren	Hi	Sei	Saku	Hatsu		Ki	To		Han		Gui			Ban	Hatsu	Ju	Koku		Deng	To	Dang	Hai	Fei		To	Haku	Ka	Ko	Treo	Zhi	Kan	Mei		Huan	Shi	Sen		Pa	Bi	To	Po	Ki	In		Haku			Er		Huan	Byu	Nguoi	Shu	Ko	Ko	Sei	Mui						Ko	Chang	Kai	Luo	Fou	Ko				Shu	Shu			Chou	Shin	Zu	Nan	Xiao	Heu	Phau	Via		Trang	Bai	Lu	Ha	Luo	Tei		Nian	Ze		Jyun		Zhu	Hu	Dau	To	Hui	Tang	Chou						Zai	Huang	Dou	Tram	Vang	Tei		Wong		So	Jit	Miao		Bo	Chi	Ho	Di	I	Deng	Pu	Ki	Song	Chou	Gyo	Rei	Bik	Sei	Yao	Meng	Long		Mon	Nguoi	Nhenh	Lian		Yo	Bie	Satsu	Phech	Faa		Lu	Rei	Yo		Reki	Se	Zuo		Saai	Shaku	Cun	Ling	Zheng	Pi	Bao	Haku	Kan	Que	Hi	Vo	Pi	Nan	Pi	Bo	Bei	Fa	Ho	Min	Mo	Wa	Zhao	Zhi	Cu	Ko	Dan			Xun	Ji	Gui		Cheng	Hi	Shu	Da	Han	Xiao	Que	Zaap	Chuo		Fu	Shu	Ki	Trong	Bit	Fu	Qin	Lu	Que	Dian	Qian				Hatsu	Chang	Ta	Bei	Shu";
    case 592:
      return "	Du	Beng	Hou	Ko				Zha	Zha	I		Giay	Hi	Que	Ma	Han			Liu	Lu	Hitsu	Zi	Ban	Pi	Zhou		Zao		Niu	Shi	Shaku	Hui		Fun	Xue	Ban	La	Hi	Hi	Yo	Ei	Ung	Nou	Yan	Ran	Nao	Batsu	La	Guang	Du	Mo	I	Lu			Juku	Jian	Xie	Qi	To	Seki	Xiang			Guo	Jie	Mang	U	Haku	Xia	Kui	Hatsu	Kan	Hachi	Ko			Yong	Sho	Hai	Mi	Yao	Jau	Han	Wen	Ko				Bo	To	Sho		Jin	Li	Juan	Wu	Qiao							Han	Mo	San	Ki	Tan	Diao	Chu	Mei	A	Suo			Chong	Bo	Han	Quan	She	Tan	Tan	Shi				Mei	Yan	Meng	Ju	Kan			Roku	Ho	Trom	Ko	Tu							Nong	Mo	Ko		Roku	Mei	Tan	Fen				Am			Kai	To	Ao	Guo	Hu	Can	Dun	Hai	Jiao	Gu			To			So	Gu	Chu	Chu	To		Jin	To		Yang	Kai	Yaku		Rei		So		Cha		To	Ko				Rai	Ro	Ko			Hui	Rei	Rei			Mam			Qu	Ke	U		Kin	So	Mam	Mam	Ku		Het	Qing	Yi	Ken		Kai	Jiao		Moku	Chou	Bu	Gen	Jiao	Zhi			Wen		Bin	Nhap	Gu	Ku	Xiong	Fan	Han		Yi	Chuan	Yao	Shu	Yu	Yang	Du	Yan";
    case 593:
      return "Yo	Meng	Choku				Shi	Chi	Mu	Jiao	Kyo	Nu	Sui	Guo	Xue	Shi	Bin	Fu	Xue	Fu	Pei	Mo	Xi	Wo	Shan	Shi	Shi	Xi	Qi	Mian	Ho				Moku			Ki	Dan	Ko	Chou	Kyo		Gap	Ngu	Ngo	Nham	Ngom	Nhon	Fei	Mie	To	Xue	Xu	Si	Ju	Mao	Bao	Chitsu	Yi	Gua	Ni	Sei	Yi	Tei	Zuo		Nhon	Nu				Laap							Ko		Dian	Fan	Yi	Shi	Bi	Chu	Cu	Zhen	Hei	Ko	Kitsu	Kitsu	Kei	Shi	Jiao	Hou	Er		I			Lei	Xue	Geng		Shou	Shu	Juan	Shi	Bi		Sai	Sei	Chau	Kei	Jie	Wei	Sei	Shou	Jing	Ki	Xu	Chong	Bei	Daap	Zong	Chop	Giuong	Liec	Nham	Nho	Quang	Jiang	Mou	To	Ko	Yu		Kutsu	Jue	Jo	Kyo	Sei	Gyo	Ting	Kan	Shin	Xiao		Dou	Ken	Guo	Mang	Wang	Xu	Wang	Suo	Juan	Yue	Katsu	Han	Gan	Shen	Moku	Xie	Liu	Run		Gei						Bi	Ko		Nao	Toku		Chin	Wan	Jiu	Que	Ngop	Dau	Ru	Le	Ngom	Nhin	Quau	Mekurashi	Tro	Bet		Ni	Ban	Mi	Suo	Nhon	Qiang	Kon	Mo	Han	Zhuo	Mi	Xu	Shin	Lang	Jie	Ding	Chang	Zhi	Fei	Jia	Jun	Huo	Qi	Ju	Zhun	Eki	Dian	Jiao	Ya	Eki	Zhan	Gwat	Jia	Ken	Sik	Noi				Ko		Zhi	Bi	Mai	Hu	Xie	Shi	Gui	Tei	Katsu	Him	Nhom	Nhac	Ngai	Tron	Tro	Nhoi	Nho	Sho	Xu";
    case 594:
      return "Ku	Nghenh	Ji	So	Chuang	Ten	Mao	Ruan	Xu	Huan	Sha	Ju			Katsu	Kuang	Sai	Hou	Guan	Gua	En	Mi	Die	Bi	Liang	La	Shan	Lu	Xi		Man	Sou	Jeoi		Mi							To	Son	O	Ou	Ngac	Leng	Lay	Hong	Nhin	Kip	Chot	Nguoc	Nhon	Nam	Ku	Gui	Nhom	Dom	Xi	Pan	Se	Jue	Hong	Guan	Ju	Ko	Nai	Hua	Ge	Li	Gou	Ti	Teki	Ma	Teng	Da	Shi		Kan	Qi	Yu	Jiao	Mie	Geng	Meng	Wei	Bo	Ti	Qi	Sui	En	Chen	Dou	Bo	Pan			Za				Ben	Jaku		Trong	Hay	Trong	Let	Trit	Soc	Khoe	Han	Yo	Tron		Mi	Ma	Lu	Qi	Keng	Rai	Die	Qi	Jiao	Kang	Qiao	Mi	Shan	Sai	Shi		Bo	Gai	Sho	Jian	Li	Ke	Xu		Caau				Sho	Man	Feng	Chan	Hui	Teki	Dui	Guom	Ghe	Zong	Mo	Trong	Nguyt	Chop	Quac	Nhan	Song	Nhon	Thang	Thang	Nguoi	Dom	Mu	Kou	Ri		Wei	Guan	Ji	Zun	Huo	Xie	To	Shin	Do	Sen	Sui		Ruan		Te	Yo	Kan	Rui	Zheng	Kun	Xiang	Mian	Shin	Xi	Kan	Jun	Hyo			Caang					Sa	Sui			Byo		Tre	Ngoanh	Trung	Trom			Saau	E	Mie	Zhu	Zou	Meng	Rei	Xi	Hyo	Tang	Kyu	Jia	Chang	Ji	Hyo					Sho	Ben	Seki	Zhuo	Shaku	Shun		Lem	Coi	Ngam	Him	Lam	Liec	Soi	Ngay	Dom	Bai	Guom	Trao		He";
    case 595:
      return "Cha	Qi	Mian	Zhen	Ku	Ye	Zhou		Jian	Yo	Pan	Bo	Rin	Hui	Seon	Ming	Liu	Jeoi		Cyu		Ko	Yo	Ben	Shui	Nho	Mai	Li	Hyo	Hyo	Shuo	Yi		Hen		Ben	Li	Khoe	Len	Lo	Xie	Te	Xiu	Tron	Nhin	Xuan	Li	Meng	Wei	Meng	Shun			Kan	Ki	Hieng	Dim	Ngam	Yao	Lan	Ling	Ying	Ying	Li	Jian	Gui	En		Kan	Guan	Xie			She	Kan	Zui	Hyo	Lom	Ngong	Sho		Gheo	Cham	Kan	Lei	Kan	Trom	Shin	Nheo		Bian	Ngom		Shu	Nu	Xu	Keki	Saku	Shi	Hao	Bo	Bo		Keki	Gui		Zhai	Lang	Cuan	Zhi	Feng	Qin	Keki	Ze	Na	Niu	Yi	Kin	Ko	Cong	Shi	Jian	Zong	Yan	Ying	Sho	Jo	Jun	Ruan	Mem	Rong	Xi	So	Guan	Kai	Ro	Wu	Baku	Qin	Cong	Ho	Ze	Xie	Saku	Yu	Zan	Chuang	Li	Li	Xu	Mi	Xu	Ruan	Sho	Kin	Gui	Rong	Zyun	San	Mao	Bo	Qin	Cuan	Cuan	Cuan	San	Ko	Shin	Shi	Zoku	Shin	Zoku		Tan	Wu	Shin	Fa	Ba	Gi			Ji	Tan		Qia	Zhi	Tiao	Chu	Zoku	Zoku	Ki	Chi	Zoku	Zoku	Shitsu		Zhi	Zhi	Tan	Huan	Chou	Tei	Zhi	Ten	Ten	Ten	Ying	Ei			Wu	Bei	Kei	Hong	Shen		Jue	Kui	I		Yi	Ya	Tetsu	Hetsu	Bi		Kei		Kua	Qian			Zhao	Ko	Kai	Shang	To		An	Zhe	Zhi		So	Shi	Shitsu	Ryu		Zhi	Tan	Jiao		So	Chi		Ji	Van";
    case 596:
      return "Si	Pu	Ou	Shitsu	I		Van	Ngan	So	Ngan	Zhuo	Ngui		Ngan		Coc	Ngun	Ying	Cut	Huan	Van	Ya	Seki	Hen	Shi	Pa	Pu	Suru		Teki	Mang	Chai					Kai	Faan	Dia	Loi	Dia	Yun	Ko	Ko	Gu		Jaku	Taan	Keoi									Dan	Shi	Nao	Do	Zhe		Hu		Hen	Chai	Ben	Katsu	Keng	Gaa	Die	Ting	Ai	Den	Guai	Do	Han	Qiong	Shi	Jia	Ao	Na	Pin	Jia				Mo		Do					To	Cuom	Zhe	Bu	Wo		Cha	Kaku			Do	Nao	Kan	Caak	Tsumu		Du	Guai	Qiong	Sen	Rong	Yi	Dui	Lei	Yu	Zhou	Kua	E	Xian	Dian	Nuo	E	Yong	Wu	Keng	Heki	Dia		Gai									Sen		Waak	Sa	Kai	Zhi	Sen			Zhi	Xun	Ho		Zheng	Byo		Yang		Huo	Ji	Nao	Rin	Do	Da	Dia	Ya	Lu	Ko	Ro	Fu	San	Chu	Wei	Ren	Fu	Keng	Si	Kang	Bo	Yi	Hua							Kyo	Yu		Kan	Do		Li	Mai	Vo	Lin	Du	E	Sanh	Tetsu	Gen	Qiang	Du	Rotsu	Tai	Jie	Chuo	Xian	Hi	Gi	Kei	Gao	Shin		Usu															Ken	Kaku		To	Dao	Saku			Hong	Do		Be	Mai	Dia	Vo	Canh	Som	Loi	Bo	Zong	Kyo	Sai	Qi	Tuo";
    case 597:
      return "Hong	Pi	Geng	Wai	Nie	Kai	Seki	Kong	Tei	Sho	Zhi		Iseki		Saki		Kai	Xiao																She	Yu	Jiang			Voi	Chong	Satsu	Qi	Chen	Sang		Suo	Qian	Hui	Ho	Shan	E	Kaku		Ci						Qiu		Ke		Ham	Weng	Zi	Ji	Shin	Mai	Sho	Reki	Da	Sen	Cuo	Manh		San	Lou	Kang	Kuo	Di	Qie		Mo	Tan	Ka	Guo	Hong	Chao	Hei		Gei		Zaat	Zoeng			Ro	Cao	Zhe	Hap	Keoi	Gun										Xu	Peng	Jue	Ketsu	Reki	Gan	Si	Zen	Sui	Que	So	Wu	Yan	Peng	Xiao	Pan		Zyun			Sin	Taan						Do	Tsui	La		Gun	Doi	Vo	Quanh	Vo	San	Lo	Vo	Beng	Zhen	Ji	Kotsu	Shaku	Jin	Lian	Ken	Rei	Zhou	Kyo						Hashi	Zao	Cuoi	Le	Qi	Bing							Kaku	Tsui	Yin	Pin	Tan	Oe	Tung	Me	Sou	Lu	Seki	Di	Du	Liao	Zhuo	Ma							Rai	Chang		Gach	Re	Ghe	Quanh	Soi		Chen	Ta		Jin			Ma	Que	Dao	Cin	Chen	Rang	Ko	Po	Lai			Seki			Zhong	Xie	Nen	Gach	Jiang	Qu	Lei	Ca	Que			So	Heki	Gach	Ra	Xiang	Lei	Den	Do	To	Lan			Lan	Do	La";
    case 598:
      return "Nang	La	Ben	Rei	Yu	Si	Rei	Hi	Sui	Sho	Jiao	Qin	Ji			Gan	Sui	Va	Yi			Ki	To										Yi	Zhi			Biao	Sheng	Jiu				Ngo	He	Fu	Shu	Ju	Mei	Shi	Shu	So			Taan	Tre	Tre							Na	Shin	Zuo	Yi	Shi		Dei		Xian	Yi		Si	Sai	Chui		Shin	Mo	O		Gwong	Tray	Rung														Zhan		Xun	To		Ru	Nhe	Huo	Lay	Ruoi	Yu	Shao	Sha	Sen	Ka	Shou	Katsu	Sha	Fu					To						You	Yu			Jun	Leoi	Lay	Nhe	Nhin	Luoi		Zi	Lu	Shutsu	Kan	Ka								Coeng					Chi	Kun	To		Shin		Zhun				Tho	Lai	Hou	Ho	Sai	Xu	Sai	En				De											Kai				Zong	Ying	Shin	Ken	Zhu	Shin		Liu	Shin	To	To	Lay								Nu			Ka			Nhom	Bi	Sho	Chi	In	Zu	Feng	Lu	Pu	Shin	In		Daai		Zhuan		Zhe	Shi	Yu	Lu	Liang		Le	Han	Jue	Liao	Beng	Sho	Kyo	Shi		Sin					Ho	So	Ryu		In";
    case 599:
      return "Vai			Yi	Guan	Roku	Lau						Ao			Gui	Min	Ryu	Yan	Lan	Cho		Bo			Zan	You	Rui		Kit			Ryo	Nhe	Kin	To	Re	Yi	Ni	Rei	Rei	Shin			Ni	Guo	Jun	Tan	Shi	Sui	Xian		Qian	Que	Kui	Sai	Tan	To			U	Sit		Hi	She	Setsu	Huo	Hi	Wan	Ban			Hi		Fei	Fei	Kei	Yu	Gat		Hei	Zhi	Gua	Hi	Jie	Mang	He		You							Du	Si		Li	Hi	Ri	Jie	Niu	Ba	Yu	Sui	Ki	Rei	Ki		Zhi	Hon		Shi	Wan						He	Ke	San	Koku		Cay	Du	Jia	I	Chen	Fu	Chui	He	Zhai	Sho				Mei			He	Zi	Zhu			Tuo				Giong	Cho	Zun	Ko	Ru	Duo	Jiang	So	Kei								Jia	Heng		Beng	Mo	Mochii				Zu		Kyo	Bie	Hotsu	Ku	Jia	Hi	Shoku	Katsu	Ryo	Zhuo	Hetsu	Xiu						Loi	He		Qiao		Kau	Thoc	Thoc	Ngo		Bong	Fei	Sheng	I	Tei	Hai	Zhui	Kuan	Ze	Xian	Rei	Bi	Yi	Boku	Chang	Shoku	Retsu	Ki		Muk	Gaai	Zung								Sai	Mao					To							Wan	Su	Retsu	Lui	Da	I	Bap	Wu	Ku	Wo";
    case 600:
      return "Xing	Ke	Sui	Jiu	Duan	Huan	Ren	Boku	Zhi	Ce	Rou	Ji	Rin	Ye	Shoku								Rei					Jing	Yang					Zong								Can			Trau	Giong	Rom	Rom		Si	Li	Gu	Chang	Ho	Fei	Liu	Ko	Jie	Yun		Shin	Zhi	Ko	Shu	Chou	Bie					Boku									Ki			Ji		Cho			Maa	Vua		Rei		Luo	Jian	Kei	Chuang	Shuang	San	Lu	Jun	Jiao	So	Ti	Zha	Ho	Gei	Yi	Chitsu	Cong	Nei	Jia	Seki	Shu	Jiao	Jung	Kei	Ji					Bon				Ai			Rei	Sui	Ma	Nanh	Mam	Rieng	Rieng	Jian	Sen	Thoc	Ben	Ryu	Fan	Sui	Zun	Dian	Gao	Gao	Lao	Ju	Zhuo	Shoku	Sho	Ki							Son				Tui				Bi	Ju				Gat	Ve	Hetsu	Hua		Shi		Cheng	Chua	Rei	Ra	Kuai	Dang	Ge	Xie	Shoku	Jie	Seki	Can									Zu		Pu		Shoku	Shu	Bu				Vung	Trong	Gio	Shi			Gi	Ning	Yan	Zhou	San	Meng	Boku	Bian	Dek	Xiang	Shin	Leon			Lu	Li	Chi		Shu	Ji	San	Mie	Lei	Rei	Zhi	You	Bian	Shoku	Tan					Ryo	Mu		Ran		Sui	Chuoi";
    case 601:
      return "Reki	Shun	Niao	Jau		Hi	Sen	Shin	Hi		Quan	Zhe	Yoku		Byo		Lei	Hi	Tai	Hen				Dang	Jue			Cau	Ling		Ling	Yan			Ketsu	Yao	Zhen	Qi	Ai	Soku	Nu	Mang	Ji	Gyaku	Niku		Tu			Kan	Seki	Jiu	Yan	Mian	Hi	Yin	Wan	Yao	Wa	Pi	Sui	Seki	Kyo	Soku					Hin	Kong	Miu	Sei	Hong	Shu	Ming	Ling	Yi	Shen	Yo	Zuo	Sho	Ro	Seki	Hi	To		Gu					Tu		Yong	Etsu	Wa	Gui	Hong	Sen	En		Shi	Tan	Xiong	To	A								Cheng		Keng	Yi	Yang	Ting	Dou	Cha	Liu	Ko	Kei	Shaku	Qiu	Xuan	Shen	Kuan	Tong	Kyo	Qian	Kyu	Chou	Ko	Tan		Mi	Wen		Long	An	Hin	Dei	I	Sotsu			Kan		Yao		Fu			Kai	Beng	Lan	Qia	Dian	Yu	Sai	Jiao	Gui	Bi	Xiong	En	Yu	Ke	En			Coeng	Sai								Kyu	Xian	Wong	Fu	Yu	Gen	Zan	Sha	Shoku	So	Ko	Shaku		Gong		So		Ou	Ke			Kutsu	Ku	Mei		Hang			Tian	Gou	Ma	Hi	Liu		Kiku	Yo	Wei	Wen	En	Fu	Go	Zai	Yo	Ryu	Gong	Jo	Tu	Ning			Mi		Nup	Rong	Lang	Qian	Man	Zhe	Ro	Hua	Yong	Jin	Yo	Mei	Gei	Sei	Fu	Go	Tam	Kyu	Qu	Setsu	Cho";
    case 602:
      return "					Seki		Kyu				Lung	Liu	Fu	Dan	Shun	Gong	Cho	Cui	Kyu	Kyu	Xing	Ki	Zan	Gei				Tu	Shou			So	So	Sui					Xo	Trong		Qiong	So	Zan	Yo	Kyu			Setsu	Jo	Rong	Kiku		Kyu	Setsu				Li	Kiku	Ryo	Ki	Ji	Tuo	Kiku	Sui					Hoam	Hiso	Chui	Kei	So	Tong	Xo	Shi		To		Tan	Setsu	Ling	Gen	Yi	Ruan	Senchirittoru	Pa				Ca			Tan	Yue	Que	Zhu	Hai									Gatsu	Gatsu	Dung	Sap	Fa	Hai	Tai	Zai	Hei	Oku				Lie	Deshirittoru			Hotsu	Bo	Bu	Ping	Lie	Shu		Xoi					Kui	Fu	Tian	Wo	Ha	Ju	Ryo	Ryo				Bing			Zhen	Shu	Fu	Shu	Ting	Trong	Trong				Long			Shu	Xi	Tian				Ji	Fuku		Zoeng	Yao	Kei	Cu		Miririttoru	Pang	Qie	Shaku		Dung		Gi	Long	Ji			Do			Tong	Yi		Chang			Ryo	Tai		Gong	Troi	Do	Dong		Sho				Ko		Xiang	Zuk		Ting	Ki	Zhuan	Yi	Yi	Zi	Qi	Ki	U	Cha	Yo	Ya					Zoek			Dun	Nua		Chong	Lu	Dun	Kyo	Fang	Shi	Ti	Ji	Qiu	Shui	Chen		Ko	Huang	Shi";
    case 603:
      return "Yun	Jun		Isasa			Long	Sho	Man	Gou	Can	Se	Chi	Xian	Mo	Ko	Shen		Po	Yao	Qu	Ran	Hi	Sen	Sen	Ju	Saku	Saku	Yin	Bai	Nie		Chou							Chom	Khau	Nia	Rong	Chuan	Nie	Li	Jiang	Kao	Ce	Chong	Zhua	Zi	Yang	Sen	Kyoku	Shun	Ta	Shun	Ei	Yo	Wen	Yu	Chiku	In												Ji	Ji	Dam	Mang	Mau	Lu	Qiu	Dun	Bao	Chan	Ya	Bo	Ho	Chi	Zhe	Mang	Shu	Ji	Miao	Yuan	Sa	Wu	Zhi	Ping	Ryo	Kin	Chong	Gin	Detsu	Kan		Sho	Mi	Fei	Cuo	Meng		Chiku	Ki			San	Na	Mang	Ryo	Sho				Lu									San		Buong	Hum	Pou	Dua	The		Yin	Mang	Dian	Diao	Ko	Qian	Sen	Tan	Hang	Zhi	Ju	Nian	Sen	San		Mi	Gu			Ken	Sen	Shu	Zhua	Nie	Zhuo	Ro	Ye	Cong		Xu	Saku	Xi	Za	Saku	Bo			Cho		Dung										Can					Yan			Sung	Ro	Van	Do	Ra	Manh	Tre	Mui	Xom	Cong		Jin	Sai	Shin	Ju	Dang	Du	Seon	Ye	Jing	Ke	Luo	Wei	Tu	You	Pai	Hai	Pi	Ding	Betsu	Wei	Che	Jian	Saku	Si	Zhuo	Sou	Ki	Ruan	Saku	Yu	Yu	Ei	Shi		E	So	Rei	Ku	Haku	Zhu	Chiku	Kiku		Keki	Kan	Xia	Ko";
    case 604:
      return "	Zing	Shu		Cau		Dai	Ke	Sieng		Thap	Kaku													Hi	Bi	Byo	Fu	Tao	Xi	Chou	Yuan	Lu	Ce	Shan	Liu	Ryu	Xi	Ji	Yi	Tan	Yo	Hu	Zei	Kiku	Cuo	Ge	Ka	Shi	Sao	Hong	Xian	Jun	Ho	Xia	Ryu	Sen	Ko	Chiku	Mu	Suo	Chi	Zhai	Jun	Fu	Se	Nu	Yi	San	Jin		Zen			Zik	Ryo				Ko					Zaan																Izaki	Ceoi		Qin	Qing	Kiku	Cot	Sao	Ghi	Gianh	Noi	Thoi	Gio	Chom	Ken		Vo	Hui	Shuang	Dan	Ou	Mo	Qian	Chi	Pai	Juan	Ryo	Kyo	Chao	Lie	Bing	Kou	Dan	Chou	Tong	Dan	Man	Hu	Liao	Xian	Kan	Cao	Lu	Chuan	Wu	Man	Chiku			Zi	Kai	Du	Da	Ko	Shuang	Fu	Ju	Zhou	Shi	Diao	Wang	Chuang	Qian	Tui	Heoi	Lian	Biao	Li	Sei	Kiku	Li	Sen			Toku	Ko												San	Ben	Sa			Wai	Geoi	Luoc	Khai	Gian	Ra	Bi	Fu	Cui	Du	Hai	Zan	Long	Xun	Qiong	Ji	Qian	Kan	Jian	Shao	Duo	Shu	Bu	Xu	Dong	Sui	Ran	Shuku	Yang	Rui	Lin	Jian	Di	Fen	Dian	Zui	Teki	Ning	Shun	Sai	Ten	Ryu	Suan	Tian	An	Sen	Rui	Ce	Ding	Shen	Du	Ti	Jiao	Zui	Zhang	Jian	Dan	Dan	Song				Gwan";
    case 605:
      return "Chiku		Hitsu														Zhan	Ting	Zhi	Sui	Bi	You	Pai	Thung	Mui	Dau	Gau	Choi	Chieu				Zyun	Li	Chi	Ho	Qian	Ken	Sui	Ju	Ai	Ge	Ju	Tun	Bi	Qia	Bo	Hui	Zing	Jian	Bin		Gou	Suan	Tan	San	Betsu	Saku	Ci	Qiang				Yan				Zaan		So										Dian	Ryo		Mie	Ki		Chieu	Toi	Hom	Ray	Giau	Lak	Nong	Po	Ling	Jie	Zhu	Gu	Ko	To	Duan	Zhao	Ban	Shao	Qin	Mi	Fuku	Ping	Cong	Chou	Chiku	Den	Sa	Kaku	Kiku	Kei	So	Bin	Beki	Tian		Bi	So				Chu	Chong	Mung	Thung	Lat	Gay	Mung	Non	Liu	Lu	Lu	Zou	Zhuan	San	Han	Lu	Huan	Sho	Tiao	Tui	Qiang	Lin	Bei	Pao	Zhan	Kei	Li	Sha	Sei	Ten	Ti	Hu	Sho	Kyo	San		Taga	Lie								Saku	Bi			Toi	Coi	Nung	Phach	Choi	Dam	Ta	Hui	Qu	Xuan	Sen	Jing	Die	Sui	Sui	Wei	Rei	Yan	Yan	Ban	Sei	Jiang	Ni	Li	Hu	Qi	Zhong	Kyo							Taku	Bi	Lach	Noi	Yu	Die	Lin	Li	Zhuo	Ji	Ju	Shuku	Feng	Ton	Yu	Sho	Ryo		Ryu	Sei	Kiku			Trac	Lie	Za	Qian	Jie	Guan	San	Zhuo	Kan	Sen	Fu	Gyo						Seki	Se	Mo	May	Cu	Ton		Sho";
    case 606:
      return "Bi	Nan	Gen	Hui	Giam	Hen	Liep		Dang	Long	Yi	Ki		Sieng	Tang		Ro	Kan	Nan	Nip			Ten	Sa	Yue		Di		Kan	Trum			The	Gan	Zan	Shan	Yu	Bo		Ding	Fan		Yu	Zoku	Shen	Kiku	So	Miriametoru			Gong	Ki	Mie	Tun	Detsu	Shi	Lie					Ketsu	Ryo	Ba	Tam	Zha	Pei	Fu	Mi	Betsu	Ming	Fan	Ta	Na	Si	Yi	Jia	Zhu	Fun	San				Ban	Yu	Rei	Po		Banh	Chao	Huan	Can	Jiao	Sho	Ei	Zoku	Tan	Jo	Bun		Saku	Ame				Zhi		Mi	Kao			Doi	Lau	Yao	Dui	Quan	Bu	Chu	Qiao	Liu	Bo	Bi	Kang	Fen	Sho	Ko	San	Jun		Zong	Gwing	Zi		Dao	Sen		Gin	Dou	Ge	Cho			Boi	Xoi	Thinh	Tam	Thinh	Lo	Xoi	Ba	Ba		Hi	Ling	Xi	Hai	Ni	Zhou	Zhou	Hi	Min	Chi	Bi	Chou	San		Dim													Sho	Nian	Ji	Shi	Qu	Sho	Oan	Xep	Com	Aa	Suong	Khan	Ia		Tan	Ran	Ratsu	Kai	Hyoku	Zoku	Xian	Yo	He	Ri	Lin	Ratsu	Zi	Fun	Sai	Shi	Ou	Cu	Shi	Fun	San	Ken	Cha	Leon	Me	Nam			Zhong	Bu	No	Deo	May	Thinh	Day	Chou	Xi	Sa	Xian	Se	Mian	Fun	Fan	Zhi	Ho	Cui	Shu	Fun			Rei	Xia	Shi			Bun	Che	Khe	Nep	U	Cut	Nuo	Li";
    case 607:
      return "Zu	Ritsu	Cui	Ze	Fu	Li	Satsu	Fun	Fun	Hi		Ri								Hi		Lep	Man		Qi	Roku	Zhuo	Cui	Pu	Chi	Fan	Tan	Hi	So		Shiina	Sei					Zi	Zu	Zhou	Rong	Lin	Tan			Keo	Ham	U			Shi	Sen	Rei	Ki	Cui	Zi	Fu	To	San	Kan	Cho	Xiao	Ki	Kyu	Thung	Hi		Kan	Feng	Seki	Ken	Cim	Gao	Com	Hem	Xian	Jian	Hi	Fen		Men			Li	Mo	Kyu	Hai	Rei	Haze			You		Phan	Phen	Rei	Xia	Huo	Saku	Qu		Xay	Duc		Niang	Ran	Rei		Mi	San	Bei	Qi	Ban	Nhao	He	Haku	Lian	So		To	Ran	San	So	Zuo	Sho	Tan	Ling	Men	Zoku	Zhu	Kyu	Niao			Ji	Reng	Jie	Gan	Ki	Gen	Yi		Shi	Zhou		Wu	Shun	Diu	Soi	Ko	Geng	Cu	So	Mie	Sho			Xun	Zen	Zhi	Xiao	Ko	Ki	Fu	Hu	Shi	U	Ketsu	Di		Jue	Diao						Phang				Shou	Ju	Ki	Wang	Ben	Buoc	Ngo	Vit	Vuong	Tim	Na	Di	Shi	Ci	Shu	Futsu	Wa	Che	Fan	O	Gu	Yuan	Futsu	To	Guan		Ki	Hikizuna			Giay			Qie		Zhan	Dai	She	Saku	Katabira	Ni	Wang	Chao	Khau	Soi	Zhou	Xiang	Ming	Zi	Huang	Mi	Keki	Xi	Zhi	Pai	Duo	Ta	Shu	Sai	Ci	Mou		Chao	Ko	Yi	Gou	Shi		Agemaki";
    case 608:
      return "					Nien		Jing	Saki	Ta	Dai	Buong	Nomi	Rach	Riet	Thua	Chang	Troi	Ku	Zeng	Ping	Ye	Jie	Shoku	Pi	So	Tei	Sha	Zhuang	Jiong	Kan	Sa	Liu	Yu	Sen	Ju	Kyo	Kyoku	Shi	Sho	Nuo	Dyun	Va	Yem									Mang	Chuoi			Mao	Thun	Xe	Cui	Noi	Keo	Rang	Vai	Boi	Nuoc	Ban	Shi	Chen	So	Zhuan	Nian	Kong	Jie	Hua	Shoku		Xin	Zuo	Yan	Jue	Sho	Mo	Shoku	Tan	Hu	Zhou	She	So	Yan	Kei	Xie	Die		Zui	Chen	Aki		Chang	Go	Nim	Chi											Ki	Zoku	Jian	Ji	Shin		Chuo	Hong	Mang	Ro	Mon	Nit	May	Vuong	Ung	Go	Da	Sui	Cho	Ting	Kai	Xing	Hui	Jian	Zhou	Zha	Fu	Chi	Beng	Nuo	Shuku	Shu	Ko	Ji	Qian	Futsu	Wan	Ou	Bi	Shuo	Kyo	To	Sho	Shi	Kei	Shu			Jing	Ye			Ping	Dam														Gan	Ko	Ju		Sen			Uom	Luot	Kasuri	Dot	Det	Buoc	Chai	Geki		So	Fei	Raku	Raku	Li	Shu	Kei	Li	Pi	Shin	Han	Shoku	Sai	So	Ko	Sui	Liu	He	Hun	Tan	Shuo	Zhi	Bo	So	Keki	Ken	Xi	Shi	Kei	Shi	Po	Qun	Kyo	Mu	To		Heki						Shima	Gai	Toi														Yong	Luot	Vai";
    case 609:
      return "Ma	Thun	Dai	Chit	Quan	Det	May	Nit	Xuyen	Shuku	Qi	Diao	Nie	Shuang	Satsu	Shao	Kun	Sui	Hen	Dou	Die	Hei	Shu	Ryo	Chin	Saku	Ju	Shi	Gong		Van		Nut	Maan		Cuon												Zhuan	Guo	Hen	Shuku		Chai	Dut	Ria	Thong	Xung	Chao	Rang	Kase	Xu	Qu	Hoku	Boku	Xun	Ta		Jiao	Zhe		Dian	Sang	Beng	Shoku	Suo	Qian	To	Rui	Ju	Xu	Ken	Xun	So	Shu	Mo	Shaku			Ken	Man	Jau	Cam	Cyu									Sho	Sen	Chi	Shu	Kai			Chu	Dui	Tan	Nhang	Dum	Thua	Vot		Vo	Sui	La	Zhu	Zhou		Li	Kan	Dan	Ju	Shaku	Yun	Chan	Luo	Shoku	Kan	Se	Ban	Lian		Zuan	Sen	Kyo	Lai	Shuang	Qie	Eki	Sen						Hi	Ryo	Yaku	Dou	Soi	Neo		Shu	Hyo	Wu	Meng	Ki	Ji	Kei	Chi	Chi	Mitsu	Ni	Sa		I	Ka	Ho	Sho	Cyu	Fai	Ban	Hetsu	Hei	Liu						Yao	Dui	Linh	La		Ritsu	Lu	Haku	Sui	Fu	Ken	Cho	Lei	Wei		Nhao	Sa						Cong	Ken		Ma	Roi	Kei	Li	San	Pin	Sen	Jun	Ju	I	La		Jing	Kin				Shin	Kai		Hen		Ji	To	Sen	Mie	Sen	Yao	Bian	Chung		Shuku	Cong	Si	Hyo		Si	Ken	Hi	He	Itsu	Ba	Kan	Shi		En";
    case 610:
      return "Shaku	Ritsu	Nhau	Nang		Die		Itsu	Che	Yun		Xiu	Shu		Chan	Min	Lian	Yin	Xing	Wei	Gu	Tou	Ta	Fei	Da	Nie	Cu	Zuo	Jie	Xuan	Bo	Jin	Yin	Xu	Fu	Yu	Xiong		Qi	Bei	Xing	Gong		Ketsu	Zui	Etsu	To	Ki	Jie	Ji	Kai		Fu	Xing	Bei	Shu	Yu	To	Zhou	Zhan	Sui	Chau				Tei	Zhong				Cha	Hei	Chui	Liu					Sui	Ka	Zhu					Sen	Sui		Caang	Bian	Utsu			Xin	Kan	Ya	Utsu	Taam	Ling	Rei		O	O	Ya		Rai	Sei	Mo	Ting	Shi	Mo	Mo	Bo	Bay		Mo				Toku	Mo	Di		Kan	Gun	Mong	Mo	Etsu		Pi	Hu	Cen			Ko				Tian	Mou	Juan	Ko	Mou	Bo	Ju	Liu	Ko	Ling	Dan	Sha	Ko	Liu	Hu	Gu	Bon	Tu		Shu	Min	Gu	Ho	Ko			Ko		Fu	Hu		Sha	E	Gong	Gu	Ko	Bi			Gua								Lue		Fan	Lu	Meng	Fu	Liu					Fu	Xie	Gu	To	Xian	Bo	Ki	Ji	To	Bo			Coek	Fu		Quan	Lu	Bay	Tetsu	Shin	Chi	En	To	Zai	To	Ra	Shuo	Mo	Sen	Mou	Yu	Han			Ra	Sho		Yue	Dan	An	Batsu	Sen	Shi	Yu	Jian		Chi	Gang	Kei					Baku		Ba	Hai	Sha	Sha	Cao";
    case 611:
      return "Shen	Liu	Hitsu	Chi		Mo	Jiao			Su	Su	Zhong				Roku	Ri	Ryu	Liao	Kei	Xuan	Lu	Chi	Ji			Yan		Sho	So	Kei	Lu	Haku	Min	Ti	Ken	Chi		Huan			Yi	Tan	Dan	Wu	Ki	Ken		Ji	Ki	Hi	Bu	Ra	Leoi	Ken	Du	Kun		Jun	Sen	Ro		Ken	Shi	Nan	Po		Ken	Shu	Quan	Ken	Hen	Ki	La	Ki	Me	Ren		Kyo	Fen	Tatsu	Goeng	Ta	Tun	Ta	Yang		Sho	Gan		Ko	Yo	Hatsu	Tei	Tei	Shu	Lik	Mi			Saku	Ta	Duo	Ci	Ketsu	Gu	Fen		Ko	Rou	Shu			Gao	Xiang		Xiang	Hou		Tao	Shan	Yang	Zi	To	Yuan	Sho	Ketsu	Tei	Do			Shitsu	Su		So	Chuan	Xiang	Cho	Ban	Chi	Man	Zen	Fu	La	Li		Jie	You				San	Yu	Yu	Chi	Guong	Chuan	Yi	Shan	Ko		Xinh	Ji	Yan	Ju	Kan	Wu	Chun	Mang	Katsu			Tanh	Fu	Jia	Gou	Gu	Jia			Ko	Xian		Jin	Zi	Lou		Kan	Gou		Sai		Ren	Gi	Shan	Bu	Dom	Jue	Tong	You	Reki		Kan	Shin	Do	Ei					Mieu	Bon	Jian	Du	Kan	Hu	Kai	Shi	Ei	Sao	Yu	Ei	Rui	Zen	Ko	Gi	Mai	Ken	Zhi	Yan	Gao	Juku	Huai	Reki	Rei	Sen	Sen		Quan	Zen	Rei	Yang	U	Zui	U	Jik	Bu	Xiao	Yi	Yan	Hong	Yu	Ko			Chi";
    case 612:
      return "Mou	Chi	Jik	Dan	Hang	Se	Pa	Ta	Fen	Chi	Shi	Ketsu	Hong	Xue			Man	Ci	Ngai			Ei	Zhi	Futsu	Zen	Ho	Haku	Qu			Ei		Xi	Fu	Hi	Shu	Hai	Ko	Po	Gei	Ci	To	Ei	Ei	Kyu	Hi	Yu	Yu	Chai	Riku	Botsu	Hong				Fu	Pao	Shen	Xiao		Shi	Xuan	Ci	Ting	Po			Canh		Luon		Ta	Cha		Zing	Zu	Huo	Xu	Yan	Chai	Kei	Tuo						Quat	Xian	Xuan	Hou	Huan	Ge	Chong	Bi	Hong	Hong	Chi	To	Cha	Ko	Sho	Sen	Shi	So	Fai	Cho					Zha	Ken	Zhai	Ta	Sen	Doku	Po	Ta		You	Fu	Ci	Da	Ta	Kyo	Liu			Ci		Hong	Wai	Han	La	To	Shi	Jap	Haku			Tong	Hui	He	Pie	Yu	Gyo	Kyo	Itsu	Sen	Yoku		Cin				Xian	Han	To	Po			Ko	Shitsu		O	La	Huo	Ro	Ro	Rin	To	Ken		Hi		Tai	Ko	Shu	Ro	Lao	Khu	Shu	Bo	Shu	Sau	Dao	Dian			Ten	Ki	Ki		Ju		Bo	Gia	Ju	Khu	Xiong	Lu	Coi	Wang		Che	Nai		Jue		Ji	Er	Er	Nu	Nu	Futsu	Dai		Sen		Lau	Zhuan	Fu		Ji	Ma	Nuo		Lie	Lei		Ba	Shi		Kitsu		Cheng		Ko	Gui	Quan	Ge		Gong	Shao	Shi		Un		Lai	Zheng	Yi	Gun	Wei	Lun	Cay";
    case 613:
      return "	Kyoku	Shi	Ying	Sheng	Tu	Bi		Ze	Zhong		Rong	Qi	Fu	Ce	Ko	Un		Zi	Li	Man		Lian	Biao	Do	Cay		Chuang	Yi	Tei	Tetsu	Ri	Pai	Seki	Seki			Yi	Kuai		Man	Biao	Ro	Chi	Qu	Mo	Zhe	Sha	Sha							Yao	Gong	Nai			Xie	Cho	Fu	Tian	Sei	Bun		Daam			Ye	Shin	Miu	Sha	Hei	Bo	Bun	Tan		Sao	Tan	Shin	Dian	Xu	Bo	Bo		Shin	Cho	Qu						Venh	Hong	Sheng	Ting														Duo	Ren	Gaap	Lau	Ta	Liao	Sei	Hong	Li	Ko	Xiang	So	Ryo	Shen	Katsu	Cho	Fu					Cho	Tei	Bit	Yan	Wang	Qi	Duo		Hua	Qian	Shu	Xie	Nghe											Sei	Ci	Sheng		Sim	Diec	Er	Shu	Xing	Kai	Tui	Yan	Ratsu	Lie	So	Bun	Mi	Jyu											Zong	Ren	Zi	Tai	Hu	Ying	Lian	Da	Tian	Tian	Jiku	Bi							Ta	Rong		Ai		Lang	Ai	Zhe	Guo	Lu	Zhao	Mi	Liao	Zhe		Ta		Qu	Cong	Lom	Ghe	Ting	Sho	Tan	Zhan	Hu	Ro	Pie	Katsu	Da	Rong						Nao	Tan				Nang	Dang	Jiao	Shoku	Go				Ju	Er	Diec	Katsu	Kai";
    case 614:
      return "			Ki	Kai	Kaku			Ren	Katsu	Li	Kai	Guo	Wai					Nie	Ei	Jin	Kai			Chu			Shuku		Shuku		Cho	Sho			Taku			Siu	Ve	Shi	Pi	Chi	Ko	Ko	Tei				Voc	Pi	Yi	Du	Wa	Xun	Ken	Qi	Shan	Hi		Xu	Jo	Kan	He	Pan	Chi	Pei	Sho	Xiong	To	Chi	Tan	Zui	Zuan	Qi	Du		In		Nguc	So							Go	Chi	Shui	Saku	Shun	Na	Xi		Sei	Chi	Ko	In	Moc	Shaguma	Hong	Tim	Chao	Yi	Ko	Ken	Zheng	Hitsu	To	Ju	Dai	Shi	San	Ka	Shin	Zhu	Wan	Gu	Ko	San	Ban	Jia	Mai	Ci		Kei		Ketsu	Kyo		Hai					Tuo	Shin	Qi		Ton	Kyo	Kyu	Zhuang	Tuo	Ken	Kyo	Ping	Chao	Cam	Zaap	Top	Shi	Shi	Shi	San		Peng	Kuang	Yi	Shin	Xie	Yue	Hen	Yu	Hou	Zheng	Chun	Shi	Wa	Ai	Xie	Ko	Sho	Shi	Jan	Kyo	Lou				Sai			Geng	Ko	Sen	San						Do	I	Kaku	Kyo	E				Deo	Chon	Gat	Ruot	Tai	Shi	Ku	Na	Shu	Shin	Ju	Xuan	Qu	Che	Lu	He	Sheng	Nan	Shin	He	Cha	Yan	Geng	Nie	Zen	Guo	Yan	Guan	Wan	Zen	Zhi	Lao	Ko		Jo	In			Du	Qi	Qu	Jue	Do	Su		Kyaku	Ratsu		Shi	Bet	Thon	Bing	Ngom	Nuc	Mang";
    case 615:
      return "Phi	Feng	Ko	Xu	Tui		Han	Ku	Cho	Hi	Shen	Zhi	Kin	Pang	Zheng	Li	Wan	Kei	Fan	Xin	Shitsu	Ki	Ya	Sei	Nyu	Jin	Ko	Ju	Shen	Heso	Ron	Ho		Sha									Cho		Jiku	Mang		Tun	Zhuo	Xi	Yin	Jing	Tun	Kyu	Bo	Geng	Ji	Kei	Heki	Shu		Yo	Sei	Kan		Kei	Dit	Rom	Rang	Phen	San	Dit	Ngac	De	Tron	Mun	Mep	San	Phop	Zhuan	Ho	Iku	Tie	San	Zhi	Do	Ji	Fu	Ki		Ying	Wei	Kei	Huan	Ting	Chan	Ra	Jim	Kui	Qia	Ban	Cha	Tuo	Nan	Jie	I	Yan	Yo	Tu	Ritsu	Wen	Tetsu	Cong	Shu	Ei	Xu	Yin	Kan	No	Beng	Zen	Luon	May		Lu					Zai	Da		No	I	Nie	Ju	Hou	Kai		Riku	Geng	Cay	Nghen	Oi	Nguc	Voi	Day	Phay	Hoan	Hou	Kan	Gong		Hui	Xie	So	Shoku	Xi	Han	Mi	Ton	Weng	Hun	Sao	Xin	Zhe	Huo	Ryu	Gong	In	Sho	Sai	Jin	Wa		Shi	Ritsu	Dui	Chi	Jung	Jim		Fuku							Xi			Ra	Bo	Mi	Zang	Sang					Com	Phoi	Bo	Zin	Gay	Suoi	Khu	Ma	Ia	Gion	Tun	Zhi	Wen	Mo	Nem	Yin	Tun		Chong	Ze	Seki	Xiao	Mo	Cu	Kai	Shun	Bian	Xiu	Ton	Baku	Yi		Yo	Luon				Huang	Roku	Zha	Suo	Hun	Ju		Beu	Nem	Boi	Nach	Lon	Ngoai	Nac	Be	Mat	Khu	Dui";
    case 616:
      return "Setsu	Cu		Sei	Ji	Xun	Sun	Ceng	Ketsu	Yi	Do	Chi	Ji	Kaku	Biao	Ta	San	Ketsu	Jue	Li	Setsu	Sei	Pao	Seki	Vai			Za	Ye		Bi	Zhe	Zhe		Jiu	Zhe	Do	Kan	Shu		So	Reki	Xi	Don	Sen			Nhon	Vac	Phet	U	Suon	Cam	Roi	Seo	Xu	Nai	Xian	Gun	Wei	Ro	Voi	Ji	Sa	Shitsu	To	Dong	Nuo	Du	Zheng	Ku	Taku	Yo	Ming		Ron	Yo			Ndwen						Bao	Hui	Shu	Tsui	Zong		Hi	Hi		Gam	Lung	Song	Ngay	Rau	Bam	Chun	Nach	Dong		San	Shitsu	Teng	Yi	Chi	Yu	Pou	Dit	Haku	Yao	Ning	Ro	Chou	Hun	Kan	Dui	Ji	Qi	Ying	Bing	Ning	Huang						Zen	Buoi	To	Ying		Ji	Mat	Bao	Ko	Duk	Ki	Guang	Lei	Zun	Shuku		Mak		Seki	Yo			Chan	Fu	Ryo	Kun	Shu	Cho	Phich	Rang	Noc	Noc	Jian		Sui	So	Meng	Sen	Xiao	Sui	Ro		Ho	Kan	Xin		Li		Vai	Lot	Rom	Dui	Ma	Haku		Qiao	Yo	Ei	Kaku	Gay	Wei	Na	Hyo	Pang		Lei		Ba	Luo	Haku	Rui	Dei	Luan	Bu	Geng	Nan	Luan	Ren	So	Qu	To		Pheo	Luo	Nhau	Nang	Nang	Dei	Luo	Yue	Ji	Ji		Bo		Shui		I	Mi	Wang	Ce	Jian	Wang	En				Ko	Jia	Nam	Zak	Rin		Huan			Rin	Lian	Zi	Bai	Shou	Ji	Kei	Wan	Kei";
    case 617:
      return "Chou	Wan	Shu	Ko	Batsu		Un	Gui	Xi	Sen	Ru	Yao	Ki	Ko	Gao		Ko	Gou	Shu		Ben	Yue		Ko	Yong	Wa	Bo		Go	Ben	Getsu	Xin	Hoi	Yo	Pi	Bo			Hai	Zhai	Wo		Ye	Bi	Hai	Let	Thoi	Kham	Thum	Khan	Butsu	Shi	Shi	Shi	Zhi		Chi	Zi	Chi	Zhi	Oku	Ni	Den	Oku		Wu	Ai	Den	Dai	Tetsu	Aku	Zeon	Ai	Yu	Chi	Chi		Jing	Zhi	Zhi	Zhi	Ju	Shi	Shin	Shin		Han			Ei	Ping	Caap		Yao		Yo	Yo	Hatsu	Kan	You	Ping	Hatsu	Mo	Hen	Yo	So		So	Zuo	Po	I	Xue	Kuang	Yi	Po	Ken	Sho	Yo	Kyu	Kyo	Yo	Kyo	Yo	Zhui	Yo	Sho	Haku	En	Shin	Bei	Shi	Ni	Qiu	Cou	Kyoku	Sui	So	Sen	Kyu		Yao			Sei	Haku	Fen		Sho	Hi	Xia		Jiang	Cha	Kyo	In	Xiao	Cha	Kyo	Yo				Cheng	Cui	No	No		Qiong	Jim	Yu	To	Yu	Jo	So		Wen	To	Cha	Yu			Cung	Jo			Zuo	Dao		Shu	Juan	Dao	Ying		Feng	Sen	Lau	Jin	Weng		Shi	Jin	Qi	Sen	Qin		Kuo	Kin	Tan	Xian		Tian	Shi	Kuo	Sen	Tian		Hu	Zhu	Zhan	Ta	Luoi	Tian	Ta	Ta	Hua	Yan	Tie		Tie	Ta	Ji	Shi		Ten	Shi	Shi	Huai	To	Jia	Qi	Kei	Ta	Loe		Tan	Hua	Sha	Liem	Zhuan	Hua	Laai	Ten	Lan	Luoi";
    case 618:
      return "	Ko	Mua	Ko	Ko	Bu	Zun	Yi	Fu	Wu	Fuku	Fu		Ding	Ta	Gitsu	Tai	Chai			Jin	Fuku	Chao	Han	Ki	Ri	Quan	Ko	Ge	Tei	Kawara	Shi		Fu	Di	Diao	Yong		Jia	Moku	En	Long			Yong	Pi	Doi	Huo	Qiong	Shin	Fan	Wu	Tong	Hang	Chin	Batsu	Tan		Ei	Khoang	Ko	Kin	Heng	Tei			Syun		Tiao			So	Zhou	Shu	Geki	Bai	Xie	Dao	Chin	Jin		Loi				Hu	Bei		Ding	Shu	Mui	Gu	Nuo	Wei	Yu	Fuku	Xing	Fu	Xian	Qi	Tu	Ketsu	Shin	Ji	Shin	Ying	Ka	Deng	Wei	Xi		Pai	Xuong	Sheng	You	Gia	Ai	Jian	Kei	Gou	Ruo	To	Kyo	Cho	Gong	Shu		Sha	Tang		Do	Song	Ko	Tei	Ki	Lu	Ao	Shin	Qi	Xiu	Yoriai	Dai	Ho	Thong	Song	Fa	Wei	Shuku	Dun	Liao	Fan	Huang	Jue	Ta	Zun	Rao	Can	Teng			Hua	Xu		Zhan	Ho	Shuku	Xuong	Gan	Tray	Rei	Peng	Can	Xie	Da	Sa		Go	Ji	Shuku			Ghe	Li	Boku	Sa	Pan		Khoang	Ghe	Long	Li	Xi	Teng	To	Yo	Ling	Rei	Sa	Rei	Waku	Li	Ran	Ling			Futsu	Gun				Kan	Shaku	Po	Mo	Pai	Ho	Bot	Ba		Futsu	Kyoku	Shun	Gan			Qi	En	Ho	Yan		Kei		Gan		Wa	Ang	Kei	Ming	Min	Xun	Meng	Ho		Guai			Jiao	Ko	Jin	Yu	Shi	Gai	Kai			Gai";
    case 619:
      return "Ya	Cai	Wu	Zhe	Ren	Kou	Bo		Kitsu	Kai	Zi							Tabako		Jau	Zhao	Zhong	Qiu	Guo	Gong	Pu	Hu	Mian	Ko	Hatsu	Tian	Ki	Kyo	Sui	Bodai	Wang	Ko	Kyu	Gi	Yu	Cek											Ka		Bodai	Ngo	Shi	Zhu	Da	Xiong	Na	Detsu	Ho	Juan	Kai	Shi	Nian	Kan	Hei	Shi	Kai	So	Shi	Hu	Sha		Ho					Cik	Ting	Zing	Sai								Cin	Zhi	Batsu		Ta	So	Si	Han			Yi	Tro	Tup	Cho	Shi	Hung	So		Qiong	Zhi	Lu	Ru	Soku	Qi	Yu	Zhou	Yang	Xian	Mou	Chou	Hui	Jiu	Jiu	Piao			Ya	Tatsu	Jiao	Si	Guai	Bo	Mo	Shu	Shitsu	Shi	Ryu	Su	Ko	Ken	Kai	Ko	Ji	Xi	Pu	Kyoku	Kei			Jau		Jo	Ki				Mong			Mo														Yoku	Ji			Re	Kei	Nen		Wen	Bei	Yi	Fu	Si	Juan	Ji	Koku	Ni	Ku	Ben	Son	Shuku	Kyoku	Ru	Xu	Bo	Ju	Qin	Bo	Ketsu	Chiku	Wang	Zhe	So	Wo	Shao	Zao	Yang	Sho	Tei	Song	Nie		San	Sha	Katsu	Bi	Kan	Sho	Bi	Kyo	Gan	Ki	Sen	Cu	Qiang	Ken	Byo	Yo	Kyu	Sui	Xiao	Zhi	She		Bo	Zhi	Peng				I			Miu	Ki";
    case 620:
      return "															Diao							Wo	Ka	Zhi	Bi		Fen	Ta		Cho	Ngon	Ong	Na	Nua	Day	Lau	Bang	Cai	Yo		Gaan	Qiu	Ni	Bo	Dun	Fu	Shi	Xu	Chang	Xu	Ye	Mi	Kai	Kyoku	Mitsu	Xin	Zhuo	Fu		Seki	Pi	Xue	Ta	Yu	Xian	Yu	Yu	Gu	Ju	Ta	Kong		Ryo	Zheng	Meng	Gang	Ma	Ji		Ko	Sen	Mu	Xi	Bi	Ka	Fu	Ji	Bo	Chu	Un	Betsu	Xiao	Retsu	Bai	Bo	Jiu	Jaku	Jaku	Gou	Baku	So	To	Kutsu	Bi	Kyuku	Su	Shu	So		Hei		Chi	Jiu	Jiu	Shi	Baku	Sha	Jaku	Fei	Ryo	Kyo	So	Su	So		Ping	Diu	Ji		Geoi	Yu			Kyoku	Butsu	Kai										Nhai												Shin						Ji							Fu	Ma			Wan	Xu	Bo				Chenh		Lei	Jyu	Ra	Sa	Rom	Ngo	Jan	Muop	La	Mui	Hao	I	Xie	Pian	Yu	Yan	Tian	Pi	I	Shi	Kuai	Ji		Sho	Zha	Nai	Mou	Jin	Fu	Du	Kyu	Kei	Sheng	Cha	Chi	Chi	Gui	Min	Tang	Bai	Qiang	Hatsu	Zhuo	Wei	Xun	Hyo	Miao	Zai	You		You	Son	Shan	He	Lu	Zhi	Shu	Kyo	So	Jing	Zhen	Katsu	Shaku	Meng	You	Shu	Wo	Ba	Chi	Zetsu	Juan	Ru	Cou";
    case 621:
      return "Zhi	Betsu				Sui	Ko	Ei	Jaku	Hu	Yang	Mu	Jun	She	Kou	Ho	Han	Qian	Kyo	So	Meng	Taku		I	Kai	Rei	Tiao	Sen			Ten		Boku		Ci	Ji	Jing	Seon	Haak	Fei	Kwan	Seon	Nei				Han		Cho	So	Betsu	Ko								Kan	Shin																			Zong	Nie	Geoi	Shu			Shirakuchi		Ke	Sa	Nhua	Nu	Dot	Ray	To		Chi	Araragi	Xiong	Ko	Hun		Utsu	Di	Lang	Bi	Zao	Ce	Suo	Zu	Sui	Setsu	Xia		Xie	Shin	Kiku	Jie	You	Chiku	Gou	Geng	Tan	To	Sen	Jun	Huang	Ji	Pou	Wu	Fun	Yi		Detsu	Nai	Ju	Rong	Nan	Shi	Ping	Shan	Diao	Ji	Hua	Dui	Kong	Ta	Ka	Hong	Ku	Shu	Rui	Kiku	Ken	Heng	Fen	Bo					Gan	Hou	Hong	Lit	Jyun			Gwan		Mehajiki	Ju		Sui	Rei	Wan	Keki	Hei		Kou																									Nagi								Katsu	So	Ro		Kyo	Sho	Nian	Shi	Ho	Haa	Chu	Satsu	So	Do	Ki		So			Qiang		Che	Bom	Seoi	Hoi	Bi	Coi	Ngo	Mai	Fau	Sen	Xi	Hu	Song	Wo	Bo	Hai	Ru	Meng		San		Wu	Tei	You";
    case 622:
      return "Kei	Tan	Shen	Ken	To	Kau	Qi	Seot	Guo	Qia	Xian	Kan	Kan	Tatsu	Ji	Sui	Lu	Betsu	Ji	Qi	Diao	Doku	Ju	Qi	Jia	You	Xi	Chao	Sai	Shitsu	Mitsu	So	Zei	Mi	Lou	Bi	Sai		Hotsu	Kin	Kin	Hitsu	Pei	Kon	Shun	Go	Zhen	Shen	Chan	Fu	Go	Joku	Tetsu	Kyo	Qu	Si	Shu	Kyu	Zui						Kugo	Yo	Bou	Fau	Siu	Jyun	Kin	Sa	Sa	Bo	Go		Tai	To																Tsuta			So	Hyo	Zo	Kai	Sen	In	Ei		Sho	Ho	Baku	Zhao			Coi	Co	Mam	Gung	Wan	Thom	Bim	Co	Voi	Pui	Den	Nhai	Rac	Dam		Pi	Bo	Sa	Cou	Ei	Ha		Hing		Gao	Du	Syun	Fu	Guan	Sao	Sou	Jian	Pou	Ko	Can	Beng	Mou	Zhao	Xiao	Ki	Ju	Shu	Jian	Li	Chu	Chuan	Lao	Do	He	Hu	Gu	Zhang	Jie	Xiang	Jo	Du	Han	Jia	Xiang	Ji	Shu	Lang	Ji	Shan	Yu	Cho	Tao	Zi	Shuan	Yoku	Ji	Chu	Ji	Shen	Lin	Liao	Kei	San	In	An	Ruan	Shoku	Ti	Dan	Son	Huan	Sen	Sa	Ki	Kei	Haku	Fuku	So	Kin	Fu	Kin			Zaau	Wing	Mou	Cing	Fei	Jan	Hyun	Zeon						Keki		Sho	Kin	Shu	To	Rai	Sen	Hi	To	Kan	Ko		I";
    case 623:
      return "			Sang			Rui	Wu	Ju	Huan	Leng	Lu	Den		Tan	Zeng	Hyo	Shuku	Shin	Qian	Leu			Xi		Tei	Lum	San	San	Nau	Dua	Khay	Akebi	Ci	She	Iku	Ryo	Dua	Sing	Sa	Cu	So	Mao	Qu	Sho	Bo	Gan	Zuk	Qie	Juan	Dang	Chang	Yang	He	Cho	Ji	Ko	Bing	Tetsu	Mei	Gyo	Ki	Chu	Dun	Ao	Jing	Lu	Mian	Dian	He	Getsu	Jian	Yu	Tan	Hua	Gou	Fuku		Lu	Fu	Hui	Shun	Zei	Kei	Jin	Si	Qun	Futsu	Shi	Son	Getsu	Ko	Dan	Ra	Wan	Bian	Go	Bo	Tai	Kan	Jia	Shin	Man	Yu	Ko	Ju		Dan	Jiu	Xian	Bo		Tranh	So		Jyu	Zing			Sen	Ka	Bo		Ho																				Xia	Ran	Biao	Batsu	Ka	Kyu	Po	Bitsu	Shin	Sao	Bei	Sha	Wei		Cang	Lu	Zaan	Dua	Mei	Ram	Choi	Do	Vung			Getsu	Dan		Gu	Za	Bang	Gan	Ryoku	Rin	Chao	Ji	Lie	Han	Qiong	Jian	Lu	Duan	Suan	Yao	Yin	Ko	Ta	Yao	Jing	Chu	Fu	Yuan	Shao	Cho	Bing	Dang	Shi	Yaku	Sen	Lu	Qie	Luo	Po	Satsu	Meng	Jie	So	Shin	Ji	Hei	Sho	Lu	Bo	Sho	Taku					Cung	Ji	Iku		Bo	Ko	Chiku	Yu			Shi	So	Ho												Nagi	Ogi	Tan";
    case 624:
      return "			Kyoku	Chang	Mie	Meng	Jian		So	Cai		Su	Kyoku	Gou	Sung	Goi	Giong	Non	Ru	He	Sa	Tei	Zi	Keng	Geng	Si	Hi	Sam	Teki	Trai	Day	Ti	Zhan	Xie	Shui	Chi	You	Lu	Meng	Lie	Si	Ro	To	Xi	Fan	Fu	Shen	Ti	Chai	Yue	Shi	Fu	Jian	Di	Shin	Boku	Zhe	Xie	Dan	Setsu	Sho	Tei	Zhi	Kan	Jo	Sui	Xu	Sen	Sho	Sho	Jaku	Nie	Fan	Meng	Min	Bo	So		Tei			Joeng		Fu	Hei	Kiku	So	Shin																Su								Kei				Ghem	Vo	Gien	Kho	Vung	Kho	Ruom	Ki	Zui	Ryo	Lou	Du	Baku	Zhan	Jian	Han	Dan	Sen	Jian	Tan	Jiao	Po	Kai	Ping	Shun	Zhuan	Ko	Liao	Zi	Sen	Zhuo	Chi	Hu	Bo	Kyo	Shin	Do	Xi	Sho	Meng	Ju	Mie	Xian	Ki	Kui	Meng	Jian	Koku		So	Nou	Ban	Di	Sao					Zing	Wan	Jin	Ketsu	Kiku	Ten	Kan	Ban																						Dua	Rap	Kwai	Setsu	Chu	Zhi	Qian	Lu	Kiku	Zhuo	Ken	Sen	Ko	Zuo	Han	Sui	Gou		Chou	Ji	Yi	Yu	So	Kyo	Kon	Jin	Ei	Kan	Bi	Nou	Ni	Ruo	Sha	U	Ka	Lin		Kwai	Ning			Tsuzura	Dang	Muong	Khoai	Fai		Bo	Shoku		Ung";
    case 625:
      return "								Reu	Zung	Han		Dan	Qiao	Yao	Fu	Shuang	Kui	Qu	Dong	Shu	Shoku	Hyo	Sho	Gi	I	Li	Ju	Rui	Saku	Geki	Sen	Zha	Sho		Sho	Xiao		Fuk	Wan		So	Ka	Han							Mo	Kieu	Ngong	Rap	Ran	Geki	Men	Shi	Dian	Li	Deng	Zan	Hi	Luo	Can	Kyo	So	Ao	Gi	Ka	Jian	Ken	Diao	Kyu	Ryo	Ying		Jo	Shoku	Rei				Kyu		Rap	Yi	Dang	Nou	Gi	Yue	Cho	Shin	So	Shu	To	Sei	Katsu	I		Bou	Hing				Sen	Shun	Rac	Men	Muong	Li	Li	Hu	Sei	You	Ri	Sei	Pan			Tan		Nang	Zen	Jo	Kai				So	Chen	Ra	Thuoc		Yaku	Ken	Gi	Feng	Bie	Zen				Man	Gan	Huo	Kan	Cu		You	Zen	Kai	You	Son	Zen		Xu	Gyaku	Ko			Xu	Hu	Lu	Gi	Xia	Yi	Gyaku	Ro	Gyaku	Ko	Gitsu	Ko		Hu	Hu	Zi	Gyaku	Hei	Kyo				Gong	Tui	Wu	Ling	Gu	Zhong	Beki	Kyo			Ko	Ko	Han	Lu	Beki	Kyo	Sa	Zu				Tong	Xia	He	Ro	Shuku	Ho	Ho	Yue	Gai				Sho	Nan	Bo	Hu	Qi	Shu	Qiang	Zhou	Yao	Gu	To	So	Sho	Ban	Kan	Ji						Ho	He	Ji	Hu	Yan	Ko				Chun	Ding	Qiu	Hou		Beki	Hao	Kyo	Ki	Zu";
    case 626:
      return "Rei	Xian			Xia	Xi	Shu	Hin	Se	Ha		To	Ge	Xi	Kaku		To	Ge	To	Kaku	Lu	Ro	Ge	Ke	Ryo	Shou	Zhu	Si	Teng	Ya	Ni	Joku	So			Nai			Luo	Sui	Chi	Toku	Chan	Gu	Ko	Wu		Yu	Ki								So	Zao	Toku	Yi	Xi	Hong	Quan	Wang	Chi	Xi	Tian	Yun	Ben	Yi	Ji	Hui	Fou	Toku	Fu	Ben	Shi	Ji	Xuan	San	So	Tai		Du	O	Can		Yuan	Chi	Trun	Vat	Di	Ki	Cay	Zhu	Tai	Shi	Rong	Xue	Yu	Fan	Bei		Qu	Kyo	Bu	Jia	Zha	Bun	Nu	She	Bo	Ten		Li	Ho	Mitsu	Aku	Shu					Bang					Gaa	Moku			Gui	Guai	Fu	Dai		Buom	Nhong	San	Chao	Shi	Etsu	Gai	Ritsu		Ci	Cho	Yan	Song	Shi	Ji	Ku	Zhi	Tong	Qu	E	Kaku	Xing	Ru	Yu	Kyo		Yi	Yi	Xu	Fou	Ge	Zen	Ho	Raku	Kai	He	Yin	Kyo	Hong	I	Duo	Cyun			Gong	Doe	Mo	Shi					Xing	Fan	Retsu	Chau	Nhai	Vo	Chuon	Cong	Ran	Doi	Chach	Chi	Qi	Sha	Go	Du	Di	Li	Yi	Xi	Geng	Tong	Kao	Hong	Kun	Nie	Chi	Ti	So	Tong	Kyu	Shitsu	Cho	Cho	Bo	Li	Na				Soku	Mei		Nomi							Kyo		Zhan	Bei	Kyo		Cuong	Mot	Ghe	Tranh	Gioi	Chay	Lan	Nhong	Mang	Op	Khoai";
    case 627:
      return "Than	Tiao	Muguromochi	Za	E	Shou	Kong	Peng	Fu	Lu	Xie	Xie	Xiu	Lu	Tian	Ta	Ci	Qu	Yoku	Fu	Zhi	Yu	Xie	Zou	Fei	Min	Xing	Fu	Sho	Tong	Qi	Kyu	Piao	Shitsu	Sui	Er	Kan	Seki	Bo	Hu	Seki	San	Kyo	Ko	Ryaku	Shi							Ki	Retsu						Song	Shu	Bie	Ding	Ban	Shi	Xie	Xiao	Fei		Sua	Cua	Sua	Dom	Dia	Gioi	Ngai	Chau	Ray	Hon	Cua	Ray	Mo	Chuan	Shuai	Yao	Jue	Sheng	Chaku	You	Fan	Kai	Yo	Kui	Di	Gaku	Mao	Jie	Soku	Yan	Tai	Shi	Wei	Ten	Kan	Sang	Jie	Yu	Wei	E	Quan	Jiong	Feng	Long	Die	Pian	Yu	Lian	Hu	Lu	Kaku	Shu	Men	Ko	Hen	Retsu	Gi	Shu	Dian	Seki	Kai	Ka	Cui	Mou																	Wang	Juan	Ke	Yan	Jiao	Haa	Dot	Oc	Chau	Ho		Ran	Gong	Toku	Rong	Sun	Shan	Kyo		Chi	Ketsu	Qi	Suo	Toku	Ye	Zao	Que	Zhan	Ba	Zu	Suo	Zhe	Xi	Ki	Chu	Jiao	Zui	Ge	Wu	Yo	Shin	Lue	Ji	Shi	Chi	Xie	Xie	Sei	Seki	Dou	Rei	Men		Bo	Qiu	Go	Shi	Bun	Sho	Gen	Ping	Kyo	Liu	Chi	I	Pan	Ci			Koku	Kisa	Ketsu	Sei							Chiku	Jie	Zen	Hui	Ki	Ki	To	Sha	Shi			Nhuc	Sam	Dom	Ret	Bo	Choi	Rong	Ran	Nhuc	Zhi	Ai	Xu	Bi	Shu	Ye	Ni	Zhu";
    case 628:
      return "Jo	Su	Shoku	Xie	Yu	Qu	Ki	I	Zu	Zhi	Zhang	Lue	Wei	Chong	Mi	Chi	Ji	Ryaku	Su	Ye	Xi	Tuan	Lian	Xuan	Bo	Wu	Sha	Fuku	Koku	To		Mao			Hou	Ryaku									Hong	Seki	Sen	Lue	Du	Cong	Chan	Lu	Su		Seki		Diu	Doi	Thuong	Nhoi	Chau	Rom	Bo	Sung	Lue	Sam	Cay	Ngao	Zung	Etsu	Zhong	Li	Fei	Fu	Jing	Kui	Yi	Hua	Cui	Zuk	Yu	Beng	Tun	Shu	Dai	Wu	Ci	Ning	Dang	Zu	Han		Pi	Chuan	To	Ryu	Du	Pa	Gi	Jo	Zhu	To	Xie	Zhe	Qie	Xuan	Han	Sao	Shu	Tetsu	Zen	San	Toku	Tetsu	Shuku	Sa	Ki				Shu								Bi	Sho	Fu	Yo	Gaan	Buom	Zyun	Sau	Li	Rua	Ray	Rom	Rua	Rua	E	Shin	Ye	Shu	Ho	Se	Kyu	Qi	Guo	Se	Ka	Fu	Mao		Lei	Zhan	I	Shu		Katsu	Shitsu	Getsu	Katsu	Go	Chu	Bitsu	Chai			Dei		Wei															Kei	Lei	To	Zei	Ying	Ai	Xie		Bi	Nong	Chuon	Rien		Sei	Hi	Chan	Kei	Ban	Pi	Cong	Lie	Qi	In	Ji	Jing	Dong	Fei	Yi	Tuan	Han	Ketsu	Ko	To	Hen	Ka	Shun			Bun						Meng	Can	Ya	Mitsu	Kei	Men	Vich	Ngoe	Sam	En	Yang	Shitsu	Ting	Tai	Ho	Setsu	Zhi	Bun	Xie	Lu	Bo	Li	Kei	Mao";
    case 629:
      return "Jun	Yoku	Xia	Katsu	Katsu	Sou	Hi	Zen	Ken						Ro	Tei	Tai						Su	Xue	Ken	Bau	Cong	Nhang	Ram	Li	Yuan	To	Ki	Zhan	Sen	Ta	Xuan	Wei	Ye	Pang	Mao	Ti	Pin	Jun	Du	Qiu	Yi	Hi	Sen	Tai	Mei	Tuo	Chai	Katsu	To	Jin			Tai		E		Gioi	Diu	Vich			Chan	Ying	Ling	Ki	Xian	I	Qi	Sho	Yue	Lue	Ying	Qu	Sit	So	Ho	Fei	Zi	Katsu	Bo				Qing	Trai	Ta	Gen	Ning	Wei	Shuang	Shu	Fu	Yoku	Sen	Mo	Mo	Tuo	Chai	Zang				Re	Ram	Li	Li	Fu	Xia	Juan	Ra	Nan	Mi	Gi	Shun	Huang	Shun	Shuang		Xu	San	Setsu	Fei		Xie	To	Hen	Rei	Bitsu	Ta	Yong	Hi	Zhan	Sei	In	To	To			Rom	Qiang	Nang	Yu	Lin	Hi	Ban	No	Luan	Xian	Fu	Chi	Ling	Sho	Ten		Sao		Hui	Maan	So		Moi	Tei	Ting	Jiku	Qing	Ketsu	Huang	Ko	An	Hai	Mau	Mau		To	Myaku	Man	Tan	Ni	Mei		Tan	Guo	Ou	Mei	Kan	Xiang	Kan	Jin	Deki	Shin	Kan	Mu	Zheng	Ki	N	Ho	Shin	San	Hu		Zu	Hui	Kan	Chu	Ji		Sai	Do	Ye	Jiku	Sho	Kyoku	Kyoku	Kan	Kan	Ki	Do	Do	Jin			Ko	Hon		Xing	O	Gyo	La	Yu	Jue	Bi	Ken	Gyo			Shu	Zheng	Gen	Yong	Shutsu	Ge	Jutsu	Jian	Xin	Ken	Gyo	Hui	Hang	Hang	Shuai";
    case 630:
      return "		Chong	Hang	Do	Ko	Ku	Ay	Liao	Ei	Ei	Han	Jing	Jiang	U	Gong	Taku	Zhuo	Han	Tei	Shimo	Kami		Qi		Han	U		Qian	Hyo	Dou	Po	Fun	Hyo	Hu	Shu	Ko	Niu	Hyo	Qi	Diao	Diao	Sha	Li	Han	Kin	Xiong	Ei	Hyo	Fuki	Zi			Han	Kyu	Kai	Xon	Taai				Na	Shi	Zheng	La	Zhi	Hi	E	Bo	Po	Xu	Yong	Ci	Li	In	Shi	Pao	Chitsu	Ko	Xiu	Kin	Ka	Kan			Mei	Wu	Jau	Ho			Pu	So	Che	Qi	Ei	Shu	Yi	Shoku	Ti	Duo	Long		Jian	Jin	Retsu	Kai	Kan		Zhan	Yuan	Ken					Kei	Reki	Yu	Retsu	Geng	Ka	Hou	Lot	Rach	Truong	Qi		Mu	Huan	Long	Xi	E	Lang	Fei	Wan	Ki	Cun	Ten	Peng	So	Kyu	So	Cuo	Weng	Kaku		Kamiko	Tung	I						Toku	Chi	Sai		Vay	Song	Gao	Xong		Kei	Cui	Cho	Ko	Qi	Li	Qie	Qian	Kong	Beng	Cho	Shou	Tei	Ho	Retsu	Sei	Kyo	Shi		Wei	Ho	Kon	Shi							Sei	Ko	Kon	Shan		Dup	Trang	Lun	May	Rach	Nem	Vat			Zi	Aku	In	Ti	Qian	Du	Bo	I	Tu	Kyoku	Ho	Wei	Kin	Ho	So	Hu	Xing	Koku	Shan	Zhi	Ka	Sho	Ko	No	Chi	Ei	Ko	Katsu	Ko	Kun						Ei	Shu			Day	Toi	Zhou	Weng	Chi	Suo	Xie	I	Ke	Reki";
    case 631:
      return "Ming	Shai	Shi	Shou	Kan	Jie	Ju	Yo	Jo	Gao	Lu	Kai		Shi	Tasuki	Pui	Tre			Ka	Xie	Tei	Chan	Maa	Vien	Xong	Zhi			Shitsu	Man	Ei	Shuai	Ke	So	Diao	Yi	Seki	Su	Chuang		Bo				Suk	Sai	Ho	Fuku	Cui	Tuo			Xie	Gin	I	Sui	Xuoi	Bau	Dung		Xuan				Hyun	He	Jue	Ju	To	Ti	Fei	Sho	Zhi	Shi	Tui	To	Ta	Chong	Reki	Ti	Zhan	Heng	Tan	Qu	Wei	I	Dun	Bao	Cho	Cho	Kai	Liao	Laai	Gei						Si		Rach	Chen	Cheo	Toang	Biao	Xie	Bie	Seki	Cong	Ko		Ken	Ju	He	Toku	Cho	Katsu	Kui	Yong	Ra	Bo	Sho	Hyo	Katsu	Ho	Kyo	Shu	So	Jo		Jyut	Daat					Dai	Rem	Sho	Nie	In	Yu	Zhuo	Meng	Hu	Shi	Kai	Lie	Tan	Toku		Ken		Shuku	Jo	Jie	Xiong	Sen			Kon	Yan	Toac	Noi	Sho	Hyo	O	Jie	La	Shu	Jie	Lei	Taku	Ho	Zu	Hyo	Shi		Diu		Toku	Kai	Wei	Du	Su	Jo	Ken	Chi	Mac	Rach	Chen	Vien	Kyo	Xie	Rang				Hyo	Kan	Haku		Luo	Hi	Shoku	Kon	Ken	Qian	Jo		So	Cho	San	Kon	Nang	Ling		Shu	Ji	Vat	Fuku	Shu	Ming			Gu	Ken	Ken		O	Xuan	Tan	Chin		Xu			Ko		Bo	Ha	Ha	Ko	Bo				Tan			Wei	Hi		Sei";
    case 632:
      return "		Ku	Fuku	Ki	Up	Wan	Ji	Cha	Shi	Mao	Ke		Shin	Ci	Yaku		Bo	Xian	Mo					Beki	Beki	Hun	Chan	Shi	Zhen	E	Mi	Bei	Shi	Qu	Shu		Ci	Yan		Beki	Hu	Qi	Zhi	Huang	Kaku	Kan						Zhi	Shi	You		Shin			Ji	Gao	Yao	Pou	Chin						Ren		Yi	Cheng	Ji	Thay	Ai	Kan	Dong	Gei	Sui	Seki	Jiu	Beki	Ra					Qi	Lian	Xuan	Rai	Liao	Tin	Gai	Kyo	Ren	Yun	Xuan	Cou	Pian	To	Kui		Ti	Huan	Dan	Gui	Chen	Tei	Shang	Ji	Tai				Lian	Kan	Sheng	Yo	Dou	You	Qi	Ten	Xiao	Rai	Yo	Shin			Yi	Lou	Byo	Etsu	Chuang					Lao	Gao	Hetsu	Hen	Gai	Zeng	Don	Wei	Bi	Seki		Jian				Kin	Ying	Fan	Li	Qian	Nghien			Yao	Han		Rei	Kui	Wei	Hyo	Que	Kan	Ki	Xiao	Que	Rei		Hu	Sei	Gok	Kyu	So	Duo	Chu	Sa	Ko	Shen		Shoku	Zhuo	E	Ji	Hai	Saku	Tan		Pa	Shi				Caau	Saku	Kin	Jie	Qiao	Tan	Tei	Aku	Ki	Qian	Ju	Tei	Kaku	Qiu	Tuo	Ko	Hai	Kon	Nuo	Si	Tei			Yi	Chanh	Gu	Hun	Pa	Zi		Jiao	Dia	Shi	Xi	Shao	Saku	Yi	Zhi		Sei	Ken	Koku	Canh	Goc	San	Lun	Shi	Zhou	Jue	Tan	Nuo	Ju	Hu	Kei	Zhi";
    case 633:
      return "Kei	Sung	Sung	Bi	Shi	Hitsu	Sen	Tetsu	Tetsu	Shu		I	Ta	Chi	Xuan	Ji	Gua	Ju	Wo	Tuo	Hai	Qiu	Wei	Duan	Tei	Shou	Kei	Zhen	Ne	Kyu	Ho	Xi	Zhe	Zhi	Kei	Na	Kwai	Ken	Kyo	Chi	Jian	Kan		Chi	Tan	Ba	Yao	Guo	Koku	Sei	Di		Huo	Jing	Tei		Mam	Thoi	Ta	Ken	Jue	Yue	Ketsu	Satsu	Hitsu	Kei	Ryu	Choi	Ji	Kwai	Su	Coi	Jian		Kun	Wo	Kuang	Biao	Jue			Bi		Chan	Va	Zi	Li	Rei	Shoku	Futsu	Fo	Qian	Yan	Shi	Tan	Mo		Tan	Ka	Kou	Xi	Kun	Ku	Jiu	Ei	Yu	Ken	Shun	Shin	Han	Hu	Hu	Jo	Fu		Shi	Yang	Guo	Kyo	Ren	Yin	Feng	Jun	Ko	Yun	Ki	Shoku	Xun	Da	Xi				O		Yo							Xia	Shun	Ken	Hang	Tei		Ghe	Ke	Don	Yo	Bo	Kyo	Hu	Zei	Shin	Hu	Pu	Fan	Aak	So	Kyo	Nei	Jia	Bo	Zen	Yi	Do	I	Ben	I		Tuo	Na										Yin	Yin	Tei	Ko			Ketsu	Beng	Ngoa	En	Shin	Ji	Wang	Shi	Dui	Duo		Tuo	Wa	Li	Seki	Shin	Ro	Re	Jutsu	Gen	Ci	Xu	Zhou	Zi	Kyu	Kyo		Ko	San	Zen	Wang	Ya	Ko	Ji	Chao	Sho	Ko					Ri		Ji	San	Tei				Khoang	Shi	Roku	Tetsu	Ko	Kan	Shan	Tu	Kyu	Bie	Xi	Pi	Zha	Gi	Fung	Hui	Kyo";
    case 634:
      return "Suo	Sa	He	Keki	Yue	Zen	Wu	Chi	Ling	Bo	Zha	Hua			Jyun	Gi								Chan	Kei	Cho	Detsu	Kon		Kei	Kei	E	Sho	Chen		Totsu		Kai	Eki	Sui		Tian	Ta	Ko	Hi	Kan	Tai	Cho	Zhi	Ti	Ao	Zhuo	Zi	Ke	Yo	Se	Tian	Lu	Shoku		Shin	Fu	Shan	Zha	I		Bo	Chong	Bu	Yan	Bo	Ken			Ko						Ko	Seo	Mu	Hu	Gin	Nei	Shu		Ku	Daan	Chi	Shun	Cho	Su	Shu	So	Fu	To	Shi	Nao	Kai	Ri	Ji	Duo	Hou	Ko	Cong	Zha	Yin	Ta	Xiao	So	Bian	Beng	La	Sa	Chi	Ben	Qia	En	An	Shi	Kon	Shu	Chi	Jun	Kan	Sen	Chu	I	Shun	Ho	Gei	Nu	Ka	Ji												Ou	Ben	Xia	Kai	So	Chai	Gan	Ai	O	So	Sheng	He	To	Ji	Chi	Xi	Zheng	Ken		Ta	To	Ma	Soku	O	Pi	Yo	Ryu	Xu	Qian	Sha	Shun	Tai	Shi	Kyo	Ki	Hotsu	Sei		Xia	Ron			Zeon	Syun	Ko											Yu	So				Ki	Sho	Jie	Xia	Lu	Hei	Qie	Rui	Cha	Kei	Kei	Tei	Yang	Ji	Sha	Lou	Kei	Ji	Zhi	Wang	Soku	Bi	An	Yi	An	Ken	Man	Kyaku	Kan	Li	Fu	Ho	Sa	Sho		Hen		Gan			Soku	Hi	Xian			Mo	Sho	Jiu	Tan";
    case 635:
      return "Rui	Hao	He	Shu	Sha	Zha	Zhan	Yi	Xi	Haku	Xi	Fa	Yan	Taku	Reki	Mu	Do	Sa	Man	Shu		Gu	So	Ki	Gaan				Sei	To	Yun	Shi	Shitsu	Sui	Saku	Shiki	Zhong		Chan	Chuang	Hui	Za	Gun	Jian	Ya	Kai	Ka	Ken	Xiang	He	Kutsu	Eki	I	Ka	Byu		Tang	Lai	Dai					So	Hetsu	Go	Setsu	Dan	So	Bo	Yo	Mian	Ning	Shin	Meng	Chi	Lie	Zhou	Pu	Tai	Gi	Ka	Yo	Ying	Teng	Guo	Gi		Fu		Qiang	To	Lu	Sa	Lie	Chi	Xie	Bai	To	Guo	Bao	Luo	Juan	Sha	Sa	Kin	E	Shun	Kai	Yo						He	Ken	Mei		Sho	Xie	Pin	Shun	Han	Chen	Shan	Hui	Ben	Hen		Shin	En	Kaku		Ying	Bai	Jian	Ka	Tai			An	Ken	Bai	In	Ta	Yi	Tui	Ho			Liu	Kon	Zuo	Kai	Li		Pin	Xue	Zen	Nen	Dou	Rui	Kei	Lan	Ken	Shi		Jo	Sho	Zhan	Jue	Zhen	Ji	Qian	Ko	Han	Fen	En	Han	Hong	He	Hou	Kyaku	Kaku		Zhan	Chou	Tai	Qian	Kei	She	Ying	Ko	Ko	Qin	Hang	Hang	Huo	Ro	Xi	He	Xi	Xia	Hao	Lao	Kan	Li	Ban	Ken	Cheng	Ka	Ko	Shun	Jun	Xi	Han	Rei	To	Chu	To	To	Dou		Dou	Wan	Kin		Dou	Zai	Juan	Gai	Lou	Chu	Hei	Zheng		To	Ho	Qi	Kan	Huo	Lai	En	Lam	Phong	Ha	Kin	Koku	In	Gai	Hi	Shou	Rei	Dong	Hei";
    case 636:
      return "Cho			Lou	Tuan	Chitsu	Hitsu	Yu	Wu	Ro	Tian	Ren	Ken	To	Lao		To	Ko	Guo	Ryo		Kaku		Nanh	Tan	Qi			Chong				Lie	Li		Xun		To	Ut	Shi	Geng	Ting	Han	Chu	Shi	Tun	Kotsu	Xiong	You	Mo	Chi		Hu	Du	Eki	Mu	Gai	Na		Ling	Zoeng	Shi		Ai	Xian	To	Kan	Shi	Kan	Si	San	Shi	I	Kai	Yi				Toku	Yi	Xiao	Sho	Zhi	Dou	Ton	Eki	Kan	Kon	Mai	So	Ken	Su	Lun	Jue	I	Kon	Taku	Qiang	Ling	Botsu	Rei				Ken	Pian	Cou	Duo	Yu	So	Ton	Ton	Zhuo	Kai	Xi	Huai	Ming	Tang	Ho			Pu	Y	Mi	Man		Guai		Qian	I	Lin	Min	Wei	Ceng	I	Hu	Sui	Heki		Ju	Sha	Meng	Bo	Hin	Haku	I	Aku	So	Ei	Ru		Wei	Xi	Ling	I	Sen	Bi	Wei	Ei	Kon		Li	Zhe		Yong	Hu	Wan	Ba	Jian	Kaku	Kaku	Cop	Shi	Zuo	Zhan	Bo	Qiu	Yang	Ko	Shin	Dong	Qu	Fuku	Kyu	Ten		Pi	Zhai	Beo		Shan	Gou	Biao	Yi	Fu	Chi	Xin	Shi	Tong	Cop		Ding	Kai	Chi	Tu	Xiao	Wu	Pei	Hui	To	Bo		Kan	Lai	Bo		Hum	Si	Cui	Sha	Zhou	Zhao	Wei	Lai	Bi	Shi	Kon	Dong			Nao	Xie	Rao	Tuan	Wei	You	Mei	Yuan	Zhong	Jeo			Dan	Atsu	Hi	Haku	Sou	Ken	Gu	Shao	Do	Zhao	Pi			Tong";
    case 637:
      return "	Chi	Peng	Chan	Yong	Shuang	Kyo	Wu		Pi	Huan	Beo	Fu	Fun	Biao	Kaku				Nao	Ri	Biao	Wei	Yong	Kaku	Nao	Guai			Ban	Kaku	Ho	Li	Tatsu	Xin	Yan	Po	Pei	Ka				Suo	Toku	Ren	Shan		Me		No	Suo	Sha	Chi	Bo	Zai	Hen	Dan	Sei	Men									Shou	Ki	Hi	Gan	Chi	Gou	Shin	Han	Shi	Yang	Bo	Gu	Sen	Fu	Ko		Ziu	Bui							Ke	Tei	Katsu	Ju	Qua	Pai	Ce	Bao	Xiong	Cai	Ki	Fong	Lin	Ai	Saku	Zoku	Gen	Mi	Lai	Kyo	Hin	Ka	Xiao	Bo	She								Huo	Ni	Bai	Baku	Ka			Katsu		Zheng	Kai	Lin	Zha	Sa	Hin	Yun	Sho	Saku	Xu	Hin	Fau					Cheng	Wo	Xi	Gan	Loi	Bei	Sei	Rai	Shang	Bo	Kin	Sha	Yu	Mi	Hi	Fu	Sen			Coeng		Ko	Ki	Bieu	Dat	Buon	Cua	Cong		Chi	Duan	Sho	To	Cha	Fan	Ze	Cheng	Ei	Ting	Bo		Ci							Kai	Yi		Zeon		Chin	To	Yao	Sei	Hei	Ku	Iku	Fen	Xie	Cheng	Bai	Sei	Shi	Rai	Iku				Kui	Jung	Xoe	Sho	Bin	Ken	Lou	So	Sa	Saku	Yi	Mi	Xie	Bai	Ki								Gui	Fu	Luo		Bai	Shan		Mua	Tau	Tron	Ko		Yo	Ju	Du";
    case 638:
      return "Zen	Hei	Xian	I	Sai	Zhi	Zei	Iku	Bin		Ko	Ki					Ji	So	Vui	Chua	In	Zhi	Zhuan	Xue	Lian	Sui				Ban	Zei							Shun	Lan	Ju	Mian	Xun	Zhan	Gun				I	Khenh	Rei	Zhi					Toku	Sen	Ton	Cong	Bui		Wei	Quan	Chai	Chi					Ngheo	So		Reng	Ko	Yue	Vay	Zi	Zaan	Shoku	Zaan	Luo	Gui	Maai	Cheng	Zoeng	Ju	Tian	Wan	Kaku	Tei	Tei	Zhi		To	Nan	Da	Tan			Han		Do	Do	Bi	Xi	Lin	Son	Lom	Yan	Xu		Ren	Huong	Tham	Hu	Gan	Xu		Xi	Koku	Ju	Shi	Cui	Do	Do	Xi	Hu	Tim	Tham	Tham	Do	Do	To	Yan	So	Kyu		Ziu					Yi	Chi	Jue		Zu	Kei	To	Ruot				Kutsu		Take	Jiao	Yi	Kitsu	Tan	Chi	Ba	Tou	Zong	Qiu	Shu	Tei	Chi	Xi								Ni		Cu	Tei	Wu		Chu	Su	Yong	Ju	Ba	Ken	Ci	Di	Pan	Chi	Sha	Qiu	Etsu	Yan										Zhai			Duoi	Ki	Xian	Beng	Kuang	Qi	Zhou	Ju	Qie	Mo	Yuan	Kei	Gui	Zui	Ta									Qie		Rao	Nhong	Shu	Su	Day		Ketsu	Hu	Qiu	Hai	Fu	Lang	Sha	Xi	Bu	Shi	Yong	Guang	Shoku	Nie	Shu		Hou";
    case 639:
      return "									En	Mi	Chay	Chay	Lanh	E	Xian	Yun	Xu	Qin	Dong	Leng	Qi	Lan	Fu	Qi	Chong	Ken	Lae	Cu	Shu	Ketsu	Mo	Bei	Ko			Dao	Chi	Han		Jie	Chong	Chi	Yu	Cui	Su	Ti	Shu	Zha	Fu	Ho	Che	Fo	Hou	Zha		Yokuhashiru									Tei	Katsu		Jie	Zha	Zhan	Day	Day	Yan	Hai	Wu	Hua	Dian	Yao	Sou	Qian	Ji	Xiong	Qi	Jun	Shin	Hai							Ko	Yan	Jie	Cui		Tuan	Zhang	Piao	Lu	Zhi	Chu	Mi	Qiang	Ten	Lian		Kitsu		Sen			Li	Kitsu	Ho	Zong	E	Su	Jue	Sen	Reki	Ju	Tan	Liao	San	Dong	Shaku	Za	Zhi				Xuan	Ling	Ban		Deng	San	Tron	Zhan	Xuan	Qin	Jiao	Pi	Shi		Han	Shi				Sei	Yu	Guo	Hon	Xun	Chitsu	Yaku	Xun	Chan	Jie	Ju	Yan	Du		Hong	Xian	Xun		Hen	San	Hon	Ling	Jie	Yi	Qu	Gan	Feng	Hyo	Jue	Qu	Zuk	Sei	Kyu		Jiu		Ji	Ji	Treo	Kyu	Getsu	Kan	Kyo	Ki	Xi	Pang		Kuang	Ku		Ku	Zha	Ki		Ba	Chen	Nhac	Chen	Hu	Nu	E	Xiong	Dun	Sheng	Wan	Fen	Zung	Jo	Xi	Zi	Tei	Hu			Hon	Fu	Bie	Ko	Tuo	Ban	Ge		Ke	Nhon	Vet	Cho	Ko			Zhui	Fu	Mo	Jia	Tuo	Yu	Den	Mu	Jue	Ju	Gua	Po	Ka	Shi";
    case 640:
      return "Ni	Lung	Cuk		Wa	Yan	Ketsu	Tei	Buoc	Cyu	Dang	Say	Lanh	Dung	Lop	Den	Rong	Ngoay	Vo	Haku	Chou	Kuang	Hai	Ka	Xiang	Xi	Shuku	Cun	Tong	Ruo	Leot	Duo	Che	To	San	Kei	Lei	Zi	Ketsu	Zheng	Zuo	Ka	Hai	Kang	Zai	Chi	Yuan	Qiong	Bang			Fa	Xun		Ji	Han	Cha	Giang	Let	Nhong	Rao	Riu	Nho	Cang	Shu	Xuan	Xie	Ti	Han	Xian	Shan	Tun	Hang	Kun	Cen	Dou	Nuo	Yan	Cheng	Pu	Qi	Yue	Fu	Cho	Tiu	Shuku		Ting	Choai				Fu	Odoru	Kon	Wo	Sheng	Tuo	Han	Ka		Du	Long	Noi	Cuong	Ba	Dau	Lia	Duoi	Rao	Lan	Xech	Xui	Va	Ap	Ho	Tan	Fu	Ya	Zhi	Lu	Yan	Ju	Cho	Hon	De	Shi	Chu	Zu	E	Zhi	Peng	Chi	Bie	To	Di	Kei		Hasu	Sai				Cho	Lai	Go	Ye	Shu	Doc	Lom	Khap	Co	Ram	Ghenh	Ron	Tatsu	Hao	Pan	Tan	Kang	Xu	Zou	Ji	Wu	Chi	Ka	Chuan	Tatsu	Tatsu	Po	Yan	Tuo	Chi	Du	Ka	Pian	Chi	Hun	Ping	Sen	Cong	Zha	Tei	Ten	Taku		Wan	To	Re	Dam	Naam	Wai				E	Wei	Bai		Jiang	Cang	Giay	Nhom	Riu	Giay	Tot	Lom	Xam	Giay	Khoeo	Yo	Cha	Gyu	Chu	Kua	Teng	Zou	Li	Ta	Sa	Cho	To	Pan	Pan	To		Saku	Sao	Qiao	Taku	Hon	Kyo	Ten	Sin		Nhao		Zu	Taku	Zhi	Yan		Jie	Neng	Gwat	Chom	Ghech	Chuc	Xong	Lang	Nap	Let	To	Nhuc	Xung	Sen";
    case 641:
      return "Sho	Dam	Lung	Choku	Luan	Qu	To	Deng	Liang	Chan	Qie	Lou	Die	Cui	Ki	Hyo	Ji	Hoku	Sai	Chao	Shuan	Zu	Zui	Kang	Riku	Kyoku	Qiang	Li		Bo	Chong	Dui	Tat							Cho	Go	Hoku	Tei	Yu	Ketsu	Roku	Shuai	Yu	Zhang	Lei		Bo	Sup	Sao	Dang	Sung	Dinh	Dao	Chui	Dan	Doi	Hom	Ghe	Giong	Lep	Sup	Mop	Xong	Nhon	Po	Ki	Toi	Cho	Lung	Zhe	Xiao	Ga	Tan	Cui	Lan	Bu	Xu	Shu	Zha	Can	San	Setsu	Bi	Peng	Teki	Go	Zuk	Choku	Cheng	To	Hyo	Ki	Chu	Hatsu	Qiao	Ji	Hi	Seki	Sen	To	Riku	Zhai	Kyaku	Lan		Dua	Waa	Chung	Shun	Zen		Han	To	So	Doi	Dung	Treo	Chom	Kheo	Lay	Lon	Sum	Vuot		Tian	Sa	Jin	Zhu	Duo	Ki	Cha	Juan	Tang	Beng	Shi	Fan	Lie	Zei	Sui	To	Chi	Choang	Cam						Se	To	Ton	Han	Cui	Long	Dung	Quay	Dep	Loi	Von	Quan	Tuon	Chi	Zhi	Tui		Qing	Chi	Chuo	Hen	Seki	Buk	Ta	Bing	Wen	Setsu	Rin	Po	Bo	Duoi	Ngoen	Giat	Veu		Cyu	Mo	Ca	Gac	Khieng	Kuang	Tetsu	Cuo	Rao	Bao	Lai	Sa	Chi	Leo	Kyaku	Seki		Nian	Li	Sa	Ri	Bai	Lui	Guom	Tan	Jiao	Lu	Li	Long	Gui	Tai	Du	Du	Chan	Kyaku		Ten			Lom	Xian	Ken	Chan	Tan	Xie	Zhan	Ki	Sen	Som	Ketsu	Ketsu	Shuang	Tan	Hen	Tan	Shuku	Sen	Nhao	Khuy	Ngoeo	Chom	Ong		Mi	Luan	Luo";
    case 642:
      return "Dian			Ten	Shuku	Yaku		Laam	Die	Ki	Wan	Yue	Luan		Luan	Ga	Ketsu	Ketsu	Voc	Leng	Tan	Wai	Din	Nen	Shao	Xie	Pi	Shi	Tan	Ro	Fuku	Ga	Tan	Sha	Ko			Mao		Yin		Bo	Shi	Zhu	Ku	Tan	Chong						Kyu	Ha	Mu	Tuo	Katsu	Tong	Ye	Ji	Yo				Ka	Huang	Hei	Ren		Ye		Sai	Tei	Pei	Hi	Tuo	Shuku	Baku				Rinh	Ka	Minh	To		Zuan	Yu			A	Sha	Zhou	Wan	Lung	Minh	Ban	Duo	Zhong	Ha	Huang	Mian	Tai			Chun	Qie	Gong	Ting	Mei	Hi	Hei	Ro	Tang	Ko		Rong	Ka		Rong	Qi	Guo	Kyu		Wu	Xiang	Tian	Nan	Hei	Tetsu	Jo			Xiao		Ka	Zhan	Cui	Raku	May	Lan	Tan	Dei				Doku	Dei	Lan	Hin	Ro	Tan	Shen		Lei	Li		Chan	Nie	Luan	Han	Ting	Hui					Gong								Ton	Qi	Yu		Xin	Chin	Ku	Jo		Yue	Ba	Dai	Ji	Xuan	Fu	Bo	Jue	Niu	Zen					Tei	Tei	Du	Ji			Gwang	Wen	Shin	Shin	Pa	Gong	Ben	Sha	Keng	Yang	Liu	Ni	Zha	Yin	Nian	Pao		Gong	Bu	He	Rong	Gui	Lip	Banh	So	Bi	Xi	Ju	Hun	Bi	Ko	Tiao	Zheng	Shoku	Hong	Yi	Ci	Tai	Bing	Toko				Gong		Bo	Fa	Kitsu	Atsu	Yang	Xu";
    case 643:
      return "Nhe	Hong	Kyo		Zang	Chai	Hong	Chiku	Tian	Ken	Gei	Kei	Zhi	Xing	Xu	Sai		Zhen		Bo	Wan		Shu		Jun					Wo	Gyo	Kyo	Lu	Ri	Zheng	Rong	Cheng	Fu	Hei	E	Tao	Tang	So	Juan	Chao	Ta	Di	Juk	Zong	Sho	Bin	Keng	Tui	Gei	Keng	Kei	Tetsu		Hon						Chi	Shi	Ki	Shi	Co	Rong	Yun	He	Zong	Cong	Qiu	Ka	Bin	Hei	Mu	Duo	Xu	Keng	Xian	Ken	Koku							Du	Kan	Kaku	Ying	Shi			Zi	Shu		Jyun	Sau	Huang	Sui	Peng	In	Li	Sen	Bo	Ge	Ju	Ke	Jo	Hu	Yao	Tang		Qiong	Rong	Liu	Hui	Ji	Ren		Gwan		Keki		Ko			Kyo	Ryo	So	Ko	Riku	Zhi	Gwan	Tang	Zhi	Kang			Chi				Yang	Kan	Tang	Hong	Chi	Fuku		Liang	Shi	Cao	Ngao	Truoc	Truoc	Nai	Zong		Deng	Ei	Jiao	Peng	Fun	Guang	Er	Jian	Jiao	Nuo	Zao	Shi		Da	Ro	Peng	Dang	Shu	Qu	Lian	Mu	Lan					Fen			Tetsu	Hun		Nhe	Chi	Kuang	Shi	Yin	Shuan	Jian	So		Iezuto	Ko	Rin		Chi	Luo	San	Lu	Ho	Sha		San	Kan	Ge	Rang		Bin	Pin	Fuku	Long	Chi	Gi	Tetsu	Zhen	Xian	Rin	So	Lin	Lian	Shan	Bo	Li			Hi	Ho	In	Raku	Xie	Ge	Min	Lian	Hi	Ran	Jue	Zhou				Getsu	Ke";
    case 644:
      return "Reki	Die	Bi	Zhe		Shu	Ji	Long	Guang	Zao	Xian	Qian	Shin	Shen		Shin	Yin	Jie	Ci		Shen	Shen	Sa					Xi	Ratsu	Heki	Ko	Ko	Shi	Ku	Heki	Qu		Ge	Ban		Bi	Qian					Cay	Heki	Bin	Ban	Ji	Zuo	Pi	Hen	Huo	Chat	Dang	Ko	Nong		Kei		Ban	Chat	Ko	Kyo	To	Shin	Shin		No	No		Chi	Nong	No	Chen	Ki	Peng	Shin	Kitsu	Fu	Tu		Ki	Hasa	Ki	Tamadasuki				U	Pi	Po	Chun	Fu	Chi	To	Sho	Xue	Qi	Wu	Jo	Tai	Zhi	Di	Cong	You		Shi	Muoi				Tei	Ting		Kitsu		Shin		Cong		Dem	Di	Zhuo		Zou	Cong	Sho	Jin	Pan	Yan	Qi	Rong	Jia	Chi	Zhi	Qiu	Yue	Sei	Shi	Sen	Seki		Hao	Muoi							Tuo	So	Ji	Bie	Cho	Kan	Dong	Hatsu		Chuo	Yu	Ci	Ko	Yin	Shi	Hai	Ruan	Seki	Yang	Chi	Kai	Ci	To	Yu	Gong	Mi	Shutsu	Ji				Omowaku	Bach	Quanh	Duoi	Gen	Zao	Tei	Sen	Tei	Beng	Saku	Ga	Tei	Bo		Xin	Kuo	Hen	Die	Ki	Sai	Ting	Yu	O	La	Nghenh				Ki	To		Yu	Hen	Shui	To	Il	Tei	Dai			Lung	Ngot		Tai	Ho	Li	Yo	Yong	Jiao		Tsui	Ta	Qu	Yin	Yuan	Jie	Cho	Qian	Yao	Ya	So	Hi	Qing	Sui	O	Ka	Tai	Ki	Sei	Tai	Pei";
    case 645:
      return "Shi	Jau	Tatsu	Ken	Tei	Teki			Choi	Go	Suot	Sho	Co	La									Yu	Jia		Tou	Yo	Ti	Retsu	To	Do	Yu		Dun	Chan	Jia	Chi	Jian	Shu	Ho	So	So	Un	Tai	Tatsu	Retsu	So	Ta	Sen	Sui	Sui			Ton	Tatsu					I	Jau	Ke	Cho	Chuc	Dit													Fu		Ren	En	Tei			Kan	Zhi	Sen	Yuan		Hen	Hu		Lie	Ho	Sen	Shi	Ze	So	Chu	Go	Kyu	To	Qiu	Beng	Sen	So	So	Shime	Ngok	Tren										So	I	Huan	Kua	Sheng	So	Jie		Wang	Ten	Do		Hu		Sang	So	Sen	Yo	Rin	Ze	Zan	Yang	Ga	Chi	Jiu	Saku										Liao	Yu			Kan	Yo	Bian	Ton	Kuang	Kaku	Shi	Sha		Mau	Roi	Quynh	Ho	Tatsu	Chou	Ya	Zhuo	Yu	Qie	Xian	Len	Yuan	Wu	Jiao	Xiang	Sha	En	Zhi		Ryu	Chong		Bian	Wei	Saku	Teki	Ki	Shin	Rin				Omoi	Seoi	Do	Kyu	Toku				So		Tei	Dao	I	Jun		Ho	So	Ho		Chau	Nhanh	Yu	Tui	Kaku	Tei	Chao	Sen	Toku		Hui	Qian	Sen	Wei		To	Yu	Shi	I	I	Go	You	To			Cim	Dit					Sen	Tai	Di	Yo	Da";
    case 646:
      return "Juk	You	Jiu	Tui	Zan			Hui	Tatsu	Sha	Shun	Jiu	Huo					Ren		Ketsu	Yao			Duoi	Va	Xian	Hen	Tai	So	Tatsu	Xian	So	Ro	Gen	Hen	Kan		Zou					Ren	Ki	Di	Ton	Jiu	Rei	Ren	Nhanh	Hui		Kao	You		Baku	Li	Ton		Jyun	Chuan		Chi	Tai	Huo	Baku	You	Yu	Yue	Gen	Ton						Tit	Keo	Ta	Zan	Ko	Ki	Yoku	Nie	Zhu	Kan	Suot	Bai		Sen	Bai	Chong	Toku	Lui	Cin	Shin	So	Xian		Yo	Ai	Xoang	Chu	Itsu	En	Shi		Kou	Qi	Tu	Fan	Cun	Sai	U	Tun	Cha	Cai	Xiang	Pei	Jing	Qi	Shao	Niu	Na	Ei	Qin	Ki				Ko								Ka	Ka	Ja	Bi		Tei		Kyu	Sho	Bi	Bao	Bian	Zi	Na	Wei	Hao	Ho	Ko					Kan	Jin	Sei	Zheng		Keki		Qie	Ko		Lap	Koek	Kyu	Hi	Hao	Tong	Zao	Sheng	Cun	Huang	Ru	Zai	Nian				Iku	Ki	Juk	Nen	Xian	San		Ho		Shu	Shu		Kyu	Zen	Quan	Ji	Yin	Li	Mang	Shao	Han	Cuo	Jun	Ji	Bu	Long	Fou	You	Kuai	Mura	Sing	Rai	Sai	Kai	Xiang		Ko	Ho	Keki	Yun		Qin	Hui	Pu	Gwan	Hi				Li	Pei	Shu	Ju	Yi	Zheng	Chong	Den	Xi	Ko	Hu	Rou	To	Ko		Ki					Shu";
    case 647:
      return "Yo		To	Ho		Ki	Ko		Shu			Ko	Huan	Qiao	Zhi	Ying	Xi	Qiao	Ji	Zheng	Huang	Ko	Yu	Zou	Mei	Ju	Yu	Shu	Sheng			Tei				Kei	Ho	Ri	Ko	Jutsu	Ko	Quan	Keki				Kei	Keki	Jiang	He	Yu	Tong	He	Wen	Yi	Pang	Ko	To	Weng	Qian	Li	Yi	Chuang	Xu	Wei	Shun					Ge	Kyo	Yu	Sa	Bei	Zhai	Gan	Qian	Kang	Li	Shen	Guan		Piao	Cho	Kai	Li	Sho	Hu			Tu	Shun	Kan	Hu	Li	Sei		Lou	Hi	Bo	Ro	Dang	Roku	Zuo	Shan	Bo	She	Kyo	Feng	Ju	Tong	Jiao	Qiao	Gao	Zi	Huang	Shan	Shi	Ryo	Tan								Tei	Rin	Kan	Rei	Yu	Bi				Ken			Tuo		Ling		Cheng	Weng	Zuo	Yu	Ko	Zhu	Rei	Qun	Xi	Qu	Bo	Ge					Ko	Kai	Qi	Xu			Kyo	Rin	Gai	Que	Shou	Meng			Shu	Bo	Kyo	To	Shen	Gi		Bo	Qiao	Can		Han	Li	Fu	Wan	Lei	Xing	Lang	Ri		Shi	Zheng	Fan	Han					Zhi		Shin	Kaku	Kei	Yin	To	Li			Ban	Shi	Mo	Wei	Rei	Ying	Rang	Ku	Tan		To	Reki	Quan		Shu	Tan	Fu	Luo	Sen		Gaku		Zen	Ri	Tan		Rei	Rei	Shutsu		Dai		Yin	Bi	Ge	Hai	Wen	Yan	Mian	Sho	Gang	Qiu	Zhi	Ko";
    case 648:
      return "Ko	Chin	Ko		Jau		Shu	Shin	Ko	Tam	Shu	Gu	Tong	Tai	Ling	Ti	Ci	Yi	Fan	Po	Bi	Ei	Bao	O	Haku							Peng		Suan	Han	Chuenh	Song	Wei	Xiao	Ji	Ji			Jau	Hao	Yan	Ta				Giam	Gay	Sua	Xoang	Yi	Zao	Ying	Nan				Shiboru	Tai	Za		Tian	Xi	Jiao	Yan				Choang	Dam	Miet	Ho	Nei	Tan	Yan	Tian	Zhi	Chou	Tao	Sho	Sho	Hei	U	Zha	Sei	Dan					Mian		Sho	Wu	Yin	Yan	Lao			Choang	Gay	Po	I	Hun	Hai	Mu	Cong	Dan	Sho	Ku	Chou	In	You	Bo	Sei	Ko	Zhuo		Kui	Sou	Giam				Ko	Shoku	Yin	Sa		Zui	Sang	Liu	Han	Wei	Meng	Hu	Li	Shi	Mi	Sei	Bang	Jian	I							Hi	Sa	Sa	Que			Cay	Meng	Hei	Mu	Hong	Hu	Mi	Shai		So	Shang	Chao	Shu	Zhuo	So	Zhi	Nian	Chi		Shuku			Ji	Ho		Ke	Zheng	Sho	Mien	Men	San	Rei	Dan	Liao	Zhan	Gong	Lao	Hua	Chuai	Yu	Jian	Kui			Saku		She	En		Sho	Ko		Kei	Chen	Tan	Rei	Hu	Meng	Pao	Zhan	Chang	Sa	Gan			Yi	Shuku	Sui	Sa	Giam	Dau	Xu	Ji	Lan	Sa	San		Yi	So	Sa	Mi	Rei	Mie	San	Shun		Cuan	Shun	Reki	Lan	So	So	Yan	So		Mi	Bi";
    case 649:
      return "	Kun	Yong	Cang	Jian	Kei		Sou	So	Jo	Sho		Tan	Ling	Yan	Ha		Juan	I	Ken	Ve	E	Ken	Ken	Fen	Ken	Fen			Fun				Guang	Mai	Cho	Lie	Ryo	Ryo	Le	Shuku	Chong		Li	Kin	Ri	Dam	Chong	Nhe	Zhi		Lei	Xie	Dam		Chou		Ji	Ri	Nhe	Nang	Pi	Kin	Chu	Kin		Jie	Han	Kin	Tsue	Nata	Zhou	Gei	Saan	Gitsu	Chu	Shi	Xiong	Sho	Fu	Kyu	Kuang	Kin				Jam			Jing		Hu			Qian				Kyo	Cen	Syu	Ko	Qi	Wan	Mao	Ken	Dou	Ryu		Pik						Sei	Kou	Chin	Dai		Nao	Ho	Hong	Ketsu			Ping	Chao	Keo	Sa	Lai	Duo	Qian	Satsu	Yin	Kyo	Nata	Ci													Lou	Hui		Sei		Fu	Mao	Heki	Zhou	Ho		Yong		Ei		Chi	Vo	Nen	Pui	Vong	Joeng	Jyu	Sei	Lao	Ji	Yi	Liu	Cong	Kyo	Nan	Kyoku	Mo	Fu	Cho	Zan		Kama	Nata	Jin	Rang		Kei	Du						Bua								Kyo	Gin	Tun	Xiang		Chitsu		Bian	Chuang	Wu		Ju			Bong	Dan	Jing	Nhan	Gang	Gwan	Bit	Hok	Hang	Xie	Pi	Zhuo	Rui	To	Sao	Zi	Sei	Zheng	Bi	Sha	Zu	Qu	Yo	Chi		Zhi	Kyo			Ming	Bing	Jin	Fan			Ei";
    case 650:
      return "					Hoat										Bo						Saam	Kam	Quan	Qian	Ya	Chao	He	Ru		Ono	So	Ju	Wu			Khep	Sam	Mai	Thep	Chieng	Zung	Che	Hai	Chi	Kuang	Bi	Cou	Ruan	Kuo	Chi	Zu	Jiao	Kei	Yu	Tu	Meng	Da	Shuo	Hatsu	Sho	Sai	Sho					Shun	Juk	Hung	Wai		Bui	Wun	Jau	Wai					Ro						Linh			Jing	Bou						Sho					Feng	Gou	Dong	Cha	Mao	Chan	Bian	Yu			Wan	Zu	Nara	Zi		Chuan	Wan	Wa	Ka	Quan	Kyo	Bo	Wan		Xia			Mo	Jiu	Seoi	Ting	Ying	Jian		Tan	Wei	Ti	Sao	Ko	Qi	Sha	Yu	Ji	Dou	Chan	Tuan		Sho	Liu	Kin	Zhui		So	Hin	Jyun	Jan	Ken	Thuong																					Ruan			Yan	Gu		Li	Cha		Tsui	Ko	Di	Liu	Zhan	Po			Bam	Lon	Ting	Chum	Choc	Thia	Sat	Gung	Zeon	Kei	Zan	Retsu	Chitsu	Kan	Lou	Tetsu	Zhi	Ko			Gaku	Fuku	Shun			Kan	Ci	Loeng	Zoek	Gin	Soeng	Kau	Hi	Coeng					Hon								Sabi			Cuoc				Kin		Tsui	Ngou	Ka";
    case 651:
      return "	Lian		So	Ban	Luo			Ma	Dui	Giao	Mieng	Kwan	Duo		Rei	Jue	Li	Lan	Jyut	Ruan	Gu	Chan	Xu	Yo	Teki	Zhi	Ko		Hei		Ko		Keoi	Sin									Hoi	Fu	Zok		Sai										Kanazuchi						Tetsu		Xue	Bo	Cheng	I	Zhu	Hei	Tsui		Ban				Bay	Xi	Choang	Daan	Thuong	Choang	Die		To	Zhan	Guo	Jo	Ken	Biao	La	Man	Satsu	Ra			Thau		Co		Jip	Jyun		Hirusu		Nokogiri		Maan														Jin		Ryo				Tsui		Gai	To	Hyo			Bung	Hom	Cun	Dam	Giua	Rua	Vam	Lap	Caan	Nhon	Thoi	Meng	Hoku	Yu	Taku	Yo	Kyo	Ban	Hou	Chu		Zim	Deoi													Xi	Kei	Piao	Si		Tetsu					Deng	Muong	Veu	Saku	Chuo	Di	Ji	Chan	Shin	Go	Shu	Zhuo		Hi	Zan	So		Lai													Yu	Cai	Leoi			Jing	Kem	Hing	Wai	Am		Ta	Jiang	Kaku	Bo	Jo	Ton	Gyo				Jin	Hei	Zaam	Hon		Jyun			Yari			Tou			Hing		Dang	Dui	Duc			Kyo	Li		Gaam";
    case 652:
      return "		Qian	Jing		O	Chuo	Kem	Kieng	Zaap		Rai	Ko	To	Ten	Ta	Hyo	Diao	Saku	Jian								Zhi	Jue	Gaan	Mo	Hi	Luo			Lai	Shaku		Bao	Sung		Tai	Thiec	Jim		Zuan	Tai	Tai	Bou		Kan	Shin	Nen	Zhe			Yu	Gaam	Ben	Bao			Ma	Xi	Hu	Yi	E	Gu	Tu	Zhen	Mou	Qiu	Su	Liang	Qu	Ling	Guan	Lang	Tou	Da	Lou	Huang	Shou	Jiao	Zun	Gai	Wei	Cho	Cho	Kun	Duan	Song	Qi	Yang	Bo		Sho	Shi	Bo	Gai	Kon	Ai	Dao	Yao	Bo		Duon	Qian	Ten	Shao	Chang	Miu	Futsu	Mo		Hatsu	Ro	Nao	Do	Tetsu	Cong		Nie	Zhao	Cen	Dai	Dai	Song	Nie	Ci	Jo	So	Jun	Nhang	Shao	Sho	Zhu	Duo	An	Bi	To		Ti		Pi	Xia	Qiu	Sheng	Sho	Ta	Ngong	Tang		Tei	Sei	Man	Pian	Shi	Ti	Rong	Sha	Kei	Sei			Hei	Shi	Cong	San	Ban	Ji	Feng	Wu	Jiao	Lao	Zeng	Peng	Can	Ryo	Nong		Chan	Go	Duon	Do		Hin	Sha	Bi		Man	Gui	Niao	Chong	Chan	Jo	San	Cho	Nang			Xia	Jiu	Ji	Zhen	Cat			Chin	Ting	Diu		Men	Yue	Shuku	Zhong	Tun	Rui	Xie	Xi	Kai	Ting	Niu	Heki	Wang	Jian	Kan	Fen		Heki	Suong									Hei		Ngo	Bian	Chu		Ho	Bin	Yi	Ten	Kan	Die	Ji	Gan	Kyoku	Yu	Jian";
    case 653:
      return "Jiong	Sen	Kai				Kai				Que		Nan	Mou	Xu	Song	Shen	Kuang	Que	Wei	Heki	San	Shuku	Die	Nan	Rin	Ruo	Gong	Dou	Sen	Nian	Shuku	Shuku	Chao	He	Yan		I	Cua		Chiku	Tu	Bu		Hu	Yong	Kan	Shi	Chu	Ketsu		Shuku	Bing				Ketsu	Xiao	Men	Li	Ti		Jian	Katsu	En	En	Zhi	Gua	Guan	A	Qi		Fei	Yu	Zhe	Wei	E	Chan	Xi	Gai	Gu	Kai	Go	Heki				Que	Hui		Xie	Ying	Kyu	Ta	Wai	Fu	Jie	Pi		Cua	Ki	Sheng	Yu	Kua	Kyoku	Pi	Xie	Nue	Xian	Jian	Xu		Bi	Kazuki			Nan	Ko	Liang	Sho	Pian	Kai			Jing			Gwaan	Ta	Yan	Ai	Ta	Rin	Xiao	Qiang	Wu	Tang	Sen	Jun	Ketsu					Kuo	Geki					Katsu	Lang	Kai	Neng	Kan	Cong	Dou	Shu	Kan	Jiao	Nie	Eun	Yu						Ce		Jiao		Hua	Wen	Ye	E	Guang	Hua	Jiao	Kei			Sha			Gwaan	Lei		Shang	Yong	In	Deng	Guan	Niu	Ketsu	Sui	Xiang	Ten	Sa	Chang	Muon						Run		Yun	Mo	Fen	Jian	Xu	I			Xi	Shu											Kan	Xie	Li			Tou	Kai	Sen	Mi	Chan	Huo	Cua	Rei	Zhuan	Yue	Sen			Cua	Bun	Sen			Lan		Yan	Dang	Xiang";
    case 654:
      return "Yue	Ting	Beng	San	Xian	Die	Pi	Pian	Mo	Ta		Jiao	Ye	Cup	Yue	Fau	Reng	Qiao	Qi	Diao	Qi		Ko	Han	Yuan	You	Ji	Gai	Hai	Shi	Chi	Qu						Sei				Wen	Riku	Ken	Zhen	Po	Yan	Gu	Ju	Tian	Sui	Ta			Ping	E		Pei	Ya	Lin	Bi		Bac		Zi	Hong	Ko	Duo	Ta	Dui	Xuan	To	Shan	In	Shan	Yao	Ran			Da				Ko	Tuo	Ta		Bing	Xu	Tun	Cheng	Bo	Dou	Yi	San	Ro	Ryu	Che	Kei			Dai		Ryo	Gen				Lo									Juan	Ji	Sei	Zhao	Beng	Fu	Tian	Hei	Ko	Saku	Ryu	Peng	Ku	Kan	To	Kei	Fu	En			Zai										Long			Tuo	Dau	Xian	Ni	Long		Ki	Zhuo		Zheng	Shun	Zong	Feng	Duan	Pi	Yan	Sou	Qiu	E	Qian	Sui	Qian	Gaai	Ca	Xun	Wai			Jyu	Jung		Zhui			Mao	Jiao		Kan				Zhan	Pi	Xi	Yan	Fei	Nie	Shun	Zhi	To	Suo	To	Yi	Shu	Lei	Xu		Yi	Chi	U	Wei	Bai	In	Ji	Chen	Die	Hei	Fong										Yuan		Xi	Ryu	Liu	Suo		Ling	Ro	Xo		Ven	Gai	Chin	Beng	Xia	Yan	San	Cui	Gwik	Kang	Shu	Ai	Qing	Lou	Bi	Shu	Rai	Shu";
    case 655:
      return "						In		Zhan	Cuan	Wu	Xu	Chen	Hao	Jue	Ji	Chen	Cha	Chan	Zhi	Xun	Zui	In	Yo	Yo	Gyo	Be									Ge	Chen	Ye	Sui				Chu	Qu	Xie	Ken	Zhan	Ken	Ki	Jue	In										Nho	Qu	Tsui	Meng	Ye	Zou	Pu	Rin	Shi				Ai	Shu	Chan		Jan	Du	Tsui	Guo	Lu	Yan					Niao	Bin	Sei	In				Ai		Tui	Tai	Sui				Shitsu	Ni	Huan	Qian		Ai	Riku	Bu		Tai	Xia	Riku		Ling		Ai	Sui	Kaku	Lian	Shi	Yi		Li	Si	I		Dai	Rei	Rei	Wei	Tai		Ci	Cho	Hoku	Shi	Jiu	Hong	Shi	Yu	Yoku	Kui	Seki		Ho	Hang	Ge	Fang	Ketsu	Sei	Kui	O	Ho	Gui	Chi	Shu	Fu	Jiu			Sui	Ko	Boku	Die	Bo	Shi	Bin	To	Hatsu	Fu	Ri	Sui		Shun	Jo	Qin	Shi	Chu	Yoku	Gui	Jo	An	Sen	Retsu	Kyu	O	Zhui	Gi	Shi	Tiao	Ji	Kiku	Yue	Jin	Jin		Lok	Gai	Zui	Shu	Su		Kei	Ho	Ga	Geki	Wu	Cui	Kan	Eki	Shun	Ken	Ki	Toku	Kyo	Chi	Bo	Fu	Zhi			Shu		Shui	Shun	Dong	Ki	Ya	Kiku	Ho	Taku	Kan	Sei	Kon	Ki	Sei	Wei	To	Rei		Ken	Riku	Yo	Shi	Hi	Ko		Ke	Bin		Gan		Seoi		Chong";
    case 656:
      return "En	Ki	An	Bin	Yo	Ton	Totsu	Gaku	Ken	Ko	Kai	Run	Ri	Gu	Keki	Nan	Chun	Yoku			Bin	Shu	Ji	Tei	Yo	Nan	To	To	Diao	So	Cang	Sen	Kou	Nan		Wei	Nan	Saku	Shu	Can	Sho	Kyu	Ma	Ou	Yo	Shin	Ru	Sho	Sho	So	San	Song	Fun	Ka	Wei	Han	Do	Ko	Bai	Shu	San	In	Ketsu	Jin	Shin		Kan	Jun	Ri	Sui	Shaku	Taku	I	Sen	Heki	Kyo	Wei	Shoku	Rei	Tan	Ro		Yo	Gaku	Dei	Yo	Bi	Raku	Nan			Shun	Rui	Betsu	Cai	Li	Hoku	Koku	Nan	Nan	Nan		Loi	Kan	Ro	Nan	Nan	Ken	Nan			Yue		Nhom	Nan	Nan	Yun	En	Ngat	Cheng		U	Shan	Rei	U				Con	Ngut	Hu	Shai	Tun	Sen	Fou	In	Qin	Xu		Gan		Chuan	Fu	Che	Ram	Bung	Yi	Dong	Fu	Fu	Ze	Pu	Ko	Ling				Shai	Pao	Mu	Day	Wa	Yin	Luo	Hua	Yin	Beng	Yu	She	Rai	Xie	Chu	Den			Jau	Dou	Ji		Rei	She	Dian	Set		Chin	Yi	Saku	Che	Geng	Long	Ping	Yun	Yan	Mo	Sen	Sui								Jing	Ton	Song	Pang		Ya	Se	Duo	Den	San	Chuang	Xie	An	Tuan	Gong	Xuan	In	La	Sen	Ling	Sei	Dai	Zha			Kei	Pui							Yin	Song		Yu	Tuo	Tuo		Bong	Ba	Ran	Bo	Dai	Hi	Zha	Hou	Bai	Fun		Hui	Den";
    case 657:
      return "Rei	Ki			Sei	Lu	Sei			Haku	Ling	Ru		Cau	Mua	Bung	Gong	Nom	Um	Rop	Xang	Dan	Meng	Xia	Weng	Han	Zi	Zhen	Se	Cuo	Li	Gai	Dian	Lian	Gou	Rai	Ha	Rai	Peng	Sen	Guot		Ying	Tei	Hou	Go	Dui	Wu	Set	Dong	May	Tanh	Bong	Nap	Xoi	Piao	He		Long	Mo	Fei	Lu	Ze	Bo	Dian	Mang	Tan	Zhuang	Lu	Pang	Dui	Bu		Shu			Chen	Man	Den	Den	Ryu		Haku	Kaku			Xi		Toc	Sam	Doi	Fung	Rang	An	Zhong	Haku	Nan	Tuo	He	Tai	Sen	Dui	Wan	Zhong	Cen	Li	Shuang	Tai			Cen	Ko	Si	Ten	Dui		Hun		Rei	Tan	Ryu	May	Rau	Zyu	Jian	Nong	Dan	Fu	Huo	Hui	Ci	Shi	Yong	Sa	Ting	Rei	Rei	Shin		Rao		Rao	Liu	Rop	Sam	Suan	Ling	Man	Dian	Rei	Rei	Haku	Pao		Ling		Ling	Li		Nou	Mong	Rao	Am	Lie	Shan	Sen	Fei		Fung		Mit	Shan	Mong	Shu	Ling	Zhan	Tai	Bin	Li		Lo	Si	Rang	Jian	Zhuo	In	Ki	Ling	Ling	Meng	Khuya	Shuang	Do	Bai	In		Ling	Mu	Sam	Hun	So		Kaku	Shu	Haku	Loa	Ling	Jian	Qu	Kaku	Shin	Leoi	Nong	Jing	Chen	Ten				Cing	Zhen	Qing	Ten	Qing	E		Xanh	Se			Bo	Bo	Bo	Bei	Hi	Fei		Hi	Fei	Fei	Shitsu	Shi			Fang	Ku	Ga		Koku		Za	Hui		Fei		Kyo";
    case 658:
      return "Han	Dui	Bay	Tai	Jiku	Kan	Pa	Niu	Pang	Dan	Dan	Ai	Tan	Tian	Chao	Ao	Mei	Nan			Bo	Yu	Xian	Mai	Mat	Katsu	Ping	Iku	Dui	Dan	Dao	Shu		Xing	Ni	Han	Chu	Shua	Man		Fu	Na	Tran		Wan	Yi	Diao	Yan		Wo	Suan		An	Lan	Nan	An	Qiu	Mian	Nuo	Can	Can	Jutsu		An	Lan	Tian	Ye	Sen	Nian		Shua	Yo	Sho	Ko	Ten	Ci	Ba	Jian		Gi	Gan	Ba			Jian	Guo	Kai	Zhan		Luo	Ba		Ji	Gui	U	Kotsu		Jia	Ji	Ben	Ko	Xuan	Ko	Feng	Ko	Ko	Jo	Bi	Qi			Yuan	Ang	Di	Gu	Ko	E	Fen	Tei		Ju	Ni	Tuo	Ta	Shen	Fu	Xia	Qu	Po	Wan	Ling	Ma	Zhou	Bao		Yu	Kei	Ko		Ho	Beng	Mai		Jia	Jo	Yang	Ei	Kua	Jiao		Bing	To		Fuku	Luo	Gui	Duo	Zhi	Shi	O	Numekawa	Zhen	E	Zhu	Ba	Shu	Shu	O	Zhen	Feng	Dou	Nian	Bu	Dui	Sha	Se	Bi	Shikoro	To	Kyo	Zhi	Zhe	Bu	Kon		To	Jue	Xun		Hia	Don	Xi	Shi	Zhuo	Bai	Yao	Chou	Ta	Qian	Hetsu	Nao	Yu	E	Jian	Yi	Xiao	Kutsu	Nie	San	Cho	Bing	Shu	Haai			Guo	Xie	Diao		Ei	Ju	Suo	Die	Fu	Mian	Shi	Xuan	Ti	Yu	Ka	Tan	Xie	Fu	Zhi	Ni	Xuan	Yang	Ban	Feng	Zong	Zhou	Xuan	Ho			Zhu		La	Ko	Ying	Gao	Kuo	Boku	E	Wei	Mei";
    case 659:
      return "Ko		Giay	Huai	Chou	So	Suo	Ta	Suo	Ta	Xue	Yo	Gong	Jia	Hi	Bo	Ta	Yuan	Kaku	Cho					Ta		Kyo	Hei		Chui			Xiong	He	Suo				Shi	Mo	Chong	Sui	Ze	Lu	Zhang	Luo	Xu	Jian	Shan	So	Xu	Shi			Kin			Ken	Ken	Ben			Jiang	To	Sa	Fuku	Bao	Mai	Do	Tong	Xi	Ka		Rong	Jo	Sheng	Zhou		Jian	Fu	Deng	San		Yong	Ju	Tatsu	Yi	Bang	Hi	Se	Sui	Katsu	Duo	Xie	Kutsu	In		Huan	Roi	Dep	Taku	Ru	Ni	Zhou	Gui	Hyoku	Luo	In			Jo			In	Zhi	Xu	San	Zhi		Jue	Ju	Un		Yuan	Lu		Ki	Bo	Ken	Ka	Rong	Xie	Sen	Ken		Shoku	San	Xi	Luo	In	Ken	Ken	Ge	Kaku		Zuan	Han	Hi	Jiao	Sa	Qin	Qun	Pao	Yue	Che	Fu	Pei	En		Mei		Futsu	Tao		Ken	Xi	Ko	Bi	Ken	I	In	Duo	Ko	Yi	I	I	Sui	Kyo	Xia	Juan		Wei		Yi	Ken	Yu	En	Bai	Tuo	Ta	Pao			Sho	Bing	Hi		Yun	Yun	Duan	Ruan	Wei	Kyoku	To			Ko	Wei	Gui	Kan	Da	Xia	Yo	Fuku	Hun	Juan	Sui	So	Sui			Lou	Bai	Yu	Zheng	Gui	Shu	Kui	Gao	Dan	Hai	I	Yo	Xian	Zhai	Se	I	Ke	Bu	Bo	Ken	Ki	Sui	Via	Yu	Bu	Jiu	Jiu	Shu	Juan	Jue	Ko	Na	Zhai	Tao	Wei";
    case 660:
      return "Xia	Xie			Ki	Sa	Ji	Sei		Xie	Sei	Sei	Dui	Zi		Han	Sei				Ko	Tai	Ki		Yuan	Qin	Fu	Peng	Pao	Wan	Yin	Haku	Hong	Zu	Kyo	Gong	Dong	He	Wo	An	Pang			Su	Kan	Nie	Hao	Feng	E	Ye	Bo	Wan	Ting	Dong	Zhe	Sang		To	Ko	Mo	Su		Le	Hoeng	Pu	E	Zhuo	Ye				Xiang	Guang	Ren	Ling	Ketsu	Yu	Ao			Chai	Yo	Duo	Qiong	Ku	Xu	Huan	Yao	Zhen	Ting	Beng	Hatsu		Ang	Zen	Kan	Che	Ku	Pei	You	Ao	Men	Mo	U	Kotsu	Rai	I		Fu	Qing	La	Dou	Tan	Hatsu	Yu	Qian	Yao	Wei	Hu	Mo	He	Xuan	Jim	Bi	Po	Shi	Di		Zhen		Shi	Kan	Ce		Tei	Xu	Zhen	Shin	Zhu		Kai			Hui	Chi	Kyo	Ko	Hong	Nou	Nie	Yan	To	Chong	Fu	Guang	Qi	Ta	Gen	Ting				Tan	Qian	Kei		Jiu	Xu	Qi		Zhen	I		Shu	Qiu	Kin	E	Kon	Katsu	Hui	Hong	Qing		Che	Shin	Zen	Fu	Gin	Hong	Xi	Wu	Mang	Sa	Go	Ti	Rai	Ho	Hong	Gaku										Bo	Hi	Qin	Gen	Otsu	Rai	Fu	Kui	Kaku	Wing	Kwai	Ngup	Mang	Bie	Jing	Kan	Gui	Ki	Gao	Xu	An	Yue	Wu	Yi	Jing		Lu	Quan	Tui	Hi	Ji	Hin									Ki		Jiong	Jue	Pie	Kun	Zen";
    case 661:
      return "Wai	Hui	Dun	Yuan	Jie	Hei	Gui	Gao	Po	Men	Zhuan	Hang	Hi						Kai		Yong	Qiu	Leoi	Lei	Ang	Pi	Weng	Sen	Yo	Qin	Kan	Qin	Mie	Dou	Mi	Zhan	Hin	Qing	Yi								Ban	Kyo	Ken	Juan		Ze	Xu	Lan	Ma	Ma	Ou	Bei	Ro	Pou	Xu	I	Hei		Ao		Yu		Seon	Kin	Hong		Han	Hong	Zhan	Dei	Sen	Gao	Ri	Po	Liao		Han	Yo	Rin	Wai	Xuan		Hin				Kui	Gan	San	E	Han	Se	Tei	Go	Dan		Gaku			Tei	Xuan	Bo	E	Gai	Gan	Dao	Ben	Meng	Yi	Ning	Ran	Pin	Rin		Sen	Cang	Gai		Rin		Yuan		E	Nie			Yin	So	Gin	Qiao		Hong	Ling		Chan	Ying	Ko	Hi	Shu		Guan	Hin	Niao	Xu	Tan	Jin		To	Hyo	Peng	Ho	Liao	Laam		Bei	Hyo	Ko	Xin	Tun	Chao	Gan		Hu	Wang		Vuong	Fu	Pei	Shin	Nao	Xun	Xue	Jo	Ka	Liu	Ling	Xue	Qu	Hao	Yi	Han		Fu	Ba	Yi		Bo	Satsu	Mat	To	Hong	Li	Kyu	Ko	Hyo	Sa	Xi	Han			Shi	Piao	Hua	Yi	Bo	Bo	Nei	Qiu	Ryo	Geoi	Wei	Che	You	Kutsu	Wei	Hui	Sa		Ryu	Tou	Hong	Sou	Han	Pao		Fang	Chi	Liu	Zhou	Pi	Ryo	Li	Shi	Wai	Chui	Xi	Zheng	Sho	Beng	Zheng	Sui	Yan	Hyu				Qing	Wu	Liang	U";
    case 662:
      return "Zhao	Liang		Retsu	May	Jie	Hyoku	Hong	You	Chi	La	Hou	Shu	Yuan	Hong	Ye	Kutsu	Ying	Xuan	You		Ei	Sho	Kai	Quan	Hei	I		Tang	Suo	Hyo	Li	Sou	Li		To	Yu	Kai	Shu	Yi	Dong	Thoi	Giong	Hay	Thoi	Xiu	Ao	Tuan	Su	Shuai	Ko	Yu		Feng		Ryu	Ryu	Su	Tui	Yu	Zheng	Zheng	Da	Tao		Ko	Ryo		Liu	Itsu	Cheng	Sui	Sao		I	Gio	Gio	Gio	Da	Gu	Feng	Lie	Piao	Ko	Ryu	Bao	Li		Long	Chu	Xiao	Hong	Xie	She	Hyo		Long	Hou	Xuan	Feng	Kotsu	Ba	Bo	Tao	Su	Zhao	Biao	Sou	Tui	Suo	Xiao	Heng	Sao	Hi	Fei	Lieng	Kan		Kan	Niu	Mang	Bong	Yoku	Bay	Ken	Huan	Zhi	Shoku	Shoku	Shoku	Yi	Shoku	Yu	Shi		Yi	Yue	Chi	Ton	Kitsu	Yaku	Shoku	Ki	Son			Ju	To	Nhu	Yin	Niu	Rong	Ko	Sho	Aku	Na	In	Tetsu	Tei					Tian	Kitsu	Ba	Thet	Qua	Tei	Ko	Er	Zheng	E	Pou	Ji	Ni	Fun	Jiong	Jia	Han	Utsu	Gan	Shuku	Ryu	Tetsu	Ling	Tetsu	Zui			Bei	Yo	Tei	Ho	No	Qua	Banh	Shu	Yi	Pai		Shi	Ho	Nao	Shi	Tai	Man	Shi	Ji	Ti	Ho	Shin					Gong		Sai	I	Doi	Lei	Bao	Yuan	Zuo	Lang	Xiu	Ji	Yo	Zai	Cheng	Jian	Mao	Jia	Yu	Ko	Yo	Yu	Yi	Kei	Asaru		Mang	Zai		Zhui	Ti	Bua	Moi	Xi	Ju	Zan	Lu	Tao	Kai	To";
    case 663:
      return "Zhui	Ling	Shi	Ju	Aku	So	Ji	Juan	Yo	Sha	Zi	Sho	Yue	Dong	Sei	Yo	Kitsu		Nang	Shoku		Ho	Chong	Bi		Jo	Kai					Ang		Tei	Yo	Geng		Bo	Ding	Wei			Nhay	Moi	Quan	Ke		Shu	Pi	Kan	Fu	Yong	Shi	Tuan	Tou	You	Yao	Sen	Ye	To		Yan	Sen	Ho	Fun	Sen	Fun					Moi	Xian	Yo	Ti		Sui				Ci				Xu	Wu	Can	Yu	Shun	Shi	Chan	Xia	En	Kao	Cang	Cha	Qiu	Ken	Ra	Da	En	Su	Sai	Shu	Hua	Ho		Sho	Bo		Shi		Ho				Sho	Do	Shu	Wu	Yuan	Yo	Nuoi	Chan	Fun	Jiang	Xiang	Zhai	San	Mo	To	Shang	Cao	Sui	Chuang	Mi	Zhu	Chong	Ji	Chong	Soku	Soku	Kin	San	So	Fun								Lian	En			Mem	Hai			Shi	Sui	To	Dun	Xiang	Cheng	Shang	Li	Huang	Dan	I	Deng	Yo	Shi	Liang			Shin			Ko	Za	Ryu			Huo	Lin	San	Haku	Du	Han	Yong	Yuan	Guo	Ling	Ci	Lian	Sui	Ao	Dang	Yi	Nong	Shan	San	Xin			Da	Yu	Can	Wo	Cha	Bo	San	Jian	Sho	Setsu		Haku		Mama	Meng	Wei	Mo	Doi	Bo	Wai	Wai	Shui	Jie	Shuo	Huo		San	Chuo	Soi	Long	Huai	Kaku	Tuo	Ki		Yu	San	Duc	Chan	Yong	Huo		Lan	Nang	Nuoi			Na";
    case 664:
      return "Ba	Gan	Yi	Jia		Da	Ding	Xun	Ren	Juan	Tuan	Xu	Song		Cao	Cheng	Sau	Ding		Gat	Mao	Hatsu	Hatsu	Kyo	Ngoai	Hatsu	Hai	I	Kei			Wu	Cui	I	I	Kyo	Fu	Kei	Qi	Guc	Ji	So	Gan	Ton	Shu	Oc	Kui	Wei		Chui	Kaku	Chui	Cui	Choi	Shou	Fu	Noc	Tuan		Bie	Ko	Tan	Hang	Pie	Hetsu			Yu	Tan	Hetsu			Hetsu		Fuku	Thom	Xiang	Hyu	Xiu		Ko	Fuku	Hotsu	Weng	Hai	Peng	Yi	Cau	Fuku		Ai		Lung	Tan		Bie	Xiang	Hetsu	Ko	Yi	Ai	Hyo	Piao	Huan	Mu	Ba	Kan	Fan	Ba	Boku		Ding	Ho	Fun	Jitsu	Chu		Ho		Fen	Shi	Tetsu	Jie	Yo	Hen	So	Suo	Ba					Wan	Ge			Fen	Ro	Tuo		Wen	Gua	Duo		Zhe	Ci	Yao	Ko	Ban	Bu	Mo	Kyo	Po	Fun	Hatsu	Ge	Shin	Hen	Liu	Ga	Tai	Ran			Juk		Giong	Ku	Gan		Hu	Mou	Lua	Shi	Xiu	Huang	Fu	Hui	Sai	Qu	Jie	Tuo	Yu	Mo	Zhou	Jiu	Ken	Shu	Kuang	Qiong	Lie	Fu	Zen	Tei	Shin	Do	Haku	Kyu	Bachi				Xu		Ku	Go			Ko	On	Ryu			Ku	Lin	Ku	Nie	So	Pi	To	Fu	Bu	Yi	Sa	Sa	Bo	So	E	Tan					Zhe	Hang	Li		So	Tu	Da	Sui	Lu	Yan	Dong	Qie	Wan	Ming	Zui	Fu	Qu	Ben	Ao	Qiang	Kiku	Ta	Su";
    case 665:
      return "Ku	Qun				Geoi			Que	Hua	Xian	Kun				Cui	Ho		Yi	Kutsu		Biu	Chi	Zong	Nao	Cheng	Duan	Yong	Zhe	Bu	Tan	Yang	Xie	Xuan	Tei	Duan	Shua	Xian	Xian		Shin	E	So	To	Hen	Ju		Jing			La	Hen					Wei	You	Yu	Kei		Ti	Gyo	Jin	Ki	Tang	Qi	Bo	Dian	Tao	Lu	Zhan	Wen	Ji	Ao	Ou	Qia	Sei	Bu	Cho	Shi	Ta	Ko	To	Mo		Ryu	Sui	You					Zi	Ki		Zha		Ki	Yao		Soku					Fung	Chong	Li	Yu	Chan	Yi	Hi	To	Chi	Tetsu	Li									Tu		Zu	Ri	Sui	Xian	Kan	Rei	Ri	Jo	Xi	Hyo	Bie	Han	Qi	Sang	To	Fei	Ryo	Shan	To		Mo	Kan				Huan			Chu	To	Sing	Katsu	Ki	Bang	Yu	Yu	Ka	Ji	Hon	So	Ban	Keki		Sho							Kuai	Zong	Ho		Rei	To	Tetsu	Ki	Xian	Meng	Ra	Raku	Tai	Hyo		Tetsu		Reki	Li	Zhi	Fan	Lie	Cai	Du	Guang	Xiong	Li	Qi	Ruoi	Kei	Jue	Tuo		Ju	Xiao	To	Ko	To		Qu	Hyo	Ku	Kiku	Zhuan				Rei	Jue	Tei	Ra	Tan	Ro	Jie		Zhou	Xian	Long	Yang	Ran	Yi	Lie	Bo	Hun	Ji	Dong	Zhou	Quan	Jie			Li		Ju	Wan	Ben			Bi";
    case 666:
      return "Ge	Chun		Qian	Sou	Wei	Cheng	Lou	Yu	La	Qian	Dian	Ta	Zhan	Ji	Fan	Lie	Ting	Ji	Qian	Hu	Ga		Yu	Qi	Yu	Wa		Ba	Qi	Sa	Qiao	Ya	Xian		Ho			Kai	Kai	Ci	Fan		Kun	Gun	Que	E	Qiong	Tetsu	Shi	Ma	Ku	Yao	Shi	Katsu	Que	Chu	Jia	Ko	Zhu	Kheo	Dui	Wa	Bai	Nao		Gan		Yan	Tong	Ka	Song	Kui	Ko	Kan	Xing	Gun	Ping	Katsu		Sohoki	Yu	He		Zhuo		Song	She	Yu	Hi	Hi	Ji	Sui	Qiang	Shui	Chuo	Zu	Leng	Ni	Yo	Wa	Zha	Yo	Dan		Veu	Xuong	Xuong	Xac	Sei	Du	Bian	Jie	Qia	He	Chong	Yan	Ko	Yan		Roku	Ko	Song	Teng	Yao	Ko	Kao	Hom	Zhui	Gui	Ai	Hai	Sui	Hei	Tai		Suo	Xu	Biao	Go	Feng	Qu	Mang	Sui	Guo	Sa	Shi		Ton	Go	Bi	Jue	Chuang	Yoku	Ryo	Pu	Ketsu		Sun	Yi	Yo	Ton	Qian	Yi	E	Ling	Sui	Bi	Go	Yoku	Sho			Huo	Mo	Ban		Xun	Katsu	Shi	Yan	So		Sui	Li	Ki	Tan		Ken	Cut	Luan	Shuku	Kai	Mao	Xiao	Yo				Ai			Ta			Mei	Ko	Guo				Gao	Nao	Hao	Kaku				Ko	Chot			Ko		Que					Cao	Sao	En	Jo	Kaku	Hi	Pi		To	Hi	Haku	Ro	Yo	Xie	Xiao	Ju			Bo		Cheng	Nao					So";
    case 667:
      return "Nei		Setsu	Hatsu	Setsu	Jim	Gay			Kai		Hi		Mu		Shao	Kai	Dian			Ling		Zhen	Yao	Dei	Fu	Qian	Qiong	Ju	Bing	Mao	Zha	Tai				Chong						Bop	Zhai		Shi	Yong		Qiong	Dao	Ti	Zhui	Hi	Yin	Shi	Nao	Bo	Kuang	Zhi	Duo	Cong	Bao	Ya					Sa			Cop	Li	Ban		Ju	Wen	Lie	Fu	So	Wo	Shi	Niao	Mang	Jiu					Xiu		Ho		Xui	Wo	Shi	Dao	Kan	Xi	An	Da	Zong	Han	Chui	Bi	Ken	Dong	Kutsu	Zhang				Ya			Di	Huo		Quan	Rau	Min	Ho	Saam	Fu	Futsu	Bao	Ke	Mao	Re	Zong	Qia	Xia	Sou	Xiu	Na	Teki		Shu	Man					Zha	Chan	She	Wo			Quan	Xom	Ai	Bang	Hao	Jo	Sao	Suo	Ti	Ya	Ri	Bing	Rong	Bo	Sa	Sen								Sha	Weng	Ria	Ryo	Ao	So	Zhuang	San	Piao	Sui	Yi	Sou	Dou	Sou	Luo	Ban			Boku		Chop	Toc	Rau	Gay	Fei	Zun	Fu	Nao	Deng	Zhi	Cuo	Liao	Ji	Bo	Cong	Cheng	Bu	Shun	San	Zan			So			Jiao			Yao	Lu	Ryo	Can	San	Ben				Sen		Chu	Hyo	Ni	So				Ban	Mon	Xoam	Jie	Pu	Zhuang	Zan					Sa	Soi	Li	Ryo		La	Do	Ki";
    case 668:
      return "Chong	Sei	Rei	Zhan		So		Futsu	Nheo		Geki	Kiku		Bian	Weng	Fun	Dei	To	To	Hong	Kin	Geki	To	Pin	Jiu	Se				Hin	Ni	Fen	Xu		Shi	Shaku	Ju	Shaku	Shaku	Shaku	Jue		Yu	Ka	Guo	Guo		Hu	Jing	Sho	Li	Xie	Er	Yuan	Hai			Jing		Ke	So	Zong	Fei	Shin	Peng	Geng	So	Jian	Ni	So	Xian	Li	Chao	Fu	Er	Geng	Yu	Hu	Fei	Ao	Sho	Sho	Ko	Er	Reki		Soku	Kei	Ke	Ku	Bo	So	Joku	Ye	Jiao	Shuku	Sen	Ken	Iku	Hi	Ken	Sai	Chao	Geng	Ru		Yue	Soku	Lin	So	Joku		Sho	Yu	Yue	Zhai	Xiao	Batsu	Yaku	Mie	Betsu	Chi		Gui	Jiu		Tuo	Bi	Bi	Xi	Wei	Zhuo	Wei	Kui			Mei	Bi	Hao	Hang	Fang	Niu	You	Hua	Bi	Bi	Lang		Kai				Bo	Kai	Ki	Bo	Ka	Bi	Ki		Zhu	Gui	Bi	Jia	Tiao	Chi	Lu	Kong	Zui	Ling	Qi	Chi	Zhu	Jung				Gu	Zu	Ko	Yang	Su	Chi	Kui		Chang		Yao	Ko	Ki	Yu	Bi	Chi	Kai	Chi			Shu	Lai	Yi	Dou	Ki	Ranh	Satsu	Wu	Ying	Fu	Zhuan	Fu	Yu	Su	Li	Yao	Tui	Keki		Satsu	Sai				Gui		Bi	Yoku	Lu	Yan	Qi	Lang	Zhu		Gui	Hu	Chi	Bi			Kai	Ryo	Jing	Ko	Shin	Chi	Troi	Que	Ju	Zha	Ki	Miao	Ki	Shu";
    case 669:
      return "Zhu	Gan	Xiong	Ji		Via	Ki	Shai	Mei	Yun	Yu	Shin	Gan	Shou	Bi		Lu	You	Jiang	Nuo					Ju	You	Troi	Kyo	Yi	Teng	Wei	Che	Lin	Gu	Kitsu	Li	Liao			Jiao	Yang	Biao	Qi		Via	Chi	Yi	Gi		Bin	Meng	Cha	Da	Gan	Ju	Gi	Hin	Qu	Di	Lei			Mit	Ki	Ling	Rei	Rei	Troi	Huan	Qu		Luo	Ku	Kui		Ju	Ryo	Qiu	Yu	Hua	Shitsu			Lei	Ta	Ren	Xiao	Si			Du	Bie	Ca	Chai	Thien		Niu	Ga	He	Pei	Eki	Fei	Mu	Ki	Shin	Fu	Ki	Shin	Hu	Wang	Sha	Ko	Jiao	Wu					Gen	Shi		Fu			Jau	Tom	Kamasu	Ngu		Bing	Zhu	To	Zhu	Chi	Sei	Shen	Hu	Bu	Kan	Bo			Ran			Ro					Mu	Isaza	Li		Hai	Jia		Chinh	Ma	Buop	Kai	Meng	Mou	Zhou	Xian	Hui	Guai	Jiu	Hi	Mu	Shi	Ru	Si	Wu	Ko	Ru		Zha												Retsu	Katsuo	Kyu		Nuo	Xie	So	Jiang		Kai	Hung	Liet	Giec	Thu	Li	Shu	Yi	Di	Qing	Ju	En	Shin	Zhi	Shin	Lang	Bu	Kuang	Yi	Ho	Bo	Kochi											Ina	Chi			Fugu		Kyo	Jiang		Wo	Xun			Vay	Da	Tun	Mang	Ta	Fang	Zhuo	Fu	Qia	Sei	Ta	Qi	Ta";
    case 670:
      return "Peng	Bie	Fen	Tu	Hua	Fu	Jip	E		Hi	Haku	E	Sa		Ding		Ru					Hamo	E		Quan						Yan	Si	Sho					Ying	Ni	Ni	Yi	Koi		Katsuo		Leoi	Wataka	Chuoi	Go	Ghim	Sua	Moi	Tre	Chinh	Iwana	Roi	Thia	Mi		Ta	Cho	Hokke	Ye	Po	Cou	Ho	Wei	Gaku	Hai	Ying	San	Ting	Zhi	Fei	You	Tei		Kui	An	Ba	Ko	Han	Rei											Kawahagi	Nan	Nai			Jing		Thu	Wei			Dyun	Nau	Me	Tep	Kho	Chay	Ei	Tuoi	Tranh	Chu	Bo	Suo	Tao	Qi	Tang	Wei	Gan	Giec	Ge	Hi	Han	En	Na	Ge	Seki	Sho	Hen	Sa	Zheng	Shi	Sa				Ara	Ngo	Giai				Anago							Ta		Kyo	Dai	Si	Ryu	Ni	Sang			Ami	Chach	Trau	Sat	So	Thon	Chay	Bong	Vay	Bon	Xie	Zeoi	To	Roku	Zu	Yu	Ni	Qi	Sa	Ban	Shen	Kan	Hitsu	Ri	Fu	Ki	Ko	Bu	Fuku		Katsuo				Sung	Kan					Shi		Kun	Li	I	Gua		Mam	Lep	Katsuo	Dua	The	Tram	Yan	Bu	Jian	Gaku	Wu	Cen	Lin	Zhuan	Ju	Hui	Ban	Tong	Zha	San	Hei	Ken		Guo	Shi	Maguro								Jing	Kan		Kan	Die	Shaku	Ying	Dai	Cheo	Vay	Ika	Zhi";
    case 671:
      return "Vay	Namazu	Wei	Kei	Ji	Rong	Ri	San	Ao	Dang	Luo	Ye	Wei	Tei		I	Ta		Qiang						Shin	Ge	Ji		Saku	Sho	Ri	Shoku	Kai	Go	Vich	Gwo	Tram	Kiku	Zou	Hen	Yi	Rin	Gyo	Zha	Haku	Lie	Sa		Ci				Ye			Duoi	Duoi			Sa	Zhan	Ri		Seki	Chou	Biao					Xu	You		Sau	Lui	Su	Kei	Xie	Wei	Li	San			Tatsu		Ko	Ruoc	Quynh	Kiku		Ki	Bo	Jian	Chan	Kun	Sa		Qing		Betsu	Sau	Luon		Shuang	Xi	Qu		Sa	Ro			Hyo	Luo	Ten		Dang	Nian	Li	Shin	Ba	Nheo	E	Fu	Fu	Hun	Zha	An			Qiu	Chou	Mian	Xun	Tu	Ni	Hu	Shu		Xu	Zhong	Kang		You	En		Cho	Xiao	Xiao	Ci	Chi	Fu	Diao	Yi		Ding	Kyu	Ryoku	Han	Wan	To	Yi	Bao	Yi	Kyo	Kotsu	Kotsu	Gan	Xun					Xiang				Shi	Ko	Kotsu	Bi	Kai	Shu	Jie	Ge	Ze	Kyu	Zhen	Hu	Xi	Xin	Xiao	Fu	Zhong		Mao	Xin	Qiang	Kyu	Kotsu	Ko	Fen	Ban	Huan	Kyo			A		Shi	Jiao	Shi	Bao	Ya	Yao	Kaku		Mao	Qua	Khuou	Xi	Fun	Ju	Caa	Qu	Yue	Tai	Tou	Mo	Zha	Qu	Shi	Fu	Shi	Qu	Chi	Gan	You	Kei	Su				Mo					Ti	Ko		Wa		O	Tuo		Chu";
    case 672:
      return "Ho	Ge			Chim	Qua	Se	Hi	En	Ge	Qu	O	O	Shi	Sa	Ju	Bip		Die	Yi	Shi	Yi	Shu	Gui	Jiang	Yoku	Song	Qiong		E	Huang	Hui	Xun	Ryaku	Fuku	Ju	Ko	Zhai	Chi	Lao	A	Qi	Xiu	Su	Hui	Tong		Uso									Choku		Fu		Jin	Xun	Jie	Mi	Yu		Diec	Chien	Ket	Sac	Hau	Song	Zhuang	Jiao	Zhi	Cheng	Geki	Jie	Xiao	Chen	Li	Yue	Bo	Zhi	Lao	Wo	Qu	O	Wang	Go	Yi	Yi	Lang	Katsu	Tou	An	Jue	Yan	Ho	Ho		Ju	Tei	Zhen	O	Zhi	Mang			Ho	Xiu		Chi	Chuang	Chu	Tra	Coc	Coc	Qua	Bitsu	Qiang	Fei	Chang	Shi	Mian	Su	Ao	Shu	Fu	Bitsu	Kan	Hi	Wei	Zhi	Min	Chang	Yan	Yu	Ta	Fu	Ta	Ji	Jun	Fei	Bu	Shi	Hu	Ju	Fun	Yu	Fuku				Riku	Qi	Mei	To	Hi	Bie	Guo	Bei			Ming	Fu	Wan	Wan			Fu			En	Co	Go	Gie	Vac	Co	Cun	Jing	Yu	Xian	Ko	Shuku	Chun	Ji	An	Xiang	Pen	Fu	Tei	Ka	Ho	Liu	Fuku	Sai	Xue	Zou	Ketsu	Jie	Zen	So	Zhan	Yo	Yu	Yu	Mei	Miao	Mao	Duo	Fu	Bin	Kaku		Ken	En	Cha	Shutsu	Jian	Katsu	Shi				Hung		Toku	Kei		Miao	Byo	Ao		Yoku			Ke		Bin	En	Hau	Cha	Jing	Ga	Tra	Hou		Jip	Seki	Gou	Baku	Xi	Fu	Rong	Ge";
    case 673:
      return "Pan	Yuan	Xia	Sen	Cho	Sha	Pi	Fu	Qing	Yong	Qu	Bitsu	Gong	Gaku	Ge	Xian	Sen	Su				Ban	Qi	Hou	Kyo			Xi	Shi	Wu	Su					Huk	Sao	Cut	Choe	Hich	Sao	Shun	Choku	Yo		Qi	Hu	Gui	Bitsu	Di	Shang	Mai	Min	Ji	Xi	Xian	Ji	Chang	Kou	Chong	Yo	Ko		Dan			Zhang	Piao	Su	Lue	Li	Meng	Chong	Tian	Chi	Ling	Ri	Chi			Mok						Chong			Chi	Baku		Sho	Niao		Yong		Ryu			Kashidori	Vac	Cuoc	Choi	Ri	Sam	Quach	Vac	Yeng	Tu	Mi	Ko	Shu	Shoku	Xi	Ryu	E	Zi	Cong		Jie	Ji	Hou	Sheng	Li	Shin	Qi	I	Zhou	Si	Qu	Tan	Sho	Sho	To	Chu	Zen	Ko	Sho	Xie	Bei	Ho			Tori			Si			I	Si			Ko	Xu		Tai			Fu	Teki		Yeng	Kuina	Khuou	Tu	Vet	Bo	Shu	Ko	Keoi		Shuku		Nong	Ya	Liu	Jia	Gui	Kui	Chi	Can	Chu	Kotsu	Guo	Kyo	Dan	Rai	Ro	Shun	Jian		Dang	Hou		Kou		Chu	Qian	Ai	Yo	Pi	Cui	Nong	Qua	Quam	Cuong	Sao	Xun	Jing	Meng	Shi	Bin	Lan	Gu	Chou	Kiku	Yo	Yong	Gua	Yu	Zhou	Juk	Dan	Ko	Kiku						Bo	Ngan	Chich	Cui	Yo	Cai	Sen	Liu	Bu	Luo	Jie	Zhen	Mie	Guang		Jia	Ro	La	Ri		Nan			Yo";
    case 674:
      return "Shou	Shin		Guo	Itsu	Kiku	Meng	Qian	Lai	En	He	Tuan	Toku	An			Rai	Hui	Ro	Kiku		Bi		Ro	Hong		Ho	Betsu	Lu	Rei	Ko	Jia	Jing		Kiku		O	Gui	Rai	Kun	Yi	Huan		Hoku			Ban	Kaku	Luo	Kyaku		Lei	Jue	Ho		Tai	Guan	Ri	Shoku	Quan	Niao		Nhan	Man	Rai		Yun	Wen	Chi	Chi	Zhi		Ci	Zhuang	Hua	Jie	Qu	Tu	Min	Mei	Yu	Ao	Ban		Pi	Zhen	Lu	Chi	Tou	Tan	Jie	Ko	Zhan	Kyo	Tan	En		Ko	Jin	Lu	Sa	Muoi	Jian	Tan	Chang	En	Ci			Wai	Cou	Kan	To	Bian	Tan	Kan	Muoi	Sa	Ko	Tan	Wen		San	Qian		Man	Man	Gan	Kitsu	Sa	Hui	Kai	Gan	Mam	Ji	Gan	Sa	Huai		Ki		Si		O	Fu	Ken		Leon	Ki	Pi	Ko	Ca	Hyo	Roku		Yu	Ben			Sang			Shi			Huan	In	Gui	Ki		Ou	Dan	Hyo	Lin		Hin		Rin	Leon	Pao	Syun	Ying	Ting	Xiao	To	Zhu	Leon	Yu		Gwan				Jian	Bo	Bei	Qu	Wan	Kun	Zhui	Bei	Yu	Guo	Ping	Zui	Zu	Yu	Zhu	Nuan	Zhu			Kei	Ko	Piao	Mi	Rei	Sha	Rei		Bi	Su	Kogara	Zoeng	Kei	Pu	Mi	Ju				Sha			Rei	Ye	Yu		Yu	Ju	Zhu	Sen	Rin	Ling		Roku		Rin	Bei	Gan	Nou	Chin	Kiku		Ling	Buk";
    case 675:
      return "Liao	Bo	Tuo	Ketsu	Bi	Na	Qu	Ketsu	Pi	Dou	Nie	Tun	Netsu	Ji		Ling		Go	Ryo	Ku	Su	Sho	Kyo	Kiku	Tou			Rin		Baku	Nai	Ze			Tong	Ge	Dui			Jie		Tian	Tiao	Chi	Qu	Ken	Sha	Sotsu	Bo	Li	Kiku	Luo		Liao	Shu	Deng	Bo	Chi	Mie		Tao	Hun	Hi	Nie	Ki	Jun	Hu	Kotsu	Lu	Ye	Ri	Mo	Chao	Sho		Yoku	Suo	To	Ke	Fu	Setsu	Chao	Ko	Bo	Suo	Sotsu		Qiu	Bo		Kiku	Su	Hi	Yun	Hi	Suo	Ku	Bo		Lou	Mo	Koku	Lian	Xuan	Suo	Man	Bi	Bo	Sa	Bo			Sa		Ti	Sui	Lian	Tan	Shan		Qu	Du	Huan	Sao	Teki	So	Go	Kuang	Sa	Ro	Rai	Nie	Haku	Nie	Luo	Zuo	Yi	Xian	Chao	Tie	Loi						Shuo	Bi	Mi	Bi	Bi	Mi			Ma	Wan	Ki	Ben	Qiang		Mo	Chu		Liu	Wo	Seki	Mei	Seki	Tou	Waa	Shu	Mu	Fun	Mei	Ki	Hi	Fun		Zuo		Tun	Kang	Tun		Ko	Ko	Che	Zheng		Chong	Tian		Zhi	Chan	Chan			Qing	Tun	Hui	Que	Zhan	Jian	Chan	Yo	Huang		Hui	Chi	Ko	Huang	Heng	Yun	Ki	Tuan	Bian	To	Huang	Yun	Yu	To	Tan	Kai	Mo	Gong	To	Gong		Gui	Ko	Chan	Ro	Que	Rui	Kuang	Piao	Ko	Lai	Ru	Rei	Ko		Niu	Hu	Jin	Ni	Bao	Da	Ni	Ko	Bi	Hu	Li	Ko		Zhu";
    case 676:
      return "Na		Quan	Feng	Bi	Li	Bie	Nian	Dong	Ko		Lian	Ni	Lian	Ma	Zhe		Chi	Fuku	Jia	Yi	Kei	Long	Koku	Yi	Hoku	Ei	Gei	An	Dai	Du	Kan	Ton		Si	Yi	Yu	Tai	Hang	Shu	Tan	Beki	Tatsu	Koku	Wan	Ei	Su	Yao	Er		Zhen	Shin	Zyu			Kuroi		Wai	Dou	Jian			Si	Pang	Hui	I	Cha	Shan	Lu	Wei	Yu	An	Yan	Wan	Qiao	Luo	Yu			Tu	Wei	Ngam	Tun	Tan	Roku	Hun	Ben	Qie	Ryo	Jin	Lai	Mei	Zhi	Yu	Ryo	Ci				Ten			Ye	Die	Cha	Dian	Man	Tai	Deng	Wei	Nian	Lei	Bing	Wu	Etsu	Zhen			Rou	Wai	Mi	Jie		Hou	Ken	Zhai	Ru	Zi	Pan	Rei	Mo	Yoku	Mi		Qi	Mo	An		Zhi	Ban		Mie		Lu	Beki	Qi	Chong	Ro	Li	Yi	Ei	Tham	Deng	Cuo	Rei	Dui	Ma	Yan	En	Zeng	Yan	Dui	Pu	Utsu		Yue		Tan		Huo	Mai	Jian	Nong	Qin	Ten	Qin	Hon		Ye	Ngon	Tai			Ngom		Jian	Rei	An	Cha	Trui	Dan	Teng	Li	Tai		Niang	Chan	Zang	Tan	Den	Nghit	Utsu	Yu	Bei	Zui	Bian	Hen	Ben	Chu	Bo	Gen	Kyu	Kyu	Bo	Bo		Ran		Ran	Yang	Bo	Bo	Ku	Ku		Cu	Bei		Wai	Bei		Shin	Cho	Ku	Tranh	Sam	Mi	Setsu	Ke	Bei	Cu	Yo	Cho		Go	Shuku	Go	Xi	Ta	Ma		Shi	Dian	Ta	Go	Shi";
    case 677:
      return "Betsu	Shu	Ding	Jiong	Shi	Yuan	Gan		Un		Hui	Ji		Peng	Ko	Deng	Ko	Beng			Pang	Ta	To	Yuan	Gao	Yuan	Dung	To	To	To		Jia	Trong	Boi	Ryu	Kong	Cho	En	Dong	Cho	Ko	Xian	Qi		Sang	Fun	Ko	Seki	Yin	En		Long		Fun	Teng	Long	Cho		Ren	Shu	Shun	Yin	Ping	Pu	Yuan	Rong	Hoku	Fang	Shu		Keki	Hang	Mi	Hu	Zi	Ryu	Ling	Jiong	Rong	Yu		Shi	Ping	Guang	Er			Ko	Kaku		Ryu	Kan	Go	Cu	Jun	Hai					En		Xiu	Tei	Er	Ti	Sui	Yang	Tei	Ai	Hu	Xi		Hu		Si	Li	Shi	Yi	Gu	Koku	Tang	Ho			Shi	Ko	Kyu	Que	Zong	Li	Koku	Jiao	Fun	Hatsu	Fan	Pu	Si		Jie	Lu	Li	Chan	Ku	Yao	Kyo	Kyu	Kyu		Hui		Ko		Hou	Dian	Qiu	Jue		Pi		Seo	Gotsu	Kui	Tei	Gotsu	Xi	Ti	Shin	Ko	Xu	Ki	Mui	Mui	Ngui	Tei	Bian	Tei		He	Lian		O	Su	Liao			Ngay	Kyu	Jin	Shin	Kai		Hit	Li	Chan			Qi	Qi	Zai		Zi	Sei	Zi	Sei	Qi		Qi	Zi	Shi	Zhai	Zhai	Pa		Ju		Ketsu	Yan	Kotsu	Gan	Hang	Na	Ki	Ketsu	Shin	Go	Kai	Kai	Yan	Shin	Zhan	Shi	Zhi	Chi	Shi	Tetsu	Sa	Zha		Gin		So	Rei		Rong	Zha	Sai	Yi	Ming	Ya	Shi	Zhi		Kuo	Xia	Ratsu";
    case 678:
      return "Pian	Ta	Getsu	Yi	Kan	Getsu	Xiu	Zhai		Duo	E	Gi	Loi	Tan	Yin	Saku	E	Suan	An	Cuo	Sei	Tuo	Getsu	Tuo	Xia		Go	Chuo	Tai	Suan		Kon	Sa	Sa	Katsu	Ga	Sho	Ji	Qian	Zu	Zhai	Yun	Zhan		Yi	Kotsu	Soku		Gaku	Shi	Ya	Yue	Shu	Rang	Kan	Sho	Shu	He	Qia		Ratsu	Gaku	Cha	Sai	Sho	Sa	Ratsu	Ou		San	Setsu	Setsu	Hu	Shi	Yan	Shi	Qie	Bo	Qiang	Jie	Shi	Setsu	So	Getsu	Tai		Ken	Shu	Sei	Sei	Setsu	Ni	Chitsu	Sho	Chan	Qin		Zao	Tai		Yin	Xie	Sai	Qi	Jian	Kan	Reki	Xu	Shi	Zeng	Saku	E	Katsu		Kon	Zu	Yi	Sa	Shi	Ro	Shi	Zhi	Li	Satsu	Sa	Li	Yin		Ren	Lian	Haku	Chan	Ren	Jue		Za	Haku	Ten		Gatsu		Shi	Zhai	Pian		Long	Ken	Long		Kan	Ro	Ro	Long	Rei	Trong		Ken	Long	Ro	Ken	Long		Mang		Trong	Zhe	Ki	Ki	Ki	Gwi		Dan	Gan	Gou	Ran	Cu	Jiao	Sho	Waki	Dan		Ko	Ku	Bo	Kyo	Zhu	Qiu	Yang	Shu	To	Bai	Ki	Xiao	Shu	Hui	Qu		Rua		Rua	Ling		Yin	Sho		Chi	Pi	An	Sui	Sui	Lian	Roku	Chi	Sho	Sho								Wing";
    case 679:
      return "														Qiao								Isogi																			Sagi	Sagi		Yo												Toneriko					Katsu									Ka												Ka						Kutsugaesu							Imashimeru																						Laeuz																																	Han	Nei		Bun				Duo																	Rei							Fubuki															Saku			Kujirieru							Jian									Kanari						Ji										Tabakaru																Uchikau";
    case 680:
      return "Ku															Jim									Kai							Zhen		Sa																	Botsu	Ce		Leon			Huk					Dong			Kiu			Maai		Wani			Bai			Jim				Zhan												He			Kui		Sen	Nigekamu							Nageku																	Hikaeru	Lai								Tsukuzuku						Sau		Kamabisushii		Laan	Get			Laai		Shu			Zyut											Laan														Luan																								Dung												Waan											Zao								Hotogi			Sama																			Lou";
    case 681:
      return "				Bai																			Liao			Leon																																										Tei																												Reng			Ara								Soeng			Shutome		Ning		Kannagi											Omina		Duk											Namameku					Kisaki				Min																			Yome		Yamome						Uba												Kase						Jing																								Geoi							Nei";
    case 682:
      return "							Teoi			Song				Shaka									Jue										Fumu	Arashi					Leon		Ya			Ha				Qu						She	Ngaam		Tuo														Lou							Jing										Yan			Nie														Ichi															Fan																									Qiao												Yong	Coeng																						Yi						Ko		Bat			Yuzuka					Nichonoyumi								Lung																					Li						Omoshiroi					Nengoro											Cau	Obiyakasu		Cim";
    case 683:
      return "			Ken		Akogareru																					Pin																																					Suzuroni										Arawasu																				Wei					Cung					Mei								Guai		Sagasu				Loeng		Taguri			Ratsu		Tsumuru		Haan					Can				Ra				Sok											Zyut																												Sho	Maan			Laai	Sa											Nyaengq				Eto					Sim														Teki";
    case 684:
      return "																		Saru																					Ko			Asaborake												Fai										Shibomu																																				Mutsumajii	Fan			Oboro	Meku								Kine	Munenoki	Muku			Zanbuto	Bui		Mochinoki		Enoki											Hajiki	Fushi							Zai				Momiji	Yatsubo	Lai		Hashira					Gai							Sakaki				Udachi	Sho	Kaki						Fai					Kaki									Maki						Nuru	Norikura			Shide			Sugi	Suginoki			Sip		Ryo			Kurumi	Teratsutsuki			Hi							You				Tsuikushi	Sasebu		Miyatsukogi			Hainoki										Tsukisai		Sugi							Koganoki";
    case 685:
      return "Hari						Muronoki	Shitagura							Yuyanagi		Setsu			Nashinoki		Koshiki				Cyun							Ju	Mochinoki				Yuru										Ngap																																		Hiu																	Byoem	Hei														Lai																			Si					Hama									Luo																												O																				Bo										Todae	Qing																							Rin																									Zaan		Wing";
    case 686:
      return "																					Hei													Tsukuro							Wai		Moekuzu																					Yi																																					Hatameku														Zuk			Akutabi			Ta																	Ei						Tsukamu																			Dao							Lung			Kiu					Shiromu					Cong		Nu		Nung		Ngan								En							Mujina				Cong			Yo					Tan																Duk										Kwan								Gwai";
    case 687:
      return "											Bat						Katai																									Iwa												Mari	Mika	Nabe	Nabe		Tsubo	Yokobe											Ke				Arakihari													Aze					Boi								Bito					Zoeng			Jian	Lou						She			Ji			Ashinoke																										Xu			Moru											Xian				Lou	Manajiri	Miru				Niramu									Shikaru			Pan			Torime	Meshii			Miru									Yaki		Ya																								Hi									Paau";
    case 688:
      return "			Noto									Shi							Min																				Muku	Jian				Chu		Dang									Minoru		Aki								Tagaesu	Baa				Nariwai											Mado					Nerau	Hoki								Zyun		Li																	Mou	Wai				Soeng												Man		Aoda	Gwok		Fei	Sechi									Tamanosudare				Ai			Su										Shizuki						Utsubo									Momigara													Sa					Chimaki			Kumashine																Jiu					Kou																						Hokorobi			Ru";
    case 689:
      return "										Hanazuna													Kataho		Gau	Wu	Gam	Mou	Diao	Bi	Si	Gang	Dung	Fuk	Nung	Daat	Saai	Jie	Yan	Chi	Faan	Sang	Lit	Sit	Fuk	Ting		Bong	Sik	Mou	Si	Leot	Beng	Koeng	Yi	Xun	Zeoi												Ji																		Fan																						Pin															Lian			Kusagiru																Zim				Mimibukuro								Sakayaki		Be											Mae															Hozo			Otogai																														Laai				Hannya				Takashi						Ying		Hahaki	Muko	Gang			Wei							Co							Makikusa		Nung		Shiba";
    case 690:
      return "		Tatami		Tamazushi		Kinugasa	Sai		Gaan					King					Ebine											Namenunawa	Can					Suge												Qia				Hatsu	Zyut				Warabi				Kikurage			Saki	Oi			Syu			Wa						Soba				Hiru	Namomi							Hishi			Tsuranagusa				Suzumimushiro												Wok				Kubote											Namomi					Ori				Kuro																				Shitagura				Tezukuri		Gyaku								Jogomushi	Kamikirimushi			Chang	So			Lou		Ayu	Gaan		Kai					Giu		Kiku	Cing		Shimi	Semi				Sai	Amabiko		Semi	Mina	Giu		Kisa		Sakazukimushi	Te		Shu	Shin	Gong					Hae	Awabi		Mina		Ashiharagani			Ari					Kirigirisu		Kumo											Sumu			Au			Kinu		Zaak		Jiu		Kui	Itogoromo		Ko";
    case 691:
      return "Ji					Obi		Zip	Akome			Shu								Kutsu												Katami						Ukagaimiru		Kaomi	Luo		Mik	Lian	Byo	Mei		Jiao								Denshin													Hayasu		Kotogotoshii					Kobosu					Pin		Hakanai							Yi	Jiu	Fan	Heoi	Dung	Hu	Yi	Jyun	To	Nao	Tong	Giu	Tiu	Nung	Ci	Zan	Faa	Gei	Yan	Mong	Nei	Wat	Xian	Xi	Zyun	Xiao	Zung	Lau	Ngou	Chi	Kwai	Sin	Ze	Sha	Hei	Zhong	Xuan	Ning	Zin		Yatsu					Zung	Mo					Geoi									Makanai																	Lung	Gau	Lian	Cam	Can	Taam	Gam	Cing	Ni			Lik		Bat					Sen		Can						Kohagi		Furui	Coeng	Tei		But			Anaura		Jue	Leoi			Tazuneru	Zaam	Luo			Kutsugaerifusu	Jaang									Tan			Tona							Sin	Tadoru					Korobasu";
    case 692:
      return "				Yue	Sim	Kuai	Naap	Bat	Ling	Faan	Zhi	Ping	Tian	Ji	Zau	Ni	Gun	Gwang	Rou	Ke	Wai	Gaau	Buk	Ham	Leoi					Oshitatsu						Ato											Yu								Lau																															Kataho		Zyun									Meng																				Masuzu		Jim										Sotomo					Mojikiri			Abumi					Mizukane				Mune	Kanausu			Imono				Umanokamibasami		Tozasu										Tatsuki				Kabuto					Nata			Kanei		Hokosaki		Han						Sakahoko				Kutsuwa			Heshikugi							Kanae			Fuki			Herakuki				Nokogiri				Sabi		Aotsurugi											Baat	Zi	Fu	Gwo	Cong	Jyun		Zaap	Joeng	Liu	Ji	Seot	Kiu	Gwan	Rai	Mau	San	Xuan		Faan	Ji	Lou	Nip	He	Zung	Juk";
    case 693:
      return "Lin	Fan	Dik	Kan	Jau	Sok	Bei	Bai	Sok	Jing	Sau	Fun	Sin	Fan	Jue	Chan		Zhan		Kaku	Kwai		Nong			Jin	Utsuro			Tsubusani	Fuguri	Batsu		Dou									Azaru			Hoi		Dau	Bin	Lan	Xiao		Leon	Zi	Nie															Sei																					Sho					Sora				Arare		Wan			Sam																			Sozoro								Fui		Lung		Hoe				Kutsunokibisu						Qin	Bat	Bing	Bai	Gau	Zheng							Utsubusu		Hazama			Ken						Kuboshi		Ku	Zam	Zhen		Yi	Fu	Duo	Gan	Wan	Yun	Ze	Ngok	Haan		Jyun	Cuk	Fan												Sameku	Yu	Bo	Bung	Am	Sat															Jian				Zin	Yuan	Zhang	Ko	Zok	Bit	Shi	Wan	Bu	Su	Lang	Lo	Wai	Wu	Nyun	Wai	Huang	Hau	Deoi	Lian		Jiang	Zhan	Hoeng";
    case 694:
      return "							Hiki				Ao										Tokiuma						Hon	Wen	Jue	To	Po	Zi	Gwing		Han	Ai	Kwan	Tao	Lu	Ti	Wong	Yuan	Aan	Xi	Soeng	Zaak	Cang	Zin	Kwai								Hisashi				Kut					Rau						Nai			Sozoroku				Sumi		Gonzui	Konoshiro			Anago	Dojo				Namazu		Konoshiro		Ishimochi	Sake	Iruka	Sawara				Tanago		Chika	Todo	Bora	Menada	Indotai	Gigi		Ayu	Haya	Hamu	Manakatsuo	Iruka	Namazu		Yamame	Kisu		Suitataki	Burizado		Fugu	Mekujira		Kajika		Wakasagi		Same		Hae	Sawara	Bora	Ara	Xu	Hong	Joeng	Zyun	Saa	Fan	Bing	Kiu	Yang	Bit	Fu	Lit	Hui	Shi	Ci	Gap		Pu	Zip	Dyut	Kwai	Hua	Lei		Gyun	Zau	Jin	Bin	Zi	Haa	Jung	Cau	Bu		Wat	Sou		Lie								Teratsutsuki						Misago			Tsubabirako		Hashitaka				Kamo	Sagi								Otori				Sagi	Minashigodori		Uzura		Taka	Isodori	Shijukara	Kukuwakenaku	Gin	Zhi	Fau	Fun	Jue	Lung	Zha	Fuk	Ning	Wat	Gaa	Gaap	Wu	Shu	Pei	Aan	Jyu	Jyun	Tou	Kuang	Bit	Fong	Kei	Zok	Diu	Fuk	Ti	Gwat	Chi	Wu	Ti	Byo	Hou	Duo	Kwai	Leot	Chu";
    case 695:
      return "San	Bai	Zhang	Jam	Zeon	Huan					Wen							Fung	Tuo	Ken	Pei	Ku				Ying		Kumoru				Cu					Kagu				Baa	Ngit	Ngaau		Zaak	Co	Yan	Jie	Ngaa		Lung	Nan		Lam	Dan	Shou	Hua	Ke							Go	Bo	Sho	Ji	Kyu	I	Kon	Mei	Hun	So	Den	Shu	Yo	Ko			Zen	Sei	Hi	Kyo	Gyo	Shin	So	Ko						Gan		Cho	Dan	Da	Sho	Masu	Shu		Bui	Syu	Fai	Cau	Gong	Loi	Wui	Jing	Laan	Gaku	Kama	Nei	Ko	Ko		Dou	Sa	Za	Gen	Nen			Hatsu			Tsuki	Zoku	Hata	Gyoku	Sho	Shin	Xun	Mata	Ryu	Sasu	Ryu	Tochi	Sho	Momi	Dan	Kyo	Kyo	Ken	To	Reki	Sai		Shi	Min	Man	En	Bo	Zi	Zyu	Man	Kyut	Kan	I	Ling	Wing	Zhi	Caan	En	Bui	Zai	Lou	Laam	Men	Jin	Kamasu	Kei		Teki	Ei	Ei	En	Shin		Sai	So	Nade	Kuai	Bara	Ku	Sechi			Sa	Hei	Yanase	Mochi	Ka		Jam	Wang	Liang	Cung	Liu	Bi	Shoku		Yo	Gai	En	Ko	To	Bo	Ling	Yo	Gan	Ketsu	Kei	Zo		Ei	Ei	Ri	Tan	Kan	Jo	Zi	Pun	Cin	Cung	Tan		To	Keng	Sui		En		Hen	Li	Zhi			Ju	To	Chu	Kau	Zi	Fan	Wan	Saan	Li	Sik	Hong	Hoi	Zau	Da	Zu	Zu	So";
    case 696:
      return "Cou	Hap	Ling	Shu		Gaak	Kui	Cam	Bik	Ba	Xuan	Luk	Bang	Sayori		Mu	Haam	Sou	Zoeng	Cho	En	Yo	Kyu		Yu		Shutsu		Ni	Betsu								Lou	Sho																																											Yin	Luk																		Atsumaru								Wo										Dan	Hekutaru																			Cin					Tei			Lung		Gui				Dui	Dung																	Lin		Lou	Wai											Dan	Chong	Caam			Fukutsukeshi				Hayarasu			Sen					Laam	Oi								Kame			Hetsurau						Qian																Su										Mane";
    case 697:
      return "																								Ji				Kyodai		Futsutsuka																		Yo								Mou					Gan																Yan																			Osoroshii																		Tachi	Li		Li		Dyut			Ye	Juku	Ya					Suo				Siu			Shuneku	Lou			Zyut																			Cim					Kaichi	Kaichi				Loeng		Katana						Bo		Dyut			Jiji			Yumeyume						Hatameku																																					Baku										Buk	Sit								San								Duk";
    case 698:
      return "						Xia																																							Se														Tan																										Gwang	Mun				Gang	Cung									Ye	Gau	Nip	Gan		Chu		Ye			Naku	Hai				Ngai							Zeon			Hong	Baan		Go	Loi	Yan	Lai	Jian	The							Zam	Sam					Baan						Ou		Zaam	Modaeru							Ning		Suwa			Hiu			Zhi							Saa									Ti			Jin						E	Ngaap			E	Bap					Torakasu								Ting											Kai						Daam		Ban					Saezuru				Zuki	Zeon			Lu									Pan	Ling";
    case 699:
      return "Doe			Waa				Bok									Coi		Saat				Zoeng		Baa	Gun		Zeon				Die					Ne	So			Ang									Maih		Hoi				Ke									Gaam		Tian													Kawaya								Fuse							Zyun	Ou			Lun						Baat		Haau				Ce	Xun		Kura	Ngaam										Lao							Shan		Cam								Sai	Atsuchi														Yin								Yachi								Jiang	Osore													Horikiri				Meisho																				Nong									Tian										Kut												O					Wan		Atama	Han";
    case 700:
      return "Koshi	Hata	Do											Wai						Musuko							Mosu	Xing				Ko	Dong	Hua	Wai	Re					Maai								Cim									Kwai															Kannagi	Uwanari		Doreai										Laam														Wazurau				Odoru																				Nabikasu				Qia										Xin														Zaan																Kogane		Wakai					Fushi						Lan	Michi			Fung											Aa										Utsuho			Sai							Dam";
    case 701:
      return "																																																				Sho								Be																						Tui					Kaigane	Bi																	Waragutsu								Cat			Tawa	Joeng	Wai	Li	Keng	Tai				Arashi								Shin		Die			Lan											Wing				Wasabi				Gan			Sozoro							Kun											Keng																			Kun			Xu	Hin	Shin		Lan					Ha	Zukin						Sanh																				Loi		Jam									Xin		Lau					Jing";
    case 702:
      return "																																								Butcho	Kou																					Yunzei																					Yuku																				Ketsu	Ko						Jyu						Wai			Sung					Dong	Soeng				Hip	Hip				Waa				Cai		Gung			Itamiureru				Mun	Kun		Wit	Namajii	Lou																		Joeng	Chanh		Okotaru										Naan										Xi		Da				Katsu																				Suzuroni										Hodashi		Osameru";
    case 703:
      return "											Notare								Mara				Mo				Diao		Cau						Pie	Ze	Goi		Waa				Bi			Nong			Kang	Lay	Kobosu		Lou	Suo		Jaap						Kap		Na	Lin						Waak			Gaau	Lyut					Jian				Niu					Kang									Duk	Zoeng		Hin		Fei			Nuru		Mizuguruma		Dang				Niao	Bi														Yan		Xiao		Sabaku				Ki									Muzuto																											Chu					Li									I							Kai																					Shu																						Sai																	Ureshii";
    case 704:
      return "																							Yugake														Huo		Kusaka		Wei	Xian		Hiko		Dui			Hoi						Shang				Riku																						Trua															Xiang																			Ma		Au			So		Ngaa			Sun			Jeon		Lo	U		Daan				Sing														Hareru				Edanashi	Hoda			Matagi	Mou	Hi								Jia			Kase		Saat		Nung			Tara		Matahori	Tsukabashira					Tarai				Katakumi	Kwai									Utsugi	Zhi					Yuru				Hamayuka				Tsubaki	Ji					Taro					Hobashira	Mase			Jian				I	Hin			Fei		Kinokawa		Lin	Yan		Samomo	Kuchinashi	So			Shiishi				Tamo";
    case 705:
      return "									Kashinoki		To	Yamamomo		Kumahajikami				Sugi			Jib	Hoya	Masugata			Ochi				Chua	Tanohi	Nashinoki					Hahaso		Shigarami		Jan		Hiba	Getsu						Hiiragi				Wananoki		Tara		Etsuri	Mohoko	Kushi									Yanagi		Muku			Ko	Naranoki			Koshiki				Utsugi			Utsu		Ume											Xia			Gwaa						Pan																																		Hikaetari							Ta	Hen				So		Nao											Gik								Kau				Ki												Mou					Jian	Bin			Dip									Denki					Wan			Tyun	Bei			Nakunaku																				Men									Guo			Kyo";
    case 706:
      return "	Taan						Tari										Mei				Fai							Jing											Gip					On					Po				Kikusui									Hua				Fan					Saap				Wai													Fuka								Laan	Jeoi						Han																		Seki	Matsuru		Ou						Caau						Xun	Daat				Cau	Gung								Mui	Jian					Lo								Chan		Sim															Tong	Laam				Wui				Ran					Lian					Sho					Lai	Kame								Zetsu										Iikashigu												Kanaguru";
    case 707:
      return "																							He						Co												Zeni					Hiu				Yu		Rei			Shan					Shaguma																								Zei		On			Zaan		Li						Dang			Xun											Ka																							Ying											Laan																			Yokobe		Sanake	Cung	Ta			Hisago	Tan		Motai	Nabe	Yokobe				Aioi										Yo										No								Aze												Maa			Gai				Sen	Ryo		Fai					Wan			Gwo								Hahakuso	Fen					Aza";
    case 708:
      return "																										Hai						Yang				Hai																																		Gwan	Chang	Omeome					Cau	Medetai	Ying	Yasui		Kou	Jip	Zhong	Gwan	Maboroshi	Gaan		Mai			Meku	Miru				Chou	Atome					Min	Miru				Maboroshi																	Donbuto								Kuma	Jap	Lan	Que		Cuoi			Wan	Hang					Ra	Geng	Suk		Lan	Xin																Ego					Zenji					Futsu	Hi														Inoru			Ikenie		Tan																Saka										Gei	So					Aramaki					Cau						Ben	Tei	Awa		Jung			Shai	Aramoto			Tui";
    case 709:
      return "Ugoku		Wai												Obotsukanai	He																									Shinai				Shimoto			Ou	Sashi								I	Hai								Mino	Long		Sai						Gaan	Sudare			Sasara													Fu											Au	Amahako					Ling		Kiseru								Sono													Zyun				Kuda										Haan	Kewai				Chou		Shi						Shi		Lou			Yusuru											Haam												Ran	Kate																											Dan				Ken																		Tsugari";
    case 710:
      return "			Saa					Koto											Xun	Mie	Kau	Gaan		Dan	Yue	Wa	Keoi	Zhan	Zan	Diao	Sin	Goi	Yin	Kwong		Leoi	Cyun	Pai	Cai	Zik	Ting	Lim	Huan	Qian	Chen	Mik	Zhun	Jyun	Yao	Zha	Xu	Cau	Gang	Cau	Ci	Chi		Tou	Hat	Sui	Zhi	Shuang			Yan	Yan	Qian		Zhu	Faan	Jin	Leon	Daan	Mo	Xiang			Lou															Bat													Ken	Ken		Wai			Kaga																				Suk																									Sasayaku												Iwakura																Wa				Kei					Habaki										Tanashishi							Toribishio		Vai							Bin																												Nie	Tong			Jyu";
    case 711:
      return "											Yakata							Han		Da		Utsuke	Tomabune												Iso		Laam		Faat	Wai	Ka			Man	Tokoro	Hige	Liang	Kaisogu	Ira	Hondawara		Tabako			Ya	Waai		Ju	Sai	Inui		Haan	Gwok		Yu	Nuta	Lao							Si	Zit		Hakobera							Kagamiuri		Shirakuchi							Sarukaki	Namomi		Zei					Kane	Wara			Yafuku				Asa		Pan					Ran							Kubote				Suzuhori										Kahashikusa		Jian		Karamushi			Akutareru				Narihisago	Laan			Teoi	Natane						Pin		Tsurumaki		Sen			Tsune					Ham													Oi	Wara			I					Yi	Igisu									Amazura					Tsukikusa		Ieararagi	Hun					Sui										Komokusa				Kazura				Gwik												Nokihamushi	Koenomi	Nomi		Cong			Dong";
    case 712:
      return "Shirami		Ebi	Bi		Dong			Gong	Fun	Ji	Umuki		Momu	Hiki		Wang		Katatsuburi						Ei	Funa				Kaki	Kawahori	Funa	Caak				Hiru			Kurage		Tsubi			Kumo	Kuwago	Kasamushi	Awabi		Moi		Sakenohae	Kumo			Tuo				Kaki					Fukumu							Niu						Diao	Zhou				Gaap	Dip	Shi	Shai						Fusuma					Lo					Cho	Toku			Tamoto														Zaan				Chan		Mise	Miru						Iken		Nabiku	Cha	Dong	Ci	Zi	Tiu	Zi	Shi	Dou	Dan	Qi	Jing	Ming	Hetsu	Dang	San	Kai																				Zau					Jing				Cam				Hetsurau						Sukasu		Tap	Wai				Noberu												Omoshiroi					Nichi	Horeru	Serifu		Xu	Kou	Zi	Hou	Kwan	Zhu	Tau	Gam	Jian	Tuo	Zyu	Gyun	Tou	Aau	Fai	Ngaa	Wui	Wai		Fui	Dong	Ming	Ren	Fui	Zau	Pou	Hen	Bai		Zaa	Cuk	Hon	Cuk		Ting	Long	Lin	Zaak	Lou";
    case 713:
      return "Haak	Tou	Tam	Gangj	Cam	Ji	Gwan	Yin	Tei	Wui	Shi	Cong	Zha	Wong	Hyun	Duo	Go	Gaak	He	Chi	O	Ta	Gun		Cat	Fu	Ying	Cim	Zha	Hui	Yi	Liu	Yan	Ou	Zyun	Deoi	Zang	Zhuan	Wai	Ka	Cou	Ngaai	Daap	Haak	Tyun	Wai	Zaan	Jian	Fun	Tui	Kodama					Hitsu													Zip				Maau																																											Cong	Han	Yi	Bei	Zaang	Cyun	Sha	Yan	Ruan	Duan	Hau	Lan	Zhan		Beni				Tang	Tuan						Etsu																Karui				Naai			Li		Bui	Kibisu	Leon		Zou		Duo		Haneru		Xie					Bing	Zhang		Hina		Cho	Ko	Gwaan			Laam		Coeng			Teng		Komura												Nian		Tsugo							Dian					Nong			Lung		Lou			Shitsuke		Guo			Shitsuke	Yatsureru		Ping				Densha";
    case 714:
      return "	Mou	Qi	Zen	Ong	Nian	Gung	Hoi	Waan	Tin		Zang	Pi	Got	You	Xu	Hui	Song	Guang	Caau	Bei								Korobu																			Ha																															Huo								Satemo																																							Xun	Loi															Mau																									Suzuhori	Jyu	Zaan	Nong			Karashi														Guang	Kaeru				Senchiaru					Katsuchi									Xu				Katsuchi					Suki	Hasami						Sho			Fukurin					Shitomigane		Tagane						Kanahikaki			Abumi	Hotogi										Kanahoko			Tagani";
    case 715:
      return "		Kabuto					Zhe	Yana	Hera	Kagari													Jin											Kanuchi	Fuki				Hon	Hua	Yi	Kau	Pai	Wai	Lun	Chang	Jam	Coeng	Jin	Pik	Qi		Cam		Sek	Shu	Shen	Co	Lu	Jip	Zok	Ning	Zhao	Zi	Mu	Hong	Pei		Xiang	Do	Guo	Zaak	Zai	Du		Hua	Hon	Hong	Joeng		Zi		Tin	Cuk	Diu	Paang	Neoi		Daan	Chun	Bo	Leoi	Saam	Da	Cou	Caa	Ziu	Gwai	Sin	Hou	Cung	Nau		Ceoi	Weng	Hat	Zin	Hui	Cik		Pie	Ji		So	Xi	Git		Hei	Cheng	Lin		Biao	Giu	Sui	Bik		Kai	Hing	Bok		Zuan	Jiao	Hiraku	Shinatarikubo							Hoengh				Kikigaki					Kan		Wik	Muon						Leon	Haa	Jian	Hung	Kuang	Gap	Cuk	Kan		Waak	Qi	Saa			Kwai	Ki	Que	E	Yin	Jiu	Baan	Am	Xian				Deng	Maa	Wu				Gai	Ji	Kechi				Haap									Tui																																				Hinazuru	Manazuru		Ku			Arare";
    case 716:
      return "	Sai		Mu					Shigure																									Luo		Jian	Zhou	Loeng	Shikoro		Yugake				Kohaze					Han	I	Dip			Ceoi	Chan	Yu		Ye																	Ashimoto				Gan				Kwai	You	Mo	Di	Daam		Pun		Zhuan	Leoi	Gen	Kyo	Wei	Kut	Ta	Wan	Chen	Katsu	Hong	Hei	Ki			Ji	Ding	San	Po	Au	Shou	Pei	Zhan	Ben	Jyu	Tsumujikaze	Wai		Hyut	Xue				Hoi	Syun	Rumz	Gwok	Fat					Liu	Yu															Zan							Cheng	Motai								Shi	Zi			Aku	Chuang	Nian	Shi	Ze	Tai	Gou	Shang		Ning	Yi	Man		Ci	En	Guo	Mang	Bao	Ti	Jip		Wu		Ye	Ngaau	Zeoi	Pi		Sui	Gin		Ken	Da	Tou	Sik	Qiu	Tong			Chong	Ying	Deng	Yong	Mo											Fan																San	Tsukige		Chan	Faan	Pei	Pi	Jiong	Gua	Ak		Sai	Kuang		Shen	Ci	Tu";
    case 717:
      return "Long	Ngon	Fei	Huo		Paang	Kei	Chi			Lin	Tit	Meng	Biu	Tuo	Gin	Fun																							Hige	Nao	Nong			Kaminosue																	Hashita	Kibishii			Ayu	Hiuo		Suppon		Inada	Ina	Same		Isaza	Urumeiwashi	Hio	Hae		Same	Sake	Nibe	Namazu		Geso	Namazu	Fugu	Gigi			Katsuo		Tobiuo	Gigi	Katsuo	Magoi	Kamakiri	Su	Kawaragori	Funa			Kajika	Katsuo	Mi	Nibe	Saba	Hae	Haze	Migoi		Menada	Mekurahaze	Haya	Okoze	Ishimochi	Nashimono	Kisu	Iruka	Ako		Tai	Suzuki	Fugu		Subashiri	Yagara		Git	Jan	Tou		Diu		Bang	Gaai		Wu	Gang	Ju	Doi	Tuo	Zit	Wei	Zhao		Shin	Ting	Hou	Tai	Jip	Lou				To		Koi	Wu	La	Lian	Kawahagi	Sing	Zaa	Tai		You	Jau	Ji	En	Ni	Wong	Keoi	Ji	Xi	Guo		Jing	Zoeng		Pu	Gwaan		Kon			Gun	Ba				Yotaka					Kashidori					Toki									Kamo		Tsuru	Bu		Uso		Misago				Tsugumi				Uguisu	Isuka				Washi	Sagi				Konaishi	Niwatori			Zeon	Hina	Yamagara		Sakunaki		Uguisu		Kayakuki			Otaka		Jik	Xiao	Hung	Sho";
    case 718:
      return "Man	Wa	Ge		Ro	Co	Sang		Ci	Qiong	Jam		Sha	Chou	Li	Lang	Chuang	Yue	Kei		Shu	Ang	Yan		Yan	Miao	Yue	Wong	Pin	Am	Leoi		Ge	Lan	Gou	Xian	Piao	Chong	Zhuo	Jin	Qi	Ou	Fan	Tan	Kou	Ya	Kwai	Pik	Hok	Keoi		Gaan		Zhan	Chang	Cou	Bian	Gan				Kagoya	Cai							Coi		Bo	Sotsu	Wan	Ki	Hun	Nie	Mo	Shan							Zhen	Nung	Lai	Teng											Zyu	Ta																	Da					Ngaa	Na	Xie	Hang		Shi	Zha	Zhi	Nie	Ngoi	Kuo	Chan		Cuo	Yi	Ze	Yun	Zu	Ji	Gaam	Ci	Bo		Setsu	Yin	Chu	Gam	Caat	Jue						Lung			Yao																	Edanashi	Edaoroshi	Naengh	Ban	Ndeu	To	Kai		Hei		Hei	Shi					Bosatsu	Ko	Shu		Daemq		O	Sai	Su	Ko	Laj	Bodai	Laeng	Naj	Ka	Hwnj	Sho	Su	I	Roengz		Yu	Nding	Cwngq	Su	Doek	Dingq	Kyo	Mu	Mu	To			Laj			Nding	Sui	Gai		Doek	Rag						Vengh	Doemq			Deng	Vingq	Ken	Gyang	Ka		Aen		Kyo		Cawx	Gyawj	Ya";
    case 719:
      return "Shite	Dara			Onsu		Shomon	Doz	Fu				Hei	To				Caj		Raez	Ruz		Bo	Guren	Shi	Cho	Cho		I						Mbin	Gyaeuj								Sa	Mbin												Ryo		Tei			Kan	Ko	Kyoku	Fwj	Fwj	Fwj	Ei	Haih		Kai	Kai	Choku	Kyo	Kyo	So	Jo	Sui								Kai	Ichi						Yo				Hen	Sho		Hen		Caj	Kyu	Kyu		Sa		To	Lawz	Gvai	Chi			Hauh					Ko	Ko		Yaku		Hoiq		Doengz			Gyoengq		Loenq			Gwiz		Liengj			Yu	Biek				Bangx							Jing	Ko	Hi		Tai				Gaemx	Soij									Hi		Wnq				Yu		Sengj			Mbaiq						Ken		Ryo	Hek			Kyo			Pa					De									Foux												Coz										Kei				Au								Yu		Saeq			Gyaeq				Chu";
    case 720:
      return "Hin									Shuku							Gyoij						Li	In	Da	Da	Ju		Da	Ga		Cho	Men	Cho	Hung	To	Nami	To		Hawq	Ko						Rongh	Baed	San	San	Gonq		Rongh	Senq	Ndongj	Gonq			Senq		Get	Gyax	Gaeuj	Haeuj	Coeg				Geki	Boux	Itsu	Yo	Yo	Yo	Mbat		Fiengh				Ken	Gyang	Haet	Baeuq	Kan	Yo	Lueg		Gyuk	Dingz	Gumq	Roeb	Don	Gyoengq			Zen	Sai	Ryo	Sho	Byou	Caiq		Noix		Ko	Ko	Ko	Ngaeuq	Hei	Ndei	Ko	Doq			Ho				Mei			Kan	Fu	Shi		Yaemz			Sha		Goemq		Ken					Nit	Gaet	Cog		Yo			Shuku		Shun		Lueg							Shitsu	Cengx				Caengz			Nit	Moq						Bon	Ga			Ko														Cat	En	Yak	Ok		Cangz	Daet	Setsu	Gai	Gai	Cax	Heh	Faenz		Byax	Katsu			Gaj	Gyax	Gaj				Daet	Veh			Toji	Katsu	Cax	Faeg	Fag			Nyeuq	Sho	Dat			Sei	Daeq		Sho	Raemj	Lauh			Sei	Raemj		Wan	Shu	Tatsu									Yangj	Gaj	Mid";
    case 721:
      return "	Laeuz			Bag							Mid	Mid		Doz	Geki							Gvej		Ryu			Zin		Vet	Bun					Sei	Rengz	Do		I				Yo						Gyax	Hoengq	Cho	To		Mu	Ak		Bon			Maenh			Kan		Ki	Tsutomeru	Kan		Katsu				Fwet	To					Rumq	Ki	Kan	Sa						Kyo					En		Ko	Yoshi	Hi	Byongh	Baet		Nanz			Soh	Sotsu			Soh			Ko	Ko	Gaj	Setsu	Gyo	Gyo	Bo					Ro		Kyo	Kyo						Shin			Chi	Kachi		Chi		Naek				Kachi	Kan		No		Ki			Na		Shun		Bae			San			Tan	Ken		San	Han	Gwnz		Youq	Youq	So	So	Ka			Hon	Caemh				Yori		Ken		Gou	Haeuj	Han	Cam					Nyi	Go	Gongz							Raez	Roku	Mbaj						Sai		Fek				Ko	Raeuz	Han	Raeuq		Put		Vet			Dyut	To			Gan					Kei					Lau			Fwen	Fwen";
    case 722:
      return "				Daej	Luenh	Ai		Mu	Ingq							Sek		Byoengq	Caej	Haq	Nuengx							Bei	Kei		Senx						Nauh		Cam	Gaeuq				So		Huan	Haiz		Geq								Go		Saengq	Tan			Dwen	Goemz	Haeb	Haen			Saej	Haenh	Taku	Sha	Hot					Van			Haen	Naj	Gangj	Naj			Get	Ku	Dore	Myaiz			Syu		Naeuz	Shiyu							Dang	Zui	To												Sen							Nanq		Cienz	Sa								Naeuz					Kyo	Van			Hop	Nyaij											Duenq	Gyonj																						Mboen					Lad			Han											Kei																		Jaku			Do			Byangj	Son													Dwen";
    case 723:
      return "										Haengj		Do								Gen												Senj						Shi										Getsu																	Geux																											Cang		Moku	Gyaeng	Shoku		Gvaengz			Shoku	Koku	Gvaengx				Suen								Gyaeng		Suen						Za	Sho	Deih			Kin		Zung			Tochi				Vaih				Euq	Ko							En				Kin		U	Dou	Daenz	Duh				Ya	Cuk	En														Haem				Fai										Ashida		Hwnj							Doemq				Jo							Dez	To				Naengh		En							Dieg				Oi																Genz		Wai						Bin";
    case 724:
      return "Dan	Lawz																				Ho	Shu			Ju				Hatsu	Daeuq		Masa		Ka	Ka		Ka	Hen					E	Ken					Ki		Shuku	Ta		Raeuh		Hi	Lad	Ywnz	Ywnz			Raq	Haemh	Gyoengq	Haemh		Ka	Hung	I	Mbwn	Mbwn			Kan				Gyaeuj	Kan	Gyax	Kei	Kan		Dek	Kei	Ichi		So	Mbwn		Raeuj			Gyo	Ten				Fun					An			Meh				Fu	Moiz	Sauj				Ito	Nix	Sau		Gvan			Dai	Maen	Oyama	I														Iu							Ki			Ki	Maenh			Meh			Kan			Ken												Ri									Nding			Lwg		Nyez	Mi	So	Gyax	Gyaeng	Lan	Sai	Son	Gwiz	Mbauq		Cih	Gaku		Cing	Iq		Lunz	Nyez	Lan	Mbwk	Eng	Sai			Shuku	Kaku	Coh	Gaku	Gaku	Saw								Fa		Goemq					Ranz	Kai	Gvangq	Mwh				Gai				Shin								Bitsu	Fa	Sasa	Ko	Mei";
    case 725:
      return "Mitsu			Ki	Nei	Hekutaru		Naez					Bo										Senchiaru									Ho													Sho					Joku	Imiki			Fu	Shu		Tai	Tai					Tai	Son						Nip	Suo	Ten	Dangh	Yo	Iq	Rei	Iq	An			Shu		Shu		Ndi	Bwnh			Bi	Hei				Sei								Ka								Zoku	Geq																Chun	Chun	I	Ciem		De	Akutsu								So						Ho											Ngaux		Dat																Da		Kyo																	Ndongj	To				To									Gamj		Bi	Chi		Gan									Yamachi	Geuq		Ke						Hamq			Gi			Gan														Kei	Do		Do	Retsu";
    case 726:
      return "Shu						Fu		Geix	Yamagatsu	Ki			I	Hong				Toshi	Fu							Yoshi	Feiz			Tsumu	Fad			Rae	I				Tai	Daeh	Cho						Baengz					Zukin					Mboek					Nen	Hawq		Byaenz	Bi	Rengx	Baez	Bei	Bei						Ki						Nobu					Tei																Sho								Hiro							Yo				Seki	Kire								Sei														Taka	En	En					Kei	Rongh		Iemq				Ni		Shoku				Kyu	Kwok		I					Nwnj							Ko	Tae	Bi		Kyo	Kyo			Kyo				Ut	Hatsu		Aek		Bi		Rungq						U	Nae															Ei			Yaku							Rai		Kei";
    case 727:
      return "								Tetsu			Vi		So	Bo		Go	Kyo											Mbouq	Ndiep				Ko		Kyu	Kyu	En	Kyo	Shitsu		Haenh					Kyo	Raemx				In	Kyo	In	Kichi																				Lingz	Lingz		Nai					Siengj						Coj		Gyaez			Shi	Gvaix		Shitsu	Ko	Hi							Hoj		Haenh		Yienq	Haenh																			Sho			Oi	Zo						Nikumu	Ken			Tai	Ryo								En						Kan							Kyo																Son				Kan						Fup					Ren												Maij												Ngvanh	Suzuroni	Yoku																	San		Mo	Sen				Shu						Gi		Gi";
    case 728:
      return "	Rug	Kyoku			Rei			Fangz	Ko	Beiz	Vad		Sai		Lax				Baen	Gaem	Hawj	Coux	Yaeuj	To	Pok					Yaeuj		He	Sho	Hoenx	Sai	Vad	Yaeuj						Gaeb					Coux		Humz	Gvaek	Loengh				Coux		Gen	Bek	Byaz	Gang	Duq	Viq				Ronq		Gyongz	Nyaengq	Na	Sho		Gyok				Goenh							Gaenx			Boenq	Gen	Fad		Coemj				Datsu	Duk			Saeg	Laengz	Sing			Saenq		Duk		Hot	Saenz		Gej		Hah	Gaex	Venj	Dok	Sauq		Sho	Rap		Riuj	Rom					Mbiq				Kyo	Ryo	Genz			Fwngz	Buenz						Gaep	Hawj							Daek				Rap	Bu							Doek		To				Raku				Nyo								Saengq	Ndaem		Donj						Ndaem			Gvaek	Ran			Din													Shi						San								Yu	Shu				Jik		Setsu			Shuku			Saku	Satsu	Satsu			Choku	Hatsu			Tan	San	Hatsu	Hi			Tan";
    case 729:
      return "Kai	Yaku	Yaku	Ka							Bunsho	Su			Lei	Gen				Rei			Masa	Masa	Sai	Bin		Hen				Seki	Kin					Tei		Ho		Ko	Hakata	Cuengq			Shi		Jyu		Fiengh			Dieg								Kyo									Sen		Hamq	Langh	Geh			Shi	Shi	Dax					Ngoenz			Bo					Sho			In		Haet					Ko	Sho		Laep	Romh	I	Kan	Katsu	Dak					Caeux					Sho		Gyang			Hwngq	Ij		Kyo		Ngoenz	Seki	Rongh		Ndat						So		Cog			Kiyoi						Ban		Shin	Ko		Rengx	Rengx	Senq											Kyo														Ndeiq							Rengx				Ho	Caeux	Rengx				Hwngq			Tong				Haemh		Ketsu	Lwenz	Romh			Raeuj	Henz			Heih					Ei											Laep						Ndeiq			Setsu							Haex	Ndau	Ndau	Do";
    case 730:
      return "Cin					Ndeiq										Henj								Keizu	Ei	Guiz		Goemz			Ban	Cingq		Saw				Nyaeuq	Daengz	Goengq			Cij	Daengz			Saej		Mata		Ai	Ij			Gen		Hoz				Mbaq	Sayaka									Hangx						Muengx								Muengh	Ngeiz				Raq	Ngai	Haan			Congz	Shin	Yo	Ko		Gyauh		Ta	Gaz		Muh		Ndouj			Gaj		Naeuh	Fat	Bo	Ju	Zusa									Faex	Maex			Shitsu	Rei					Zaa	Goenq			Saeu	Ndoj	Sak	Gaj	Gvaz					Maenj		Gechi	Gechi	Ju		Gyu		Kei			Gieg			Gaeu			Nganx	Nim	Nganx	Ngingh					Cak		Wan						Gechi	Kote											Gwai					Dok	Ndoek	Nyoeg	Shitsu				Sang		Hae				Gechi			Ten			So	Dik	Do		Kitsu	So	Ki	Kashinoki				Goux	Raek							Sai	Han							Yuzuriha					Kyoku	Gaq	Aioi					Ka";
    case 731:
      return "			Ndoek	Rap			Rungz									Kai	Han	Reki										Shishinokushi												Kajinoki							Kun				Ken							Sugomori									Shijikuhe					Aa		I	Ketsu			Kan	Ueru		Unq		Sa	Kyo	Kan					Swix						Youq									Shu	Mbieng																			En	Shi		Shi	En				Ran			Botsu									Son					Hi						Laemz							Kan								Dan		Tan			Kaku	In		Ki		Ki	Kei				Ten	Keki	Keki											Mai	Gyax		Beix		Bi				Goenq	Haemq	Ndoq	Bwn	Bwn	Nyungq		Fwed		Rieng					Byoem				Rieng														Bo		Nyah		Uke	Hoiq		Mboq	Mieng					Vax	Dah";
    case 732:
      return "	Kai		Dah	Mouh			Nyouh		Sei	In	San	Dumz		Dong	Sen	Shu		Cat			Haux	Dei									Daej				Tai		Tan	Sen				Raq						Rei	Shu								Shin				Raemx				Shitsu	Uchiwatasu		Hon			Fax	Naiz		Hung				Ban												Ei							Hitsu								Man	Ban				Ire		Shun	So					Ndaek						Sa	Ban						Itsu	Ko							Tetsu		Sai				Kan	Shin												Ban		Ren		Raq					Seki				Zuk																			Shun			Shun	Raeuz											Do		Oyogu				Ban							Haku	In														Ryo						Sei											Sai					Satsu";
    case 733:
      return "Daemj		Maet					Yiemz	Hoenz	Vun	Mou	Ndit		Byouz			Cik	En	Hauj				Ka	Boh		Ten	O												Byoq	Daeuh				Sho			Fouz			Moet		Gyaenq	Ndat	Coemh		Seki			Kyoku			Hi	Mu	Bu	Feiz	Feiz			Ken			Sho	Ken					Dex	Dak							Saeuq							Kun				Sho	Sen			Byoq																Netsu							Cuz	Sho	Cawj					Yo						Cit		Ho								Raku	Feiz				Sho										So									Sho														Reki		Boh	Aen	Yi	Ge																		Faenz	Heuj	Geuq	Ngah						Shu				Vaiz							Ken													Fu	Moz									Ton				Daeu";
    case 734:
      return "			Raeuq			Noh				Mu			Gei			Nag	Nyaen	Bo	Linh					Mou		Henj							Ryo	Nag	Ken	Duk							Haeu			Ken			Ma	Mou			Kyu	Taku						Ei	Machigimi																								Bo	Tomo	Ryu					Lo							Taku															Shuku																				Ai																					Ga	Ga							Sai		Mika		Kurabone			Kan	Kan			Sho				Nuengx	Gei	Ndip				Yo		Jo	Doeng			Hitsu	Shoku										Fuku	Kai		Riyu	Raeuz	Rib		Ta				Lai			Sako			Mbauq	Rap				Sai				Boek	Nax	Hyoku			Kyo	Kyo				Denz	Sai	Kyo	Jo				Kyo	Jo			Jo		Mato	Fan				Jo";
    case 735:
      return "		Ka	Gi		Gi	Ngvangh	Vax	Bag		Humz	Jichi			Ro			Bingh					Nikimi					Doek						Mwnh															Reki					Wazurai			Yo					Hatsu	Ki			To	Hatsu				Mamaimo	Bo					Mbaw					Hau	Shin		Hoi									Mak								Gyong		Beix	Bi		Su				Biz		Gyong			Naeng					To				On						Ko				Kan				Ro	Kan				Ko	Ro								Baed	Liuq	Da		Jun			Shi							Ko	Gam	Yoj	Kan	Kei			Gaeuj	Ninz			Kei			Miz						Lah				Soj						Cim					Hwnz	Yawj	Yoj			Leiq	Liengq			Cim	Jo				Ojiru					Mei	Liengq			Ngonz	Yoj				Yokome		Liengq			Kyaku						Mwt					Mu	Mu	Itsu						Dinj";
    case 736:
      return "	Shin				Duenh					Rox	Daz		Vamh									Heng			Daenz				Rin	Siuq	Sok		Rin	Cauh		Lou					Guenq	Gun		Vai	Boenz					Geng		Genq		Ken		Ken			Naek					Hauz												Ko						Moh																	Rei					Sei						Tatari	Ku				Ka	Yuki																						Fuku					Kyo					Hyu						Sho		Nyo		To				Ne		Baiz			Sei						Ngaeuz		Toshi										Faen	Hatsu							Sho	Ndij		Ta										Sho								Ju					Kei							Kei	So													Kuwa		Ndaem									Kan";
    case 737:
      return "Caenz	So	Wa	Hoengq												Byouq	Daenj		Zan										Sui							Kame				Fu	Loeb			Lix	Ywg		Jun	Yo		Mei		Laep	Sho							Laep			Moq	To				Sashi					Dak	Sasa		Duk		Ndij	Ndoeng	Tei			Utsubo		Haku	San		Mbaet						Rug	Sen			Ho		Demx	Saz						Gyaep					Han	Ko						Chu		Ndoengj	Faenx								Cok	Riu	Yagura				Raeng								Laan								Mboek									Deq								Tan	Deq	San									Saemq	Ren									Kiku			Ebira		Kushi	Caeuz	Gaeuj	Samj			Caeuz	Faengx		Ko		Gaeuj				Cid	Gyaj	San	Aa			Ngaiz	Ngaiz	Ngvih		Bingj			Sui	Cuk	Ngaiz	Bing	Gok	Rin	Ringz	Raemz		Boemz	Caeuz	Su		Faengx	Rei	Diengz		Ciz		Daeq		Ngaiz	Ceh";
    case 738:
      return "	San			Mon	Take	Yu			Nyungq		To						Ketsu			Shi	Shiyo						Ketsu								Ko		Faiq	Ryo											Shaku				Ki		Fu																	Ken															Ro								Ri	Kau	Lou	Dit	Zok	Gwaa	Riet		Loeng	Gwaa		Zau	Jeoi	Ceoi		Seoi	Coi	Sui	Ketsu		Gang		Fu			Kan			Mbinq	Zen					Ku	Bonno		Bin		Kan						Mo						Be	Be	Sho		I		Utsu										Bi			Jo						Gi			Maeq							Rui	Myo	Rui	Ju		Fun					Ryu	Ryu	Ko									Ko								Hon										Geq	Ki						Ndai					Rauq			Rauq	Nyi		Ta	Nwj								Nuk		Sho		Sei";
    case 739:
      return "	Itsu			Shuku		Shuku	Niku	Gwnz		Yeq	Sha					Ken		Shitsu		Ko	Momo	Shi			Mbaq	Kyo	No	Momo													Ra								Gumq												Gumq	Naeuh						Zo					Ushinoatsumono			Shin	Kan	Zo		So		So									Ben					Chi		Daengz	Shin		Kan			Sho			Yo	Ai	Yo					Kin		Van		Linx		Sij	Sen				Van				Bu				Koeru	Han	Ruz				Haku		Takashi						Takarabune				Ro				Shoku	Shoku	Lieng					Kyo				Ei	Ei		Byaek						Kane	Bo				Lup	Hako		Bo		Kin	Kin	Ko			Hoku	Hako	Soba				Kin		Gaeuj	Ko				O						En		Go	Jo		Hoku								Ko					Sho				Muro		Gyu		Heq	Nyod						Seiz								Dug	Waku	Waku			Yana";
    case 740:
      return "			Mo			Biek						Haz	Haz						Sho							Faan										Hoj	Nazuna	Aona		Jing						Ko											Jo		So	Zo	Haemz								Gut					Kei																Do	Ro	Kun	Shi		Ndiq	Heki																						Sho										Haemz							Rum								Doek	Niraki				Tsuta			Kaku		Shiki	Ieararagi	Gei					Haz								Sanakazura			Zetsu														Sen						Warabi					Haemz		Nyaengq	Ngaih	Kaku	Fwz		Warabi			Mbaw								So	Ko	Gyaku	Ko	Ken		Ko		Yu		Kyo	Kyo		Ko		Gu	Ko	Guk									Ki	Ki	Maet	Maenz		So				Gyan			Chu	Se";
    case 741:
      return "	Ko	Zit			Fu	Rwed	So		Mitsu	Loeng		Mbwx				Bing	Nduen		Mod	Yamabiko			Ratsu	Biux		Vauz	Doq		Nishi			Reiz				Goep		Doq									Lanh	Sei									Daek					Nengz	Caengh			Awabi	Hitonoko					Tamamushi		Gyaeq					Daek			Sen		Moku							To	Ketsu	Jiku			Lwed	Rei							Nda	Soe	Chu	Sui	Vaq				Vaq	Sui	Moeg	Sij	Nda						Ei		Sij	Vaj			Haiz	Loeng	Daenj	Gin									Haiz	Nda		Vaj						Cah					Sho				Liengj		Sho					Ho		Bangj			Moeg	Congz				Zen		Kit			Daenj							To			Hinagata	Sen	Sen	Sen	Tan	Sen		Hwet												Haen		Kaku			Kaku		Ran		Kan		Kaku			Yo	Yo			Gaeu					Kai			Shiki			Kai									Ko		Ndaq";
    case 742:
      return "	Denshin	Setsu						Kai						Ren	Gyoz	Sen									Ken								Ei			Yo		To				Ki			Ken											Byu	Ken				Hen	Gen							Komagoto	Ron			Vaq	Jan	Duk								Faek				Jo	Fu			Tan		Sho	Sho	Go	Sho			Ton							Bo				Gai				Ki	Fouq											Shin	Don		In		Don	Gen	Rai	Soku	Gen	Nyok			San	San					Sho		Rouh		Ken	Fu			Gonq	Ken		Cawx							Cawx									Hai						Yied			Hwnq	Chin	Gyaeuj	Ko					Banh				Yet	Giuj	Ha		Cok	Ndwn			Ha		Fwngz	Goengz					Ga	Byaij	Douh	Lanx	Yin		Tek	Yamq	Sho		Ruenz			Vaiq	Caemq	Gvaij	Kyo							Roen	Hashiru	Kei					Raih								Din		Ndoet				Riengz	Yaemh";
    case 743:
      return "Sho			Ma	Deq			Hoq		Shu					Vaij				So	Gyang		Sho		Hoq										Ngaux				Laemx							Agaki			Aemq			Gumq		Ndang	Ninz	Dou			Hoemj	Gengz					Ki	Ku	Dex		Ce	Loek			Geki											Daeu		Baenq									Kyo												Reki			Reki								Gu	Ji		Fan	Ceon	Waan	Got	Hi		Manh	Shin			Cam	Kitsu			En	Zo		Cueng	Gyo										Deuz					Ji	Ni	Jo																		Bin	Ken										Ku				Daemq		Hen	Hen	Laeg	Sen			Kan	Boenq						Bongh						Sho							Hen			Hen			Ren	Ji	Maez				Hen				Gyae											Tai											Ciuz	To";
    case 744:
      return "																	Ri				Yu	Shu	Ndiu			Shu				Coeng				Meiq				Soemj			Meiq				Koku						Cam			Kan		Sakazuki			Meiq									Ro				Ke	Shitarushi			Jo			Hi								Rai		Raez		Dag						Naek			Yo			Tai	Gyo		Dai							Shaku	Cauq													Kana									So	Kanabi												Sei				Sei	Ko		Tetsu			Mimigane					Kanakuso				Tetsu				Gyo																		Tetsu			Saku												Sa		Shaku	Jo	Shu						Sho		Kaku																									Gong	Wang	Sin	Zyut	Leoi	Ju		Hatsu";
    case 745:
      return "							Bon								Gyaeng										Gaek	En														Tatsu	Hiraki		Mun	Cyu	Diu	Mbwn	Rui	Noix		Bei	Gyaeng	Aj	Vangj	Hoengq	Hoengh	Laep					Raeb						Ko									Arashi			In				Ryu							On																										Tai	I	Kan	Bun		Kan	Seki				Ku	Kan	Zatsu		Yosete		U	Mbwn	U	Fwn	Nae	Fej					Liengj						Fwj	Raiz		Mbwn	Hun						Byaj	Ei			Sho													Byaj	Roix			Raez				Reki												Heu				Sen	Ing	Naj	Tan		Shoku	Naj						Kaku					Gyong	Haiz		Haiz			Kote	Saya															I	I	I		To		Coeng	Wei						Ryu";
    case 746:
      return "Utau							Ko	I																														Ayatsuru							Rumz							Fung	Lau	Fei	Ro	Ngah					Yo				Kan					Gyan											Ko										Bat	Hoi	Aai	Ji		Gyaeuj		Gyaeuj				Kei				Fwngq																		Do						An				Yaeuh	To	Gyo	Maj				Ki															Rai				San	Mong	Haai	Zung	Cou	Deon	Kan						Kai				Ndok			Ndok		Oet					Sung	Kyo	Sang						Ning		Ta			Kazura				Ryo			Kamisoru	Kazura							Cho	Shaku	Utsu	Reki						Kai	Fangz												Go	Go	Go	Go	Kamatsuka		Ro	Funako	Sushi	Ko				Ken	Katsuo	Bya	Masunosuke	Sake	Isebi";
    case 747:
      return "Ayu	Iwashi	Wataka				Fugu			Fugu			Vanx	Coeg	Dojo	Iwashi					Bozugori			Ro	Kujira			Jyu	Ngai	Gwai	Caan	Huo	Luk	Hua	Jung	Haam	Zam	Gae			A				Ho	Roeg			Ho	Cho	Ta			Lawz		Hangh		Mei			To															Shi							Laej						Uguisu					Kiku		Ho	Ku	Gaai	Jiu		Mie	Gong	Chen		Aan		Soeng			En			Gang	Roku			Ho		Rei	Rei		Rei								Hishio			Ben	Ryo	Ho	Mau									Sho	Sho			Fuenx		Ndaep			Ndaem	Baex	Hak					Chi						Ko						Nou				Hi	Hi	Hi	Hi	Hi	Hi			Ndaeng	Tai	Sei	Sei	Sei	Shi	Shin					Cho	Ko	Gin		Saku	Ken			Gaku	Ku		Aku									Okuba		Kaa		Ki	Ki	Ki	Ki	Ki	Kai																				Ngai	Ou		Yi	Lik	Fung		Ging";
    case 748:
      return "				Cung					Pang											Wai																																				Ji			Xin		Yue	Laan	Qie		Zeon					Man	Lin			Lo						Wan		Niu		Mun						Lo		Ji				Zeon			Teoi						Wan						Daan						Qiao						Jing						Jin	Fung	Lok	Dung			Gwok								Khoi					Ai							Hei		Jiu		Seoi															Soeng		Bi		Hing				Zin		Joeng											Ji		Gwai	Wo		Tran							Hin							Yan	Syu			Gan		Jap				Fung	Fung	Zhu	Lian				Hiu								Fan				Cung	Jip		Jing				Bo";
    case 749:
      return "		Ji			Leon	Fung	Fung				Fat					Yi	Gaap	Hei	Kiu	Jip			Jiu	Daat		Katai						Lai					Hoi			Cung																				Jin			Tin						Hei		Nhon										Nou															Ji	He													Diao			Loi														Caa		Guan	Fung	Tou																	Wei					Laam				E	Fei						Wan								Jian							I						Laan								Vien				Dung		Lok	Gei		Bo			Cyu									Gei	Taai		Kashidori	Zang	Gwang		Tou			Kei			Jyun		Juk			Li	Na												Gei	Chai		Jyun			Lau		Syu";
    case 750:
      return "Lin			Pik	Seot		Hing		Gwan	Gung	Cim		Sik			Cyun	Fong				Shun	Fuk		Hin			Jan	Hoi	Hoi	Jing	Qi	Soeng	Jin		Hoi	Zan	Ao	Kit	Fu								Kit									Wan		Gu			Biu	Fei			Pan		Fei			Mo	Ji			Ao		Zau	Wan											Ling	Ang	Hok			Yan	Daap";
    case 760:
      return "Li	Wan	Yi	Sen	Ni	Wu	Tui	Bing	Za	Bei	Seng	Xiang	Jun	Suo	Mian	Tu	Huang	Ju	Kon	Din	Nei	Zai	Satsu	Jung	Yuan	Bing	Dong	Kuang	Qing	Qian	Ren	Pi	Ke	Luo	Ge	Chan	Ji	Jung	Mian	Qin	Shao	Bao	Cong	Bei	Hui	Bei	Bo	Ji	Ji	Qing	Qing	Qing	Shi	Hui	Ji	Sou	Ton	Jiao	Chi	Jiu	Xian	Xi	Cheng	Zhou	Ngok	Mie	Tang	Qi	Xian	Shan	Shan	Hui	Chi	Zha	Yao	Tu	Tan	Tu	Hao	Pen	Qie	Zhuang	Cheng	Zhi	Tu	Xing	Ji	Bao	Di	Kai	Mai	Hu	Feng	Duo	Meng	She	Chi		Ji	Yu	Tui	Ping	Fu	Sao	Cha	Rao	Lan	Lan	U	Yuan	Zhi	Ning	Bao	Lao	Shou	Jiang	Dang	Wang	Yao	Tu	Cit	Xiu	Qian	Wu	Yan	Setsu	Dian	Zi	Chan	Xun	Chao	Yi	Xun	Shui	Mao	Fen	Man	Nan	Yi	Bing	Bi	Shu	Lang	Shuo	Gong	Yo	Yo	Yu	Tou	Tao	Yi	Kotsu	I	Xing	Diao	Shan	Dong	Ren	Zhi	Kuang	Yuan	Huang	Jue	Hui	Dong	Dun	Ci	Huang	Shen	Huang	Lou	Zeng	Xian	Fen	Can	Meng	Cheng	Lan	Cheng	Jia	Ku	Bao	Ba	Juan		Wan	Pin	She	Sao	Ji	Sau	Zeon	Yan	Yan	Dou	Mo	Jiang	Hui	Jiao	Hei	Min	Jing		Ji	Shu	Zeon	Wei	Shu	Wen	Chang	Mou	Mian	Zui	Pu	Na	Tan	Lang	Wang	Zong	Qi	Biao	Shi	Hua	Guai	Gai	Sang	Mei	San	Ao	Ben	Zi	He	Zha	Yao	Gai	She	Ko	Zhi	Yi	Ci	Yu	Xu	Kun	Sui	Wen	Sha	Qiao	Den	Bai	Juk	Fan	Ki	Yan	Ben	Qian	Wu";
    case 761:
      return "Pai	Hai	Liu	Hao	Jin	Nie	Ben	Baan	Gang	Yan	Long	Zi	Dian	Sha	Yan	Chao	Ki		Fen	Yue	Jing	Ying	Shu	Qian	Zai	Zhuan	Tan	Ken	Duan	Sai	Cong	Ko	Cuan	Jue	Zha	Ga	Xi	Bei	Yan	En	Ta	Wang	Gong	Yue	Ping	Ping	Dai	Yu	Tian	Suo	Qiong	Xing	Rui	Shin	Zai	Hei	Yi	Ping	Yu	I	Faa	U	Yan	Ji	Zhi	Ku	Gu	Shi	To	Zhen	Zhen	Zhen	Juan	Jie	Chen	Ye	Shi	Teki	Xing	Lu	Tian	Hui	Jiu	Zu	Chi	Liu	Fu	Shu	Jian	Gu	Ji	Wen	Shaku	Tian	Tian	Ping	Ping	Saku	Zhuan	Zhu	Wei	Chao	Bei	Xi	Jiang	San	Ji	Kyu	Beng	Yao	Zi	Zong	Sao	Luo	Xing	Hei	Mei	En	Chao	Ken	Yang	Ao	Zhe	Sen		Ping	Ratsu	Cong	Ken	Ren	Yu	Cui	Cong	Pi	Ying	Ryu		Xuan	Sho	Yu	Xi	Ci	Beng	Qi	Yu	Zhi	Lao	Hua	Fong	Ya	Ku	Detsu	Ruo	Chai	Rong	Jie	Wu	Mang	Di	Zhu	Ping	Ju	Jun	Cai	Kyoku	Suo	Kyu	So	Ping	Jin	Cuo	Bo	Rui	Sho	Cheng	Lu	Chao	Lu	Kui	Nue	Lu	Kui	Xi	Chi	Qian	Yuan	Ping	Yun	Sip	Zhu	Ci	Ji	Gui	Xiang	Ci	Zhun	Yi	Jian	Liu	Shui	Lu	Yan	Mao	Rei	Ku	Nin	Yuan	Cheng	Yu	Bian	Shi	Jian	Gun	Bi	Gan	Qi	Shu	Zhao	Ba	Jian	Pian	Gun	Ren	Shu	Tei	I	Qi	Ping	Zi	Kei	Chao	Bo	Xuan	Hua	Bing	Qiang	Zan		Kai	Peng	Shai	Sho	Wei	Qian	Xi	Yun	Pang	Ping	Lu	Chan	Bi	Sei	Kun	Yan	E	E";
    case 762:
      return "Ping	Xue	Ji	Ban	E	Yun	Bao	Tui	Gan	Qiong	Zhen	Ji	Jian	Jiu	Ji	Pi	Yu	Ma	Sha		Ken	Ma	Qian	Zhi	Min	Zhi	Mi	Fen	Bi	Pian";
    case 768:
      return "					Naengh							Ndeu	Yak		Gwnz		Sai								Benj			Mbit		Rwix			Qian	Jian		Vangj				Roix					Li		Rangj																	Ranz							Gou	Saw			Mbin									Cwngq						Ngox	Byanz	Luan			Myox	Ndongq			Gungx				Sung	Mbaw		Sueng	Da		Gat						Cangh	Haw			Iet	Dong	Ciuh					Fu			Laeuz		Caemh				Beix				Haan	Gij		Haan	Juk	Faen	Liengj		Gvai				Dai					Teoi		Bingh			De			Daeuj	Yiet	Leoi		Coi	Sou	Baih			Ci					Gyo								Git						Soemz	Sug		Lw	Raix		Zaan						Mig				Rongh	Raeuz	Vid	Nyez	Dangq	Myak				Haeuj	Ciq	Haeuj	Yeb			Baz		Biek		Laz		Yiuh							Rim		Xue				Doemq			Cix		Cong	Rawz	Yaep	Baez	Bi	Heiz	Saenz	Liengz	Duk";
    case 769:
      return "Laix	Shen	Fai	Rei	Senx	Sak	Ndangj	Nit	Sied	Cung	Caep	Dongj	Lak	Ndat	Seuq	Ruj	Rumz	Mboep		Dongq		Conh	Nduk	Nok		Bag	Deu	Nyaeg			Tyun	Buq	Ronq		Mbaen	Mbaek	Bauh	Byaenz	Raed	Ven			Cax	Yangj	Dat	Rei	Geuz			Baen	Cauj	Danj	Iem	Gaj	Camz	Gvet	Cab	Faeg	Daeq	Liemz	Dan	Donj		Mid	Raemj	Gvej	Doz			Lek	Ndaemq	Dik				Baeg	Maenh		Rengz	Loz			Haenq		Leoi		Lik	Lawz	Coengh	Ngoeg				Sieg	Fag	Gyongx	Duk			Gaek		Duk	Daan	Sieng																	Cangz		Gvanq	Xia	Geh			Byongh		Moj																			Viz	Wei				Tai	Laam	Daenz					Naenx											Gaiq				Gix							Mbiengj			Rouh		Haiz		Gouh	Yaep		Haai	Cam			Foek		Coemq	Wx			Cienz			Congh	Dung	Bwh	Dwenx					Gaap	Hong	Gaeu	Ji		Boq	Fok	Heiq		Naeuz		Gaa	He		Hei		Maih	Doenx	Gvaix					Lom		Gaep	Ndoet		Hauh	Taam	Doq	Lup	Soq		Duengh	Fangz	Fieg			Saam	Sip";
    case 770:
      return "	Deuq		Ceij	Gip		Hei	Soeng		Boih	Dim	Doeg		Can						Laam					Caw	Hangz	Baenh	Riengz	Coh		Euq	Gyonj					Byop	Dot	Haeb	Ruz	Fwngq	Daen	Rueg				Aak	Zaan	Ndonj		Det				Bok					Beu		Ged				Yan	Dek		Zaan	Gang		Haengj	Ruj	Swenj	Boemh		Rongx	Gaemz							Hoengx				Wei	Gong	Jin	Dienh	Gumz	Hauz		Mbaek		Doengh	Lih	Jik	Beiz	Gaap				Kok	Jip					Singz		Gaan			Gong		Hoemj			Mboeng			Boengz	Hok					Dit			Zhan	Demh		Coeng						Youq			Haam										Kui				Man		Jim	Cim	Doem		Vunq			Henz					Genq						Iu	Ndoi	Laeb				Sok															Byuk		Byak	Gyong					Gaeuq	Gyoengq	Raq	Gaeuq		Soeng	Raeuh	Loq	Maed		Hung							Fuemx	Nax				Nip				Laj	Foeg	Goek	Sing		Biengz	Saeg	Byak		Daep					Dong	Zyun				Jim	Bi	Bawx";
    case 771:
      return "Jing		Zing	Gij	Dah	Baj	Cim	Zaak	Ciz	Yun		Maen			Dai		Sauj	Bongq		Nauq	Liuz	Geq		Ndei		Laan			Sai	Dog		Fwj			Nou		Laenj	Nding	Aa	Lwg	Sau		Gwiz	Ndai	Mbauq		Lan	Laeq	Hag		Rauq				Byouq	Wai					Bi					Ngaeuz									Yo						Han	Sat									Nda	Hak								Baed	Loengz	Sei						Iq	Oiq			Couh			Roet		Yaet	Cik	Hangx	Uk			Nda		Dot				Soem			Roq	Byai	Rieng		Sienq		Goengq		Bumz	Sung		Lung	Dung	Lu	Jip	Baq	Ngeuh	Jiu	Bya	Zak					Kuai			Naau		Ngaam	Rungh	Wei									Ngok												Gaku		Jin	Gamj						Can	Cyun				Mbaeu		Yied		Cauh	Hong	Gueg	Swix	Saix	Ceng			Dau		Wu		Zin					Sai		Lou	Faiq		Laan	Suj	Baengz	Nyan	Daengh		Gyai		Rawz	Bingx		Gyo	Hop	Bywngj	Hawq					Ma			Gvangq	Kui	Maz				Bo	Daai	Ei		Nden";
    case 772:
      return "				Mbaenq	Byom		Cangq			Ceg	Hoiz										Fij	Nya			Ut		Giengz					Yienz	Goz	Guiz	Ra			Ngaeuz	Raeb				Raeuz		Beg														Geih			Kong			Tyun		Hwt	Leon	Soengx								Lingz			Lanh				Zap	Jim	Niemh			Lau	Caeuz		Cingz			Gung		Genz				Haan	Nyaengq	Caam	Ngvanh	Soengx	Sing	Luo	Zi		Vak					Numq		Dai	Singj		Ai	Senz	Vuet				Nyap	Tong					Liuh	Seg	Mun					Nyengh					Cieg		Cit	Co			Miao			Mwenx	Gyax		Mbok		Lieb		Huk																				Fungh		Fuengz	Caet		Byaet	Deu	Riuj	Samj	Vanq	Daem			Mbiq	Vaij	Yaeuj	Caang		Wu	Caeq	Hoq		Banz	Biengj		Gaemh	Goj	Gvaz	Saej	Gab	Ndenq		Sim	Douh	Baet	Ep		Jip	Sonx	Veg	Zit	Sai		Cap	Hoenx				Hawj	Mo	Vat	Syun			Lued		Lai		Moeb	Cug	Gap	Hang	Bek				Loih	Ruan	Gaex			Kwai	Saam	Sik		Sij";
    case 773:
      return "Va			Faq		Gik		Dai	Ndai		Mbe	Gwai	Nyoeg	Ciemz	Dek		Viq	Gen		Boed	Led		Vad	Caem		Buen						Yaeb	Gang		Baenz	Dam		Dub			Tan					Gaenx	Sai		Lox	Ndau	Hin	Duet		Honz	Yu		Raek	Daek	Duk			Genz	Dawz	Lax		Cam				Keoi			Giu					Cuengq			Xie										Sinq		Son										Moq					Langh		Kui		Siuj				Ceij	Haet	Ndit		Gaeh		Rengx							Caeux	Haed	Daeng			Senq			Jim		Ciengq		Vangj			Lwenz		Genq	Ngoenz	Saed	Dak	Mboengq					Raeuj				Ndeiq	Langh	Nan							Buemx		Lei	Dig			Cog		Seiz				Ndau			Bonz	Ngamq	Suemj	Hwngq			Sawz		Coenz	Muengh			Saw	Raengh		Ndwen	Hui	Daengz	Byouh		Ndaek	Hamq								Fong			Leon	Ngingh	Kan	Chou	Xie	Sik	Jim		Dangq			Caan	Wan	Za		Bien	Zeon		Si	Myaz	Vet		Cin			Hanz		Dad		Vangh	Vengh	Sam				Suk	Fan";
    case 774:
      return "Daai	Swiz			Daeuq				Guk	Vei					Sak	Romj	Fwnz	Liu		King	Siengz				Lumx	Nduk			Rag	Bam	Cat		Jim			Min	Yuih		Haex	Sangq	Yiu	Xiao	Fiengz		Nim							Laai			Sou		Sau		Dongh	Ruh	Dug					Mak	Angq	Ndaek								Wu			Lim			Siu				Lou					Daengx																												Hanz		Cieng			Lib	Sanj																Dag	Bwn	Bit	Ndoq	Nyungq		Goen		Ning						Haz						Coeng			Mumh			Leoi				Ran		Byoem					Ye	Bwnh											Fwt			Gaed							Conj	Cangq	Mboen	Maa	Conh		Nyouh	Fou	Cung			Dung						Sij	Mok		Sim		Naeuh				Bat	Caix	Zap	Zit	Ji	Wai			Sim	Lyun				Lou				Lim			Haan				Lumz	Yaem	Ling	Doengj	Ding	Raiz";
    case 775:
      return "	Gonh					Dumh	Saex								Iep	Laam							Byumx					Can	Joeng			Haenq	Gyaengh	Ho						Zin	Eun						Laeg				Jing							Doek	Rad						Mbaeq				Jing				Raengx	Mug	Yin	Byouz	Fai			Cimq			Saw		Unq		Gaan	Cit				Iemq		Siu	Sin				Gveuh	Hin									Mboq		Yaiq		Ngauj										Cien		You	Chui		Cij			Baek	Iengj	Youz		Jik	Daeuh	Dung		Gep	Ndat	Zit		Duemh								Saz	Hangq								Gangq	Cug	Goen		Gin		Saeuq			Cit						Gyang	Hoi	Hoj	Bik		Fwi		Ngaeh	Zao				Fan		Gwg		Cienq	Mauh	Saenq									Dangj	Hoenz		Dex		Yik				Muenz	Caux				Jim					Raeg	Ceuj				Gyoq												Myab			Aeuq			Dumq		Mong		Remj";
    case 776:
      return "	Raih				Ruenz		Coj				Lungz	Fouh	Au													Fan	Zin	Bej	Faq	Bienh		Nyaq		Gaet	Heuj	Geuq						Ek	Gong	Oengj			Coh	Mej		Hang		Yao	Langh				Bei					Cenh			Roeg		Mui	Lou		Nyungz	Vaiz			Hiu	Hui			Loi	Wo	En	Mou	Nyaen		Caam						Hin	Lwngq	Beuq		Ban	Caeg	Doq		Ying							Kei	Ma	Duenh					Che					Lou						Nou		Sau							Suk																									Liengz			Ndiq		Mou	Mboenj	Aang		Lau		Nyued				Heu	Did	Lix																						Rib		Gax				Youx		Gvan						Diuh	Vet	Lau				Naz			Coemq								Cungh		Caeuz	Wei	Banh	Cang	Nengz	Nong		Zek		Gyak	Gaan					Sep		Teoi			Ndamj			Zik	Lyun		Cez";
    case 777:
      return "Dot								Rei	Biuj										Tang		Lik			Hau				Boeng		Niuj	Lot			Naeng						Taat	Reih		Du	Duk				Iemj					Cenj												Baex	Goemq		Cw	Enj			Gyu		Ham	Ndiu							Cung		Yiuq			Da				Fen			Ying	Mbaet	Maan		Saai	Keng					Gaan		Kwai			Meng	Ngonz		Gaeuj			Demq	Raeb	Gywq	Yawj		Ra	Tong	Soh														Cim												Kwai				Rox			Gud	Baa					Dinj					Lik		Wai					Lung			Zaak		Doiq		Aa	Dok	Haenz	Lou			Muh				Ngaam	To		Cuenq		Gaan	Rin	Boed		Jin	So	Zat	Caem				Qin	Sinz				Yungz	Laam			Cuiz	Zyu			Yaiq		Baenz		Req						Daengj							Gvi				Joeng											Kui			Nung";
    case 778:
      return "Luengq																						Tai						Kong					Gyaj		Huz		Semz	Zai					Byaz				Fiengz				Ci		Ndamq		Mik					Loq	Daep					Daengj		Cueng	Lung			Laep				Giq	Gyoeng		Tiu				Cang		Gaeb					Yauj					Daenj								Seoi			Rag			San	Tyun		Mbaet		Lou	Demx	Swx				Giu	Dong	Ak	Zaa		Gvaj			Dungh		Feiq	Coq	Saez			Faenx	Saz	Diemx	Zung	Duk			Rieng	Lou			Raep	Mbungz	Giuq	Gvingz		Soemq	Dawh	Nyinz	Songz			Gyumj	Mob	Sat			Bien	Jing			Ca					Tyun	Vaeng	Zoeng		Imq	Miz		Hoz	Mbaet	Raz		Tyun	Ciem	Ciu	Nem	Ringz	Sat		Raeh	Faengx		Ngaiz					Roj			Ceiz	Bin	Giengh	Mun	Mienz	Vaenj	Ceh			Doen	Naed	Raemz	Suen		Laan	Nyib	Muengx	Swj			Caeuz		Loengz	Heux	Nyat	Saeng	Saj		Haen	Naet	Cag	Soeng		Va		Doz				Riengh	Swnj	Ndaet	Re		Gyaeb			Luz			Suk		Zang	Fau";
    case 779:
      return "Gai	Wu	O	Lie		Fu	Keoi	Zyu	Jin	To		Wang	Gang	Haap	Bat	Zyu	Hiu	Zang	Ci	Goi	Bang		Sing	Kau	Fat	Chen	Wan	Zi	Man	Ken	Cim	Wik	Waak	Cap	Cai	Sik	Bik	Zung	Hu	Taam		Sau	Saam	Zi	Miu	Beng	Hin	Zung	Zung	Sok	Cyun	Jik	Zoi	Syun	Qi	Saan	Seoi	Zuan	Zeon	Wat	La	Gaai	Lian	Fuk	Jau	Cong	Bat		Gun	Gang												Fad			Gyun						Lou	Gyaeu						Fwed	Saap	Dou			Byonj			Dai	Geq	Ngaux						Gyaih		Myw						Lung	Nuk							Dau		Siu		Hoeng		Fu			Nou												Cing			Zo				Hiu				Bwt									Bouz			Sho	Lauz		Gyaenq		Sau	Mbwng	Gumq	Ai	Naemz	Noh	Hwet	Mbuemq				Ieng		Biz		Ndwen	Gemq					Dungx				Nai			Mun			Gangh			Gemj	Daw		Angj				Mamx	Mbaq						Loenq			Giemz												Gaenj	Jian			Fwq		Sing	Rum		Gaeux			Gah";
    case 780:
      return "	Liz		Van	Linx	Nyaenx	Tan	Riz				Soeng	Zhou			Daai		Lau	Banz				Laep	Ndaem		Naek	Lwenq	Laep				Nye	Zeoi		Tang		Jau				Leon						Kui		Famh	Deoi	Vad	Si	Hei	Saat	Za	Fu		Lau	Cit		Raq		Gwo	Warabi	Gung	Gwx	Rong	Yw		Ngaih		Gaan	Wing	Mang	Nyaengq		Naap	Fan			Zuk	Jian			Aengj	Biek	Vengj				Nyod	Zung		Xiang		Fan		Em		Nyangj			Fu			Leoi					Leoi	Bei	Cauj	Ci	Zik					Raiz							Laai	Baeg		Teoi	Tang					Ndaeuq			Aeuj	Fa	Manh	Rum	Giux		Yaed	Gyoij	Leoi		Mbinj		Hiu									Wu	Zaan					Guk	Coengz			Gaeuj	Moed	Mou	Ce		Hin	Zung	Leon		Wai	Zhan	Lung	Zaak	Hing		Ok	Ngai	Guo	Daat			Goep	Venz		Ji	Zim	Gvej	Can	Gengz	Getsu		Ngwz		Fei		Daek	Rwi	Myaiz	Ndangj		Sou			Naenz	Nengz		Ang	Nyaiq		Wai	Gyau	Doq		Mbongj	Raeu	Sap	Rad	Gyaeq	Non	Nyauh	Yae	Ngieg		Lwed	Meg								Rok	Lung	Buh	Daeh	Ngai			Deoi	Yan	Nung	Daat	Si	Hauq";
    case 781:
      return "Bengh		Sam			Denz		Dangz	Minj				Gvaix	Nep				Raen		Cin		Pit	Siu	Li	Gaan	Gwan	Leoi	Dou	Ceoi	Lo	Ceoi				Luk	Hok	Daai										Haenh	Jing					Ngon	Yanj			Fwen	Geng	Coengh	Maenj		Gangj					Laeux		Nanq				Daengq		Giu		Joeng	Zeon	Jau	Caau	Fan	Ngo	Sam	Seot	Jai		Ngai	Joeng	Zen	Dit	Ling	Gau	Tou	Wo	Wing		Naau	Hang	Shan	Hap	Ngaak	Ci	Haau	Zi	Zim	Bou	Kei	Dou	Bie	Cim	Ngo	Saa	Hang	Cam	Hei	Zhuo	Cuk	Ngai	Zeoi	Zyut	Daap	Zip	Jyun	Xu	Waak	Tou	Hai	Hok	Jyu	Ji	Cung	Zaap	Zaa	Hao	Ham	To	Ci	Taan	Ji	Ken	Nau	Gyun	Sap	Jiu		Lung	Bauz	Reb	Duk							Faek					Duh		Iengj						Mi		Cap		Lau			Lumj					Doj		Huq	Yiemz					Dienz	Si	Lingx			Dangq						Nyok										Saengq	Bengz	Dij	Gai	Gungz				Saw					Tik		Ji	Wun	Ci		Seoi	Cung	Fai	Zeon	Kui	Sing	Jat	Biu	Zhuan	Zong	Jyun				Benz		Li	Hiu	Kiu		Du";
    case 782:
      return "		Daz	Giuj			Byuj	Shuang	Dip		Gwai				Chan		Saai	Gwt			Lin	Bywngj	Nyangz		Gvaij	Yamq	Zai	Cai			Teoi		Ndoet		Diem	Gyaep		Dingz	Hoq			Deuz	Raek	Bongh	Daez	Dieb	Ndiengq			Daengh	Gvez				Gemh		Gvih					Beq	Ndaek	Loh	Do	Ngeng	Gingq	Ndoj		Baih	Aij	Reux			Ge		Loek	Baenq						Veq														Boek																Han	Wai	Chun	Faan	Ngai	Kwong	Yue	Tyun		Faan	Ba	Zaan	Paang	Xian	Fu	Dai	Keoi	Pou	Deoi	Gung	Guk	Hong	Wun	Wan	Sin	Ling	Zip	Lu	Gwo	Paai	Paang	Ham	Jyun	Cyun	Fuk	Zong	Duo	Zeon	Laam	Keng	Sik	Er	Lao	Faan	Cung	Zaan	Gik	Nie	Hat	Luo	Leon	Min			Nden	Huo	Hamz				Chen					Dong	Gungj			Gvax	Jiu	Dox	Duenz	Byaij	Gyae		Riengj			Gvaq			Coux			Dai				Gau									Roeb			Loeng		Nyeux	Dep				Biang	Biang			Heoi					Wai		Ciuz						Hiu					Bei					Haenx";
    case 783:
      return "					Jik	Ndo		Ndwq			Lao	Fiz			Lan		Mai			Get		Soemj						Caemq		Naemq		Fei		Fouj				Faz		Soem					Goq	Goenh					Giemq	Naq		Ciz	Laz		Doz		Hing	Mwt	Sieng				Gu						Diz	Hang	Loek	Rek		Siuq									Gei	Baat	Hua	Dai		Kong	Ciu	Au	Lik	Aak		Zi	Jat	Jin	Jan		Bing	Lung	Pei	Zaai	Kaa		Sang	Wo	Ngau	Fau	Zyu	Bun	Fat	Gat	Ham	Kwaa	Gwong	Tung	Wai	Pik	Ci	Gwai	Ren	Beng	Yong	Gwo	Zip	But	Hung		Zok	Mui	Ham	Juk	Tun	So		Cong	Fu	Zim	Biu	Pai	Tou	Fei	Gam	Gun	Taap		Jip	Do	Kim	Zam	Jyu	Wui	Gaai	Dyun	Seng	Zung	Fuk		Gwang	Se		Haa	Kwai	Zuan	Ngou	Ko	Jip	Aa	Gaam	Taap	Oi	Lim	Tong	Ceoi	Cung	Luk	Lan	Si	Ko	Wai	Zaam	Ding	Zyun		Tin	Cyun	Suk	Jit	La	Gaam	Ou	Seoi	Mit	Leoi		Zyun	Zha	Zim	Leoi	Luo	Maj		Noengq		Raez					Rangh		Ai	Mboek	Maenz			Aq		Rog		Raiq	Gwenj		Hoengq	Fung	Muenz		Zhen	Chin	Gun	Xia	Byoenx	Wai	Peng	Daemz	Mwh	Dou	Ni	Byaengq	Roenx	Saat	Ngaat	Yu	Con	Sonj	Haeu	Henj	Tang	Kap	Gyaeng	Riengh	Pik	Hai";
    case 784:
      return "Suen																	Zat																Fan																						Dat			Roh															Nya									Deoi				Gengz					Doengz			Wan		Byaj			Nae	Mig			Myaex	Soemh						Yaemz		Naj	Yi		Duo	Bat	Bien	Cin	Duk		Gwai	Lau			Laan	Laan		Raem		Rae	Sa	Mui	Bei	Gaap	Hyun	Wan	Ciu	Sip	Duk	Hu	Dui	Haai		Wan																Duo	Ku	Zhuo	Jiu	Fui	Ngaak	Ping	Loi	Aat	Fu		Jim	Kwai	Ceoi	Pi	Seoi	Ham	Ham	Soi	Gao	Gong	Fui	Seon	Zhan	Ban		Piu	Ciu	Beiz									Bongz															Biu	Haa	You	Toi	Lit	Lau	Li	Kutsu	Rui	Haau	Yu	Zaap	Biu			Ngah	Sim			Gueng	Cup	Gyan		Boemz	Go	Lauq	Ciengx	Bwnq	Donq	Xi	Jyu	Bok	Faan	Ying	Caeuz	Ban	Zhi	En	Tim	Iek	Ban	Ak	Bau	Daam";
    case 785:
      return "Fan	Tou	Shu	Gin	Fui	Shu	Ci	Shang	Mung	En	Zaan	Gyaeuj				Rang	Fwngq													Gwih																															Zyu	Tok	Guang	Duk	Bou	Zap	Saap	Geoi	But	Lung	Yaeuh	Can	Bat	Jung	Zi	Ji		Xu	Fu	Tou	Bok		Tei	Bo	Sung	Loi	Hyun	Ngo	Kan	Teoi	Se	To	Jiu	Pin	Haa	Jau	Hon	Gwai	Sing	Tou	Pan	Bo	Wong	Heoi	Bu	Zaap	Tim	Wat	Jin	Aek	Haau			Giz	Gangj	Ndok				Sang									Haan	Haan		Kui	Fei	Laam	Mun		Zuan				Soeng	Chao									Ki			Caau	Kui	Cau		Fangz	Byaiz						Vanx	Dan	Bya	Nouq		Haux		Ndeiq	Fw				Gvi		Lingz					Yaemz																						Ya	Hiuo	Tok	Jyun	Bei	Pei	Wu	Naap	Yu	Baan	Leon	Hong	Sam	Mut	Mei	Keoi	Pei	Sin	Haap	Cau	Sing	Gwan	But	You	Gang	Fu	Ji	Suk	Giu	Lok	Ru	Yi	Loi	Mong	Saau	Ye	Jau	Fu	So	Na	Zik	Luk	Cok	Jing	Zhi	Gwai	Haam	Gau	Guk	Zung	Suk";
    case 786:
      return "Ju	Saan	Jyu	Wei	Hau	Zung	Lou	Gang	Geng	Kin	Lau	Hou	Sau	Joek	Sang	Zuk	Zyun	Fai	Si	Cam	Cen	Faan	Lai	Jyu	Soeng	Mit	Ngok	Meng	Sin				Geuq	Ga	Gumj		Hanq		Gut							Beuj	Linh	Mauh		Gaeq	Raeu		Gaen		Bit	Saeuq																Jyut	Dou		Gon	Han	Ji	Juk	Fu	Tyun	Gwik	Baan	Huan	Wu	Kyut	Go	Pei	Daan	Zeoi	Zi	Tit	Zi	Fu	Gip	Mou	Zaak	Ging	Bin	Jiu	Song	Gui	Gat	Lou	Yuan	Aa	Ji	Ngaai	Zyu	Giu	Gui	Lok	Joeng	Jyu	Kwan	Mau	Maai	Joeng	Loi	Hon	Yi	Tou	Hei	Fu	To	Zik	Gei	Zeon	Zeon	Luk	Kei	Ming	Lei	Jik	Zeoi	Tou	Guk	Jik		Hung	Gin	Geoi	Zyut	Zi	Fuk	Gaai	Ceon	Yuan	Mo	Fuku	Tai	Dat	Jau	Cyun	Zan	Tin	Zeon	Niao	Tong		Hat	Tou	Jiu	Ji	Yan	Jung	Shang	Ji	Kyut	Keoi	Tou	Ling	Jyu	Shu	Jyu	Lo	Gik	Ji	Dik	Bu	Leoi		Joek		Ndaengq			Lu	Lu	Chuai	Huai					Bei			Kiku	Saan	Hat	Kuang		Mut	Heoi	Kiku	Tou	Hua		Kuk			Ge	Bing	Qu	Fu	Fu	Sha	Gwo	Hi		Mo	Bu		Ko	To	Lou	Ciu	Kiku	Bo	Bo	Hi		Sa		Zhi	Kwong	Lian	Rai	Mung	Nyeuq	Ndaij	Fan			Chan		Lou				Nyaengj				Cuk	Heoi";
    case 787:
      return "Yang	Keoi	Duengq	Waa	Zi	Mi	Man	Bit	Ma	Bik	Coeng					Wan			Mup	Gyaen	Ndaeng	Ko	Nung	Cai	Zi	Zi																Hangz	Faenz	Jin	Zaak	Zau	Ceot	Ci	Yao	Sit	Kyun	Wan	Zhai	Zhan	Cuk	Yi	Ji	Jyu	Din		Shi	Jik				Gung	Daap		Ran	Gou	Jiao	Tung	Bit	Sho							Qi				Roengz	Pa	Lamq		Vut			Ao			Fat		Daemq			Gveng			Biengz																								Nanz																											Ndongq				Mbangj			Si																	Ngvangq		Gaenj			Kua						Ge									Ji			Bwnh			An				Lw								Baez	He	He						Hen					Lu													Lao		Byok					Don";
    case 788:
      return "					Baez	Gau									Gu	Beb			Faenz			Danj	Cax		Chan		Tuo						Cax									Maengh						Gyaek															Wai																							Guan				Faeg																																																										Aep	Byouq						Mang											Souh		Ji										Go				Maenj							Boih	Ged				Din	Gap												Cub	Fit													Swnx													Heuj		Ceoi				Ri";
    case 789:
      return "											Ngamj		Dau							Gonh			Dek			Guz									Gvej												Zhan																Cup													Lo																																		Paan		Lei									Bau				Nongz	Baez	Gyok	Hong					Bian		Gan							Ao			Ju	Shan			Zhuai	Tu			Hen				Zai	Zai	Kuang								Chong				Wu		Gong			Tuo		Jian					Cheng					Pai	Zhong			Byoz		Sa	Hun		Niao		Six		Wa		Ge	La		You							Qiu	Zhong				Yong				Ku	Ling			Huang		Gao																					Mwnq			Ruengh";
    case 790:
      return "						Hai			Lian																										Lengq										Nang	Fen				Tuo																						Hei	Nyingz		Lo											Gux						Ndi											Xu														Lan		Me	Nag							Gyax		Iq			Hongj																									Zha									Mao		Soem							Mo		A																Dang					Niao							Lun					Hong	Long	Le			Ngamz																Hao	Hong				Shi													Ye				Duan";
    case 791:
      return "Nang																		Xie				Rongz									Hongx									Rok				Liang											Bonq						Bep						Shua	Sao					Tong																	Gung									Bumz																	Hu	Byaemh									Doeg	Ngeix						Vi				Saej	Gaz		Hua							Vuen							Heiq			Qie	Angq						Gaeg	Ngeix					Veiq			Meu													Nyaek																		Gyoh				Heih				Naemj														Bik	Bej		Gonh					Niu	Chan	Baeb	Mit	Deng													Coux		Wo	Souj";
    case 792:
      return "			Raengq							Doz	Goenq				Kang				Cuengq	Gen	Saq													Sik		Dangh						Dit														Yuan																		Danz																																																																										Sai		Bonz											Huan				Mwh				Dak																	Miz				Caet				Wu		Hui													Rou	Heng			Qi				Saeu	Lung																															Zang		He";
    case 793:
      return "																	Gui						Ge															Luan							Peng			Daet										Beng		Daem								Dingz												Meng				Cangq								Naa	Mwnh	Byoem	Yue			Cien	Ruo													Ya		Byoux					Na												Daej		Dumx			Gui								Inq													Congh																																				Meiq																									Lian																				Myaiz						Mai";
    case 794:
      return "																									Zha																															Kuo										Ying							Wu																																																		Gvaengz		E																																								Roengz		Gyoq							Aeuq			Coq														Xun		Cauq			Hwngq													Byaeu	Fwn																								Douh														Lang";
    case 795:
      return "															Lian									Siu	Feiz												Caemj									Coemh																										Haengj	Gyoih																Vengq									Geuj			Nyaenj					Guj	Yueng				Cae	Weng									Nyaen							Mui																		Sang						Nanh			Fongz	Tan						Laz																		Gang		Mbangj	Cang								Bang																																								Fu";
    case 796:
      return "														Sheng									Che		Byoeng	Byoeng			Sawj							Qin	Lei	Hoenz							Zi	Ling									Ndaek									Fonj													Baeg											Naiq		Xi			Vangh															Nwnj	Yan				Jue														Boek				Naeng			Ce								Ying														Goeb															Bax						Ciem						Ra					Mwq								Baiq			Rez	Yiuq			Chu																		Rox	Zi				Hui							Hen	Dai									Wu";
    case 797:
      return "		La					Cheng									Chang				Fa				Jiang						Hou						Gyu	Sok			En																						Gua		Nyeuq	Shen																																																																																																Gan																		Ranz								Tuo				Ndonj				Bauz																																												Coiz					Naeuz	Giuq										Ciengj";
    case 798:
      return "	Gyok	Ou	Xi				Lao	Seh			Momh			Caj								Yang					Ben	Gan					Hao				Tiao	Lad	Lu																Mog		Bauz	Nu							Qi			Ceh																						Faengx																						Gaeu	Gauj	Swnj										Zi																																												Mian						Hao																																	Gyaeu																									Geq												Zha";
    case 799:
      return "																							Don							Han	Dingh	Laeng																							Zhi																		Miq		Nyaj	Bodai		Bei				Gyau			Dao	Shen				Yak														Bang				Gaeu							Goemz												Jiang				Hua			Guan								Xie			Baez										Gaemz		Zhui									Byaek																								Pu							Bong								Cieg										Biang				Ndwen			Lanh		Ai			Ke								Tang				Wai	Sip						Baenz									Deh";
    case 800:
      return "			Bang	Xu											Gyaeq																Hang						Cang				Denz	Fong					Xie		Vinj												Vuengz		Ngau										Zhen										Biang	Lai						Gox									Mang															Yax			Duenq																	Xia													Zao	Zhuo																																Bengz		Gai					Ying																														Benz				Ruenz	Sat		Ndij												Gvaeg	Saet						Bin";
    case 801:
      return "Mi		Bungz																					Kuai	Vangx		Lao									Ndaij					Qian	Boj																									Rou																	Mbaeu																				Henz		Baih														Daengq														Dam																																	Xi	Fiz		Song		Xun			Ha		Xi			Pin		Rong														Rau							Xi				Luengz		Ciz			Van						Xiu				So		Mid																	Ri";
    case 802:
      return "													Ye									Ga																							Rug															Chu				Co	Luengq		Rox		Tang				Lun																															Kuang								Naiz			Meb	Byot																Rip																			Seuq														Niep						Sin														Chai				Ci				Xing														Pao																																							Mai";
    case 803:
      return "									Ju				Fa				Gangj													Qian			Qiang												Six			Mao		Ndoek																					Yi		Yuan						Xian	Mi							Huan								Laej								Ceiz						Zhun	Fang	Jian	Mi			You						Bao					Zhui	Ye						Chi	Tong		Meng	Mo";
    case 3584:
      return "																																 	!	\"	#	$	%	&	'	(	)	*	+	,	-	.	/	0	1	2	3	4	5	6	7	8	9	:	;	<	=	>	?	@	A	B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	[	\\	]	^	_	`	a	b	c	d	e	f	g	h	i	j	k	l	m	n	o	p	q	r	s	t	u	v	w	x	y	z	{	|	}	~";
  }
  return "";
}

// ../../node_modules/.pnpm/any-ascii@0.3.3/node_modules/any-ascii/any-ascii.js
var blocks = {};
function anyAscii(string) {
  let result = "";
  for (const c of string) {
    const codePoint = c.codePointAt(0);
    if (codePoint <= 127) {
      result += c;
      continue;
    }
    const blockNum = codePoint >>> 8;
    const lo = codePoint & 255;
    let b = blocks[blockNum];
    if (b === void 0) {
      blocks[blockNum] = b = block(blockNum).split("	");
    }
    if (b.length > lo) {
      result += b[lo];
    }
  }
  return result;
}

// src/executors/transcribe.ts
async function runTranscribe(ctx) {
  const { claimed, signal, report } = ctx;
  const job = claimed.job.payload;
  const url = claimed.urls.sourceGet;
  if (!url) throw new Error("No source video URL was provided for this job.");
  const source = join8(mediaCacheDir(), `${job.videoId}.${extOf(claimed.media?.mime)}`);
  await report("Downloading video", 2);
  await downloadTo(url, source, { signal, onProgress: (f) => void report("Downloading video", slice(2, 15, f)) });
  const dir = jobDir(claimed.job.id);
  const wav = join8(dir, "audio.wav");
  try {
    await report("Extracting audio", 16);
    const info = await probe(source);
    if (!info.hasAudio) throw Object.assign(new Error("This video has no audio track to transcribe. Add captions manually or import an SRT."), { code: "NO_AUDIO", retryable: false });
    await extractWav(source, wav, signal);
    await report("Preparing speech model", 22);
    await ensureWhisperBinary();
    await ensureModel(job.model, (f) => void report("Downloading speech model", slice(22, 32, f)), signal);
    await report("Transcribing", 33);
    const { words, language } = await transcribeWav({
      wavPath: wav,
      model: job.model,
      language: job.language,
      signal,
      onProgress: (f) => void report("Transcribing", slice(33, 92, f)),
      normalize: {
        durationMs: info.durationMs || void 0,
        romanize: job.romanize ? (t) => anyAscii(t) : void 0,
        vocabulary: job.prompt ? job.prompt.split(",").map((s) => s.trim()).filter(Boolean) : void 0
      }
    });
    await report("Saving captions", 95);
    await ctx.api.complete(claimed.job.id, {
      kind: "transcribe",
      engine: "whisper_cpp",
      model: job.model,
      language: language || "en",
      durationMs: info.durationMs,
      width: info.width,
      height: info.height,
      words
    });
  } finally {
    rmSync5(dir, { recursive: true, force: true });
  }
}

// src/loop.ts
var sleep3 = (ms) => new Promise((r) => setTimeout(r, ms));
var cmp = (a, b) => a.localeCompare(b, void 0, { numeric: true });
function classify(e) {
  const message = e instanceof Error ? e.message : String(e);
  const code = e?.code;
  if (code === "NO_AUDIO") return { code, retryable: false, message };
  if (code === "ENOSPC" || /no space left/i.test(message)) return { code: "DISK_FULL", retryable: false, message: "Your computer is out of disk space. Free some space and retry." };
  if (/Unsupported|Invalid data found|moov atom not found|could not find codec/i.test(message)) return { code: "BAD_MEDIA", retryable: false, message: `The video could not be read: ${message.slice(0, 300)}` };
  return { code: code && typeof code === "string" ? code : "WORKER_ERROR", retryable: true, message };
}
async function runCompanion(cfg, opts = {}) {
  if (!cfg.token) throw new Error("This computer is not paired yet. Run: capseasy login");
  const api = new CompanionApi(cfg.apiBase, cfg.token);
  let active = null;
  let stopped = false;
  let refuseJobs = false;
  const stop = (why) => {
    if (!stopped) log.error(why);
    stopped = true;
  };
  opts.signal?.addEventListener("abort", () => stopped = true, { once: true });
  const heartbeat = async () => {
    try {
      const hb = await api.heartbeat({ version: VERSION, platform: process.platform, capabilities: await buildCapabilities(), currentJobId: active?.id ?? null });
      if (hb) {
        if (cmp(VERSION, hb.minVersion) < 0) {
          if (!refuseJobs) log.error(`This companion (${VERSION}) is older than the required ${hb.minVersion}. Update it, then restart.`);
          refuseJobs = true;
        }
        if (active && hb.cancelJobIds.includes(active.id)) {
          active.reason = "cancelled";
          active.controller.abort();
        }
      }
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) stop("This computer's access was revoked. Pair it again with: capseasy login");
      else log.warn(`heartbeat failed: ${e instanceof Error ? e.message : e}`);
    }
  };
  const execute = async (claimed) => {
    const a = { id: claimed.job.id, controller: new AbortController(), reason: null };
    active = a;
    let lastSent = 0;
    let lastStage = "Starting";
    let lastPercent = 0;
    const send = async (stage, percent, message) => {
      try {
        const r = await api.progress(claimed.job.id, stage, percent, message);
        if (r?.cancelRequested && !a.reason) {
          a.reason = "cancelled";
          a.controller.abort();
        }
      } catch (e) {
        if (e instanceof ApiError && e.code === "LEASE_LOST" && !a.reason) {
          a.reason = "lease";
          a.controller.abort();
        }
      }
    };
    const ctx = {
      api,
      cfg,
      claimed,
      signal: a.controller.signal,
      report: async (stage, percent, message) => {
        const now = Date.now();
        const changed = stage !== lastStage;
        lastStage = stage;
        lastPercent = percent;
        if (!changed && now - lastSent < 1e3) return;
        lastSent = now;
        await send(stage, percent, message);
      }
    };
    const keepalive = setInterval(() => {
      if (!a.controller.signal.aborted) void send(lastStage, lastPercent);
    }, 2e4);
    log.info(`job ${claimed.job.id.slice(0, 8)} ${claimed.job.kind} started (attempt ${claimed.job.attempts})`);
    try {
      if (claimed.job.kind === "transcribe") await runTranscribe(ctx);
      else if (claimed.job.kind === "render") await runRender(ctx);
      else if (claimed.job.kind === "proxy") await runProxy(ctx);
      else throw Object.assign(new Error(`Unsupported job kind: ${claimed.job.kind}`), { code: "UNSUPPORTED", retryable: false });
      log.info(`job ${claimed.job.id.slice(0, 8)} completed`);
    } catch (e) {
      if (a.reason === "lease") {
        log.warn(`job ${claimed.job.id.slice(0, 8)}: lease lost, dropping work`);
      } else if (a.reason === "cancelled" || a.controller.signal.aborted) {
        log.info(`job ${claimed.job.id.slice(0, 8)} cancelled`);
        await api.fail(claimed.job.id, "CANCELLED", "Cancelled", false).catch(() => void 0);
      } else {
        const c = classify(e);
        log.error(`job ${claimed.job.id.slice(0, 8)} failed: ${c.message}`);
        await api.fail(claimed.job.id, c.code, c.message, c.retryable).catch((err) => log.error(`could not report failure: ${err instanceof Error ? err.message : err}`));
      }
    } finally {
      clearInterval(keepalive);
      active = null;
    }
  };
  log.info(`companion ${VERSION} online (${cfg.apiBase})`);
  await heartbeat();
  const hbTimer = setInterval(() => void heartbeat(), 15e3 + Math.random() * 2e3);
  try {
    while (!stopped) {
      if (!active && !refuseJobs) {
        try {
          const claimed = await api.claim(["transcribe", "render", "proxy"], 2e4);
          if (claimed) {
            await execute(claimed);
            if (opts.once) break;
            continue;
          }
        } catch (e) {
          if (e instanceof ApiError && e.status === 401) stop("This computer's access was revoked. Pair it again with: capseasy login");
          else log.warn(`claim failed: ${e instanceof Error ? e.message : e}`);
        }
      }
      await sleep3(refuseJobs ? 15e3 : 250 + Math.random() * 250);
    }
  } finally {
    clearInterval(hbTimer);
    if (active) {
      active.reason = "cancelled";
      active.controller.abort();
    }
  }
}

// src/cli.ts
var program2 = new Command().name("capseasy").description("CapsEasy Companion: transcribes and renders on your own computer").version(VERSION);
program2.command("login").description("Pair this computer with your CapsEasy account").option("--api <url>", "CapsEasy web app URL").option("--name <name>", "Name shown in the web app").option("--no-open", "Do not open the browser automatically").option("--pair-code <code>", "Pre-approved code from a one-click setup file (no browser step)").action(async (o) => {
  ensureDirs();
  if (o.pairCode) await loginWithPairCode(loadConfig(), { apiBase: o.api, name: o.name, pairCode: o.pairCode });
  else await login(loadConfig(), { apiBase: o.api, name: o.name, open: o.open });
});
program2.command("start").description("Start processing jobs from your CapsEasy projects").option("--once", "Exit after finishing one job").action(async (o) => {
  ensureDirs();
  const ac = new AbortController();
  process.on("SIGINT", () => ac.abort());
  process.on("SIGTERM", () => ac.abort());
  await runCompanion(loadConfig(), { once: o.once, signal: ac.signal });
  process.exit(0);
});
program2.command("check-pairing").description("Exit 0 (and print the computer name) if this computer is still paired with --api; used by the installers").option("--api <url>", "CapsEasy URL").action(async (o) => {
  const cfg = loadConfig();
  const same = !o.api || o.api.replace(/\/$/, "") === cfg.apiBase.replace(/\/$/, "");
  if (!cfg.token || !same) return void (process.exitCode = 1);
  try {
    const hb = await new CompanionApi(cfg.apiBase, cfg.token).heartbeat({ version: VERSION, platform: process.platform, capabilities: await buildCapabilities(), currentJobId: null });
    if (!hb) return void (process.exitCode = 1);
    console.log(cfg.workerName ?? "this computer");
  } catch {
    process.exitCode = 1;
  }
});
program2.command("status").description("Show pairing and machine status").action(async () => {
  const cfg = loadConfig();
  console.log(`API:      ${cfg.apiBase}
Paired:   ${cfg.token ? `yes (${cfg.workerName ?? "unnamed"}, ${cfg.workerId})` : "no. Run: capseasy login"}
Model:    ${cfg.whisperModel}`);
  console.log(JSON.stringify(await buildCapabilities(), null, 2));
});
program2.command("doctor").description("Check that everything needed is in place").action(async () => {
  ensureDirs();
  const cfg = loadConfig();
  const rows = [];
  const add = (name, ok, note) => rows.push([name, ok, note]);
  add("Node.js >= 20", Number(process.versions.node.split(".")[0]) >= 20, process.versions.node);
  const caps = await buildCapabilities();
  add("ffmpeg (bundled)", Boolean(caps.ffmpeg), caps.ffmpeg ? "ok" : "missing: reinstall the companion");
  const free = diskFreeGb();
  add("Disk space >= 5 GB free", (free ?? 0) >= 5, `${free ?? "?"} GB free`);
  add("RAM >= 8 GB", (caps.ramGb ?? 0) >= 8, `${caps.ramGb} GB`);
  try {
    await ensureBrowser2();
    add("Chrome (renderer)", true, "ready");
  } catch (e) {
    add("Chrome (renderer)", false, e instanceof Error ? e.message : String(e));
  }
  add("Speech model installed", installedModels().length > 0, installedModels().join(", ") || "none yet (downloaded on first job, or run: capseasy models install small)");
  try {
    const r = await fetch(`${cfg.apiBase}/health`);
    add("CapsEasy reachable", r.ok, `${cfg.apiBase} (${r.status})`);
  } catch (e) {
    add("CapsEasy reachable", false, `${cfg.apiBase}: ${e instanceof Error ? e.message : e}`);
  }
  if (cfg.token) {
    try {
      const hb = await new CompanionApi(cfg.apiBase, cfg.token).heartbeat({ version: VERSION, platform: process.platform, capabilities: caps, currentJobId: null });
      add("Paired & authorised", Boolean(hb), hb ? `worker ${hb.workerId}` : "no response");
    } catch (e) {
      add("Paired & authorised", false, e instanceof Error ? e.message : String(e));
    }
  } else add("Paired & authorised", false, "run: capseasy login");
  for (const [name, ok, note] of rows) console.log(`${ok ? "\u2714" : "\u2718"} ${name.padEnd(26)} ${note}`);
  process.exitCode = rows.every((r) => r[1]) ? 0 : 1;
});
program2.command("autostart <action>").description("enable | disable | status: start the Companion automatically when you log in").action((action) => {
  ensureDirs();
  if (action === "enable") {
    const r = enableAutostart(dirs.logs);
    console.log(`Autostart enabled (${r.path}). ${r.note}`);
  } else if (action === "disable") {
    console.log(disableAutostart() ? "Autostart disabled." : "Autostart was not enabled.");
  } else if (action === "status") {
    console.log(autostartEnabled() ? `Enabled (${autostartPath()})` : "Disabled");
  } else {
    throw new Error("Use: capseasy autostart enable | disable | status");
  }
});
var models = program2.command("models").description("Manage local speech models");
models.command("list").action(() => {
  const have = new Set(installedModels());
  for (const m of WHISPER_MODELS) console.log(`${have.has(m) ? "\u25CF" : "\u25CB"} ${m}`);
});
models.command("install <model>").action(async (model) => {
  if (!WHISPER_MODELS.includes(model)) throw new Error(`Unknown model "${model}". Try: ${WHISPER_MODELS.join(", ")}`);
  ensureDirs();
  await ensureWhisperBinary();
  let last = -1;
  await ensureModel(model, (f) => {
    const pct = Math.floor(f * 10) * 10;
    if (pct !== last) console.log(`  ${pct}%`), last = pct;
  });
  console.log(`Installed ${model}`);
  const cfg = loadConfig();
  saveConfig({ ...cfg, whisperModel: model });
});
program2.command("logout").description("Forget the pairing on this computer (also revoke it in the web app)").action(() => {
  const cfg = loadConfig();
  saveConfig({ ...cfg, token: void 0, workerId: void 0 });
  rmSync6(join9(dirs.cache, "jobs"), { recursive: true, force: true });
  console.log("Signed out.");
});
program2.parseAsync().catch((e) => {
  console.error(`
Error: ${e instanceof Error ? e.message : e}`);
  process.exit(1);
});
